"""Shell policy is explicit; process lifecycle belongs to the injected service."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import time
from typing import Literal

from cogit_tool_core import Model, Tool, ToolError, ToolLike
from cogit_tool_execution import (
    InputRequest,
    PollRequest,
    ProcessOutput,
    ProcessService,
    StartRequest,
    StopRequest,
)
from pydantic import Field

ShellKind = Literal["powershell", "bash", "cmd"]
_PARSER_SECONDS = 30.0
_HEADER_HINT = re.compile(r"\b(?:using|param)\b", re.IGNORECASE)
_UTF8 = (
    "[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false); "
    "[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); "
    "$OutputEncoding = [Console]::OutputEncoding; "
)
_PARSE_HEADERS = _UTF8 + (
    "$source = [Console]::In.ReadToEnd(); $tokens = $null; $errors = $null; "
    "$ast = [System.Management.Automation.Language.Parser]::ParseInput("
    "$source, [ref]$tokens, [ref]$errors); $end = 0; "
    "foreach ($item in $ast.UsingStatements) { "
    "$end = [Math]::Max($end, $item.Extent.EndOffset) }; "
    "if ($null -ne $ast.ParamBlock) { "
    "$end = [Math]::Max($end, $ast.ParamBlock.Extent.EndOffset) }; "
    "@{header_end_utf16=$end; parse_failed=($null -ne $errors -and $errors.Count -gt 0)} "
    "| ConvertTo-Json -Compress"
)


class _HeaderResult(Model):
    header_end_utf16: int = Field(ge=0, le=131072)
    parse_failed: bool


class ShellRequest(Model):
    command: str = Field(min_length=1, max_length=65536)
    cwd: str = "."
    wait_ms: int = Field(default=1000, ge=0, le=10000)
    max_runtime_seconds: float = Field(default=600.0, ge=0.1, le=3600.0)


class ShellService:
    def __init__(
        self,
        processes: ProcessService,
        *,
        kind: ShellKind | None = None,
        executable: str | None = None,
    ) -> None:
        self.processes = processes
        self.kind = kind or ("powershell" if os.name == "nt" else "bash")
        default = "pwsh" if self.kind == "powershell" else self.kind
        found = executable or shutil.which(default)
        if not found and self.kind == "powershell":
            found = shutil.which("powershell")
        if not found:
            raise ToolError("shell_unavailable", f"Shell executable unavailable: {default}")
        self.executable = found
        self._closed = False

    def run(self, request: ShellRequest) -> ProcessOutput:
        if self._closed:
            raise ToolError("service_closed", "Shell service is closed")
        if self.kind == "powershell":
            command = self._powershell_command(request)
            args = ["-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command]
        elif self.kind == "bash":
            args = ["--noprofile", "--norc", "-c", request.command]
        else:
            args = ["/D", "/S", "/C", request.command]
        if self._closed:
            raise ToolError("service_closed", "Shell service closed during preparation")
        return self.processes.start(
            StartRequest(
                argv=[self.executable, *args],
                cwd=request.cwd,
                wait_ms=request.wait_ms,
                max_runtime_seconds=request.max_runtime_seconds,
            )
        )

    def _guard_powershell_args(self, command: str) -> None:
        argv = [self.executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command]
        try:
            units = len(subprocess.list2cmdline(argv).encode("utf-16-le")) // 2 + 1
        except UnicodeEncodeError:
            raise ToolError("invalid_command", "PowerShell source must be valid Unicode") from None
        if sum(map(len, argv)) > 65536 or (os.name == "nt" and units > 32767):
            raise ToolError(
                "command_too_large", "PowerShell command exceeds the process argument limit"
            )

    def _powershell_command(self, request: ShellRequest) -> str:
        if "\x00" in request.command:
            raise ToolError("invalid_command", "PowerShell source may not contain NUL characters")
        self._guard_powershell_args(_UTF8 + "\n" + request.command)
        encoded = request.command.encode("utf-16-le")
        end = self._header_end(request) if _HEADER_HINT.search(request.command) else 0
        if end > len(encoded) // 2:
            raise ToolError("shell_parse_failed", "PowerShell header offset exceeds source")
        try:
            prefix, suffix = (
                encoded[: end * 2].decode("utf-16-le"),
                encoded[end * 2 :].decode("utf-16-le"),
            )
        except UnicodeDecodeError:
            raise ToolError("shell_parse_failed", "PowerShell header offset is invalid") from None
        # Keep the original top-level -Command program. An invoked ScriptBlock
        # changes return/native-failure status. A semicolon after an actual
        # header preserves inline comments; a leading newline preserves #requires.
        command = prefix + ";" + _UTF8 + suffix if end else _UTF8 + "\n" + suffix
        self._guard_powershell_args(command)
        return command

    def _header_end(self, request: ShellRequest) -> int:
        # Only parse user text. Do not compile or invoke its ScriptBlock. Use a
        # separate owned stdin pipe so main-command stdin remains available.
        self._guard_powershell_args(_PARSE_HEADERS)
        result = self.processes.start(
            StartRequest(
                argv=[
                    self.executable,
                    "-NoLogo",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    _PARSE_HEADERS,
                ],
                cwd=request.cwd,
                wait_ms=0,
                max_runtime_seconds=max(0.1, _PARSER_SECONDS),
            )
        )
        process_id = result.process_id
        output = result.output
        deadline = time.monotonic() + _PARSER_SECONDS
        try:
            result = self.processes.input(
                InputRequest(
                    process_id=process_id,
                    cursor=result.cursor,
                    text=request.command,
                    eof=True,
                    wait_ms=0,
                )
            )
            output += result.output
            while result.status == "running" and time.monotonic() < deadline:
                result = self.processes.poll(
                    PollRequest(
                        process_id=process_id,
                        cursor=result.cursor,
                        wait_ms=100,
                        max_chars=2048,
                    )
                )
                output += result.output
                if len(output) > 2048:
                    raise ToolError(
                        "shell_parse_failed", "PowerShell parser output exceeded its bound"
                    )
            if result.status != "exited":
                raise ToolError(
                    "shell_parse_timeout", "PowerShell header parsing exceeded its bound"
                )
            if result.exit_code != 0 or len(output) > 2048:
                raise ToolError("shell_parse_failed", "PowerShell header parsing failed")
            try:
                parsed = _HeaderResult.model_validate_json(output)
            except ValueError:
                raise ToolError(
                    "shell_parse_failed", "PowerShell parser returned an invalid result"
                ) from None
            if parsed.parse_failed:
                raise ToolError("shell_parse_failed", "PowerShell source could not be parsed")
            return parsed.header_end_utf16
        finally:
            self.processes.stop(StopRequest(process_id=process_id))

    def tools(self) -> tuple[ToolLike, ...]:
        return (
            Tool(
                "shell_run",
                f"Run a {self.kind} command in the workspace with a minimal environment. "
                "Returns persistent process ID; poll/input/stop use process tools. "
                "Trusted local execution under OS permissions; not sandboxed.",
                ShellRequest,
                ProcessOutput,
                self.run,
            ),
        )

    def close(self) -> None:
        self._closed = True
