"""Action binding pairs an operation with exposure metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic

from cogit_agent_sdk.operations.contract import InputT, OperationContract, OutputT
from cogit_agent_sdk.operations.schema_parity import assert_descriptor_schemas_match_operation
from cogit_agent_sdk.types import ActionDescriptor


@dataclass(frozen=True)
class ActionBinding(Generic[InputT, OutputT]):
    """Pairs one operation with one action descriptor."""

    operation: OperationContract[InputT, OutputT]
    descriptor: ActionDescriptor

    def __post_init__(self) -> None:
        assert_descriptor_schemas_match_operation(
            self.operation,
            self.descriptor,
            name=self.descriptor.name,
        )
