"""Action and tool binding registration and class-level collection."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from cogit_agent_sdk.operations.action_binding import ActionBinding
from cogit_agent_sdk.operations.errors import ActionRegistrationError, ToolRegistrationError
from cogit_agent_sdk.operations.schema_parity import assert_descriptor_schemas_match_operation
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.types.actions import canonicalize_action_descriptor
from cogit_agent_sdk.types.tools import canonicalize_tool_descriptor


class DuplicateActionError(ActionRegistrationError):
    """Raised when an action name is registered more than once."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Action {name!r} is already registered")


class DuplicateToolError(ToolRegistrationError):
    """Raised when a tool name is registered more than once."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Tool {name!r} is already registered")


class RegistrationFrozenError(ActionRegistrationError, ToolRegistrationError):
    """Raised when registration is attempted after freeze."""

    def __init__(self, name: str, *, kind: str = "Action") -> None:
        self.name = name
        self.kind = kind
        super().__init__(
            f"{kind} registration is frozen; cannot register {name!r}",
        )


class ActionBindingRegistry:
    """Mutable registry that becomes immutable after freeze."""

    def __init__(self, initial: Sequence[ActionBinding[Any, Any]] | None = None) -> None:
        self._bindings: dict[str, ActionBinding[Any, Any]] = {}
        self._frozen = False
        for binding in initial or ():
            self.register(binding)

    @property
    def frozen(self) -> bool:
        return self._frozen

    def register(self, binding: ActionBinding[Any, Any]) -> None:
        name = binding.descriptor.name
        if self._frozen:
            raise RegistrationFrozenError(name, kind="Action")
        if name in self._bindings:
            raise DuplicateActionError(name)
        assert_descriptor_schemas_match_operation(
            binding.operation,
            binding.descriptor,
            name=name,
        )
        canonical_descriptor = canonicalize_action_descriptor(binding.descriptor)
        self._bindings[name] = ActionBinding(
            operation=binding.operation,
            descriptor=canonical_descriptor,
        )

    def freeze(self) -> None:
        self._frozen = True

    def list_bindings(self) -> tuple[ActionBinding[Any, Any], ...]:
        return tuple(sorted(self._bindings.values(), key=lambda item: item.descriptor.name))


class ToolBindingRegistry:
    """Mutable tool registry that becomes immutable after freeze."""

    def __init__(self, initial: Sequence[ToolBinding[Any, Any]] | None = None) -> None:
        self._bindings: dict[str, ToolBinding[Any, Any]] = {}
        self._frozen = False
        for binding in initial or ():
            self.register(binding)

    @property
    def frozen(self) -> bool:
        return self._frozen

    def register(self, binding: ToolBinding[Any, Any]) -> None:
        name = binding.descriptor.name
        if self._frozen:
            raise RegistrationFrozenError(name, kind="Tool")
        if name in self._bindings:
            raise DuplicateToolError(name)
        assert_descriptor_schemas_match_operation(
            binding.operation,
            binding.descriptor,
            name=name,
        )
        canonical_descriptor = canonicalize_tool_descriptor(binding.descriptor)
        self._bindings[name] = ToolBinding(
            operation=binding.operation,
            descriptor=canonical_descriptor,
            prepare_arguments=binding.prepare_arguments,
        )

    def freeze(self) -> None:
        self._frozen = True

    def list_bindings(self) -> tuple[ToolBinding[Any, Any], ...]:
        return tuple(sorted(self._bindings.values(), key=lambda item: item.descriptor.name))


def collect_class_bindings(cls: type) -> tuple[ActionBinding[Any, Any], ...]:
    """Collect inherited and declared :class:`ActionBinding` values in MRO order."""

    by_name: dict[str, ActionBinding[Any, Any]] = {}
    for klass in reversed(cls.__mro__):
        if klass is object:
            continue
        for value in klass.__dict__.values():
            if not isinstance(value, ActionBinding):
                continue
            name = value.descriptor.name
            if name in by_name and by_name[name] is not value:
                raise DuplicateActionError(name)
            by_name[name] = value
    return tuple(sorted(by_name.values(), key=lambda item: item.descriptor.name))


def collect_class_tool_bindings(cls: type) -> tuple[ToolBinding[Any, Any], ...]:
    """Collect inherited and declared :class:`ToolBinding` values in MRO order."""

    by_name: dict[str, ToolBinding[Any, Any]] = {}
    for klass in reversed(cls.__mro__):
        if klass is object:
            continue
        for value in klass.__dict__.values():
            if not isinstance(value, ToolBinding):
                continue
            name = value.descriptor.name
            if name in by_name and by_name[name] is not value:
                raise DuplicateToolError(name)
            by_name[name] = value
    return tuple(sorted(by_name.values(), key=lambda item: item.descriptor.name))
