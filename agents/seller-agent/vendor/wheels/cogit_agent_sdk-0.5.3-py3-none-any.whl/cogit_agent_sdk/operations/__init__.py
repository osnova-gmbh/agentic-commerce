"""Operation contracts, bindings, and registration (Proposal 014/019)."""

from cogit_agent_sdk.operations.action_binding import ActionBinding
from cogit_agent_sdk.operations.action_contract import (
    ACTION_CONTRACT_SCHEMA_VERSION,
    ActionContractExportError,
    action_descriptors_from_bindings,
    export_action_contract,
    export_action_contract_json,
    parse_action_contract,
    write_action_contract_artifact,
)
from cogit_agent_sdk.operations.binding import (
    bind_action,
    bind_tool,
    bind_tool_from_action,
    operation,
)
from cogit_agent_sdk.operations.contract import (
    OperationContract,
    OperationError,
    OperationInvocation,
)
from cogit_agent_sdk.operations.errors import (
    ActionRegistrationError,
    SchemaMismatchError,
    ToolRegistrationError,
)
from cogit_agent_sdk.operations.registry import (
    DuplicateActionError,
    DuplicateToolError,
    RegistrationFrozenError,
    collect_class_bindings,
    collect_class_tool_bindings,
)
from cogit_agent_sdk.operations.requirements import OperationRequirements
from cogit_agent_sdk.operations.schema import derive_model_schema
from cogit_agent_sdk.operations.tool_binding import ToolBinding

__all__ = [
    "ACTION_CONTRACT_SCHEMA_VERSION",
    "ActionBinding",
    "ActionContractExportError",
    "ActionRegistrationError",
    "DuplicateActionError",
    "DuplicateToolError",
    "OperationContract",
    "OperationError",
    "OperationInvocation",
    "OperationRequirements",
    "RegistrationFrozenError",
    "SchemaMismatchError",
    "ToolBinding",
    "ToolRegistrationError",
    "action_descriptors_from_bindings",
    "bind_action",
    "bind_tool",
    "bind_tool_from_action",
    "collect_class_bindings",
    "collect_class_tool_bindings",
    "derive_model_schema",
    "export_action_contract",
    "export_action_contract_json",
    "operation",
    "parse_action_contract",
    "write_action_contract_artifact",
]
