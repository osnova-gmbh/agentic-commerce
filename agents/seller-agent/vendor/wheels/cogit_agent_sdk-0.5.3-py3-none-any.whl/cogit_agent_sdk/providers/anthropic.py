"""Anthropic provider adapter for the SDK model-client contract."""

from __future__ import annotations

import json
from collections.abc import Iterable
from importlib import import_module
from typing import Any

from cogit_agent_sdk.coordination import raise_coordination_failure
from cogit_agent_sdk.types import (
    AssistantMessage,
    Cancellation,
    ContentBlock,
    Diagnostic,
    FileRefContent,
    Message,
    ModelClient,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
    StructuredContent,
    TextContent,
    ThinkingContent,
    ToolCall,
    ToolResultMessage,
    Usage,
)


class AnthropicModelClient(ModelClient):
    """ModelClient implementation backed by Anthropic's Messages API."""

    def __init__(
        self,
        api_key: str | None = None,
        client: Any | None = None,
        default_model: str | None = None,
    ) -> None:
        resolved_client = client
        if resolved_client is None:
            try:
                anthropic_module = import_module("anthropic")
            except ImportError as exc:  # pragma: no cover - exercised by optional extra users.
                raise RuntimeError(
                    "Install cogit-agent-sdk[anthropic] to use AnthropicModelClient"
                ) from exc
            import os

            timeout = float(os.getenv("ANTHROPIC_TIMEOUT_SECONDS", "600"))
            resolved_client = anthropic_module.Anthropic(
                api_key=api_key,
                timeout=timeout,
            )

        self._client = resolved_client
        self._default_model = default_model

    def generate(self, request: ModelRequest, cancellation: Cancellation) -> ModelResponse:
        cancellation.throw_if_cancelled()
        kwargs: dict[str, Any] = {
            "model": self._model_name(request),
            "max_tokens": request.max_output_tokens or self._model_max_tokens(request),
            "system": request.system or self._system_from_messages(request.messages),
            "messages": self._messages(request.messages),
        }
        if request.temperature is not None:
            kwargs["temperature"] = request.temperature
        tools = self._tools(request)
        if tools:
            kwargs["tools"] = tools
            tool_choice = self._tool_choice(request)
            if tool_choice is not None:
                kwargs["tool_choice"] = tool_choice
        messages_api = self._messages_api(cancellation)
        stream_method = getattr(messages_api, "stream", None)
        if callable(stream_method):
            # Stream internally so long tool-call generations are not killed by
            # idle HTTP timeouts on a single non-streaming response. Iterating
            # events also gives cooperative cancellation a chance between SSE
            # messages before the final response is assembled.
            stream_context: Any = stream_method(**kwargs)
            with stream_context as stream:
                if hasattr(stream, "__iter__"):
                    for _event in stream:
                        cancellation.throw_if_cancelled()
                response = stream.get_final_message()
        else:
            # Preserve compatibility with Messages-compatible gateways and
            # injected test clients that implement create() but not stream().
            response = messages_api.create(**kwargs)
        cancellation.throw_if_cancelled()
        return self._response(response)

    def stream(
        self,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> Iterable[ModelStreamEvent]:
        """Stream normalized deltas from Anthropic's raw SSE events.

        Ordinary provider failures and cancellations terminate with a single
        `error` event carrying the
        partial message assembled so far. Gateways that ignore `stream=True`
        and return a complete message fall back to one `message_completed`.
        Host CoordinationFailure exceptions propagate for reconciliation.
        """

        accumulator = _StreamAccumulator()
        sequence = 0

        def next_sequence() -> int:
            nonlocal sequence
            sequence += 1
            return sequence

        try:
            cancellation.throw_if_cancelled()
            raw = self._messages_api(cancellation).create(
                model=self._model_name(request),
                max_tokens=request.max_output_tokens or self._model_max_tokens(request),
                temperature=request.temperature,
                system=request.system or self._system_from_messages(request.messages),
                tools=self._tools(request),
                tool_choice=self._tool_choice(request),
                messages=self._messages(request.messages),
                stream=True,
            )

            if hasattr(raw, "content"):
                response = self._response(raw)
                yield ModelStreamEvent(
                    type="message_completed",
                    sequence=next_sequence(),
                    message=response.message,
                    usage=response.usage,
                    stop_reason=response.stop_reason,
                    diagnostics=response.diagnostics,
                )
                return

            for event in raw:
                if cancellation.cancelled:
                    yield accumulator.error_event(next_sequence(), "aborted", "Run was cancelled")
                    return
                for normalized in accumulator.consume(event):
                    normalized.sequence = next_sequence()
                    yield normalized
        except Exception as exc:
            raise_coordination_failure(exc)
            reason = "aborted" if cancellation.cancelled else "error"
            yield accumulator.error_event(
                next_sequence(),
                reason,
                f"Provider stream failed ({type(exc).__name__})",
            )
            return

    def _messages_api(self, cancellation: Cancellation) -> Any:
        """Bind the provider transport timeout to the remaining run deadline."""

        client: Any = self._client
        remaining = getattr(cancellation, "remaining_seconds", None)
        with_options = getattr(client, "with_options", None)
        if isinstance(remaining, int | float) and callable(with_options):
            cancellation.throw_if_cancelled()
            client = with_options(timeout=max(0.001, float(remaining)))
        return client.messages

    def _model_name(self, request: ModelRequest) -> str:
        if request.model is not None:
            return request.model.model
        if self._default_model is not None:
            return self._default_model
        raise ValueError("Anthropic model must be supplied in request.model or default_model")

    @staticmethod
    def _model_max_tokens(request: ModelRequest) -> int:
        if request.model is not None and request.model.max_output_tokens is not None:
            return request.model.max_output_tokens
        return 4096

    @staticmethod
    def _tools(request: ModelRequest) -> list[dict[str, Any]] | None:
        if not request.tools:
            return None
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.input_schema,
            }
            for tool in request.tools
        ]

    @staticmethod
    def _tool_choice(request: ModelRequest) -> dict[str, str] | None:
        # Anthropic Messages API requires tool_choice to be an object when set.
        # Omit it entirely when there are no tools.
        if not request.tools:
            return None
        if request.tool_choice == "none":
            return {"type": "none"}
        if request.tool_choice in {None, "auto"}:
            return {"type": "auto"}
        return {"type": "any"}

    @classmethod
    def _messages(
        cls,
        messages: list[Message | AssistantMessage | ToolResultMessage],
    ) -> list[dict[str, Any]]:
        converted: list[dict[str, Any]] = []
        for message in messages:
            if isinstance(message, ToolResultMessage):
                tool_text = cls._content_to_text(message.content)
                if not tool_text.strip():
                    tool_text = "{}"
                converted.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": message.tool_call_id,
                                "content": tool_text,
                                "is_error": message.is_error,
                            }
                        ],
                    }
                )
                continue
            if message.role == "system":
                continue
            converted.append(
                {
                    "role": "assistant" if isinstance(message, AssistantMessage) else "user",
                    "content": cls._content_blocks(message),
                }
            )
        return converted

    @classmethod
    def _content_blocks(cls, message: Message | AssistantMessage) -> list[dict[str, Any]]:
        blocks: list[dict[str, Any]] = []
        for block in message.content:
            converted = cls._content_block(block)
            if converted.get("type") == "text" and not str(converted.get("text") or "").strip():
                continue
            blocks.append(converted)
        if isinstance(message, AssistantMessage):
            blocks.extend(
                {
                    "type": "tool_use",
                    "id": tool_call.id,
                    "name": tool_call.tool_name,
                    "input": tool_call.arguments,
                }
                for tool_call in message.tool_calls or []
            )
        if not blocks:
            blocks = [{"type": "text", "text": "(empty)"}]
        return blocks

    @staticmethod
    def _content_block(block: ContentBlock) -> dict[str, Any]:
        if isinstance(block, TextContent):
            return {"type": "text", "text": block.text}
        if isinstance(block, ThinkingContent):
            return {"type": "text", "text": block.text}
        if isinstance(block, StructuredContent):
            return {"type": "text", "text": json.dumps(block.data, ensure_ascii=False)}
        if isinstance(block, FileRefContent):
            return {"type": "text", "text": block.uri}
        return {
            "type": "image",
            "source": {
                "type": "url",
                "url": block.source,
            },
        }

    @staticmethod
    def _content_to_text(content: list[ContentBlock]) -> str:
        values: list[str] = []
        for block in content:
            if isinstance(block, TextContent | ThinkingContent):
                values.append(block.text)
            elif isinstance(block, StructuredContent):
                values.append(json.dumps(block.data, ensure_ascii=False))
            elif isinstance(block, FileRefContent):
                values.append(block.uri)
            else:
                values.append(block.source)
        return "\n".join(values)

    @staticmethod
    def _system_from_messages(
        messages: list[Message | AssistantMessage | ToolResultMessage],
    ) -> str | None:
        system_parts: list[str] = []
        for message in messages:
            if isinstance(message, Message) and message.role == "system":
                system_parts.extend(
                    block.text
                    for block in message.content
                    if isinstance(block, TextContent | ThinkingContent)
                )
        if not system_parts:
            return None
        return "\n".join(system_parts)

    @classmethod
    def _response(cls, response: Any) -> ModelResponse:
        content: list[ContentBlock] = []
        tool_calls: list[ToolCall] = []
        diagnostics: list[Diagnostic] = []

        for block in getattr(response, "content", []):
            block_type = _get(block, "type")
            if block_type == "text":
                content.append(TextContent(text=str(_get(block, "text") or "")))
            elif block_type == "thinking":
                content.append(ThinkingContent(text=str(_get(block, "thinking") or "")))
            elif block_type == "tool_use":
                tool_calls.append(
                    ToolCall(
                        id=str(_get(block, "id")),
                        tool_name=str(_get(block, "name")),
                        arguments=dict(_get(block, "input") or {}),
                    )
                )
            else:
                diagnostics.append(
                    Diagnostic(
                        level="warning",
                        message=f"Unsupported Anthropic content block: {block_type}",
                        source="anthropic",
                    )
                )

        usage = cls._usage(getattr(response, "usage", None))
        stop_reason = getattr(response, "stop_reason", None)
        model = getattr(response, "model", None)
        assistant = AssistantMessage(
            content=content,
            model=str(model) if model is not None else None,
            provider="anthropic",
            usage=usage,
            stop_reason=str(stop_reason) if stop_reason is not None else None,
            tool_calls=tool_calls or None,
            diagnostics=diagnostics or None,
        )
        return ModelResponse(
            message=assistant,
            usage=usage,
            stop_reason=assistant.stop_reason,
            provider_response_id=str(getattr(response, "id", "")) or None,
            diagnostics=diagnostics or None,
        )

    @staticmethod
    def _usage(raw_usage: Any) -> Usage | None:
        if raw_usage is None:
            return None
        return Usage(
            input_tokens=int(getattr(raw_usage, "input_tokens", 0) or 0),
            output_tokens=int(getattr(raw_usage, "output_tokens", 0) or 0),
            cache_read_tokens=int(getattr(raw_usage, "cache_read_input_tokens", 0) or 0),
            cache_write_tokens=int(getattr(raw_usage, "cache_creation_input_tokens", 0) or 0),
            provider="anthropic",
        )


def _get(value: Any, key: str) -> Any:
    if isinstance(value, dict):
        return value.get(key)
    return getattr(value, key, None)


class _StreamBlock:
    """Mutable per-content-block accumulation state during streaming."""

    def __init__(self, kind: str) -> None:
        self.kind = kind
        self.text = ""
        self.tool_id = ""
        self.tool_name = ""
        self.partial_json = ""


class _StreamAccumulator:
    """Normalizes raw Anthropic stream events into SDK ModelStreamEvents.

    Follows the pi-ai accumulation rules: usage is seeded at `message_start`
    (so aborted streams still carry input tokens), `message_delta` only
    overwrites non-null fields, and partial tool JSON is accumulated per
    block and parsed on completion.
    """

    def __init__(self) -> None:
        self._blocks: dict[int, _StreamBlock] = {}
        self._usage: Usage | None = None
        self._stop_reason: str | None = None
        self._model: str | None = None
        self._response_id: str | None = None
        self._diagnostics: list[Diagnostic] = []

    def consume(self, event: Any) -> list[ModelStreamEvent]:
        event_type = _get(event, "type")
        if event_type == "message_start":
            return self._on_message_start(event)
        if event_type == "content_block_start":
            return self._on_block_start(event)
        if event_type == "content_block_delta":
            return self._on_block_delta(event)
        if event_type == "content_block_stop":
            return self._on_block_stop(event)
        if event_type == "message_delta":
            return self._on_message_delta(event)
        if event_type == "message_stop":
            return [self._completed_event()]
        return []

    def _on_message_start(self, event: Any) -> list[ModelStreamEvent]:
        message = _get(event, "message")
        self._response_id = _get(message, "id")
        model = _get(message, "model")
        self._model = str(model) if model is not None else None
        self._usage = _merge_usage(self._usage, _get(message, "usage"))
        return [
            ModelStreamEvent(
                type="message_started",
                usage=self._usage,
                metadata={"responseId": self._response_id, "model": self._model},
            )
        ]

    def _on_block_start(self, event: Any) -> list[ModelStreamEvent]:
        index = int(_get(event, "index") or 0)
        raw_block = _get(event, "content_block")
        kind = str(_get(raw_block, "type") or "text")
        block = _StreamBlock(kind)
        if kind == "tool_use":
            block.tool_id = str(_get(raw_block, "id") or "")
            block.tool_name = str(_get(raw_block, "name") or "")
            self._blocks[index] = block
            return [
                ModelStreamEvent(
                    type="tool_call_started",
                    tool_call_id=block.tool_id,
                    tool_name=block.tool_name,
                )
            ]
        if kind == "redacted_thinking":
            block.kind = "thinking"
            block.text = "[Reasoning redacted]"
        self._blocks[index] = block
        return []

    def _on_block_delta(self, event: Any) -> list[ModelStreamEvent]:
        index = int(_get(event, "index") or 0)
        block = self._blocks.setdefault(index, _StreamBlock("text"))
        delta = _get(event, "delta")
        delta_type = _get(delta, "type")

        if delta_type == "text_delta":
            chunk = str(_get(delta, "text") or "")
            block.text += chunk
            return [ModelStreamEvent(type="message_delta", delta=chunk)]
        if delta_type == "thinking_delta":
            chunk = str(_get(delta, "thinking") or "")
            block.text += chunk
            return [
                ModelStreamEvent(
                    type="message_delta",
                    delta=chunk,
                    metadata={"channel": "thinking"},
                )
            ]
        if delta_type == "input_json_delta":
            chunk = str(_get(delta, "partial_json") or "")
            block.partial_json += chunk
            return [
                ModelStreamEvent(
                    type="tool_call_delta",
                    tool_call_id=block.tool_id,
                    tool_name=block.tool_name,
                    tool_arguments_delta={"partialJson": chunk},
                )
            ]
        # signature_delta and unknown delta kinds accumulate silently.
        return []

    def _on_block_stop(self, event: Any) -> list[ModelStreamEvent]:
        index = int(_get(event, "index") or 0)
        block = self._blocks.get(index)
        if block is None or block.kind != "tool_use":
            return []
        return [
            ModelStreamEvent(
                type="tool_call_completed",
                tool_call_id=block.tool_id,
                tool_name=block.tool_name,
            )
        ]

    def _on_message_delta(self, event: Any) -> list[ModelStreamEvent]:
        delta = _get(event, "delta")
        stop_reason = _get(delta, "stop_reason")
        if stop_reason is not None:
            self._stop_reason = str(stop_reason)
        self._usage = _merge_usage(self._usage, _get(event, "usage"))
        return [
            ModelStreamEvent(
                type="usage_delta",
                usage=self._usage,
                stop_reason=self._stop_reason,
            )
        ]

    def _completed_event(self) -> ModelStreamEvent:
        message = self._assemble_message(self._stop_reason)
        return ModelStreamEvent(
            type="message_completed",
            message=message,
            usage=self._usage,
            stop_reason=self._stop_reason,
            diagnostics=self._diagnostics or None,
        )

    def error_event(self, sequence: int, reason: str, message: str) -> ModelStreamEvent:
        self._diagnostics.append(Diagnostic(level="error", message=message, source="anthropic"))
        partial = self._assemble_message(reason)
        return ModelStreamEvent(
            type="error",
            sequence=sequence,
            message=partial,
            usage=self._usage,
            stop_reason=reason,
            diagnostics=list(self._diagnostics),
        )

    def _assemble_message(self, stop_reason: str | None) -> AssistantMessage:
        content: list[ContentBlock] = []
        tool_calls: list[ToolCall] = []
        for index in sorted(self._blocks):
            block = self._blocks[index]
            if block.kind == "text":
                content.append(TextContent(text=block.text))
            elif block.kind == "thinking":
                content.append(ThinkingContent(text=block.text))
            elif block.kind == "tool_use":
                tool_calls.append(
                    ToolCall(
                        id=block.tool_id,
                        tool_name=block.tool_name,
                        arguments=self._parse_arguments(block),
                    )
                )
        return AssistantMessage(
            content=content,
            model=self._model,
            provider="anthropic",
            usage=self._usage,
            stop_reason=stop_reason,
            tool_calls=tool_calls or None,
            diagnostics=self._diagnostics or None,
        )

    def _parse_arguments(self, block: _StreamBlock) -> dict[str, Any]:
        if not block.partial_json:
            return {}
        try:
            parsed = json.loads(block.partial_json)
        except ValueError:
            self._diagnostics.append(
                Diagnostic(
                    level="warning",
                    message=f"Tool call {block.tool_name} arguments were incomplete JSON",
                    source="anthropic",
                )
            )
            return {}
        return dict(parsed) if isinstance(parsed, dict) else {}


def _merge_usage(current: Usage | None, raw_usage: Any) -> Usage | None:
    """Merge raw Anthropic usage into the running total, keeping non-null fields."""

    if raw_usage is None:
        return current
    base = current or Usage(provider="anthropic")

    def pick(field: str, existing: int) -> int:
        value = _get(raw_usage, field)
        return int(value) if value is not None else existing

    return Usage(
        input_tokens=pick("input_tokens", base.input_tokens),
        output_tokens=pick("output_tokens", base.output_tokens),
        cache_read_tokens=pick("cache_read_input_tokens", base.cache_read_tokens),
        cache_write_tokens=pick("cache_creation_input_tokens", base.cache_write_tokens),
        provider="anthropic",
    )
