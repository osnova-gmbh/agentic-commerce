"""Optional first-party model provider adapters."""

from cogit_agent_sdk.providers.anthropic import AnthropicModelClient
from cogit_agent_sdk.providers.openai import OpenAIModelClient

__all__ = ["AnthropicModelClient", "OpenAIModelClient"]
