"""Action descriptor types (definitions.md §8, Proposal 014/019)."""

from __future__ import annotations

import re
from typing import Annotated, Any

from pydantic import (
    ConfigDict,
    Field,
    PlainValidator,
    WithJsonSchema,
    field_serializer,
    field_validator,
)

from cogit_agent_sdk.types._base import SdkModel, to_camel
from cogit_agent_sdk.types._immutable import (
    FrozenDict,
    FrozenList,
    freeze_value,
    thaw_value,
)
from cogit_agent_sdk.types.requirements import (
    IdempotencyLevel,
    OperationRequirements,
    RiskLevel,
    normalize_required_capabilities,
)

_CAPABILITY_PATTERN = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")

_JSON_SCHEMA_DECLARATION: dict[str, Any] = {
    "type": "object",
    "description": "JSON Schema declaration for action payloads.",
    "additionalProperties": True,
}

_DOT_NAMESPACED_CAPABILITY: dict[str, Any] = {
    "type": "string",
    "pattern": _CAPABILITY_PATTERN.pattern,
    "description": "Dot-namespaced capability key such as run.cancel or artifact.read.",
}

_REQUIRED_CAPABILITIES_JSON_SCHEMA: dict[str, Any] = {
    "type": "array",
    "items": _DOT_NAMESPACED_CAPABILITY,
    "uniqueItems": True,
    "default": [],
    "description": "Sorted unique capability keys required before invocation.",
}

_METADATA_JSON_SCHEMA: dict[str, Any] = {
    "anyOf": [
        {"type": "object", "additionalProperties": True},
        {"type": "null"},
    ],
    "default": None,
    "description": "Informational metadata that does not alter enforcement.",
}


def _parse_frozen_mapping(value: Any, *, field_name: str) -> FrozenDict:
    if isinstance(value, FrozenDict):
        return value
    if isinstance(value, dict):
        return freeze_value(dict(value))
    raise TypeError(f"{field_name} must be a JSON object")


def _parse_frozen_metadata(value: Any) -> FrozenDict | None:
    if value is None:
        return None
    return _parse_frozen_mapping(value, field_name="metadata")


def _parse_frozen_capabilities(value: Any) -> FrozenList:
    if isinstance(value, FrozenList):
        items = list(value)
    elif isinstance(value, list):
        items = value
    else:
        raise TypeError("required_capabilities must be a list of strings")
    normalized = normalize_required_capabilities(items)
    return FrozenList(normalized)


InputSchemaField = Annotated[
    FrozenDict,
    PlainValidator(lambda value: _parse_frozen_mapping(value, field_name="input_schema")),
    WithJsonSchema(_JSON_SCHEMA_DECLARATION),
]
OutputSchemaField = Annotated[
    FrozenDict,
    PlainValidator(lambda value: _parse_frozen_mapping(value, field_name="output_schema")),
    WithJsonSchema(_JSON_SCHEMA_DECLARATION),
]
MetadataField = Annotated[
    FrozenDict | None,
    PlainValidator(_parse_frozen_metadata),
    WithJsonSchema(_METADATA_JSON_SCHEMA),
]
CapabilitiesField = Annotated[
    FrozenList,
    PlainValidator(_parse_frozen_capabilities),
    WithJsonSchema(_REQUIRED_CAPABILITIES_JSON_SCHEMA),
]


class ActionDescriptor(SdkModel):
    """Declaration of an agent action."""

    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        extra="forbid",
        alias_generator=lambda field_name: to_camel(field_name),
    )

    name: str
    description: str
    input_schema: InputSchemaField
    output_schema: OutputSchemaField
    risk: RiskLevel = "read"
    requires_approval: bool = False
    idempotency: IdempotencyLevel = "inherent"
    required_capabilities: CapabilitiesField = Field(default_factory=FrozenList)
    metadata: MetadataField = None

    @property
    def requirements(self) -> OperationRequirements:
        return OperationRequirements(
            risk=self.risk,
            idempotency=self.idempotency,
            required_capabilities=tuple(self.required_capabilities),
            requires_approval=self.requires_approval,
        )

    @field_validator("description")
    @classmethod
    def _require_non_empty_description(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("description must be a non-empty string")
        return value

    @field_serializer("input_schema", "output_schema", "metadata")
    def _serialize_frozen_mappings(self, value: Any) -> Any:
        if value is None:
            return None
        return thaw_value(value)

    @field_serializer("required_capabilities")
    def _serialize_frozen_capabilities(self, value: FrozenList) -> list[str]:
        return list(value)


def canonicalize_action_descriptor(descriptor: ActionDescriptor) -> ActionDescriptor:
    """Revalidate and deep-freeze a descriptor for registration."""

    return ActionDescriptor.model_validate(descriptor.model_dump(mode="json"))


def requirements_from_action_descriptor(descriptor: ActionDescriptor) -> OperationRequirements:
    """Return the canonical requirements value for an action descriptor."""

    return descriptor.requirements


__all__ = [
    "ActionDescriptor",
    "CapabilitiesField",
    "IdempotencyLevel",
    "InputSchemaField",
    "MetadataField",
    "OutputSchemaField",
    "RiskLevel",
    "canonicalize_action_descriptor",
    "requirements_from_action_descriptor",
]
