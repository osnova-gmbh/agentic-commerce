"""Tool, toolset, and related types (definitions.md §7-8, Proposal 015/019)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import ConfigDict, Field, field_serializer, field_validator

from cogit_agent_sdk.types._base import SdkModel, to_camel
from cogit_agent_sdk.types._immutable import FrozenList, thaw_value
from cogit_agent_sdk.types.actions import (
    CapabilitiesField,
    InputSchemaField,
    MetadataField,
    OutputSchemaField,
)
from cogit_agent_sdk.types.messages import ContentBlock
from cogit_agent_sdk.types.requirements import IdempotencyLevel, OperationRequirements, RiskLevel
from cogit_agent_sdk.types.usage import Usage

ExecutionMode = Literal["parallel", "sequential"]


class ToolDescriptor(SdkModel):
    """Declaration of a tool's interface and metadata."""

    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        extra="forbid",
        alias_generator=lambda field_name: to_camel(field_name),
    )

    name: str
    description: str
    input_schema: InputSchemaField
    output_schema: OutputSchemaField
    risk: RiskLevel = "read"
    idempotency: IdempotencyLevel = "inherent"
    required_capabilities: CapabilitiesField = Field(default_factory=FrozenList)
    requires_approval: bool = False
    execution_mode: ExecutionMode = "parallel"
    timeout_seconds: int | None = None
    metadata: MetadataField = None

    @property
    def requirements(self) -> OperationRequirements:
        return OperationRequirements(
            risk=self.risk,
            idempotency=self.idempotency,
            required_capabilities=tuple(self.required_capabilities),
            requires_approval=self.requires_approval,
        )

    @field_validator("description")
    @classmethod
    def _require_non_empty_description(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("description must be a non-empty string")
        return value

    @field_validator("timeout_seconds")
    @classmethod
    def _validate_timeout(cls, value: int | None) -> int | None:
        if value is not None and value <= 0:
            raise ValueError("timeout_seconds must be a positive integer")
        return value

    @field_serializer("input_schema", "output_schema", "metadata")
    def _serialize_frozen_mappings(self, value: Any) -> Any:
        if value is None:
            return None
        return thaw_value(value)

    @field_serializer("required_capabilities")
    def _serialize_frozen_capabilities(self, value: FrozenList) -> list[str]:
        return list(value)


class ToolResult(SdkModel):
    """Result of executing a tool."""

    tool_call_id: str
    tool_name: str
    content: list[ContentBlock]
    is_error: bool = False
    details: dict[str, Any] | None = None
    usage: Usage | None = None


class ToolsetDescriptor(SdkModel):
    """A named group of tools with optional trigger scoping."""

    name: str
    tools: list[str]
    allowed_triggers: list[str] | None = None
    denied_triggers: list[str] | None = None


def canonicalize_tool_descriptor(descriptor: ToolDescriptor) -> ToolDescriptor:
    """Revalidate and deep-freeze a descriptor for registration."""

    return ToolDescriptor.model_validate(descriptor.model_dump(mode="json"))
