"""Context envelope and Principal types (definitions.md §3)."""

from __future__ import annotations

from datetime import datetime
from typing import Literal, NewType

from pydantic import ConfigDict

from cogit_agent_sdk.types._base import SdkModel, to_camel

# Opaque correlation token binding tenant, installation, deployment, pool,
# version, work, attempt, and worker. Propagated through loop hooks.
AttemptToken = NewType("AttemptToken", str)


class Principal(SdkModel):
    """Identity of the caller — user, agent, service, or system."""

    kind: Literal["user", "agent", "service", "system"]
    id: str
    email: str | None = None


class Context(SdkModel):
    """Request context envelope — tenant-scoped, immutable per request."""

    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        extra="ignore",
        alias_generator=to_camel,
    )

    tenant_id: str
    correlation_id: str
    organization_id: str | None = None
    agent_id: str | None = None
    principal: Principal | None = None
    execution_id: str | None = None
    case_id: str | None = None
    queue_item_id: str | None = None
    session_id: str | None = None
    trigger: (
        Literal[
            "manual",
            "chat",
            "scheduled",
            "email",
            "queue",
            "api",
            "eval",
            "improvement",
        ]
        | None
    ) = None
    locale: str | None = None
    deadline: datetime | None = None
    notification_recipient: str | None = None
    permissions: list[str] | None = None
    metadata: dict[str, object] | None = None
