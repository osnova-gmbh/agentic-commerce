"""Agent loop state, config, result, and hook contracts."""

from __future__ import annotations

from collections.abc import Callable
from typing import Literal, Protocol, TypeAlias, runtime_checkable

from pydantic import Field

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.artifacts import ArtifactRef, ArtifactSlot
from cogit_agent_sdk.types.context import Context
from cogit_agent_sdk.types.errors import ErrorInfo
from cogit_agent_sdk.types.messages import AssistantMessage, Message, ToolCall, ToolResultMessage
from cogit_agent_sdk.types.model import ModelDescriptor, ModelRequest, ModelResponse
from cogit_agent_sdk.types.runs import RunEvent
from cogit_agent_sdk.types.tools import ToolDescriptor, ToolResult
from cogit_agent_sdk.types.usage import ModelCallReservation, ModelCallUsage, RunBudget, Usage

LoopMessage: TypeAlias = Message | AssistantMessage | ToolResultMessage
LoopStopReason: TypeAlias = Literal[
    "completed",
    "terminal_tool",
    "max_turns",
    "budget_exceeded",
    "cancelled",
    "model_error",
    "tool_error",
]


class AgentLoopState(SdkModel):
    """Serializable snapshot of loop progress."""

    messages: list[LoopMessage]
    context: Context
    current_turn: int = 0
    session_id: str | None = None
    queued_input: str | None = None
    metadata: JsonObject | None = None


class FrozenPromptStrings(SdkModel):
    """Prompt-visible strings treated as versioned API."""

    budget_warning: str | None = None
    critical_budget_warning: str | None = None
    tool_error_recovery: str | None = None
    terminal_tool_accepted: str | None = None
    continuation_after_max_tokens: str | None = None
    provider_repair: str | None = None


class AgentLoopConfig(SdkModel):
    """Serializable loop configuration that can cross package boundaries."""

    label: str
    model_descriptor: ModelDescriptor
    tools: list[ToolDescriptor] | None = Field(
        default=None,
        description=(
            "Model-visible tool allowlist. Null or omitted uses all tools registered with "
            "the loop engine; an empty list disables tool execution."
        ),
    )
    terminal_tools: list[str] = Field(default_factory=list)
    max_turns: int = 25
    wall_clock_timeout_seconds: int | None = None
    budget: RunBudget | None = None
    frozen_strings: FrozenPromptStrings = Field(default_factory=FrozenPromptStrings)
    metadata: JsonObject | None = None


class AgentLoopResult(SdkModel):
    """Result returned by the deterministic loop engine."""

    state: AgentLoopState
    stop_reason: LoopStopReason
    output: JsonObject | str | None = None
    terminal_result: ToolResult | None = None
    turns_used: int = 0
    usage: Usage | None = None
    events: list[RunEvent] = Field(default_factory=list)
    error: ErrorInfo | None = None
    metadata: JsonObject | None = None


@runtime_checkable
class LoopHookSet(Protocol):
    """Optional policy hooks consumed by the loop engine.

    Artifact and model-call observers default to a documented no-op.
    Custom sets that omit those methods stay compatible when a
    ``RunHandle`` dispatches them.
    """

    def transform_messages(
        self,
        messages: list[LoopMessage],
        context: Context,
    ) -> list[LoopMessage]:
        """Prepare messages before they are converted for the model."""
        ...

    def convert_to_model(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelRequest:
        """Convert loop state and config into a model request."""
        ...

    def transform_tools(
        self,
        tools: list[ToolDescriptor],
        context: Context,
    ) -> list[ToolDescriptor]:
        """Filter or rewrite the model-visible tool list."""
        ...

    def prepare_next_turn(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> AgentLoopState:
        """Prepare state before the next model call."""
        ...

    def before_tool_call(
        self,
        tool_call: ToolCall,
        context: Context,
    ) -> bool:
        """Return whether the tool call may execute."""
        ...

    def after_tool_call(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Context,
    ) -> ToolResult:
        """Normalize a tool result before it is fed back to the model."""
        ...

    def on_event(self, event: RunEvent) -> None:
        """Consume a sequenced event; parallel tools may call this concurrently."""
        ...

    def on_model_error(
        self,
        error: ErrorInfo,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelResponse | None:
        """Repair or retry a model error, or return None to propagate it."""
        ...

    def on_artifact_declared(self, slot: ArtifactSlot) -> None:
        """Observe an artifact slot declaration."""
        ...

    def on_artifact_finalized(self, ref: ArtifactRef) -> None:
        """Observe an artifact finalization."""
        ...

    def on_model_call_reserved(self, reservation: ModelCallReservation) -> None:
        """Observe a model-call budget reservation."""
        ...

    def on_model_call_settled(
        self,
        reservation: ModelCallReservation,
        usage: ModelCallUsage,
    ) -> None:
        """Observe a model-call settlement."""
        ...


LoopEventConsumer = Callable[[RunEvent], None]
