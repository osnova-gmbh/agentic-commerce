"""Shared operation execution requirements (Proposal 019)."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, get_args

RiskLevel = Literal["read", "write", "financial", "external", "destructive"]
IdempotencyLevel = Literal["none", "inherent", "keyed"]

_CAPABILITY_PATTERN = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")
_VALID_RISKS = frozenset(get_args(RiskLevel))
_VALID_IDEMPOTENCY = frozenset(get_args(IdempotencyLevel))


def normalize_required_capabilities(values: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    """Return sorted unique validated capability names."""

    normalized = sorted(set(values))
    for capability in normalized:
        if not _CAPABILITY_PATTERN.fullmatch(capability):
            raise ValueError(
                f"invalid capability {capability!r}; expected dot-namespaced key like run.cancel",
            )
    return tuple(normalized)


@dataclass(frozen=True)
class OperationRequirements:
    """Immutable enforcement fields shared by action and tool descriptors."""

    risk: RiskLevel
    idempotency: IdempotencyLevel
    required_capabilities: tuple[str, ...]
    requires_approval: bool

    def __post_init__(self) -> None:
        if self.risk not in _VALID_RISKS:
            raise ValueError(f"invalid risk level {self.risk!r}")
        if self.idempotency not in _VALID_IDEMPOTENCY:
            raise ValueError(f"invalid idempotency level {self.idempotency!r}")
        if type(self.requires_approval) is not bool:
            raise TypeError("requires_approval must be a boolean")
        normalized = normalize_required_capabilities(self.required_capabilities)
        if normalized != self.required_capabilities:
            raise ValueError("required_capabilities must be sorted and unique")
