"""CogitAgent convenience base class and AgentServices injection type."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, ClassVar

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.cli import CliCommandGroup
from cogit_agent_sdk.client import CogitClient
from cogit_agent_sdk.operations.action_binding import ActionBinding
from cogit_agent_sdk.operations.registry import (
    ActionBindingRegistry,
    ToolBindingRegistry,
    collect_class_bindings,
    collect_class_tool_bindings,
)
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.services import (
    ArtifactHandle,
    MemoryHandle,
    NullArtifactHandle,
    NullMemoryHandle,
)
from cogit_agent_sdk.types import (
    AgentDescriptor,
    AgentLoopConfig,
    Context,
    ModelDescriptor,
    PipelineDescriptor,
    QueryRequest,
    QueryResult,
    RunRequest,
    RunResult,
)

_ECHO_MODEL = ModelDescriptor(
    provider="runtime",
    model="echo",
    supports_tools=False,
    supports_streaming=False,
)

_DEFAULT_DESCRIPTOR = AgentDescriptor(
    name="unnamed-agent",
    version="0.0.0",
    description="",
)


@dataclass(frozen=True)
class AgentServices:
    """Dependency container injected into CogitAgent.configure()."""

    client: CogitClient | None = None
    model_client: Any = None
    logger: logging.Logger = field(
        default_factory=lambda: logging.getLogger("cogit.agent"),
    )
    environment: dict[str, str] = field(default_factory=dict)
    memory: MemoryHandle | None = None
    artifacts: ArtifactHandle | None = None


class CogitAgent:
    """Convenience base class that satisfies the AgentBase protocol.

    Subclass this instead of implementing AgentBase from scratch.
    Override only the methods you need — sensible defaults are provided
    for everything else.
    """

    _class_action_bindings: ClassVar[tuple[ActionBinding[Any, Any], ...]] = ()
    _class_tool_bindings: ClassVar[tuple[ToolBinding[Any, Any], ...]] = ()

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        cls._class_action_bindings = collect_class_bindings(cls)
        cls._class_tool_bindings = collect_class_tool_bindings(cls)

    def __init__(self, descriptor: AgentDescriptor | None = None) -> None:
        self.descriptor: AgentDescriptor = descriptor or _DEFAULT_DESCRIPTOR
        self.client: CogitClient | None = None
        self._services: Any = None
        self._action_registry = ActionBindingRegistry(list(self._class_action_bindings))
        self._tool_registry = ToolBindingRegistry(list(self._class_tool_bindings))

    # -- lifecycle -----------------------------------------------------------

    def configure(self, services: Any) -> None:
        """Accept injected services.

        If *services* is an ``AgentServices`` instance the ``client`` field
        is promoted to ``self.client`` for convenience.  Any other value is
        stored as-is (``self._services``) so callers can pass plain dicts or
        alternative containers.
        """
        if isinstance(services, AgentServices):
            self._services = services
            self.client = services.client
        else:
            self._services = services
            self.client = None

    async def startup(self) -> None:
        """Called once after configure(). Override for async init."""

    async def shutdown(self) -> None:
        """Called once before the process exits.  Override for cleanup."""

    def freeze_action_registration(self) -> None:
        """Reject further :meth:`register_action` calls."""

        self._action_registry.freeze()

    def register_action(self, binding: ActionBinding[Any, Any]) -> None:
        """Register an explicit action binding during ``configure()``."""

        self._action_registry.register(binding)

    def freeze_tool_registration(self) -> None:
        """Reject further :meth:`register_tool` calls."""

        self._tool_registry.freeze()

    def register_tool(self, binding: ToolBinding[Any, Any]) -> None:
        """Register an explicit tool binding during ``configure()``."""

        self._tool_registry.register(binding)

    # -- request handlers (must be overridden) --------------------------------

    def health(self) -> JsonObject:
        """Return a basic health-check response."""
        return {"status": "ok"}

    def handle_run(
        self,
        request: RunRequest,
        context: Context,
        handle: Any,
    ) -> RunResult:
        raise NotImplementedError(f"{type(self).__name__}.handle_run")

    def handle_query(
        self,
        request: QueryRequest,
        context: Context,
        handle: Any,
    ) -> QueryResult:
        raise NotImplementedError(f"{type(self).__name__}.handle_query")

    # -- introspection -------------------------------------------------------

    def action_bindings(self) -> tuple[ActionBinding[Any, Any], ...]:
        """Return canonical executable action bindings."""

        return self._action_registry.list_bindings()

    def tool_bindings(self) -> tuple[ToolBinding[Any, Any], ...]:
        """Return canonical executable tool bindings."""

        return self._tool_registry.list_bindings()

    def pipelines(self) -> list[PipelineDescriptor]:
        """Return pipeline descriptors from the agent descriptor."""
        return list(self.descriptor.pipelines or [])

    def commands(self) -> list[CliCommandGroup]:
        """Return agent-declared CLI command groups. Override to add custom commands."""
        return []

    def loop_config(self, context: Context) -> AgentLoopConfig:
        """Return a loop config with an echo-model fallback."""
        model = self.descriptor.model or _ECHO_MODEL
        return AgentLoopConfig(
            label=self.descriptor.name,
            model_descriptor=model,
        )

    def system_prompt(self, context: Context) -> str:
        """Return the system prompt for the agent loop.  Override to customise."""
        return ""

    def loop_hooks(self, context: Context) -> Any:
        """Return a ``LoopHookSet`` or ``None``.  Override to inject hooks."""
        return None


__all__ = [
    "AgentServices",
    "ArtifactHandle",
    "CogitAgent",
    "MemoryHandle",
    "NullArtifactHandle",
    "NullMemoryHandle",
]
