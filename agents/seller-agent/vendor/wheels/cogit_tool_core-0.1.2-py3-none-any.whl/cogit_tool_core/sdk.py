"""Optional registration adapter; the SDK retains its one execution loop."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass

from cogit_agent_sdk.coordination import raise_coordination_failure
from cogit_agent_sdk.operations import OperationError, OperationInvocation, ToolBinding
from cogit_agent_sdk.types import ErrorInfo, ToolDescriptor
from pydantic import BaseModel

from ._scoped_sdk import ToolMetadata, bind_scoped_tool
from .contracts import ToolError, ToolLike

__all__ = ["Record", "ToolMetadata", "bind_scoped_tool", "bind_tools"]

Record = Callable[[str, Mapping[str, object]], None]


def _ignore(kind: str, payload: Mapping[str, object]) -> None:
    pass


@dataclass
class _Operation:
    input_model: type[BaseModel]
    output_model: type[BaseModel]
    tool: ToolLike
    record: Record

    def __call__(self, request: BaseModel, invocation: OperationInvocation) -> BaseModel:
        invocation.cancellation.throw_if_cancelled()
        self.record(
            "tool_started", {"name": self.tool.name, "arguments": request.model_dump(mode="json")}
        )
        try:
            output = self.tool.invoke(request.model_dump(mode="json"))
        except ToolError as exc:
            raise_coordination_failure(exc)
            self.record(
                "tool_failed", {"name": self.tool.name, "code": exc.code, "message": str(exc)}
            )
            raise OperationError(ErrorInfo(code=exc.code, message=str(exc))) from None
        except Exception as exc:
            raise_coordination_failure(exc)
            self.record(
                "tool_failed",
                {
                    "name": self.tool.name,
                    "code": "internal_error",
                    "error_type": type(exc).__name__,
                },
            )
            raise OperationError(
                ErrorInfo(code="internal_error", message=f"Tool failed: {type(exc).__name__}")
            ) from None
        self.record(
            "tool_completed", {"name": self.tool.name, "result": output.model_dump(mode="json")}
        )
        return output


def bind_tools(
    tools: Iterable[ToolLike],
    *,
    timeout_seconds: int = 120,
    record: Record | None = None,
    metadata: Mapping[str, ToolMetadata] | None = None,
) -> tuple[ToolBinding[BaseModel, BaseModel], ...]:
    """Keep schema parity, sequential resource access, and errors in standard SDK bindings."""
    if timeout_seconds < 1:
        raise ValueError("Tool timeout must be positive")
    bindings: list[ToolBinding[BaseModel, BaseModel]] = []
    names: set[str] = set()
    for tool in tools:
        if tool.name in names:
            raise ValueError(f"Duplicate tool name: {tool.name}")
        names.add(tool.name)
        descriptor = ToolDescriptor.model_validate(
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.input_model.model_json_schema(),
                "output_schema": tool.output_model.model_json_schema(),
                "risk": "write",
                "idempotency": "none",
                "execution_mode": "sequential",
                "timeout_seconds": timeout_seconds,
            }
        )
        if metadata is not None:
            if tool.name not in metadata:
                raise ValueError(f"Missing intrinsic tool metadata: {tool.name}")
            intrinsic = metadata[tool.name]
            if intrinsic.idempotency == "keyed":
                raise ValueError("Use a native ToolBinding with key_for for keyed operations")
            descriptor = intrinsic.descriptor(
                tool.name, tool.description, tool.input_model, tool.output_model
            )
        operation = _Operation(tool.input_model, tool.output_model, tool, record or _ignore)
        bindings.append(ToolBinding(operation=operation, descriptor=descriptor))
    if metadata is not None and set(metadata) != names:
        raise ValueError("Intrinsic metadata includes unknown tool names")
    return tuple(bindings)
