"""Typed capabilities without owning an agent loop or Runtime."""

from .contracts import Model, Tool, ToolError, ToolLike
from .workspace import Workspace

__all__ = ["Model", "Tool", "ToolError", "ToolLike", "Workspace"]
