"""Bounded private audit evidence, separate from model-facing working memory."""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock


class Journal:
    def __init__(self, path: Path, *, max_bytes: int = 268435456) -> None:
        if max_bytes < 1:
            raise ValueError("Journal byte limit must be positive")
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path, self.max_bytes = path, max_bytes
        self._lock = Lock()

    def __call__(self, kind: str, payload: Mapping[str, object]) -> None:
        event = {"timestamp": datetime.now(UTC).isoformat(), "kind": kind, **payload}
        line = (json.dumps(event, ensure_ascii=False) + "\n").encode("utf-8")
        with self._lock, self.path.open("ab") as stream:
            if stream.tell() + len(line) > self.max_bytes:
                raise OSError("Evidence journal byte limit exceeded")
            stream.write(line)
            stream.flush()
