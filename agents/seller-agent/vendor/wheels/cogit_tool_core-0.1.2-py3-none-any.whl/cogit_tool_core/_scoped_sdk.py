"""Typed invocation-aware binding metadata, without an authorization evaluator."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Generic, TypeVar, cast

from cogit_agent_sdk.coordination import raise_coordination_failure
from cogit_agent_sdk.operations import OperationError, OperationInvocation, ToolBinding
from cogit_agent_sdk.types import ErrorInfo, ToolDescriptor
from cogit_agent_sdk.types.requirements import CapabilityNeed, IdempotencyLevel, RiskLevel
from cogit_agent_sdk.types.tools import ExecutionMode
from pydantic import BaseModel

from .contracts import ToolError

InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


@dataclass(frozen=True)
class ToolMetadata:
    """Intrinsic declarations consumed by standard SDK/AgentDB governance."""

    risk: RiskLevel = "write"
    idempotency: IdempotencyLevel = "none"
    required_capabilities: tuple[CapabilityNeed, ...] = ()
    requires_approval: bool = False
    execution_mode: ExecutionMode = "sequential"
    timeout_seconds: int = 120

    def descriptor(
        self,
        name: str,
        description: str,
        input_model: type[BaseModel],
        output_model: type[BaseModel],
    ) -> ToolDescriptor:
        return ToolDescriptor.model_validate(
            {
                "name": name,
                "description": description,
                "input_schema": input_model.model_json_schema(),
                "output_schema": output_model.model_json_schema(),
                "risk": self.risk,
                "idempotency": self.idempotency,
                "required_capabilities": list(self.required_capabilities),
                "requires_approval": self.requires_approval,
                "execution_mode": self.execution_mode,
                "timeout_seconds": self.timeout_seconds,
            }
        )


@dataclass
class _ScopedOperation(Generic[InputT, OutputT]):
    input_model: type[InputT]
    output_model: type[OutputT]
    name: str
    handler: Callable[[InputT, OperationInvocation], OutputT]
    record: Callable[[str, Mapping[str, object]], None] | None

    def __call__(self, request: InputT, invocation: OperationInvocation) -> OutputT:
        invocation.cancellation.throw_if_cancelled()
        context = invocation.context
        evidence: dict[str, object] = {
            "name": self.name,
            "tenant_id": context.tenant_id,
            "agent_id": context.agent_id,
            "execution_id": context.execution_id,
            "session_id": context.session_id,
            "correlation_id": context.correlation_id,
        }
        if self.record is not None:
            self.record("tool_started", evidence)
        try:
            result = self.handler(request, invocation)
            if not isinstance(result, self.output_model):
                raise ToolError("invalid_output", "Handler returned an unexpected result type")
        except ToolError as exc:
            raise_coordination_failure(exc)
            if self.record is not None:
                self.record("tool_failed", {**evidence, "code": exc.code})
            raise OperationError(ErrorInfo(code=exc.code, message=str(exc))) from None
        except Exception as exc:
            raise_coordination_failure(exc)
            if self.record is not None:
                self.record("tool_failed", {**evidence, "code": "internal_error"})
            raise OperationError(
                ErrorInfo(code="internal_error", message=f"Tool failed: {type(exc).__name__}")
            ) from None
        if self.record is not None:
            self.record("tool_completed", evidence)
        return result


def bind_scoped_tool(
    name: str,
    description: str,
    input_model: type[InputT],
    output_model: type[OutputT],
    handler: Callable[[InputT, OperationInvocation], OutputT],
    *,
    metadata: ToolMetadata,
    record: Callable[[str, Mapping[str, object]], None] | None = None,
) -> ToolBinding[BaseModel, BaseModel]:
    """Retain concrete typed operations at the heterogeneous collection boundary.

    Native providers needing prepare_arguments/key_for return their own ToolBinding;
    the provider loader preserves that object without rebuilding it.
    """
    if metadata.idempotency == "keyed":
        raise ValueError("Use a native ToolBinding with key_for for keyed operations")
    operation = _ScopedOperation(input_model, output_model, name, handler, record)
    binding = ToolBinding(
        operation=operation,
        descriptor=metadata.descriptor(name, description, input_model, output_model),
    )
    return cast(ToolBinding[BaseModel, BaseModel], binding)
