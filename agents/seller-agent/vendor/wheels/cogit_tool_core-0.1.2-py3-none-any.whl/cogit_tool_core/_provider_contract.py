"""Optional SDK-facing provider contracts; preparation never acquires resources."""

from __future__ import annotations

import re
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Generic, TypeVar

from cogit_agent_sdk.operations import OperationInvocation, ToolBinding
from cogit_agent_sdk.types import Context
from pydantic import BaseModel, Field

from .contracts import Model, ToolError
from .sdk import Record


def _ignore(kind: str, payload: Mapping[str, object]) -> None:
    pass


@dataclass(frozen=True)
class HostContext:
    """Trusted composition data, never capability grants or model arguments."""

    workspace: Path
    tenant_id: str
    agent_id: str
    automation_root: Path | None = None
    environment: Mapping[str, str] = field(default_factory=lambda: dict[str, str]())
    record: Record = _ignore

    def __post_init__(self) -> None:
        if not self.workspace.is_absolute():
            raise ValueError("Provider workspace must be absolute")
        if self.automation_root is not None and not self.automation_root.is_absolute():
            raise ValueError("Automation root must be absolute")
        if not self.tenant_id.strip() or not self.agent_id.strip():
            raise ValueError("Provider host requires tenant and agent identity")
        object.__setattr__(self, "environment", MappingProxyType(dict(self.environment)))


@dataclass(frozen=True)
class InvocationScope:
    tenant_id: str
    agent_id: str
    session_key: str | None


def invocation_scope(
    invocation: OperationInvocation, host: HostContext, *, require_session: bool = True
) -> InvocationScope:
    """Check resource ownership only; AgentDB/Runtime decides authorization."""
    context = invocation.context
    if context.tenant_id != host.tenant_id or (
        context.agent_id is not None and context.agent_id != host.agent_id
    ):
        raise ToolError("scope_mismatch", "Invocation does not own this provider scope")
    key = None
    if context.session_id:
        key = "session:" + context.session_id
    elif context.execution_id:
        key = "execution:" + context.execution_id
    if require_session and key is None:
        raise ToolError("scope_missing", "Operation requires a trusted session or execution ID")
    return InvocationScope(host.tenant_id, host.agent_id, key)


class ProviderSelection(Model):
    id: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$")
    provider: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z][A-Za-z0-9_.-]*$")
    settings: dict[str, object] = Field(default_factory=dict)
    dependencies: dict[str, str] = Field(default_factory=dict)


@dataclass(frozen=True)
class PreparedTools:
    """Canonical bindings and explicit owned lifecycle, without implicit startup."""

    bindings: tuple[ToolBinding[BaseModel, BaseModel], ...]
    prompt_fragments: tuple[str, ...]
    start: Callable[[], Awaitable[None]]
    close: Callable[[], Awaitable[None]]
    resource: object | None = None
    release_scope: Callable[[Context], Awaitable[None]] | None = None


SettingsT = TypeVar("SettingsT", bound=BaseModel)


def _settings_model(value: object) -> bool:
    return isinstance(value, type) and issubclass(value, BaseModel)


@dataclass(frozen=True)
class ToolProvider(Generic[SettingsT]):
    config_model: type[SettingsT]
    prepare: Callable[[SettingsT, HostContext, Mapping[str, PreparedTools]], PreparedTools]
    api_version: int = 1
    dependencies: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if type(self.api_version) is not int or self.api_version != 1:
            raise ValueError("Unsupported tool provider API version")
        if not _settings_model(self.config_model):
            raise ValueError("Provider settings must be a Pydantic model class")
        if not callable(self.prepare):
            raise ValueError("Provider prepare must be callable")
        config = self.config_model.model_config
        if config.get("strict") is not True or config.get("extra") != "forbid":
            raise ValueError("Provider settings must use strict=True and extra='forbid'")
        if not all(
            re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,127}", alias) for alias in self.dependencies
        ):
            raise ValueError("Invalid provider dependency alias")
        if len(set(self.dependencies)) != len(self.dependencies):
            raise ValueError("Duplicate provider dependency alias")
