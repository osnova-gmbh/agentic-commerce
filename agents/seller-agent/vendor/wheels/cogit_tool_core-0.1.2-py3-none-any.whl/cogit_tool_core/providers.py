"""Selected installed providers, prepared before the ordinary SDK registry freezes.

This optional integration imports the SDK. Base capability imports do not.
Entry points are trusted installed code; discovery never installs dependencies.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from importlib.metadata import EntryPoint, entry_points
from types import MappingProxyType
from typing import cast

from cogit_agent_sdk.operations import ToolBinding
from cogit_agent_sdk.types import ToolDescriptor
from pydantic import BaseModel

from ._provider_contract import (
    HostContext,
    InvocationScope,
    PreparedTools,
    ProviderSelection,
    ToolProvider,
    invocation_scope,
)
from ._provider_lifecycle import ProviderBundle

ENTRY_POINT_GROUP = "cogit.tool_providers.v1"


def _discover(selected: set[str]) -> dict[str, EntryPoint]:
    found: dict[str, EntryPoint] = {}
    try:
        entries = entry_points(group=ENTRY_POINT_GROUP)
        for entry in entries:
            if entry.name not in selected:
                continue
            if entry.name in found:
                raise ValueError(f"Ambiguous installed tool provider: {entry.name}")
            found[entry.name] = entry
    except (OSError, ImportError) as exc:
        raise ValueError("Cannot read installed tool provider metadata") from exc
    missing = selected.difference(found)
    if missing:
        raise ValueError(f"Tool provider is not installed: {', '.join(sorted(missing))}")
    return found


def _load(entry: EntryPoint) -> ToolProvider[BaseModel]:
    try:
        value: object = entry.load()
    except Exception as exc:
        raise ValueError(f"Cannot load selected tool provider: {entry.name}") from exc
    if not isinstance(value, ToolProvider):
        raise ValueError(f"Invalid tool provider contract: {entry.name}")
    provider = cast(ToolProvider[BaseModel], value)
    # Revalidate even if an installed provider bypassed the dataclass constructor.
    provider.__post_init__()
    return provider


def _order(selections: Mapping[str, ProviderSelection]) -> list[str]:
    visiting: set[str] = set()
    visited: set[str] = set()
    ordered: list[str] = []

    def visit(identity: str) -> None:
        if identity in visiting:
            raise ValueError(f"Cyclic tool provider dependency: {identity}")
        if identity in visited:
            return
        if identity not in selections:
            raise ValueError(f"Missing configured provider dependency: {identity}")
        visiting.add(identity)
        for dependency in sorted(selections[identity].dependencies.values()):
            visit(dependency)
        visiting.remove(identity)
        visited.add(identity)
        ordered.append(identity)

    for identity in sorted(selections):
        visit(identity)
    return ordered


def _validate_binding(value: object) -> ToolBinding[BaseModel, BaseModel]:
    if not isinstance(value, ToolBinding):
        raise ValueError("Provider must return standard SDK ToolBindings")
    binding = cast(ToolBinding[BaseModel, BaseModel], value)
    binding.__post_init__()
    ToolDescriptor.model_validate(binding.descriptor.model_dump(mode="python"))
    for hook in (binding.prepare_arguments, binding.key_for):
        if hook is not None and not callable(hook):
            raise ValueError("Provider binding hooks must be callable")
    return binding


def _is_text(value: object) -> bool:
    return isinstance(value, str)


def _validate_prepared(value: object, names: set[str]) -> None:
    if not isinstance(value, PreparedTools):
        raise ValueError("Provider preparation returned an invalid contract")
    prepared = value
    if not callable(prepared.start) or not callable(prepared.close):
        raise ValueError("Provider lifecycle must expose callable start and close")
    if prepared.release_scope is not None and not callable(prepared.release_scope):
        raise ValueError("Provider release_scope must be callable")
    if not all(_is_text(fragment) for fragment in prepared.prompt_fragments):
        raise ValueError("Provider prompt fragments must be text")
    for item in prepared.bindings:
        binding = _validate_binding(item)
        name = binding.descriptor.name
        if name in names:
            raise ValueError(f"Duplicate provider tool name: {name}")
        if binding.descriptor.idempotency == "keyed" and binding.key_for is None:
            raise ValueError(f"Keyed provider tool lacks key_for: {name}")
        names.add(name)


def prepare_providers(selections: Sequence[ProviderSelection], host: HostContext) -> ProviderBundle:
    """Validate the whole selected graph/settings, then prepare without resource I/O."""
    configured = {selection.id: selection for selection in selections}
    if len(configured) != len(selections):
        raise ValueError("Duplicate configured provider instance ID")
    ordered = _order(configured)
    entries = _discover({selection.provider for selection in selections})
    definitions = {name: _load(entry) for name, entry in sorted(entries.items())}
    settings: dict[str, BaseModel] = {}
    for identity in ordered:
        selection = configured[identity]
        definition = definitions[selection.provider]
        if set(selection.dependencies) != set(definition.dependencies):
            raise ValueError(f"Provider dependency aliases do not match: {identity}")
        settings[identity] = definition.config_model.model_validate(selection.settings)
    prepared: dict[str, PreparedTools] = {}
    names: set[str] = set()
    for identity in ordered:
        selection = configured[identity]
        dependencies = MappingProxyType(
            {alias: prepared[target] for alias, target in selection.dependencies.items()}
        )
        result = definitions[selection.provider].prepare(settings[identity], host, dependencies)
        _validate_prepared(result, names)
        prepared[identity] = result
    return ProviderBundle(tuple(prepared.values()))


__all__ = [
    "ENTRY_POINT_GROUP",
    "HostContext",
    "InvocationScope",
    "PreparedTools",
    "ProviderBundle",
    "ProviderSelection",
    "ToolProvider",
    "invocation_scope",
    "prepare_providers",
]
