"""Native-path guardrails. These do not sandbox arbitrary shell code."""

from __future__ import annotations

from pathlib import Path

from .contracts import ToolError


class Workspace:
    def __init__(self, root: Path) -> None:
        self.root = root.resolve(strict=True)
        if not self.root.is_dir():
            raise ValueError("Workspace must be an existing directory")

    def resolve(self, path: str | Path) -> Path:
        value = Path(path)
        # Reject Windows streams/device aliases even when tests run on POSIX.
        for part in value.parts:
            if part == value.anchor:
                continue
            if (
                ":" in part
                or part.rstrip(" .") != part
                or part.split(".")[0].upper()
                in {
                    "CON",
                    "PRN",
                    "AUX",
                    "CONIN$",
                    "CONOUT$",
                    "NUL",
                    *(f"COM{i}" for i in range(1, 10)),
                    *(f"LPT{i}" for i in range(1, 10)),
                    *(f"COM{i}" for i in "¹²³"),
                    *(f"LPT{i}" for i in "¹²³"),
                }
            ):
                raise ToolError("invalid_path", "Unsupported path component")
        try:
            resolved = (self.root / value).resolve()
            if not resolved.is_relative_to(self.root):
                raise ToolError("path_outside_workspace", "Path must stay inside workspace")
            return resolved
        except (OSError, ValueError) as exc:
            raise ToolError("invalid_path", f"Cannot resolve path: {type(exc).__name__}") from None
