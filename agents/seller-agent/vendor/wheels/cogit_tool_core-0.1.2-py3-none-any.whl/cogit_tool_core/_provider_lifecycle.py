"""Dependency-ordered acquisition with rollback and retryable resource cleanup."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from cogit_agent_sdk.operations import ToolBinding
from cogit_agent_sdk.types import Context
from pydantic import BaseModel

from ._provider_contract import PreparedTools


@dataclass
class ProviderBundle:
    providers: tuple[PreparedTools, ...]
    _owned: list[PreparedTools] = field(default_factory=lambda: list[PreparedTools](), init=False)
    _started: bool = field(default=False, init=False)
    _closed: bool = field(default=False, init=False)
    _lifecycle_lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)

    @property
    def bindings(self) -> tuple[ToolBinding[BaseModel, BaseModel], ...]:
        return tuple(
            sorted(
                (binding for provider in self.providers for binding in provider.bindings),
                key=lambda binding: binding.descriptor.name,
            )
        )

    @property
    def prompt_fragments(self) -> tuple[str, ...]:
        return tuple(
            fragment for provider in self.providers for fragment in provider.prompt_fragments
        )

    async def start(self) -> None:
        async with self._lifecycle_lock:
            await self._start()

    async def _start(self) -> None:
        if self._started or self._closed or self._owned:
            raise RuntimeError("Provider bundle can be started only once")
        try:
            for provider in self.providers:
                # A failed start can already own a partial resource.
                self._owned.append(provider)
                await provider.start()
        except BaseException as startup:
            try:
                await self._close()
            except BaseException as cleanup:
                raise BaseExceptionGroup(
                    "Provider startup and cleanup failed", [startup, cleanup]
                ) from None
            raise
        self._started = True

    async def release_scope(self, context: Context) -> None:
        """Release a drained execution scope, retaining provider-wide resources.

        Hooks must be idempotent and remove only resources owned by this trusted
        scope. Stop on failure so dependencies remain alive for a cleanup retry.
        """
        async with self._lifecycle_lock:
            for provider in reversed(self._owned):
                if provider.release_scope is not None:
                    await provider.release_scope(context)

    async def close(self) -> None:
        async with self._lifecycle_lock:
            await self._close()

    async def _close(self) -> None:
        self._closed = True
        while self._owned:
            provider = self._owned[-1]
            try:
                await provider.close()
            except BaseException as exc:
                # Retain this owner and every earlier potential dependency. Closing
                # a dependency under a still-live borrower can lose ownership.
                raise BaseExceptionGroup("Provider cleanup failed", [exc]) from None
            self._owned.pop()
