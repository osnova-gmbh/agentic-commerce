"""Native path guardrails, bounded text operations and atomic replacements."""

from __future__ import annotations

import hashlib
import os
import stat
import tempfile
from pathlib import Path
from threading import RLock

from cogit_tool_core import Tool, ToolError, ToolLike, Workspace

from .models import (
    EditRequest,
    FileEntry,
    ListOutput,
    ListRequest,
    ReadOutput,
    ReadRequest,
    SearchMatch,
    SearchOutput,
    SearchRequest,
    WriteOutput,
    WriteRequest,
)


class FileSystemService:
    def __init__(self, workspace: Path, *, max_file_bytes: int = 8388608) -> None:
        if not 1 <= max_file_bytes <= 67108864:
            raise ValueError("max_file_bytes must be between 1 and 67108864")
        self.workspace = Workspace(workspace)
        self.max_file_bytes = max_file_bytes
        self._lock = RLock()
        self._closed = False

    def _path(self, value: str) -> Path:
        if self._closed:
            raise ToolError("service_closed", "Filesystem service is closed")
        return self.workspace.resolve(value)

    def _relative(self, path: Path) -> str:
        return path.relative_to(self.workspace.root).as_posix()

    def _read(self, path: Path) -> tuple[bytes, str]:
        try:
            if not stat.S_ISREG(path.stat().st_mode):
                raise ToolError("not_regular_file", "Path must be a regular UTF-8 file")
            with path.open("rb") as stream:
                data = stream.read(self.max_file_bytes + 1)
            if len(data) > self.max_file_bytes:
                raise ToolError("file_too_large", "File exceeds configured maximum bytes")
            if b"\x00" in data:
                raise ToolError("not_utf8_text", "File contains binary NUL bytes")
            return data, data.decode("utf-8")
        except UnicodeDecodeError:
            raise ToolError("not_utf8_text", "File is not valid UTF-8 text") from None
        except OSError as exc:
            raise self._error(exc) from None

    @staticmethod
    def _error(exc: OSError) -> ToolError:
        if isinstance(exc, FileNotFoundError):
            return ToolError("not_found", "Path does not exist")
        if isinstance(exc, IsADirectoryError | PermissionError):
            return ToolError("file_access", "Path is a directory or cannot be accessed")
        return ToolError("file_io", f"File operation failed: {type(exc).__name__}")

    @staticmethod
    def _hash(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def read(self, request: ReadRequest) -> ReadOutput:
        with self._lock:
            path = self._path(request.path)
            data, content = self._read(path)
            end = min(len(content), request.offset + request.max_chars)
            return ReadOutput(
                path=self._relative(path),
                text=content[request.offset : end],
                sha256=self._hash(data),
                size_bytes=len(data),
                total_chars=len(content),
                next_offset=end,
                truncated=end < len(content),
            )

    def _replace(self, path: Path, content: str) -> WriteOutput:
        try:
            data = content.encode("utf-8")
        except UnicodeEncodeError:
            raise ToolError("not_utf8_text", "Replacement is not valid UTF-8 text") from None
        if b"\x00" in data:
            raise ToolError("not_utf8_text", "Replacement contains binary NUL bytes")
        if len(data) > self.max_file_bytes:
            raise ToolError("file_too_large", "Replacement exceeds configured maximum bytes")
        temporary: Path | None = None
        try:
            # Parent must already exist; shell handles directory creation and advanced OS tasks.
            fd, name = tempfile.mkstemp(prefix=".cogit-write-", dir=path.parent)
            temporary = Path(name)
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            temporary = None
        except OSError as exc:
            raise self._error(exc) from None
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        return WriteOutput(path=self._relative(path), sha256=self._hash(data), size_bytes=len(data))

    def write(self, request: WriteRequest) -> WriteOutput:
        with self._lock:
            path = self._path(request.path)
            if path.exists():
                if request.expected_sha256 is None:
                    raise ToolError(
                        "file_exists", "Read existing file and supply its expected_sha256"
                    )
                data, _ = self._read(path)
                if self._hash(data) != request.expected_sha256:
                    raise ToolError("conflict", "File changed; read it again before writing")
            elif request.expected_sha256 is not None:
                raise ToolError("conflict", "Expected an existing file but it is missing")
            return self._replace(path, request.content)

    def edit(self, request: EditRequest) -> WriteOutput:
        with self._lock:
            path = self._path(request.path)
            data, content = self._read(path)
            if self._hash(data) != request.expected_sha256:
                raise ToolError("conflict", "File changed; read it again before editing")
            count = content.count(request.old_text)
            if count != 1:
                raise ToolError("edit_match", f"Expected one exact match; found {count}")
            return self._replace(path, content.replace(request.old_text, request.new_text, 1))

    def list(self, request: ListRequest) -> ListOutput:
        with self._lock:
            path = self._path(request.path)
            entries: list[FileEntry] = []
            scanned = 0
            truncated = False
            try:
                with os.scandir(path) as children:
                    for entry in children:
                        if scanned >= request.max_scan or len(entries) >= request.max_entries:
                            truncated = True
                            break
                        scanned += 1
                        kind = "other"
                        if entry.is_symlink():
                            kind = "symlink"
                        elif entry.is_dir(follow_symlinks=False):
                            kind = "directory"
                        elif entry.is_file(follow_symlinks=False):
                            kind = "file"
                        entries.append(FileEntry(path=self._relative(Path(entry.path)), kind=kind))
            except OSError as exc:
                raise self._error(exc) from None
            return ListOutput(
                entries=sorted(entries, key=lambda item: item.path),
                scanned=scanned,
                truncated=truncated,
            )

    def search(self, request: SearchRequest) -> SearchOutput:
        with self._lock:
            base = self._path(request.path)
            if not base.exists():
                raise ToolError("not_found", "Search path does not exist")
            pending = [base]
            seen: set[Path] = set()
            matches: list[SearchMatch] = []
            scanned = scanned_bytes = skipped = 0
            truncated = False
            while pending:
                if scanned >= request.max_scan or len(matches) >= request.max_results:
                    truncated = True
                    break
                path = pending.pop()
                try:
                    path = self.workspace.resolve(path)
                    if path in seen:
                        continue
                    seen.add(path)
                    scanned += 1
                    if path.is_dir():
                        with os.scandir(path) as children:
                            for entry in children:
                                if len(pending) + scanned >= request.max_scan:
                                    truncated = True
                                    break
                                if not entry.is_symlink():
                                    pending.append(Path(entry.path))
                        continue
                    if not path.is_file():
                        skipped += 1
                        continue
                    remaining = request.max_scan_bytes - scanned_bytes
                    if remaining <= 0:
                        truncated = True
                        break
                    ceiling = min(self.max_file_bytes, remaining)
                    if path.stat().st_size > ceiling:
                        skipped += 1
                        truncated = True
                        continue
                    with path.open("rb") as stream:
                        data = stream.read(ceiling)
                    scanned_bytes += len(data)
                    if path.stat().st_size > len(data):
                        skipped += 1
                        truncated = True
                        continue
                    if b"\x00" in data:
                        skipped += 1
                        continue
                    text = data.decode("utf-8")
                    for number, line in enumerate(text.splitlines(), 1):
                        index = line.find(request.query)
                        if index >= 0:
                            start = max(0, index - 100)
                            matches.append(
                                SearchMatch(
                                    path=self._relative(path),
                                    line=number,
                                    snippet=line[start : start + 512],
                                )
                            )
                            if len(matches) >= request.max_results:
                                truncated = True
                                break
                except (OSError, UnicodeDecodeError, ToolError):
                    skipped += 1
            return SearchOutput(
                matches=matches,
                scanned=scanned,
                scanned_bytes=scanned_bytes,
                skipped=skipped,
                truncated=truncated,
            )

    def tools(self) -> tuple[ToolLike, ...]:
        return (
            Tool(
                "filesystem_read",
                "Read bounded UTF-8 file page; offsets count characters. "
                "Returns SHA-256 required for safe edits/overwrites.",
                ReadRequest,
                ReadOutput,
                self.read,
            ),
            Tool(
                "filesystem_write",
                "Atomically create UTF-8 file. Overwrite requires observed "
                "expected_sha256. Parent directory must exist.",
                WriteRequest,
                WriteOutput,
                self.write,
            ),
            Tool(
                "filesystem_edit",
                "Replace exactly one literal match with observed expected_sha256; "
                "conflicts preserve original.",
                EditRequest,
                WriteOutput,
                self.edit,
            ),
            Tool(
                "filesystem_list",
                "List one directory with explicit scan/result limits.",
                ListRequest,
                ListOutput,
                self.list,
            ),
            Tool(
                "filesystem_search",
                "Search literal UTF-8 text recursively with byte/entry/result "
                "budgets. Symlinks are skipped; output reports truncation and skipped files.",
                SearchRequest,
                SearchOutput,
                self.search,
            ),
        )

    def close(self) -> None:
        with self._lock:
            self._closed = True
