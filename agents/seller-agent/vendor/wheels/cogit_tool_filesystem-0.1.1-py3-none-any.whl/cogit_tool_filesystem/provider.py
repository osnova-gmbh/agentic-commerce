"""Installed typed filesystem provider; no filesystem access during preparation."""

from collections.abc import Mapping

from cogit_tool_core import Model
from cogit_tool_core.deferred import DeferredService
from cogit_tool_core.providers import HostContext, PreparedTools, ToolProvider
from cogit_tool_core.sdk import ToolMetadata
from pydantic import Field

from .models import (
    EditRequest,
    ListOutput,
    ListRequest,
    ReadOutput,
    ReadRequest,
    SearchOutput,
    SearchRequest,
    WriteOutput,
    WriteRequest,
)
from .service import FileSystemService


class FileSystemSettings(Model):
    max_file_bytes: int = Field(default=8388608, ge=1, le=67108864)


def prepare(
    settings: FileSystemSettings, host: HostContext, dependencies: Mapping[str, PreparedTools]
) -> PreparedTools:
    del dependencies
    owner = DeferredService(
        lambda: FileSystemService(host.workspace, max_file_bytes=settings.max_file_bytes), host
    )
    read = ToolMetadata(risk="read", idempotency="inherent")
    write = ToolMetadata(risk="write", idempotency="none")
    bindings = (
        owner.binding(
            "filesystem_read",
            "Read bounded UTF-8 text and its SHA-256 for safe edits.",
            ReadRequest,
            ReadOutput,
            FileSystemService.read,
            metadata=read,
        ),
        owner.binding(
            "filesystem_write",
            "Atomically create UTF-8 text; overwrite requires observed expected_sha256.",
            WriteRequest,
            WriteOutput,
            FileSystemService.write,
            metadata=write,
        ),
        owner.binding(
            "filesystem_edit",
            "Replace one exact match using observed expected_sha256; conflicts preserve bytes.",
            EditRequest,
            WriteOutput,
            FileSystemService.edit,
            metadata=write,
        ),
        owner.binding(
            "filesystem_list",
            "List a directory with explicit result and scan limits.",
            ListRequest,
            ListOutput,
            FileSystemService.list,
            metadata=read,
        ),
        owner.binding(
            "filesystem_search",
            "Search literal text recursively with byte, entry and result budgets.",
            SearchRequest,
            SearchOutput,
            FileSystemService.search,
            metadata=read,
        ),
    )
    return PreparedTools(
        bindings=bindings,
        prompt_fragments=(
            "Inspect files before editing. Use observed hashes for writes "
            "and verify resulting bytes.",
        ),
        start=owner.start,
        close=owner.close,
        resource=owner,
    )


provider = ToolProvider(FileSystemSettings, prepare)
