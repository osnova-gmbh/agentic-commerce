"""Typed requests and bounded results for native file operations."""

from typing import Literal

from cogit_tool_core import Model
from pydantic import Field


class ReadRequest(Model):
    path: str = Field(min_length=1, max_length=4096)
    offset: int = Field(default=0, ge=0, le=67108864)
    max_chars: int = Field(default=16000, ge=1, le=65536)


class ReadOutput(Model):
    path: str
    text: str
    sha256: str
    size_bytes: int
    total_chars: int
    next_offset: int
    truncated: bool


class WriteRequest(Model):
    path: str = Field(min_length=1, max_length=4096)
    content: str = Field(max_length=1048576)
    expected_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")


class EditRequest(Model):
    path: str = Field(min_length=1, max_length=4096)
    old_text: str = Field(min_length=1, max_length=1048576)
    new_text: str = Field(max_length=1048576)
    expected_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")


class WriteOutput(Model):
    path: str
    sha256: str
    size_bytes: int


class ListRequest(Model):
    path: str = Field(default=".", min_length=1, max_length=4096)
    max_entries: int = Field(default=100, ge=1, le=500)
    max_scan: int = Field(default=2000, ge=1, le=10000)


class FileEntry(Model):
    path: str
    kind: Literal["file", "directory", "symlink", "other"]


class ListOutput(Model):
    entries: list[FileEntry]
    scanned: int
    truncated: bool


class SearchRequest(Model):
    query: str = Field(min_length=1, max_length=256)
    path: str = Field(default=".", min_length=1, max_length=4096)
    max_results: int = Field(default=50, ge=1, le=100)
    max_scan: int = Field(default=2000, ge=1, le=10000)
    max_scan_bytes: int = Field(default=8388608, ge=1, le=33554432)


class SearchMatch(Model):
    path: str
    line: int
    snippet: str


class SearchOutput(Model):
    matches: list[SearchMatch]
    scanned: int
    scanned_bytes: int
    skipped: int
    truncated: bool
