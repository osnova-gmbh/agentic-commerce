"""Test doubles for code that sends messages."""

from __future__ import annotations

from .envelope import build_envelope
from .keys import AgentKey


class RecordingMessaging:
    """``MessagingSeams`` that signs and keeps what was sent instead of queueing it."""

    def __init__(self, key: AgentKey | None = None) -> None:
        self.key = key or AgentKey.generate()
        self.did = self.key.did
        self.sent: list[dict] = []

    def send(
        self,
        type_key: str,
        type_version: int,
        recipient_did: str,
        conversation_id: str,
        body: dict,
        causation_id: str | None = None,
    ) -> str:
        envelope = build_envelope(
            self.key, self.did, type_key, type_version, recipient_did, conversation_id, body, causation_id
        )
        self.sent.append(envelope)
        return envelope["message_id"]

    def of_type(self, type_key: str) -> list[dict]:
        return [envelope for envelope in self.sent if envelope["type_key"] == type_key]
