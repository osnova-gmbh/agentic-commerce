"""Agent-facing registered database operations, implemented by the run host."""

from __future__ import annotations

from pydantic import JsonValue


class DatabaseSeams:
    """Operations use admitted package pins and the host's current attempt fence.

    Agents supply business input and declared names. The host supplies tenant,
    execution, package version, digest, and worker authority. The explicit command
    idempotency key identifies the business operation across retries.
    """

    def module_query(
        self, module_key: str, query_key: str, payload: dict[str, JsonValue], *, contract_id: str
    ) -> dict[str, JsonValue]:
        """Read a registered export under the admitted run's exact contract."""
        raise NotImplementedError("This run host has no database module transport")

    def module_command(
        self,
        module_key: str,
        command_key: str,
        payload: dict[str, JsonValue],
        *,
        contract_id: str,
        idempotency_key: str,
    ) -> dict[str, JsonValue]:
        """Invoke a registered command under fenced, idempotent worker authority."""
        raise NotImplementedError("This run host has no database module transport")
