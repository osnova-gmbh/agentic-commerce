"""Portable reservation boundary around the actual selected model client.

The host owns route selection, persisted call slots, pricing, and reservation
storage. A failed provider call has an uncertain outcome: this wrapper never
automatically retries or chooses fallback after such a failure.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass
from typing import Protocol, cast

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import (
    Cancellation,
    ModelClient,
    ModelDescriptor,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
    Usage,
)


class IdentifiedModelClient(ModelClient, Protocol):
    """Client that reports its next provider/model without external effects."""

    def dispatch_identity(self, request: ModelRequest) -> tuple[str, str]: ...


@dataclass(frozen=True, slots=True)
class SelectedModelCall:
    """Host-selected concrete route with a stable, persisted logical call slot."""

    call_slot_id: str
    model: ModelDescriptor
    client: IdentifiedModelClient


class ModelDispatchFailure(CoordinationFailure):
    """A model call needs host reconciliation; SDK recovery must not retry it."""

    def __init__(self, phase: str, call_slot_id: str | None = None) -> None:
        self.phase = phase
        self.call_slot_id = call_slot_id
        super().__init__(f"Model dispatch {phase} failed")


class DispatchingModelClient(ModelClient):
    """Reserve each chosen route before dispatch and settle only known usage.

    The selector runs on every invocation, including a later host-approved
    fallback. Its slot ID must be stable across process restarts; the SDK does
    not create or persist slots. The reserve callback must enforce the admitted
    cap and chosen-model price, then return a non-None durable reservation.
    Missing usage or any post-dispatch failure leaves that reservation uncertain.
    """

    def __init__(
        self,
        select_route: Callable[[ModelRequest], SelectedModelCall],
        reserve: Callable[[SelectedModelCall, ModelRequest], object],
        settle: Callable[[SelectedModelCall, object, Usage], None],
    ) -> None:
        self._select_route = select_route
        self._reserve = reserve
        self._settle = settle

    def generate(self, request: ModelRequest, cancellation: Cancellation) -> ModelResponse:
        route, selected_request, reservation = self._prepare(request, cancellation)
        try:
            response = route.client.generate(selected_request, cancellation)
            message = response.message
            usage = self._resolved_usage(
                response.usage,
                message.usage,
                route,
                message.model,
                message.provider,
            )
            self._settle_call(route, reservation, usage)
            return response
        except CoordinationFailure:
            raise
        except Exception as exc:
            raise ModelDispatchFailure("uncertain", route.call_slot_id) from exc

    def stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterable[ModelStreamEvent]:
        return self._stream(request, cancellation)

    def _stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterator[ModelStreamEvent]:
        route, selected_request, reservation = self._prepare(request, cancellation)
        try:
            for event in route.client.stream(selected_request, cancellation):
                if event.type == "error":
                    raise ModelDispatchFailure("uncertain", route.call_slot_id)
                if event.type == "message_completed":
                    message = event.message
                    usage = self._resolved_usage(
                        event.usage,
                        message.usage if message is not None else None,
                        route,
                        message.model if message is not None else None,
                        message.provider if message is not None else None,
                    )
                    self._settle_call(route, reservation, usage)
                    yield event
                    return
                yield event
        except CoordinationFailure:
            raise
        except Exception as exc:
            raise ModelDispatchFailure("uncertain", route.call_slot_id) from exc
        raise ModelDispatchFailure("uncertain", route.call_slot_id)

    def _prepare(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> tuple[SelectedModelCall, ModelRequest, object]:
        cancellation.throw_if_cancelled()
        route = self._select(request)
        selected_request = request.model_copy(update={"model": route.model})
        self._verify_identity(route, selected_request)
        reservation = self._reserve_call(route, selected_request)
        return route, selected_request, reservation

    def _select(self, request: ModelRequest) -> SelectedModelCall:
        try:
            selected = cast(object, self._select_route(request))
        except CoordinationFailure:
            raise
        except Exception as exc:
            raise ModelDispatchFailure("selection") from exc
        if not isinstance(selected, SelectedModelCall):
            raise ModelDispatchFailure("selection")
        route = selected
        slot = cast(object, route.call_slot_id)
        if not isinstance(slot, str) or not slot.strip() or len(slot) > 256:
            raise ModelDispatchFailure("selection")
        model = cast(object, route.model)
        if not isinstance(model, ModelDescriptor):
            raise ModelDispatchFailure("identity", slot)
        if not model.provider.strip() or not model.model.strip():
            raise ModelDispatchFailure("selection", slot)
        return route

    @staticmethod
    def _verify_identity(route: SelectedModelCall, selected_request: ModelRequest) -> None:
        slot = route.call_slot_id
        candidate_client = cast(object, route.client)
        if any(
            not callable(getattr(candidate_client, name, None))
            for name in ("dispatch_identity", "generate", "stream")
        ):
            raise ModelDispatchFailure("identity", slot)
        try:
            actual_provider, actual_model = route.client.dispatch_identity(selected_request)
        except CoordinationFailure:
            raise
        except Exception as exc:
            raise ModelDispatchFailure("identity", slot) from exc
        if (actual_provider, actual_model) != (route.model.provider, route.model.model):
            raise ModelDispatchFailure("identity", slot)

    def _reserve_call(self, route: SelectedModelCall, selected_request: ModelRequest) -> object:
        try:
            reservation = self._reserve(route, selected_request)
        except CoordinationFailure:
            raise
        except Exception as exc:
            raise ModelDispatchFailure("reservation", route.call_slot_id) from exc
        if reservation is None:
            raise ModelDispatchFailure("reservation", route.call_slot_id)
        return reservation

    @classmethod
    def _resolved_usage(
        cls,
        primary: Usage | None,
        nested: Usage | None,
        route: SelectedModelCall,
        response_model: str | None,
        response_provider: str | None,
    ) -> Usage:
        if primary is not None and nested is not None:
            for field in (
                "input_tokens",
                "output_tokens",
                "cache_read_tokens",
                "cache_write_tokens",
            ):
                if getattr(primary, field) != getattr(nested, field):
                    raise ModelDispatchFailure("usage", route.call_slot_id)
            for field in ("provider", "model"):
                left, right = getattr(primary, field), getattr(nested, field)
                if left is not None and right is not None and left != right:
                    raise ModelDispatchFailure("usage", route.call_slot_id)
            cls._verified_usage(nested, route, response_model, response_provider)
        return cls._verified_usage(primary or nested, route, response_model, response_provider)

    @staticmethod
    def _verified_usage(
        usage: Usage | None,
        route: SelectedModelCall,
        response_model: str | None,
        response_provider: str | None,
    ) -> Usage:
        if usage is None:
            raise ModelDispatchFailure("usage", route.call_slot_id)
        counts = (
            usage.input_tokens,
            usage.output_tokens,
            usage.cache_read_tokens,
            usage.cache_write_tokens,
        )
        if any(type(count) is not int or count < 0 for count in counts):
            raise ModelDispatchFailure("usage", route.call_slot_id)
        for observed, selected in (
            (usage.provider, route.model.provider),
            (usage.model, route.model.model),
            (response_provider, route.model.provider),
            (response_model, route.model.model),
        ):
            if observed is not None and observed != selected:
                raise ModelDispatchFailure("usage", route.call_slot_id)
        return usage

    def _settle_call(self, route: SelectedModelCall, reservation: object, usage: Usage) -> None:
        try:
            self._settle(route, reservation, usage)
        except CoordinationFailure:
            raise
        except Exception as exc:
            raise ModelDispatchFailure("settlement", route.call_slot_id) from exc
