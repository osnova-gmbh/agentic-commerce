"""Optional first-party model provider adapters."""

from cogit_agent_sdk.providers.anthropic import AnthropicModelClient
from cogit_agent_sdk.providers.dispatch import (
    DispatchingModelClient,
    IdentifiedModelClient,
    ModelDispatchFailure,
    SelectedModelCall,
)
from cogit_agent_sdk.providers.openai import OpenAIModelClient

__all__ = [
    "AnthropicModelClient",
    "DispatchingModelClient",
    "IdentifiedModelClient",
    "ModelDispatchFailure",
    "OpenAIModelClient",
    "SelectedModelCall",
]
