"""Attention, decision, and related types (definitions.md §22)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from cogit_agent_sdk.types._base import SdkModel


class DecisionOption(SdkModel):
    """An option presented in an attention item."""

    label: str
    value: str
    description: str | None = None


class AttentionItem(SdkModel):
    """An item requiring human or supervisor attention."""

    id: str
    kind: Literal[
        "approval_required",
        "node_failed",
        "gate_failed",
        "clarification_needed",
        "human_review",
        "terminal_review",
    ]
    execution_id: str | None = None
    case_id: str | None = None
    message: str
    options: list[DecisionOption] | None = None
    metadata: dict[str, Any] | None = None


class Decision(SdkModel):
    """A decision made in response to an attention item."""

    id: str
    attention_item_id: str
    action: Literal["continue", "retry", "patch", "approve", "reject", "abort", "request_changes"]
    rationale: str | None = None
    patch: str | None = None
    decided_by: str
    decided_at: datetime
