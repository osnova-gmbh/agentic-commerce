"""Base model configuration shared by all SDK types.

All models use snake_case Python fields with camelCase wire aliases,
tolerant inbound parsing (ignore unknown fields), and exclude-none
outbound serialization by default.
"""

from pydantic import BaseModel, ConfigDict


class SdkModel(BaseModel):
    """Base for all cogit-agent-sdk Pydantic models."""

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore",
        alias_generator=lambda field_name: to_camel(field_name),
    )


def to_camel(snake: str) -> str:
    """Convert snake_case to camelCase."""
    parts = snake.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])
