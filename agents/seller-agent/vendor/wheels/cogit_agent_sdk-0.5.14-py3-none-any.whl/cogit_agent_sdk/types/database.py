"""Exact database package requirements shared with AgentDb module manifests.

These references declare authority requirements, never SQL targets or migrations.
The installer resolves them; a worker consumes the admitted run's immutable copy.
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import ConfigDict, Field, field_validator

from cogit_agent_sdk.types._base import SdkModel

DatabaseKey = Annotated[str, Field(strict=True, pattern=r"^[a-z][a-z0-9._-]{1,95}$")]
DatabaseVersion = Annotated[
    str,
    Field(
        strict=True, max_length=32, pattern=r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$"
    ),
]


class DatabaseExportRequirement(SdkModel):
    """One approved, exactly versioned query or command contract."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["query", "command"]
    key: DatabaseKey
    export_version: DatabaseVersion
    contract_id: DatabaseKey


class DatabasePackageRequirement(SdkModel):
    """Immutable package reference; empty exports grant no operation access."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    module_key: DatabaseKey
    version: DatabaseVersion
    artifact_sha256: Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]
    exports: tuple[DatabaseExportRequirement, ...] = Field(default=(), max_length=128)

    @field_validator("exports")
    @classmethod
    def _unique_exports(
        cls, value: tuple[DatabaseExportRequirement, ...]
    ) -> tuple[DatabaseExportRequirement, ...]:
        identities = {(entry.kind, entry.key) for entry in value}
        if len(identities) != len(value):
            raise ValueError("Database exports must have unique kind/key identities")
        return value
