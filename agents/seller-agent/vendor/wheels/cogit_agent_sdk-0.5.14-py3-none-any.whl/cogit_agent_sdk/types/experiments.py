"""Experiment record types (definitions.md §21)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel


class ExperimentRecord(SdkModel):
    """Record of an improvement experiment."""

    id: str
    agent_id: str
    organization_id: str | None = None
    hypothesis: str
    changed_surface: Literal["prompt", "config", "code", "tool", "eval", "data", "other"]
    branch_or_revision: str | None = None
    baseline_eval_record_id: str | None = None
    candidate_eval_record_id: str | None = None
    metrics: dict[str, Any] = Field(default_factory=dict)
    verdict: Literal["proposed", "running", "kept", "discarded", "needs_human"] = "proposed"
    created_at: datetime
    completed_at: datetime | None = None
