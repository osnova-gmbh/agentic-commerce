"""QueueItem type (definitions.md §15)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from cogit_agent_sdk.types._base import SdkModel


class QueueItem(SdkModel):
    """An item in a work queue."""

    id: str
    tenant_id: str
    organization_id: str | None = None
    queue_name: str
    item_type: str
    payload: dict[str, Any]
    addressed_to: str | None = None
    status: Literal[
        "pending",
        "processing",
        "parked",
        "processed",
        "failed",
        "dead",
    ]
    case_id: str | None = None
    dedupe_key: str | None = None
    retry_count: int = 0
    max_retries: int = 3
    lease_expires_at: datetime | None = None
    heartbeat_at: datetime | None = None
    error: str | None = None
    source_id: str | None = None
    idempotency_key: str | None = None
    available_at: datetime | None = None
