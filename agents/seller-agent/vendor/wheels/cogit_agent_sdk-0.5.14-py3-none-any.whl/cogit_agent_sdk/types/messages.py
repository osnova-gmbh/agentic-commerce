"""Message, content block, and tool-call types (definitions.md §4, §7.4-7.5)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.usage import Usage


class TextContent(SdkModel):
    """Plain text content block."""

    type: Literal["text"] = "text"
    text: str


class ImageContent(SdkModel):
    """Image content block."""

    type: Literal["image"] = "image"
    source: str
    media_type: str | None = None


class ThinkingContent(SdkModel):
    """Model thinking/reasoning content block."""

    type: Literal["thinking"] = "thinking"
    text: str


class FileRefContent(SdkModel):
    """File reference content block."""

    type: Literal["file_ref"] = "file_ref"
    uri: str
    name: str | None = None
    mime_type: str | None = None


class StructuredContent(SdkModel):
    """Structured data content block."""

    type: Literal["structured"] = "structured"
    data: dict[str, Any]


class ToolCall(SdkModel):
    """A tool invocation requested by the model."""

    id: str
    tool_name: str
    arguments: dict[str, Any]
    thought_signature: str | None = None


class Diagnostic(SdkModel):
    """A diagnostic message from the model or provider."""

    level: Literal["info", "warning", "error"]
    message: str
    source: str | None = None


ContentBlock = TextContent | ImageContent | ThinkingContent | FileRefContent | StructuredContent


class Message(SdkModel):
    """A conversation message."""

    role: Literal["user", "assistant", "tool_result", "system"]
    content: list[ContentBlock]
    timestamp: datetime | None = None
    metadata: dict[str, Any] | None = None


class AssistantMessage(SdkModel):
    """An assistant message with optional model metadata."""

    role: Literal["assistant"] = "assistant"
    content: list[ContentBlock]
    model: str | None = None
    provider: str | None = None
    usage: Usage | None = None
    stop_reason: str | None = None
    tool_calls: list[ToolCall] | None = None
    diagnostics: list[Diagnostic] | None = None
    timestamp: datetime | None = None
    metadata: dict[str, Any] | None = None


class ToolResultMessage(SdkModel):
    """A tool result message."""

    role: Literal["tool_result"] = "tool_result"
    content: list[ContentBlock]
    tool_call_id: str
    tool_name: str
    is_error: bool = False
    details: dict[str, Any] | None = None
    timestamp: datetime | None = None
    metadata: dict[str, Any] | None = None
