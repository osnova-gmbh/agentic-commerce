"""Model descriptor, request, response, and client contract types."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Literal, Protocol, runtime_checkable

from pydantic import Field

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.cancellation import Cancellation
from cogit_agent_sdk.types.messages import AssistantMessage, Diagnostic, Message, ToolResultMessage
from cogit_agent_sdk.types.tools import ToolDescriptor
from cogit_agent_sdk.types.usage import EstimatedCost, Usage


class ModelCost(SdkModel):
    """Per-token cost rates for a model."""

    input_per_1k: float | None = None
    output_per_1k: float | None = None
    cache_read_per_1k: float | None = None
    cache_write_per_1k: float | None = None


def estimate_cost(usage: Usage, rates: ModelCost) -> EstimatedCost:
    """Estimate monetary cost of `usage` from per-1k token rates.

    Missing rates count as zero, so partial rate cards still produce a
    deterministic (under-)estimate rather than failing.
    """

    input_cost = usage.input_tokens / 1000 * (rates.input_per_1k or 0.0)
    output_cost = usage.output_tokens / 1000 * (rates.output_per_1k or 0.0)
    cache_read_cost = usage.cache_read_tokens / 1000 * (rates.cache_read_per_1k or 0.0)
    cache_write_cost = usage.cache_write_tokens / 1000 * (rates.cache_write_per_1k or 0.0)
    return EstimatedCost(
        input=input_cost,
        output=output_cost,
        cache_read=cache_read_cost,
        cache_write=cache_write_cost,
        total=input_cost + output_cost + cache_read_cost + cache_write_cost,
    )


class ModelDefaults(SdkModel):
    """Default parameters for a model."""

    temperature: float | None = None
    thinking_level: str | None = None


class ModelDescriptor(SdkModel):
    """Full descriptor for a model — provider, capabilities, cost, defaults."""

    provider: str
    model: str
    supports_tools: bool = True
    supports_streaming: bool = True
    supports_images: bool = False
    context_window: int | None = None
    max_output_tokens: int | None = None
    cost: ModelCost | None = None
    defaults: ModelDefaults | None = None
    metadata: JsonObject | None = None


ToolChoice = Literal["auto", "none", "required"]
ModelMessage = Message | AssistantMessage | ToolResultMessage


class ModelRequest(SdkModel):
    """Provider-neutral request passed to a model client."""

    messages: list[ModelMessage]
    tools: list[ToolDescriptor] = Field(default_factory=list)
    model: ModelDescriptor | None = None
    system: str | None = None
    max_output_tokens: int | None = None
    reasoning_max_tokens: int | None = Field(default=None, gt=0, strict=True)
    temperature: float | None = None
    tool_choice: ToolChoice = "auto"
    metadata: JsonObject | None = None


class ModelResponse(SdkModel):
    """Provider-neutral model response."""

    message: AssistantMessage
    usage: Usage | None = None
    stop_reason: str | None = None
    provider_response_id: str | None = None
    diagnostics: list[Diagnostic] | None = None
    metadata: JsonObject | None = None


class ModelStreamEvent(SdkModel):
    """Provider-neutral streaming event emitted by a model client."""

    type: Literal[
        "message_started",
        "message_delta",
        "message_completed",
        "tool_call_started",
        "tool_call_delta",
        "tool_call_completed",
        "usage_delta",
        "error",
    ]
    sequence: int | None = None
    delta: str | None = None
    message: AssistantMessage | None = None
    tool_call_id: str | None = None
    tool_name: str | None = None
    tool_arguments_delta: JsonObject | None = None
    usage: Usage | None = None
    stop_reason: str | None = None
    diagnostics: list[Diagnostic] | None = None
    metadata: JsonObject | None = None


@runtime_checkable
class ModelClient(Protocol):
    """Synchronous model-client protocol used by the SDK loop."""

    def generate(self, request: ModelRequest, cancellation: Cancellation) -> ModelResponse:
        """Generate one complete model response."""
        ...

    def stream(
        self,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> Iterable[ModelStreamEvent]:
        """Stream provider-neutral model events."""
        ...
