"""Run request, result, and event types (definitions.md §10, §12)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.context import Context
from cogit_agent_sdk.types.errors import ErrorInfo
from cogit_agent_sdk.types.records import ExecutionRecord
from cogit_agent_sdk.types.usage import RunBudget, Usage


class RunRequest(SdkModel):
    """Request to run an agent."""

    instruction: str
    input: dict[str, Any] | None = None
    context: Context
    mode: Literal["sync", "async"] = "sync"
    budget: RunBudget | None = None
    toolset: str | None = None
    pipeline: str | None = None
    # Typed as Any to avoid circular import with ModelDescriptor.
    # Callers should pass ModelDescriptor | None.
    model: Any | None = None
    metadata: dict[str, Any] | None = None


class WorkOutcome(SdkModel):
    """Business disposition for a durable processing item, separate from execution."""

    outcome: Literal["completed", "retry", "review_required", "paused"]
    reason_code: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z0-9_.-]+$")
    awaited_action_id: str | None = Field(default=None, min_length=1, max_length=128)


class RunResult(SdkModel):
    """Result of an agent run."""

    execution_record: ExecutionRecord
    output: Any | None = None
    status: Literal["completed", "failed", "partial", "cancelled", "waiting"]
    outcome_label: str | None = None
    usage: Usage | None = None
    error: ErrorInfo | None = None
    work_outcome: WorkOutcome | None = None


class RunEvent(SdkModel):
    """An event emitted during a run."""

    execution_id: str
    case_id: str | None = None
    sequence: int
    timestamp: datetime
    type: Literal[
        "run_started",
        "run_completed",
        "run_failed",
        "message_started",
        "message_delta",
        "message_completed",
        "tool_call_started",
        "tool_call_updated",
        "tool_call_completed",
        "step_recorded",
        "attention_required",
    ]
    payload: dict[str, Any] = Field(default_factory=dict)
