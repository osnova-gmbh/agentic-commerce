"""Portable capability names and resolved module-scoped grants.

These values are deliberately independent of AgentDb persistence and claims.
The host must supply fresh, authoritative active grants before an effect.
"""

from __future__ import annotations

import re
from typing import Annotated

from pydantic import ConfigDict, Field, field_validator

from cogit_agent_sdk.types._base import SdkModel, to_camel

CAPABILITY_PATTERN = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")


def validate_capability_name(value: str) -> str:
    if not CAPABILITY_PATTERN.fullmatch(value):
        raise ValueError(
            f"invalid capability {value!r}; expected dot-namespaced key like run.cancel"
        )
    return value


def validate_module_scope(value: str | None) -> str | None:
    if value is not None and (
        not value or value != value.strip() or len(value) > 256 or any(ch.isspace() for ch in value)
    ):
        raise ValueError("module_scope must be a nonempty module identifier or null")
    return value


class _ScopedCapability(SdkModel):
    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        extra="forbid",
        alias_generator=to_camel,
    )

    name: Annotated[
        str,
        Field(
            pattern=CAPABILITY_PATTERN.pattern,
            json_schema_extra={"not": {"pattern": r"\s"}},
        ),
    ]
    # Required on typed wire records. None denotes core/unscoped authority.
    module_scope: (
        Annotated[
            str,
            Field(
                min_length=1,
                max_length=256,
                pattern=r"^\S+$",
                json_schema_extra={"not": {"pattern": r"\s"}},
            ),
        ]
        | None
    )

    @field_validator("name")
    @classmethod
    def _validate_name(cls, value: str) -> str:
        return validate_capability_name(value)

    @field_validator("module_scope")
    @classmethod
    def _validate_scope(cls, value: str | None) -> str | None:
        return validate_module_scope(value)


class CapabilityRequirement(_ScopedCapability):
    """Operation requirement for one capability in one exact module scope."""


class CapabilityGrant(_ScopedCapability):
    """A resolved active grant supplied by the host for one exact scope."""


__all__ = ["CapabilityGrant", "CapabilityRequirement"]
