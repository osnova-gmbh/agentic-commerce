"""Knowledge types (definitions.md §25)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.context import Context


class KnowledgeHit(SdkModel):
    """A single knowledge search result."""

    content: str
    score: float | None = None
    source: str | None = None
    metadata: dict[str, Any] | None = None


class KnowledgeResult(SdkModel):
    """Result of a knowledge query."""

    hits: list[KnowledgeHit] = Field(default_factory=list)


class KnowledgeQuery(SdkModel):
    """Request to query a knowledge store."""

    query: str
    context: Context
    sources: list[str] | None = None
    filters: dict[str, Any] | None = None
    limit: int | None = None
