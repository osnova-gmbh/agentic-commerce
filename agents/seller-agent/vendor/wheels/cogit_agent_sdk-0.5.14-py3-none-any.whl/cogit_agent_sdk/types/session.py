"""Session shape (definitions.md §13)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.messages import Message


class Session(SdkModel):
    """A conversation session."""

    id: str
    tenant_id: str
    agent_id: str
    created_at: datetime
    updated_at: datetime
    messages: list[Message] = Field(default_factory=list)
    state: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
