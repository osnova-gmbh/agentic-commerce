"""Durable provider intent and evidence references, without dispatch credentials."""

from pydantic import ConfigDict, Field

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.artifacts import ArtifactRef


class ActionKey(SdkModel):
    """Immutable request commitment for Runtime-owned provider coordination."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    provider: str = Field(min_length=1, max_length=64)
    credential_account: str = Field(min_length=1, max_length=128)
    operation: str = Field(min_length=1, max_length=64)
    idempotency_key: str = Field(min_length=1, max_length=256)


class ActionIntent(ActionKey):
    """Immutable action input and explicitly authorized artifact attachments."""

    input_artifact: ArtifactRef
    input_attachments: tuple[ArtifactRef, ...] = Field(default=(), max_length=32)


class ActionRef(SdkModel):
    """Canonical action status with finalized provider evidence."""

    id: str = Field(min_length=1)
    state: str = Field(min_length=1)
    version: int = Field(ge=1)
    evidence: tuple[ArtifactRef, ...] = ()
    input_artifact: ArtifactRef | None = None
    input_attachments: tuple[ArtifactRef, ...] = ()
