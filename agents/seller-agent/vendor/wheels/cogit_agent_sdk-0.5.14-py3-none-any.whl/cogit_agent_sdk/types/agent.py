"""Agent descriptor and record types (definitions.md §17)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field, field_validator

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.actions import ActionDescriptor
from cogit_agent_sdk.types.database import DatabasePackageRequirement
from cogit_agent_sdk.types.model import ModelDescriptor
from cogit_agent_sdk.types.pipelines import PipelineDescriptor
from cogit_agent_sdk.types.schedule import ScheduleDescriptor
from cogit_agent_sdk.types.tools import ToolDescriptor, ToolsetDescriptor


class AgentDescriptor(SdkModel):
    """Typed form of cogit.yaml — the agent's declaration.

    Deliberately has NO organization membership (definitions.md §17.2).
    """

    id: str | None = None
    name: str
    version: str
    description: str
    actions: list[ActionDescriptor] = Field(default_factory=list)
    tools: list[ToolDescriptor] = Field(default_factory=list)
    toolsets: list[ToolsetDescriptor] | None = None
    pipelines: list[PipelineDescriptor] | None = None
    model: ModelDescriptor | None = None
    eval_suites: list[str] | None = None
    schedules: list[ScheduleDescriptor] | None = None
    metadata: dict[str, Any] | None = None
    database_packages: list[DatabasePackageRequirement] = Field(default_factory=list, max_length=32)

    @field_validator("database_packages")
    @classmethod
    def _unique_packages(
        cls, value: list[DatabasePackageRequirement]
    ) -> list[DatabasePackageRequirement]:
        if len({entry.module_key for entry in value}) != len(value):
            raise ValueError("Database packages must have unique module keys")
        return value


class AgentRecord(SdkModel):
    """Platform registration row for an agent.

    Unlike AgentDescriptor, this includes organization_ids
    (platform-assigned memberships).
    """

    id: str
    tenant_id: str
    name: str
    version: str
    status: Literal["active", "inactive", "creating", "failed", "archived"]
    endpoint: str | None = None
    descriptor: AgentDescriptor | None = None
    organization_ids: list[str] | None = None
    metadata: dict[str, Any] | None = None
