"""Execution records and step records (definitions.md §11).

Truncation limits enforced client-side:
- ExecutionRecord.input_summary: ≤200 chars
- ExecutionRecord.output_summary: ≤200 chars
- ExecutionStepRecord.summary: ≤150 chars
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Literal

from pydantic import field_validator

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.errors import ErrorInfo
from cogit_agent_sdk.types.usage import Usage

_MAX_INPUT_SUMMARY = 200
_MAX_OUTPUT_SUMMARY = 200
_MAX_STEP_SUMMARY = 150
_MAX_STEP_DATA_BYTES = 50 * 1024


def _truncate(value: str | None, limit: int) -> str | None:
    if value is None:
        return None
    if len(value) > limit:
        return value[: limit - 3] + "..."
    return value


class ExecutionRecord(SdkModel):
    """Record of an agent execution (run)."""

    id: str
    tenant_id: str
    organization_id: str | None = None
    agent_id: str
    case_id: str | None = None
    session_id: str | None = None
    trigger: str | None = None
    status: Literal["running", "waiting", "completed", "failed", "partial", "cancelled"]
    started_at: datetime
    completed_at: datetime | None = None
    input_summary: str | None = None
    output_summary: str | None = None
    outcome_label: str | None = None
    error: ErrorInfo | None = None
    usage: Usage | None = None
    metadata: dict[str, Any] | None = None

    @field_validator("input_summary")
    @classmethod
    def _truncate_input(cls, v: str | None) -> str | None:
        return _truncate(v, _MAX_INPUT_SUMMARY)

    @field_validator("output_summary")
    @classmethod
    def _truncate_output(cls, v: str | None) -> str | None:
        return _truncate(v, _MAX_OUTPUT_SUMMARY)


class ExecutionStepRecord(SdkModel):
    """Record of a single step within an execution."""

    id: str
    execution_id: str
    case_id: str | None = None
    order: int
    kind: Literal["model", "tool", "action", "retrieval", "system", "eval", "handoff"]
    name: str | None = None
    status: Literal["running", "completed", "failed", "skipped"]
    started_at: datetime
    completed_at: datetime | None = None
    summary: str | None = None
    data: dict[str, Any] | None = None
    error: ErrorInfo | None = None
    usage: Usage | None = None

    @field_validator("summary")
    @classmethod
    def _truncate_summary(cls, v: str | None) -> str | None:
        return _truncate(v, _MAX_STEP_SUMMARY)

    @field_validator("data")
    @classmethod
    def _truncate_data(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        if v is None:
            return None

        raw = json.dumps(v, ensure_ascii=False, default=str)
        raw_bytes = raw.encode("utf-8")
        if len(raw_bytes) <= _MAX_STEP_DATA_BYTES:
            return v

        preview = raw_bytes[:4096].decode("utf-8", errors="ignore")
        return {
            "__truncated__": True,
            "original_bytes": len(raw_bytes),
            "limit_bytes": _MAX_STEP_DATA_BYTES,
            "preview": preview,
        }
