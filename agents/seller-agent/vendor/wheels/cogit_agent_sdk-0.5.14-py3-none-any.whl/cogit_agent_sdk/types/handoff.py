"""Handoff type (definitions.md §23).

The 'from' field uses alias 'from' on the wire because 'from' is a
Python reserved word. The Python field name is 'from_participant'.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel


class Handoff(SdkModel):
    """A handoff between participants (agents, supervisors, humans)."""

    id: str
    from_participant: str = Field(alias="from")
    to: str
    related_execution_id: str | None = None
    related_case_id: str | None = None
    status: Literal["completed", "failed", "needs_attention"]
    summary: str
    evidence: dict[str, Any] | None = None
    outputs: dict[str, Any] | None = None
    error: str | None = None
    created_at: datetime
