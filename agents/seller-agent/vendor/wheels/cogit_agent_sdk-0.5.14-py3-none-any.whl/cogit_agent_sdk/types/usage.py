"""Usage and budget types (definitions.md §6, §10.4)."""

from __future__ import annotations

from pydantic import computed_field

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.context import AttemptToken


class EstimatedCost(SdkModel):
    """Breakdown of estimated monetary cost."""

    input: float = 0.0
    output: float = 0.0
    cache_read: float = 0.0
    cache_write: float = 0.0
    total: float = 0.0


class Usage(SdkModel):
    """Token usage for a model call or aggregate."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    estimated_cost: EstimatedCost | None = None
    model: str | None = None
    provider: str | None = None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def total_tokens(self) -> int:
        """Total tokens across all categories."""
        return (
            self.input_tokens
            + self.output_tokens
            + self.cache_read_tokens
            + self.cache_write_tokens
        )


class RunBudget(SdkModel):
    """Budget limits for a run."""

    max_iterations: int | None = None
    max_duration_seconds: int | None = None
    max_cost: float | None = None
    max_tool_calls: int | None = None


class ModelCallReservation(SdkModel):
    """Opaque reservation handle with budget limits."""

    id: str
    input_tokens: int
    output_tokens: int
    cost_budget: float
    attempt_token: AttemptToken | None = None


class ModelCallUsage(SdkModel):
    """Actual token counts and cost after provider dispatch."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    cost: float = 0.0
    model: str | None = None
    provider: str | None = None
