"""Feedback types linked to cases and runs."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from cogit_agent_sdk.types._base import SdkModel


class Feedback(SdkModel):
    """User or system feedback attached to a case or execution."""

    id: str
    tenant_id: str
    case_id: str | None = None
    execution_id: str | None = None
    rating: Literal["positive", "negative", "neutral"] | None = None
    score: float | None = None
    comment: str | None = None
    source: str | None = None
    created_at: datetime | None = None
    metadata: dict[str, Any] | None = None
