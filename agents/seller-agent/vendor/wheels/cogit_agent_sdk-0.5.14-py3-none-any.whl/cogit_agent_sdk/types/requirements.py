"""Shared operation execution requirements (Proposal 019)."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal, get_args

from cogit_agent_sdk.types.capabilities import (
    CapabilityGrant,
    CapabilityRequirement,
    validate_capability_name,
)

RiskLevel = Literal["read", "write", "financial", "external", "destructive"]
IdempotencyLevel = Literal["none", "inherent", "keyed"]

_VALID_RISKS = frozenset(get_args(RiskLevel))
_VALID_IDEMPOTENCY = frozenset(get_args(IdempotencyLevel))


CapabilityNeed = str | CapabilityRequirement
CapabilityAuthority = str | CapabilityGrant


def normalize_required_capabilities(values: Sequence[object]) -> tuple[CapabilityNeed, ...]:
    """Sort/dedupe requirements; legacy strings are core-only, never wildcards."""

    by_scope: dict[tuple[str, str | None], CapabilityNeed] = {}
    for value in values:
        if isinstance(value, str):
            name = validate_capability_name(value)
            scope = None
            canonical: CapabilityNeed = name
        elif isinstance(value, CapabilityRequirement):
            checked = CapabilityRequirement.model_validate(value.model_dump())
            name, scope = checked.name, checked.module_scope
            canonical = checked if scope is not None else name
        else:
            raise TypeError("required capabilities must be names or CapabilityRequirement values")
        by_scope[(name, scope)] = canonical
    return tuple(by_scope[key] for key in sorted(by_scope, key=lambda key: (key[0], key[1] or "")))


def missing_capabilities(
    required: Sequence[CapabilityNeed],
    granted: Sequence[object] | None,
) -> tuple[CapabilityRequirement, ...]:
    """Return exact name-and-scope requirements absent from resolved active grants."""

    normalized = normalize_required_capabilities(required)
    available: set[tuple[str, str | None]] = set()
    for value in granted or ():
        try:
            if isinstance(value, str):
                available.add((validate_capability_name(value), None))
            elif isinstance(value, CapabilityGrant):
                checked = CapabilityGrant.model_validate(value.model_dump())
                available.add((checked.name, checked.module_scope))
        except ValueError:
            # Malformed host data must not grant authority.
            continue
    missing: list[CapabilityRequirement] = []
    for value in normalized:
        name, scope = (value, None) if isinstance(value, str) else (value.name, value.module_scope)
        if (name, scope) not in available:
            missing.append(CapabilityRequirement(name=name, module_scope=scope))
    return tuple(missing)


class CapabilityDenied(PermissionError):
    """A protected operation lacks one or more exact resolved grants."""

    def __init__(self, missing: tuple[CapabilityRequirement, ...]) -> None:
        self.missing = missing
        super().__init__("Required operation capability is not granted")


def require_capabilities(
    required: Sequence[CapabilityNeed],
    granted: Sequence[object] | None,
) -> None:
    """Fail closed on missing authority; callers must supply fresh canonical grants."""

    missing = missing_capabilities(required, granted)
    if missing:
        raise CapabilityDenied(missing)


@dataclass(frozen=True)
class OperationRequirements:
    """Immutable enforcement fields shared by action and tool descriptors."""

    risk: RiskLevel
    idempotency: IdempotencyLevel
    required_capabilities: tuple[CapabilityNeed, ...]
    requires_approval: bool

    def __post_init__(self) -> None:
        if self.risk not in _VALID_RISKS:
            raise ValueError(f"invalid risk level {self.risk!r}")
        if self.idempotency not in _VALID_IDEMPOTENCY:
            raise ValueError(f"invalid idempotency level {self.idempotency!r}")
        if type(self.requires_approval) is not bool:
            raise TypeError("requires_approval must be a boolean")
        canonical = tuple(
            item.name
            if isinstance(item, CapabilityRequirement) and item.module_scope is None
            else item
            for item in self.required_capabilities
        )
        normalized = normalize_required_capabilities(canonical)
        if normalized != canonical:
            raise ValueError("required_capabilities must be sorted and unique")
        object.__setattr__(self, "required_capabilities", normalized)
