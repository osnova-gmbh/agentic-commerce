"""Case type (definitions.md §14)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from cogit_agent_sdk.types._base import SdkModel


class Case(SdkModel):
    """A business case — long-running work tracked across executions."""

    id: str
    tenant_id: str
    organization_id: str | None = None
    agent_id: str | None = None
    source_type: Literal["email", "nfon", "telegram", "api", "manual", "improvement", "custom"]
    source_id: str
    status: Literal[
        "pending",
        "processing",
        "waiting_for_approval",
        "waiting_for_input",
        "succeeded",
        "retrying",
        "failed",
        "cancelled",
    ]
    current_goal: str | None = None
    process_id: str | None = None
    process_version: str | None = None
    assigned_agent_ids: list[str] | None = None
    owner: str | None = None
    retry_count: int = 0
    next_retry_at: datetime | None = None
    last_attempt_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    completed_at: datetime | None = None
    final_outcome: str | None = None
    error: str | None = None
    metadata: dict[str, Any] | None = None
