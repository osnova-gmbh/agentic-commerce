"""Eval record types (definitions.md §19)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel


class CheckResult(SdkModel):
    """Result of a single eval check."""

    check: str
    passed: bool
    score: float | None = None
    detail: str | None = None


class EvalItemResult(SdkModel):
    """Result for a single eval item."""

    item_id: str
    passed: bool
    score: float | None = None
    checks: list[CheckResult] = Field(default_factory=list)
    output: Any | None = None
    error: str | None = None


class EvalRecord(SdkModel):
    """Record of an evaluation suite run."""

    id: str
    tenant_id: str | None = None
    organization_id: str | None = None
    agent_id: str
    agent_version: str | None = None
    suite_name: str
    started_at: datetime
    completed_at: datetime | None = None
    status: Literal["running", "completed", "failed"]
    items_total: int = 0
    items_passed: int = 0
    score: float | None = None
    results: list[EvalItemResult] = Field(default_factory=list)
    metadata: dict[str, Any] | None = None
