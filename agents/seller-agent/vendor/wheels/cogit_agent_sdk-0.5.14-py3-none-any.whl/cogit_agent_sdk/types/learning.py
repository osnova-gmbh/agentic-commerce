"""Learning record types (definitions.md §20)."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel


class LearningSource(SdkModel):
    """Source of a learning entry."""

    kind: Literal["execution", "eval", "user_feedback", "experiment", "manual"]
    id: str


class LearningRecord(SdkModel):
    """A captured learning — tied to an agent."""

    id: str
    agent_id: str
    tenant_id: str | None = None
    organization_id: str | None = None
    source: LearningSource
    title: str
    body: str
    tags: list[str] = Field(default_factory=list)
    status: Literal["active", "superseded", "rejected"] = "active"
    created_at: datetime
