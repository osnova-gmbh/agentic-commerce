"""ErrorInfo type (definitions.md §26).

Error messages are truncated to 500 characters client-side.
"""

from __future__ import annotations

from typing import Any

from pydantic import field_validator

from cogit_agent_sdk.types._base import SdkModel

_MAX_ERROR_MESSAGE_LEN = 500


class ErrorInfo(SdkModel):
    """Typed error container — embeds in results, records, events, handoffs."""

    code: str
    message: str
    retryable: bool | None = None
    details: dict[str, Any] | None = None

    @field_validator("message")
    @classmethod
    def _truncate_message(cls, v: str) -> str:
        if len(v) > _MAX_ERROR_MESSAGE_LEN:
            return v[: _MAX_ERROR_MESSAGE_LEN - 3] + "..."
        return v
