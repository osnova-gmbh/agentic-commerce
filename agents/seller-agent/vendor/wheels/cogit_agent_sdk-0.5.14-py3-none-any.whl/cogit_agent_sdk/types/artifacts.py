"""Artifact reference types (definitions.md §16)."""

from __future__ import annotations

from typing import Any

from cogit_agent_sdk.types._base import SdkModel


class ArtifactRef(SdkModel):
    """Reference to an artifact (file, attachment, blob)."""

    id: str
    name: str | None = None
    mime_type: str | None = None
    size: int | None = None
    uri: str | None = None
    metadata: dict[str, Any] | None = None


class ArtifactSlot(SdkModel):
    """Pre-declared artifact placeholder with kind and metadata."""

    id: str
    kind: str
    media_type: str
    filename: str
    metadata: dict[str, Any] | None = None
