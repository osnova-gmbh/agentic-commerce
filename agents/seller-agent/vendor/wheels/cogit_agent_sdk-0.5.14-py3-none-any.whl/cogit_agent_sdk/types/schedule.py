"""Schedule descriptor types (definitions.md §24)."""

from __future__ import annotations

from typing import Any, Literal

from cogit_agent_sdk.types._base import SdkModel


class ScheduleDescriptor(SdkModel):
    """Declaration of a scheduled task for an agent."""

    name: str
    enabled: bool = True
    prompt_or_instruction: str
    interval_seconds: int | None = None
    cron: str | None = None
    timezone: str | None = None
    mode: Literal["single", "fanout"] = "single"
    metadata: dict[str, Any] | None = None
