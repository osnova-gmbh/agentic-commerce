"""Query request and result types (definitions.md §18)."""

from __future__ import annotations

from typing import Any

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.context import Context
from cogit_agent_sdk.types.errors import ErrorInfo
from cogit_agent_sdk.types.records import ExecutionStepRecord
from cogit_agent_sdk.types.runs import RunEvent
from cogit_agent_sdk.types.usage import Usage


class QueryRequest(SdkModel):
    """Request to query an agent."""

    query: str
    context: Context
    include_trace: bool = False
    options: dict[str, Any] | None = None


class QueryResult(SdkModel):
    """Result of a query."""

    answer: str | None = None
    interpretation: str | None = None
    data: Any | None = None
    components: list[dict[str, Any]] | None = None
    trace: list[ExecutionStepRecord | RunEvent] | None = None
    usage: Usage | None = None
    error: ErrorInfo | None = None
