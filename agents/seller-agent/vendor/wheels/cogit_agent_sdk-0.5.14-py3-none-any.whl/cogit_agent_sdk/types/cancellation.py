"""Cancellation protocol shared by model clients, tools, and loop execution."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class Cancellation(Protocol):
    """Cooperative cancellation signal passed through long-running work."""

    @property
    def cancelled(self) -> bool:
        """Whether cancellation has been requested."""
        ...

    def throw_if_cancelled(self) -> None:
        """Raise the implementation's cancellation error when cancelled."""
        ...
