"""Recursive immutable JSON container types for ActionDescriptor fields."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any, SupportsIndex


class ImmutableStructureError(TypeError):
    """Raised when an immutable JSON container is mutated in place."""


def _immutable_error(container: str, operation: str) -> ImmutableStructureError:
    return ImmutableStructureError(f"{container} does not support {operation}")


class FrozenDict(dict[str, Any]):
    """Dict subclass that recursively freezes nested JSON structures."""

    def __init__(self, mapping: Mapping[str, Any] | None = None, /, **kwargs: Any) -> None:
        super().__init__()
        if mapping is not None:
            for key, value in mapping.items():
                dict.__setitem__(self, key, freeze_value(value))
        for key, value in kwargs.items():
            dict.__setitem__(self, key, freeze_value(value))

    def __setitem__(self, key: str, value: Any) -> None:
        raise _immutable_error("FrozenDict", "__setitem__")

    def __delitem__(self, key: str) -> None:
        raise _immutable_error("FrozenDict", "__delitem__")

    def update(self, *args: Any, **kwargs: Any) -> None:
        raise _immutable_error("FrozenDict", "update")

    def pop(self, *args: Any, **kwargs: Any) -> Any:
        raise _immutable_error("FrozenDict", "pop")

    def popitem(self) -> tuple[str, Any]:
        raise _immutable_error("FrozenDict", "popitem")

    def clear(self) -> None:
        raise _immutable_error("FrozenDict", "clear")

    def setdefault(self, key: str, default: Any = None) -> Any:
        raise _immutable_error("FrozenDict", "setdefault")

    def __ior__(self, other: Any) -> FrozenDict:
        raise _immutable_error("FrozenDict", "__ior__")


class FrozenList(list[Any]):
    """List subclass that recursively freezes nested JSON structures."""

    def __init__(self, iterable: Iterable[Any] | None = None) -> None:
        super().__init__()
        if iterable is not None:
            for item in iterable:
                list.append(self, freeze_value(item))

    def __setitem__(self, index: Any, value: Any) -> None:
        raise _immutable_error("FrozenList", "__setitem__")

    def __delitem__(self, index: Any) -> None:
        raise _immutable_error("FrozenList", "__delitem__")

    def append(self, item: Any) -> None:
        raise _immutable_error("FrozenList", "append")

    def extend(self, items: Iterable[Any]) -> None:
        raise _immutable_error("FrozenList", "extend")

    def insert(self, index: SupportsIndex, item: Any) -> None:
        raise _immutable_error("FrozenList", "insert")

    def remove(self, item: Any) -> None:
        raise _immutable_error("FrozenList", "remove")

    def pop(self, *args: Any) -> Any:
        raise _immutable_error("FrozenList", "pop")

    def clear(self) -> None:
        raise _immutable_error("FrozenList", "clear")

    def sort(self, *args: Any, **kwargs: Any) -> None:
        raise _immutable_error("FrozenList", "sort")

    def reverse(self) -> None:
        raise _immutable_error("FrozenList", "reverse")

    def __iadd__(self, other: Any) -> FrozenList:
        raise _immutable_error("FrozenList", "__iadd__")


def freeze_value(value: Any) -> Any:
    """Return a recursively frozen JSON-compatible value."""

    if isinstance(value, FrozenDict):
        return value
    if isinstance(value, FrozenList):
        return value
    if isinstance(value, dict):
        return FrozenDict(value)
    if isinstance(value, list):
        return FrozenList(value)
    return value


def thaw_value(value: Any) -> Any:
    """Convert frozen JSON containers back to plain dict/list trees."""

    if isinstance(value, FrozenDict):
        return {key: thaw_value(item) for key, item in value.items()}
    if isinstance(value, FrozenList):
        return [thaw_value(item) for item in value]
    if isinstance(value, dict):
        return {key: thaw_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [thaw_value(item) for item in value]
    return value
