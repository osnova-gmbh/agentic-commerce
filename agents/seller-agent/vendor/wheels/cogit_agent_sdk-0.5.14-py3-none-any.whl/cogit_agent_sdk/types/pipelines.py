"""Pipeline descriptor types (definitions.md §9)."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from cogit_agent_sdk.types._base import SdkModel


class PipelineStep(SdkModel):
    """A single step in a pipeline."""

    id: str
    kind: Literal["deterministic", "agentic", "terminal"]
    invoke: str | None = None
    instruction: str | None = None
    input_from: str | None = None
    output_to: str | None = None
    timeout_seconds: int | None = None
    on_failure: Literal["fail_run", "continue", "escalate"] = "fail_run"


class PipelineDescriptor(SdkModel):
    """Declaration of a processing pipeline."""

    name: str
    description: str | None = None
    applies_to: list[str] | None = None
    steps: list[PipelineStep] = Field(default_factory=list)
    on_failure: Literal["fail_run", "continue", "escalate"] = "fail_run"
