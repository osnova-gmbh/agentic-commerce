"""Inert policy checkpoints and receipts; authority belongs to the host service.

These types carry commitments, never executable policy or self-issued grants.
An agent-provided loop hook cannot replace the host's policy enforcement.
"""

from __future__ import annotations

from typing import Annotated, Literal, Self

from pydantic import ConfigDict, Field, model_validator

from cogit_agent_sdk.types._base import SdkModel, to_camel
from cogit_agent_sdk.types.capabilities import CapabilityRequirement
from cogit_agent_sdk.types.requirements import IdempotencyLevel, RiskLevel

PolicyPhase = Literal["pre_run", "checkpoint", "post_run", "pre_tool", "post_tool"]
PolicyEffect = Literal["allow", "deny", "require_approval"]
EffectState = Literal["not_started", "completed", "failed", "unknown"]
_Identifier = Annotated[str, Field(strict=True, min_length=1, max_length=256)]
_Sha256 = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]


class _PolicyValue(SdkModel):
    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        populate_by_name=True,
        alias_generator=to_camel,
    )


class PolicyRef(_PolicyValue):
    """Canonical AgentDB evaluation provenance, without a policy body."""

    policy_version_id: _Identifier
    binding_id: _Identifier
    binding_version: Annotated[int, Field(strict=True, ge=1)]
    evaluation_id: _Identifier
    outcome: Literal["allowed", "denied", "not_applicable"]
    reason_code: _Identifier


class PolicyOperation(_PolicyValue):
    """Intrinsic requirements; none of these declarations grant permission."""

    kind: Literal["run", "action", "tool"]
    name: _Identifier
    agent_version: _Identifier
    descriptor_sha256: _Sha256
    risk: RiskLevel
    idempotency: IdempotencyLevel
    required_capabilities: tuple[CapabilityRequirement, ...] = Field(max_length=128)
    requires_approval: Annotated[bool, Field(strict=True)]


class PolicyCheckpoint(_PolicyValue):
    """Host-created commitment to an operation, its input and observed outcome."""

    checkpoint_id: _Identifier
    phase: PolicyPhase
    operation: PolicyOperation
    manifest_sha256: _Sha256
    input_sha256: _Sha256
    result_sha256: _Sha256 | None = None
    effect_state: EffectState

    @model_validator(mode="after")
    def _validate_phase(self) -> Self:
        if self.phase in {"pre_run", "pre_tool"} and self.effect_state != "not_started":
            raise ValueError("pre-effect checkpoints must have not_started effect state")
        if self.phase in {"post_run", "post_tool"} and self.effect_state == "not_started":
            raise ValueError("post-effect checkpoints must describe observed effect state")
        if self.phase in {"pre_tool", "post_tool"} and self.operation.kind == "run":
            raise ValueError("tool checkpoints require an action or tool operation")
        if self.phase in {"pre_run", "post_run"} and self.operation.kind != "run":
            raise ValueError("run checkpoints require a run operation")
        return self


class PolicySubject(_PolicyValue):
    """Server-derived identity, bound to the current fenced worker execution."""

    tenant_id: _Identifier
    principal_id: _Identifier
    installation_id: _Identifier
    run_id: _Identifier
    execution_id: _Identifier
    attempt_id: _Identifier
    generation: Annotated[int, Field(strict=True, ge=1, le=2147483647)]


class ApprovalRequirement(_PolicyValue):
    """Exact checkpoint requiring the existing canonical human-decision flow."""

    checkpoint_sha256: _Sha256
    reason_code: _Identifier


class AuthorizationDecision(_PolicyValue):
    """Actual module receipt; no fabricated expiry, grants or allow fallback.

    Every use is evaluated afresh against live attempt/grant authority. Policy
    revisions remain the immutable versions admitted with the run.
    """

    decision_id: _Identifier
    effect: PolicyEffect
    subject: PolicySubject
    checkpoint_sha256: _Sha256
    policy_refs: tuple[PolicyRef, ...] = Field(min_length=1, max_length=128)
    reason_code: _Identifier
