"""Portable policy port; the SDK never evaluates or defaults to allow."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types.policy import AuthorizationDecision, PolicyCheckpoint


class PolicyUnavailableError(CoordinationFailure):
    """The required authority could not issue a confirmed policy receipt."""


@runtime_checkable
class PolicyCheckpointHandle(Protocol):
    def evaluate_policy(self, checkpoint: PolicyCheckpoint) -> AuthorizationDecision:
        """Ask the bound host authority; callers cannot supply grants or policy."""
        ...


class PolicySeams:
    """Default handle behavior is unavailable, never descriptor-only permission."""

    def evaluate_policy(self, checkpoint: PolicyCheckpoint) -> AuthorizationDecision:
        raise PolicyUnavailableError("The host policy authority is unavailable")
