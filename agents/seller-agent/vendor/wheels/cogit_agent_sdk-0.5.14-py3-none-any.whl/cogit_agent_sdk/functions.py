"""Function registry and module/package loader (Proposal 010/019).

A ``FunctionRegistry`` holds named, validated callables that an agent can
dispatch dynamically. Typed :meth:`FunctionRegistry.dispatch_operation` and
:meth:`FunctionRegistry.describe_operation` expose tool-only bindings through
:meth:`FunctionRegistry.as_dispatch_tool_binding` and
:meth:`FunctionRegistry.as_describe_tool_binding`.
"""

from __future__ import annotations

import importlib
import pkgutil
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError, model_validator

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.operations.binding import bind_tool, operation
from cogit_agent_sdk.operations.contract import OperationContract, OperationInvocation
from cogit_agent_sdk.operations.tool_binding import ToolBinding

__all__ = [
    "DescribeFunctionInput",
    "DescribeFunctionOutput",
    "DuplicateFunctionError",
    "FunctionDispatchError",
    "FunctionExecutionError",
    "FunctionNotFoundError",
    "FunctionOutputError",
    "FunctionParameter",
    "FunctionRegistry",
    "FunctionValidationError",
    "RunFunctionInput",
    "RunFunctionOutput",
    "function",
]


# Attribute attached by the ``@function`` decorator; ``load_module`` /
# ``load_package`` look for it when scanning a module namespace.
_FUNCTION_META_ATTR = "__cogit_function_meta__"

# Built-in JSON-ish scalar/compound type names supported by the lightweight
# ``parameters`` validator. Anything else is treated as an opaque type and
# skipped by the runtime type check (callers should use ``input_model`` for
# richer validation).
_TYPE_CHECKS: dict[str, type] = {
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "list": list,
}


# ---------------------------------------------------------------------------
# Typed function-registry operation models
# ---------------------------------------------------------------------------


class FunctionDispatchError(BaseModel):
    """Stable failure payload for function-registry operations."""

    code: Literal[
        "FUNCTION_NOT_FOUND",
        "VALIDATION_ERROR",
        "EXECUTION_ERROR",
        "OUTPUT_ERROR",
        "INVALID_INPUT",
    ]
    message: str
    available_functions: list[str] | None = None


class RunFunctionInput(BaseModel):
    function_name: str
    parameters: dict[str, Any] = Field(default_factory=dict)


class RunFunctionOutput(BaseModel):
    result: Any | None = None
    error: FunctionDispatchError | None = None

    @model_validator(mode="after")
    def _validate_outcome(self) -> RunFunctionOutput:
        if self.error is not None and self.result is not None:
            raise ValueError("RunFunctionOutput cannot include both result and error")
        if self.error is None and self.result is None:
            # Allow explicit null results from registered functions.
            return self
        return self


class DescribeFunctionInput(BaseModel):
    function_name: str


class DescribeFunctionOutput(BaseModel):
    name: str | None = None
    description: str | None = None
    category: str | None = None
    parameters: list[dict[str, Any]] | None = None
    examples: list[Any] | None = None
    error: FunctionDispatchError | None = None

    @model_validator(mode="after")
    def _validate_outcome(self) -> DescribeFunctionOutput:
        if self.error is not None:
            if any(
                value is not None
                for value in (
                    self.name,
                    self.description,
                    self.category,
                    self.parameters,
                    self.examples,
                )
            ):
                raise ValueError("DescribeFunctionOutput error outcome cannot include metadata")
            return self
        if self.name is None:
            raise ValueError("DescribeFunctionOutput success outcome requires name")
        return self


# ---------------------------------------------------------------------------
# Value types
# ---------------------------------------------------------------------------


@dataclass
class FunctionParameter:
    """Declarative description of a single registry-function parameter."""

    name: str
    type: str
    required: bool = True
    description: str | None = None
    enum: list[str] | None = None
    default: Any = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict, omitting unset optional fields."""

        result: dict[str, Any] = {
            "name": self.name,
            "type": self.type,
            "required": self.required,
        }
        if self.description is not None:
            result["description"] = self.description
        if self.enum is not None:
            result["enum"] = list(self.enum)
        if self.default is not None:
            result["default"] = self.default
        return result


@dataclass
class _FunctionMeta:
    """Metadata captured by the ``@function`` decorator (not registered at import)."""

    name: str
    function: Callable[..., Any]
    description: str
    category: str | None = None
    parameters: list[FunctionParameter] = field(default_factory=list)
    examples: list[Any] = field(default_factory=list)
    input_model: type[BaseModel] | None = None
    output_model: type[BaseModel] | None = None


@dataclass
class _FunctionEntry:
    """Internal stored representation of a registered function."""

    name: str
    function: Callable[..., Any]
    description: str
    category: str | None
    parameters: list[FunctionParameter]
    examples: list[Any]
    input_model: type[BaseModel] | None
    output_model: type[BaseModel] | None
    module: str | None


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class DuplicateFunctionError(Exception):
    """Raised when a function name is registered more than once."""

    def __init__(
        self,
        name: str,
        *,
        existing_module: str | None = None,
        conflicting_module: str | None = None,
    ) -> None:
        self.name = name
        self.existing_module = existing_module
        self.conflicting_module = conflicting_module
        if existing_module is not None and conflicting_module is not None:
            message = (
                f"Function {name!r} is already registered (from module "
                f"{existing_module!r}); refusing to re-register from module "
                f"{conflicting_module!r}."
            )
        else:
            message = f"Function {name!r} is already registered."
        super().__init__(message)


class FunctionNotFoundError(Exception):
    """Raised when an unknown function name is looked up."""

    def __init__(self, name: str, *, available_functions: list[str] | None = None) -> None:
        self.name = name
        self.available_functions = list(available_functions or [])
        if self.available_functions:
            message = (
                f"Function {name!r} is not registered. Available: "
                f"{', '.join(self.available_functions)}"
            )
        else:
            message = f"Function {name!r} is not registered."
        super().__init__(message)


class FunctionValidationError(Exception):
    """Raised when arguments supplied to a function fail declared validation."""

    def __init__(self, name: str, parameter: str, reason: str) -> None:
        self.name = name
        self.parameter = parameter
        self.reason = reason
        super().__init__(
            f"Validation failed for function {name!r}, parameter {parameter!r}: {reason}",
        )


class FunctionOutputError(Exception):
    """Raised when a function's return value fails its declared output model."""

    def __init__(self, name: str, reason: str) -> None:
        self.name = name
        self.reason = reason
        super().__init__(f"Output validation failed for function {name!r}: {reason}")


class FunctionExecutionError(Exception):
    """Raised when the underlying function raises; wraps the original cause."""

    def __init__(self, name: str, cause: BaseException) -> None:
        self.name = name
        self.cause = cause
        super().__init__(
            f"Function {name!r} raised {type(cause).__name__}: {cause}",
        )


# ---------------------------------------------------------------------------
# Decorator
# ---------------------------------------------------------------------------


_FunctionT = Callable[..., Any]


def function(
    name: str | None = None,
    *,
    description: str = "",
    category: str | None = None,
    parameters: list[FunctionParameter] | None = None,
    examples: list[Any] | None = None,
    input_model: type[BaseModel] | None = None,
    output_model: type[BaseModel] | None = None,
) -> Callable[[_FunctionT], _FunctionT]:
    """Attach registry metadata to a callable without registering it.

    Import-time side-effect free: the callable is returned unchanged except
    for a ``__cogit_function_meta__`` attribute. ``FunctionRegistry``
    discovers it later via ``load_module`` / ``load_package``.
    """

    def decorate(func: _FunctionT) -> _FunctionT:
        meta = _FunctionMeta(
            name=name or getattr(func, "__name__", "function"),
            function=func,
            description=description,
            category=category,
            parameters=list(parameters or []),
            examples=list(examples or []),
            input_model=input_model,
            output_model=output_model,
        )
        setattr(func, _FUNCTION_META_ATTR, meta)
        return func

    return decorate


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def _serialize_result(value: Any) -> Any:
    """Defensively coerce a non-JSON-native result to a JSON-friendly shape."""

    dump = getattr(value, "model_dump", None)
    if callable(dump):
        return dump()
    return value


class FunctionRegistry:
    """In-memory registry of named, validated callables."""

    def __init__(self) -> None:
        self._functions: dict[str, _FunctionEntry] = {}
        self._categories: dict[str, list[str]] = {}

    # -- registration --------------------------------------------------------

    def register(
        self,
        *,
        name: str,
        function: Callable[..., Any],
        description: str,
        category: str | None = None,
        parameters: list[FunctionParameter] | None = None,
        examples: list[Any] | None = None,
        input_model: type[BaseModel] | None = None,
        output_model: type[BaseModel] | None = None,
    ) -> None:
        """Register a callable under ``name`` with its metadata.

        Raises :class:`DuplicateFunctionError` if ``name`` is already
        registered. ``category`` is a secondary listing index only and is not
        part of the lookup key.
        """

        if name in self._functions:
            existing = self._functions[name]
            raise DuplicateFunctionError(
                name,
                existing_module=existing.module,
                conflicting_module=getattr(function, "__module__", None),
            )

        entry = _FunctionEntry(
            name=name,
            function=function,
            description=description,
            category=category,
            parameters=list(parameters or []),
            examples=list(examples or []),
            input_model=input_model,
            output_model=output_model,
            module=getattr(function, "__module__", None),
        )
        self._functions[name] = entry
        if category is not None:
            self._categories.setdefault(category, []).append(name)

    # -- lookup / execution --------------------------------------------------

    def call(self, name: str, /, **kwargs: Any) -> Any:
        """Validate arguments and invoke a registered function by name."""

        entry = self._functions.get(name)
        if entry is None:
            raise FunctionNotFoundError(name, available_functions=self.list_functions())

        self._validate_parameters(entry, kwargs)
        self._validate_input_model(entry, kwargs)

        try:
            result = entry.function(**kwargs)
        except CoordinationFailure:
            raise
        except Exception as exc:
            raise FunctionExecutionError(name, exc) from exc

        self._validate_output_model(entry, result)
        return result

    def _validate_parameters(self, entry: _FunctionEntry, kwargs: dict[str, Any]) -> None:
        if not entry.parameters:
            return
        declared = {param.name: param for param in entry.parameters}

        for param_name, param in declared.items():
            if param.required and param_name not in kwargs:
                raise FunctionValidationError(entry.name, param_name, "missing required parameter")

        for key, value in kwargs.items():
            param = declared.get(key)
            if param is None:
                raise FunctionValidationError(entry.name, key, "unknown parameter")
            self._check_value(entry.name, param, value)

    @staticmethod
    def _check_value(name: str, param: FunctionParameter, value: Any) -> None:
        if value is None:
            return
        expected = _TYPE_CHECKS.get(param.type)
        if expected is not None and not isinstance(value, expected):
            raise FunctionValidationError(
                name,
                param.name,
                f"expected type {param.type}, got {type(value).__name__}",
            )
        if param.enum is not None and value not in param.enum:
            raise FunctionValidationError(
                name,
                param.name,
                f"value {value!r} is not one of the allowed values {param.enum}",
            )

    @staticmethod
    def _validate_input_model(entry: _FunctionEntry, kwargs: dict[str, Any]) -> None:
        if entry.input_model is None:
            return
        try:
            entry.input_model.model_validate(kwargs)
        except ValidationError as exc:
            raise FunctionValidationError(
                entry.name,
                "<input_model>",
                str(exc),
            ) from exc

    @staticmethod
    def _validate_output_model(entry: _FunctionEntry, result: Any) -> None:
        if entry.output_model is None:
            return
        try:
            if not isinstance(result, entry.output_model):
                entry.output_model.model_validate(result)
        except ValidationError as exc:
            raise FunctionOutputError(entry.name, str(exc)) from exc

    # -- introspection -------------------------------------------------------

    def describe(self, name: str) -> dict[str, Any]:
        """Return the registered metadata for ``name`` as a dict."""

        entry = self._functions.get(name)
        if entry is None:
            raise FunctionNotFoundError(name, available_functions=self.list_functions())
        return {
            "name": entry.name,
            "description": entry.description,
            "category": entry.category,
            "parameters": [param.to_dict() for param in entry.parameters],
            "examples": list(entry.examples),
        }

    def list_functions(self, category: str | None = None) -> list[str]:
        """List registered names, optionally filtered by category."""

        if category is None:
            return sorted(self._functions)
        return sorted(self._categories.get(category, []))

    # -- loading from modules/packages ---------------------------------------

    def load_module(self, module_path: str) -> None:
        """Import ``module_path`` and register every ``@function`` it defines."""

        module = importlib.import_module(module_path)
        self._register_from_module(module)

    def load_package(self, package_path: str) -> None:
        """Import every submodule of ``package_path`` and register their functions."""

        package = importlib.import_module(package_path)
        package_path_attr = getattr(package, "__path__", None)
        if package_path_attr is None:
            # A plain module was given — treat it like load_module.
            self._register_from_module(package)
            return

        for _finder, child_name, is_pkg in pkgutil.iter_modules(package_path_attr):
            full_name = f"{package_path}.{child_name}"
            if is_pkg:
                self.load_package(full_name)
            else:
                module = importlib.import_module(full_name)
                self._register_from_module(module)

    def _register_from_module(self, module: Any) -> None:
        module_name = getattr(module, "__name__", None)
        for attr_name in dir(module):
            if attr_name.startswith("_"):
                continue
            obj = getattr(module, attr_name, None)
            meta = getattr(obj, _FUNCTION_META_ATTR, None)
            if not isinstance(meta, _FunctionMeta):
                continue
            # Only register callables *defined* in this module, not ones it
            # merely imported, so that re-scanning cannot create phantoms.
            if getattr(obj, "__module__", None) != module_name:
                continue
            self._register_from_meta(meta)

    def _register_from_meta(self, meta: _FunctionMeta) -> None:
        self.register(
            name=meta.name,
            function=meta.function,
            description=meta.description,
            category=meta.category,
            parameters=meta.parameters,
            examples=meta.examples,
            input_model=meta.input_model,
            output_model=meta.output_model,
        )

    # -- typed operation / tool builders -------------------------------------

    def dispatch_operation(self) -> OperationContract[RunFunctionInput, RunFunctionOutput]:
        """Return the typed run-function operation for tool-only exposure."""

        registry = self

        def _dispatch(
            request: RunFunctionInput,
            invocation: OperationInvocation,
        ) -> RunFunctionOutput:
            try:
                result = registry.call(request.function_name, **request.parameters)
            except CoordinationFailure:
                raise
            except FunctionNotFoundError as exc:
                return RunFunctionOutput(
                    error=FunctionDispatchError(
                        code="FUNCTION_NOT_FOUND",
                        message=f"Function {request.function_name!r} is not registered",
                        available_functions=list(exc.available_functions),
                    ),
                )
            except FunctionValidationError:
                return RunFunctionOutput(
                    error=FunctionDispatchError(
                        code="VALIDATION_ERROR",
                        message="Function arguments failed validation",
                    ),
                )
            except FunctionExecutionError:
                return RunFunctionOutput(
                    error=FunctionDispatchError(
                        code="EXECUTION_ERROR",
                        message="Function execution failed",
                    ),
                )
            except FunctionOutputError:
                return RunFunctionOutput(
                    error=FunctionDispatchError(
                        code="OUTPUT_ERROR",
                        message="Function output failed validation",
                    ),
                )
            return RunFunctionOutput(result=_serialize_result(result))

        return operation(_dispatch)

    def describe_operation(
        self,
    ) -> OperationContract[DescribeFunctionInput, DescribeFunctionOutput]:
        """Return the typed describe-function operation for tool-only exposure."""

        registry = self

        def _describe(
            request: DescribeFunctionInput,
            invocation: OperationInvocation,
        ) -> DescribeFunctionOutput:
            try:
                described = registry.describe(request.function_name)
            except FunctionNotFoundError as exc:
                return DescribeFunctionOutput(
                    error=FunctionDispatchError(
                        code="FUNCTION_NOT_FOUND",
                        message=f"Function {request.function_name!r} is not registered",
                        available_functions=list(exc.available_functions),
                    ),
                )
            return DescribeFunctionOutput(
                name=described["name"],
                description=described["description"],
                category=described["category"],
                parameters=list(described["parameters"]),
                examples=list(described["examples"]),
            )

        return operation(_describe)

    def as_dispatch_tool_binding(
        self,
        name: str = "run_function",
        *,
        description: str | None = None,
        execution_mode: Literal["parallel", "sequential"] = "parallel",
        timeout_seconds: int | None = None,
    ) -> ToolBinding[RunFunctionInput, RunFunctionOutput]:
        """Build a tool-only binding that dispatches registered functions by name."""

        resolved_description = description or (
            "Dispatch a registered function by name with a parameters object."
        )
        return bind_tool(
            self.dispatch_operation(),
            name=name,
            description=resolved_description,
            risk="read",
            idempotency="inherent",
            execution_mode=execution_mode,
            timeout_seconds=timeout_seconds,
        )

    def as_describe_tool_binding(
        self,
        name: str = "describe_function",
        *,
        description: str | None = None,
        execution_mode: Literal["parallel", "sequential"] = "parallel",
        timeout_seconds: int | None = None,
    ) -> ToolBinding[DescribeFunctionInput, DescribeFunctionOutput]:
        """Build a tool-only binding that describes registered functions by name."""

        resolved_description = description or (
            "Describe a registered function by name, including its parameters."
        )
        return bind_tool(
            self.describe_operation(),
            name=name,
            description=resolved_description,
            risk="read",
            idempotency="inherent",
            execution_mode=execution_mode,
            timeout_seconds=timeout_seconds,
        )
