"""Backward-compatible dispatch from run-handle seams to LoopHookSet."""

from __future__ import annotations

from uuid import uuid4

from cogit_agent_sdk.types import (
    ArtifactRef,
    ArtifactSlot,
    LoopHookSet,
    ModelCallReservation,
    ModelCallUsage,
)


def emit_seam_hook(hooks: object | None, name: str, *args: object) -> None:
    """Call a seam observer if the bound hook set implements it.

    Missing methods use the documented default no-op: they are skipped
    rather than raised. Unbound handles emit nothing.
    """

    if hooks is None:
        return
    method = getattr(hooks, name, None)
    if callable(method):
        method(*args)


class ArtifactModelCallSeams:
    """Artifact and model-call seams that emit observers after success."""

    _hooks: object | None = None

    def bind_hooks(self, hooks: LoopHookSet | None) -> None:
        """Replace the bound hook set. A later bind does not stack observers."""

        self._hooks = hooks

    def read_artifact(self, ref: ArtifactRef, *, max_bytes: int) -> bytes:
        """Read authorized artifact bytes through the active runtime.

        The runtime must authorize the reference and verify its stored commitment.
        Unbound SDK handles cannot retrieve durable artifacts. Implementations
        override ``_perform_read_artifact`` and must bound transport reads before
        returning the body; this final check also protects callers from mistakes
        in runtime adapters.
        """

        if type(max_bytes) is not int or max_bytes <= 0:
            raise ValueError("max_bytes must be a positive integer")
        body = self._perform_read_artifact(ref, max_bytes=max_bytes)
        if type(body) is not bytes:
            raise TypeError("Artifact reader must return bytes")
        if len(body) > max_bytes:
            raise ValueError("Artifact exceeds max_bytes")
        return body

    def _perform_read_artifact(self, ref: ArtifactRef, *, max_bytes: int) -> bytes:
        raise NotImplementedError("The active runtime does not support artifact reads")

    def declare_artifact(self, kind: str, media_type: str, filename: str) -> ArtifactSlot:
        """Declare an artifact slot before its body is written.

        The default implementation is a local no-op seam: it returns a slot
        without persisting anything. Runtimes may override
        :meth:`_perform_declare_artifact` to route the declaration through
        AgentDb. Overrides of this public method must emit
        ``on_artifact_declared`` after success or call ``super()``.
        """

        slot = self._perform_declare_artifact(kind, media_type, filename)
        emit_seam_hook(self._hooks, "on_artifact_declared", slot)
        return slot

    def finalize_artifact(self, slot: ArtifactSlot, body: bytes, hash: str) -> ArtifactRef:
        """Finalize a declared artifact slot into a concrete reference.

        The default implementation builds a local reference without persisting
        the body. Runtimes may override :meth:`_perform_finalize_artifact`.
        Overrides of this public method must emit ``on_artifact_finalized``
        after success or call ``super()``.
        """

        ref = self._perform_finalize_artifact(slot, body, hash)
        emit_seam_hook(self._hooks, "on_artifact_finalized", ref)
        return ref

    def reserve_model_call(
        self,
        input_tokens: int,
        output_tokens: int,
        cost_budget: float,
    ) -> ModelCallReservation:
        """Reserve a model-call budget before dispatching to a provider.

        The default implementation returns a local reservation without
        enforcing limits. Runtimes may override
        :meth:`_perform_reserve_model_call`. Overrides of this public method
        must emit ``on_model_call_reserved`` after success or call ``super()``.
        """

        reservation = self._perform_reserve_model_call(
            input_tokens,
            output_tokens,
            cost_budget,
        )
        emit_seam_hook(self._hooks, "on_model_call_reserved", reservation)
        return reservation

    def settle_model_call(
        self,
        reservation: ModelCallReservation,
        actual: ModelCallUsage,
    ) -> None:
        """Settle a reserved model call with actual usage.

        The default implementation is a no-op. Runtimes may override
        :meth:`_perform_settle_model_call`. Overrides of this public method
        must emit ``on_model_call_settled`` after success or call ``super()``.
        """

        self._perform_settle_model_call(reservation, actual)
        emit_seam_hook(self._hooks, "on_model_call_settled", reservation, actual)

    def _perform_declare_artifact(
        self,
        kind: str,
        media_type: str,
        filename: str,
    ) -> ArtifactSlot:
        return ArtifactSlot(
            id=str(uuid4()),
            kind=kind,
            media_type=media_type,
            filename=filename,
        )

    def _perform_finalize_artifact(
        self,
        slot: ArtifactSlot,
        body: bytes,
        hash: str,
    ) -> ArtifactRef:
        metadata = dict(slot.metadata or {})
        metadata.update({"kind": slot.kind, "hash": hash})
        return ArtifactRef(
            id=slot.id,
            name=slot.filename,
            mime_type=slot.media_type,
            size=len(body),
            metadata=metadata,
        )

    def _perform_reserve_model_call(
        self,
        input_tokens: int,
        output_tokens: int,
        cost_budget: float,
    ) -> ModelCallReservation:
        return ModelCallReservation(
            id=str(uuid4()),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_budget=cost_budget,
        )

    def _perform_settle_model_call(
        self,
        reservation: ModelCallReservation,
        actual: ModelCallUsage,
    ) -> None:
        _ = reservation, actual
