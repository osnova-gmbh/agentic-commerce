"""Black-box HTTP eval client and suite configuration.

Used by the runtime EvalRunner. Never imports agent package code.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

import httpx
from pydantic import BaseModel, Field

from cogit_agent_sdk.types.eval import CheckResult, EvalItemResult


class EvalCheckConfig(BaseModel):
    """Configuration for a single check within an eval item."""

    type: str
    expected: Any = None
    path: str | None = None


class EvalItemConfig(BaseModel):
    """Configuration for a single eval item."""

    id: str
    input: dict[str, Any] = Field(default_factory=dict)
    checks: list[EvalCheckConfig] = Field(default_factory=list)
    description: str | None = None
    timeout: float | None = None


class EvalSuiteConfig(BaseModel):
    """Configuration for a full eval suite."""

    name: str
    agent_id: str = "unknown"
    agent_version: str | None = None
    endpoint: str | None = None
    items: list[EvalItemConfig] = Field(default_factory=list)
    concurrency: int = Field(default=4, gt=0)
    timeout: float = Field(default=30.0, gt=0)
    threshold: float | None = Field(default=None, ge=0.0, le=1.0)
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class _CheckContext:
    response: httpx.Response
    body: Any


def run_check(check_cfg: EvalCheckConfig, response: httpx.Response, body: Any) -> CheckResult:
    """Dispatch a single check and return a CheckResult."""
    ctx = _CheckContext(response=response, body=body)
    runners = {
        "status": _check_status,
        "output_contains": _check_output_contains,
        "output_matches": _check_output_matches,
        "json_schema": _check_json_schema,
    }
    runner_fn = runners.get(check_cfg.type)
    if runner_fn is None:
        return CheckResult(
            check=check_cfg.type,
            passed=False,
            score=0.0,
            detail=f"Unknown check type: {check_cfg.type}",
        )
    return runner_fn(check_cfg, ctx)


def _check_status(cfg: EvalCheckConfig, ctx: _CheckContext) -> CheckResult:
    expected = cfg.expected if cfg.expected is not None else 200
    passed = ctx.response.status_code == expected
    return CheckResult(
        check="status",
        passed=passed,
        score=1.0 if passed else 0.0,
        detail=(None if passed else f"Expected status {expected}, got {ctx.response.status_code}"),
    )


def _check_output_contains(cfg: EvalCheckConfig, ctx: _CheckContext) -> CheckResult:
    expected = str(cfg.expected) if cfg.expected is not None else ""
    body_text = ctx.response.text
    passed = expected in body_text
    return CheckResult(
        check="output_contains",
        passed=passed,
        score=1.0 if passed else 0.0,
        detail=None if passed else f"Response does not contain: {expected!r}",
    )


def _check_output_matches(cfg: EvalCheckConfig, ctx: _CheckContext) -> CheckResult:
    pattern = str(cfg.expected) if cfg.expected is not None else ""
    body_text = ctx.response.text
    try:
        passed = bool(re.search(pattern, body_text))
    except re.error as exc:
        return CheckResult(
            check="output_matches",
            passed=False,
            score=0.0,
            detail=f"Invalid regex pattern: {exc}",
        )
    return CheckResult(
        check="output_matches",
        passed=passed,
        score=1.0 if passed else 0.0,
        detail=None if passed else f"Response does not match pattern: {pattern!r}",
    )


def _check_json_schema(cfg: EvalCheckConfig, ctx: _CheckContext) -> CheckResult:
    if ctx.body is None:
        return CheckResult(
            check="json_schema",
            passed=False,
            score=0.0,
            detail="Response is not valid JSON",
        )
    if not isinstance(cfg.expected, dict):
        return CheckResult(
            check="json_schema",
            passed=False,
            score=0.0,
            detail="json_schema check expects a dict as 'expected'",
        )
    if not isinstance(ctx.body, dict):
        return CheckResult(
            check="json_schema",
            passed=False,
            score=0.0,
            detail="Response body is not a JSON object",
        )

    missing: list[str] = []
    type_mismatches: list[str] = []
    for key, expected_type_name in cfg.expected.items():
        if key not in ctx.body:
            missing.append(key)
        elif expected_type_name is not None:
            actual_type = type(ctx.body[key]).__name__
            if actual_type != str(expected_type_name):
                type_mismatches.append(f"{key}: expected {expected_type_name}, got {actual_type}")

    passed = len(missing) == 0 and len(type_mismatches) == 0
    details: list[str] = []
    if missing:
        details.append(f"Missing keys: {missing}")
    if type_mismatches:
        details.append(f"Type mismatches: {type_mismatches}")
    return CheckResult(
        check="json_schema",
        passed=passed,
        score=1.0 if passed else 0.0,
        detail="; ".join(details) if details else None,
    )


class BlackBoxEvalClient:
    """HTTP-only black-box client for evaluating a running agent endpoint."""

    def __init__(
        self,
        endpoint: str,
        *,
        client: httpx.AsyncClient | None = None,
        default_timeout: float = 30.0,
    ) -> None:
        self._endpoint = endpoint.rstrip("/")
        self._external_client = client
        self._default_timeout = default_timeout

    async def execute_item(
        self,
        item: EvalItemConfig,
        *,
        timeout: float | None = None,
    ) -> EvalItemResult:
        item_timeout = timeout or item.timeout or self._default_timeout
        method = item.input.get("method", "POST")
        path = item.input.get("path", "/")
        headers = item.input.get("headers", {})
        body = item.input.get("body")
        params = item.input.get("params")

        should_close = self._external_client is None
        client = self._external_client or httpx.AsyncClient(
            base_url=self._endpoint,
            timeout=httpx.Timeout(item_timeout),
        )
        try:
            try:
                response = await client.request(
                    method=method,
                    url=path,
                    json=body if body is not None else None,
                    params=params,
                    headers=headers,
                    timeout=httpx.Timeout(item_timeout),
                )
            except httpx.TimeoutException:
                return EvalItemResult(
                    item_id=item.id,
                    passed=False,
                    score=0.0,
                    error=f"Request timed out after {item_timeout}s",
                )
            except httpx.HTTPError as exc:
                return EvalItemResult(
                    item_id=item.id,
                    passed=False,
                    score=0.0,
                    error=f"HTTP error: {exc}",
                )
        finally:
            if should_close:
                await client.aclose()

        try:
            parsed_body = response.json()
        except (json.JSONDecodeError, ValueError):
            parsed_body = None

        check_results: list[CheckResult] = []
        for check_cfg in item.checks:
            check_results.append(run_check(check_cfg, response, parsed_body))

        if check_results:
            all_passed = all(cr.passed for cr in check_results)
            scores = [cr.score for cr in check_results if cr.score is not None]
            avg_score = sum(scores) / len(scores) if scores else 0.0
        else:
            all_passed = 200 <= response.status_code < 300
            avg_score = 1.0 if all_passed else 0.0

        return EvalItemResult(
            item_id=item.id,
            passed=all_passed,
            score=avg_score,
            checks=check_results,
            output=parsed_body,
        )


__all__ = [
    "BlackBoxEvalClient",
    "EvalCheckConfig",
    "EvalItemConfig",
    "EvalSuiteConfig",
    "run_check",
]
