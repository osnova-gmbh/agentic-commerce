"""Common type aliases used across the SDK."""

from __future__ import annotations

from typing import Any, TypeAlias

# JSON-compatible payload aliases. These keep open wire payloads explicit at
# public boundaries without forcing every SDK model to spell out provider- or
# tenant-specific object shapes.
JsonValue: TypeAlias = Any
JsonObject: TypeAlias = dict[str, JsonValue]
