"""Typed platform client namespaces."""

from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlencode

from cogit_agent_sdk._types import JsonObject, JsonValue
from cogit_agent_sdk.client.auth import AuthStrategy
from cogit_agent_sdk.client.transport import AsyncCogitTransport, CogitTransport, TransportConfig
from cogit_agent_sdk.types import (
    AgentDescriptor,
    AgentRecord,
    Case,
    Context,
    EvalRecord,
    ExecutionRecord,
    ExecutionStepRecord,
    ExperimentRecord,
    KnowledgeQuery,
    KnowledgeResult,
    LearningRecord,
    QueueItem,
)


class CogitClient:
    """Synchronous typed client for the Cogit platform API."""

    def __init__(
        self,
        base_url: str,
        auth: AuthStrategy,
        *,
        compat: str = "ai-org",
        transport: CogitTransport | None = None,
    ) -> None:
        self._compat = compat
        self._transport = transport or CogitTransport(TransportConfig(base_url=base_url), auth)
        self.executions = ExecutionsClient(self._transport)
        self.cases = CasesClient(self._transport)
        self.queue = QueueClient(self._transport)
        self.agents = AgentsClient(self._transport)
        self.knowledge = KnowledgeClient(self._transport)
        self.evals = EvalsClient(self._transport)
        self.learnings = LearningsClient(self._transport)
        self.experiments = ExperimentsClient(self._transport)

    def with_context(self, context: Context) -> BoundCogitClient:
        """Return a client wrapper that emits context on every call."""

        return BoundCogitClient(self, context)

    def close(self) -> None:
        self._transport.close()


@dataclass(frozen=True)
class BoundCogitClient:
    """Context-bound client wrapper."""

    client: CogitClient
    context: Context

    @property
    def executions(self) -> BoundExecutionsClient:
        return BoundExecutionsClient(self.client.executions, self.context)

    @property
    def knowledge(self) -> BoundKnowledgeClient:
        return BoundKnowledgeClient(self.client.knowledge, self.context)


class ExecutionsClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def create(self, record: ExecutionRecord, context: Context | None = None) -> ExecutionRecord:
        data = self._transport.request(
            "POST",
            "/ai-org/executions",
            json_body=record.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context,
        )
        return ExecutionRecord.model_validate(data)

    def complete(
        self,
        execution_id: str,
        payload: JsonObject,
        context: Context | None = None,
    ) -> ExecutionRecord:
        data = self._transport.request(
            "POST",
            f"/ai-org/executions/{execution_id}/complete",
            json_body=payload,
            context=context,
        )
        return ExecutionRecord.model_validate(data)

    def append_step(
        self,
        step: ExecutionStepRecord,
        context: Context | None = None,
        *,
        fire_and_forget: bool = False,
    ) -> ExecutionStepRecord | None:
        body = step.model_dump(by_alias=True, mode="json", exclude_none=True)
        if fire_and_forget:
            self._transport.fire_and_forget(
                "POST",
                "/ai-org/execution-steps",
                json_body=body,
                context=context,
            )
            return None
        data = self._transport.request(
            "POST",
            "/ai-org/execution-steps",
            json_body=body,
            context=context,
        )
        return ExecutionStepRecord.model_validate(data)

    def get(self, execution_id: str, context: Context | None = None) -> ExecutionRecord:
        data = self._transport.request("GET", f"/ai-org/executions/{execution_id}", context=context)
        return ExecutionRecord.model_validate(data)

    def list(
        self,
        context: Context | None = None,
        *,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> list[ExecutionRecord]:
        path = _with_query("/ai-org/executions", {"limit": limit, "cursor": cursor})
        data = self._transport.request("GET", path, context=context)
        return [ExecutionRecord.model_validate(item) for item in _items(data)]


@dataclass(frozen=True)
class BoundExecutionsClient:
    client: ExecutionsClient
    context: Context

    def create(self, record: ExecutionRecord) -> ExecutionRecord:
        return self.client.create(record, self.context)

    def append_step(
        self,
        step: ExecutionStepRecord,
        *,
        fire_and_forget: bool = False,
    ) -> ExecutionStepRecord | None:
        return self.client.append_step(step, self.context, fire_and_forget=fire_and_forget)


class KnowledgeClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def query(self, query: KnowledgeQuery, context: Context | None = None) -> KnowledgeResult:
        data = self._transport.request(
            "POST",
            "/internal/knowledge/query",
            json_body=query.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context or query.context,
        )
        return KnowledgeResult.model_validate(data)


@dataclass(frozen=True)
class BoundKnowledgeClient:
    client: KnowledgeClient
    context: Context

    def query(self, query: KnowledgeQuery) -> KnowledgeResult:
        return self.client.query(query, self.context)


class AgentsClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def get(self, agent_id: str, context: Context | None = None) -> AgentRecord:
        data = self._transport.request("GET", f"/ai-org/agents/{agent_id}", context=context)
        return AgentRecord.model_validate(data)

    def list(self, context: Context | None = None) -> list[AgentRecord]:
        data = self._transport.request("GET", "/ai-org/agents", context=context)
        return [AgentRecord.model_validate(item) for item in _items(data)]

    def register(
        self,
        descriptor: AgentDescriptor,
        endpoint: str | None = None,
        context: Context | None = None,
    ) -> AgentRecord:
        body: JsonObject = {
            "descriptor": descriptor.model_dump(by_alias=True, mode="json", exclude_none=True)
        }
        if endpoint is not None:
            body["endpoint"] = endpoint
        data = self._transport.request("POST", "/ai-org/agents", json_body=body, context=context)
        return AgentRecord.model_validate(data)

    def update(
        self,
        agent_id: str,
        descriptor: AgentDescriptor,
        endpoint: str | None = None,
        context: Context | None = None,
    ) -> AgentRecord:
        body: JsonObject = {
            "descriptor": descriptor.model_dump(
                by_alias=True,
                mode="json",
                exclude_none=True,
            )
        }
        if endpoint is not None:
            body["endpoint"] = endpoint
        data = self._transport.request(
            "PATCH",
            f"/ai-org/agents/{agent_id}",
            json_body=body,
            context=context,
        )
        return AgentRecord.model_validate(data)


class CasesClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def check_batch(self, payload: JsonObject, context: Context | None = None) -> JsonValue:
        return self._transport.request(
            "POST",
            "/ai-org/cases/check-batch",
            json_body=payload,
            context=context,
        )

    def find_or_create(self, case: Case, context: Context | None = None) -> Case:
        data = self._transport.request(
            "POST",
            "/ai-org/cases/find-or-create",
            json_body=case.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context,
        )
        return Case.model_validate(data)

    def claim(self, case_id: str, context: Context | None = None) -> Case:
        data = self._transport.request("POST", f"/ai-org/cases/{case_id}/claim", context=context)
        return Case.model_validate(data)

    def complete(self, case_id: str, context: Context | None = None) -> Case:
        data = self._transport.request("POST", f"/ai-org/cases/{case_id}/complete", context=context)
        return Case.model_validate(data)

    def release(self, case_id: str, context: Context | None = None) -> Case:
        data = self._transport.request("POST", f"/ai-org/cases/{case_id}/release", context=context)
        return Case.model_validate(data)

    def set_status(self, case_id: str, status: str, context: Context | None = None) -> Case:
        data = self._transport.request(
            "PATCH",
            f"/ai-org/cases/{case_id}",
            json_body={"status": status},
            context=context,
        )
        return Case.model_validate(data)


class QueueClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def enqueue(self, item: QueueItem, context: Context | None = None) -> QueueItem:
        data = self._transport.request(
            "POST",
            "/v1/queue/items",
            json_body=item.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context,
        )
        return QueueItem.model_validate(data)

    def claim(self, queue_name: str, context: Context | None = None) -> QueueItem | None:
        data = self._transport.request(
            "POST",
            f"/v1/queue/{queue_name}/claim",
            context=context,
        )
        return None if data is None else QueueItem.model_validate(data)

    def heartbeat(self, item_id: str, context: Context | None = None) -> QueueItem:
        data = self._transport.request(
            "POST",
            f"/v1/queue/items/{item_id}/heartbeat",
            context=context,
        )
        return QueueItem.model_validate(data)

    def complete(self, item_id: str, context: Context | None = None) -> QueueItem:
        data = self._transport.request(
            "POST",
            f"/v1/queue/items/{item_id}/complete",
            context=context,
        )
        return QueueItem.model_validate(data)

    def fail(
        self,
        item_id: str,
        error: str,
        *,
        retryable: bool = True,
        context: Context | None = None,
    ) -> QueueItem:
        data = self._transport.request(
            "POST",
            f"/v1/queue/items/{item_id}/fail",
            json_body={"error": error, "retryable": retryable},
            context=context,
        )
        return QueueItem.model_validate(data)

    def watermark_get(self, name: str, context: Context | None = None) -> JsonValue:
        return self._transport.request("GET", f"/v1/queue/watermarks/{name}", context=context)

    def watermark_set(
        self,
        name: str,
        value: JsonObject,
        context: Context | None = None,
    ) -> JsonValue:
        return self._transport.request(
            "PUT",
            f"/v1/queue/watermarks/{name}",
            json_body=value,
            context=context,
        )


class EvalsClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def report(self, record: EvalRecord, context: Context | None = None) -> EvalRecord:
        data = self._transport.request(
            "POST",
            "/v1/evals",
            json_body=record.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context,
        )
        return EvalRecord.model_validate(data)

    def list(self, context: Context | None = None) -> list[EvalRecord]:
        data = self._transport.request("GET", "/v1/evals", context=context)
        return [EvalRecord.model_validate(item) for item in _items(data)]

    def latest_summary(self, suite: str, context: Context | None = None) -> EvalRecord | None:
        data = self._transport.request("GET", f"/v1/evals/{suite}/latest", context=context)
        return None if data is None else EvalRecord.model_validate(data)


class LearningsClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def record(self, record: LearningRecord, context: Context | None = None) -> LearningRecord:
        data = self._transport.request(
            "POST",
            "/v1/learnings",
            json_body=record.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context,
        )
        return LearningRecord.model_validate(data)

    def list(self, context: Context | None = None) -> list[LearningRecord]:
        data = self._transport.request("GET", "/v1/learnings", context=context)
        return [LearningRecord.model_validate(item) for item in _items(data)]


class ExperimentsClient:
    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport

    def record(
        self,
        record: ExperimentRecord,
        context: Context | None = None,
    ) -> ExperimentRecord:
        data = self._transport.request(
            "POST",
            "/v1/experiments",
            json_body=record.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context,
        )
        return ExperimentRecord.model_validate(data)

    def list(self, context: Context | None = None) -> list[ExperimentRecord]:
        data = self._transport.request("GET", "/v1/experiments", context=context)
        return [ExperimentRecord.model_validate(item) for item in _items(data)]

    def update_verdict(
        self,
        experiment_id: str,
        verdict: str,
        context: Context | None = None,
    ) -> ExperimentRecord:
        data = self._transport.request(
            "PATCH",
            f"/v1/experiments/{experiment_id}",
            json_body={"verdict": verdict},
            context=context,
        )
        return ExperimentRecord.model_validate(data)


class AsyncCogitClient:
    """Async typed client for runtime and service code."""

    def __init__(
        self,
        base_url: str,
        auth: AuthStrategy,
        transport: AsyncCogitTransport | None = None,
    ) -> None:
        self._transport = transport or AsyncCogitTransport(TransportConfig(base_url=base_url), auth)

    async def close(self) -> None:
        await self._transport.close()

    async def knowledge_query(
        self,
        query: KnowledgeQuery,
        context: Context | None = None,
    ) -> KnowledgeResult:
        data = await self._transport.request(
            "POST",
            "/internal/knowledge/query",
            json_body=query.model_dump(by_alias=True, mode="json", exclude_none=True),
            context=context or query.context,
        )
        return KnowledgeResult.model_validate(data)


def _items(value: JsonValue) -> list[JsonValue]:
    if isinstance(value, list):
        return value
    if isinstance(value, dict) and isinstance(value.get("items"), list):
        return value["items"]
    return []


def _with_query(path: str, params: dict[str, int | str | None]) -> str:
    query = urlencode({key: value for key, value in params.items() if value is not None})
    if not query:
        return path
    return f"{path}?{query}"
