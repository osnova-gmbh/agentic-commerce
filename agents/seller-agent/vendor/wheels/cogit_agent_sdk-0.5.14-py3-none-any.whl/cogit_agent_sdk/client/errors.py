"""Client exception taxonomy."""

from __future__ import annotations

from cogit_agent_sdk.types import ErrorInfo


class CogitError(Exception):
    """Root SDK client error carrying an ErrorInfo payload."""

    def __init__(self, info: ErrorInfo, status_code: int | None = None) -> None:
        super().__init__(info.message)
        self.info = info
        self.status_code = status_code


class AuthError(CogitError):
    """Authentication or authorization failure."""


class NotFound(CogitError):
    """Requested resource was not found."""


class Conflict(CogitError):
    """Request conflicted with existing state."""


class LeaseLost(Conflict):
    """Queue or case lease was lost."""


class ValidationError(CogitError):
    """Request failed validation."""


class RateLimited(CogitError):
    """Server rejected the request due to rate limits."""


class ServerError(CogitError):
    """Server-side failure after retries."""


class Timeout(CogitError):
    """Client-side timeout."""


class BudgetExceeded(CogitError):
    """Client-side budget was exceeded."""


def error_for_status(status_code: int, info: ErrorInfo) -> CogitError:
    """Map HTTP status codes to the SDK exception taxonomy."""

    if status_code in {401, 403}:
        return AuthError(info, status_code)
    if status_code == 404:
        return NotFound(info, status_code)
    if status_code == 409:
        if info.code == "LEASE_LOST":
            return LeaseLost(info, status_code)
        return Conflict(info, status_code)
    if status_code == 422:
        return ValidationError(info, status_code)
    if status_code == 429:
        return RateLimited(info, status_code)
    if status_code >= 500:
        return ServerError(info, status_code)
    return CogitError(info, status_code)
