"""HTTP transport helpers for platform clients."""

from __future__ import annotations

import queue
import threading
from collections.abc import Mapping
from dataclasses import dataclass

import httpx

from cogit_agent_sdk._types import JsonValue
from cogit_agent_sdk.client.auth import AuthStrategy, context_headers
from cogit_agent_sdk.client.errors import Timeout, error_for_status
from cogit_agent_sdk.types import Context, ErrorInfo


@dataclass(frozen=True)
class TransportConfig:
    """HTTP transport settings."""

    base_url: str
    timeout_seconds: float = 30.0
    telemetry_timeout_seconds: float = 3.0
    telemetry_queue_size: int = 256


class CogitTransport:
    """Synchronous HTTP transport with auth, context headers, and error mapping."""

    def __init__(
        self,
        config: TransportConfig,
        auth: AuthStrategy,
        client: httpx.Client | None = None,
    ) -> None:
        self.config = config
        self._auth = auth
        self._client = client or httpx.Client(
            base_url=config.base_url,
            timeout=config.timeout_seconds,
        )
        self._telemetry = TelemetryQueue(self)

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: JsonValue | None = None,
        context: Context | None = None,
        timeout_seconds: float | None = None,
    ) -> JsonValue:
        headers = self._headers(context)
        try:
            response = self._client.request(
                method,
                path,
                json=json_body,
                headers=headers,
                timeout=httpx.USE_CLIENT_DEFAULT if timeout_seconds is None else timeout_seconds,
            )
        except httpx.TimeoutException as exc:
            raise Timeout(ErrorInfo(code="TIMEOUT", message=str(exc), retryable=True)) from exc

        if response.status_code >= 400:
            raise error_for_status(response.status_code, response_error_info(response))
        if not response.content:
            return None
        return response.json()

    def fire_and_forget(
        self,
        method: str,
        path: str,
        *,
        json_body: JsonValue | None = None,
        context: Context | None = None,
    ) -> None:
        self._telemetry.enqueue(method, path, json_body, context)

    def close(self) -> None:
        self._telemetry.close()
        self._client.close()

    def _headers(self, context: Context | None) -> dict[str, str]:
        headers = {"accept": "application/json", "content-type": "application/json"}
        headers.update(self._auth.headers())
        headers.update(context_headers(context))
        return headers


class TelemetryQueue:
    """Bounded background queue for fire-and-forget telemetry writes."""

    def __init__(self, transport: CogitTransport) -> None:
        self._transport = transport
        self._queue: queue.Queue[tuple[str, str, JsonValue | None, Context | None] | None] = (
            queue.Queue(maxsize=transport.config.telemetry_queue_size)
        )
        self.dropped = 0
        self._thread = threading.Thread(target=self._run, name="cogit-telemetry", daemon=True)
        self._thread.start()

    def enqueue(
        self,
        method: str,
        path: str,
        json_body: JsonValue | None,
        context: Context | None,
    ) -> None:
        item = (method, path, json_body, context)
        try:
            self._queue.put_nowait(item)
        except queue.Full:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                pass
            self.dropped += 1
            self._queue.put_nowait(item)

    def close(self) -> None:
        self._queue.put(None)
        self._thread.join(timeout=1)

    def _run(self) -> None:
        while True:
            item = self._queue.get()
            if item is None:
                return
            method, path, json_body, context = item
            try:
                self._transport.request(
                    method,
                    path,
                    json_body=json_body,
                    context=context,
                    timeout_seconds=self._transport.config.telemetry_timeout_seconds,
                )
            except Exception:
                self.dropped += 1


class AsyncCogitTransport:
    """Async HTTP transport with the same auth and error semantics."""

    def __init__(
        self,
        config: TransportConfig,
        auth: AuthStrategy,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._auth = auth
        self._client = client or httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout_seconds,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        json_body: JsonValue | None = None,
        context: Context | None = None,
    ) -> JsonValue:
        headers = {"accept": "application/json", "content-type": "application/json"}
        headers.update(self._auth.headers())
        headers.update(context_headers(context))
        try:
            response = await self._client.request(
                method,
                path,
                json=json_body,
                headers=headers,
            )
        except httpx.TimeoutException as exc:
            raise Timeout(ErrorInfo(code="TIMEOUT", message=str(exc), retryable=True)) from exc

        if response.status_code >= 400:
            raise error_for_status(response.status_code, response_error_info(response))
        if not response.content:
            return None
        return response.json()

    async def close(self) -> None:
        await self._client.aclose()


def response_error_info(response: httpx.Response) -> ErrorInfo:
    """Extract an ErrorInfo from a failed HTTP response."""

    try:
        data = response.json()
    except ValueError:
        return ErrorInfo(
            code=f"HTTP_{response.status_code}",
            message=response.text or response.reason_phrase,
            retryable=response.status_code >= 500,
        )
    if isinstance(data, Mapping):
        code = str(data.get("code") or f"HTTP_{response.status_code}")
        message = str(data.get("message") or data.get("error") or response.reason_phrase)
        details = data.get("details")
        return ErrorInfo(
            code=code,
            message=message,
            retryable=response.status_code >= 500,
            details=dict(details) if isinstance(details, Mapping) else None,
        )
    return ErrorInfo(
        code=f"HTTP_{response.status_code}",
        message=response.reason_phrase,
        retryable=response.status_code >= 500,
    )
