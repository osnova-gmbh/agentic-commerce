"""Client-side auth and context-envelope propagation."""

from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from cogit_agent_sdk.types import Context, ErrorInfo

from .errors import AuthError


@runtime_checkable
class AuthStrategy(Protocol):
    """Adds authentication headers to outgoing client requests."""

    def headers(self) -> dict[str, str]:
        """Return authentication headers."""
        ...


@dataclass(frozen=True)
class ApiKeyAuth:
    """Canonical API-key auth for v0 platform calls."""

    api_key: str
    header_name: str = "x-api-key"

    def headers(self) -> dict[str, str]:
        return {self.header_name: self.api_key}


@dataclass(frozen=True)
class AgentTokenAuth:
    """Bearer-token auth for per-agent credentials."""

    token: str

    def headers(self) -> dict[str, str]:
        return {"authorization": f"Bearer {self.token}"}


class DevAuth:
    """Explicit local-development no-auth mode."""

    def headers(self) -> dict[str, str]:
        return {}


def auth_from_env(
    *,
    api_key_env: str = "COGIT_API_KEY",
    agent_token_env: str = "COGIT_AGENT_TOKEN",
    allow_dev: bool = False,
) -> AuthStrategy:
    """Resolve auth from environment, failing closed unless dev mode is explicit."""

    agent_token = os.getenv(agent_token_env)
    if agent_token:
        return AgentTokenAuth(agent_token)

    api_key = os.getenv(api_key_env)
    if api_key:
        return ApiKeyAuth(api_key)

    if allow_dev:
        return DevAuth()

    raise AuthError(
        ErrorInfo(
            code="AUTH_NOT_CONFIGURED",
            message="No Cogit auth configured; pass auth explicitly or set env credentials",
            retryable=False,
        )
    )


def context_headers(context: Context | None) -> dict[str, str]:
    """Serialize context into individual headers plus one lossless envelope."""

    if context is None:
        return {}

    payload = context.model_dump(by_alias=True, mode="json", exclude_none=True)
    encoded = base64.urlsafe_b64encode(
        json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).decode("ascii")

    headers = {
        "x-cogit-tenant-id": context.tenant_id,
        "x-cogit-correlation-id": context.correlation_id,
        "x-cogit-context": encoded,
    }
    optional = {
        "x-cogit-organization-id": context.organization_id,
        "x-cogit-agent-id": context.agent_id,
        "x-cogit-execution-id": context.execution_id,
        "x-cogit-session-id": context.session_id,
    }
    headers.update({key: value for key, value in optional.items() if value is not None})
    return headers
