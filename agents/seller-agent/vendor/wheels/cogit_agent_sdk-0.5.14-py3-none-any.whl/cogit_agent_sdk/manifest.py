"""Manifest loading for cogit.yaml files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from cogit_agent_sdk.types import AgentDescriptor


def load_manifest(path: str | Path = "cogit.yaml") -> AgentDescriptor:
    """Load and validate a cogit.yaml manifest as an AgentDescriptor."""

    manifest_path = Path(path)
    data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Manifest {manifest_path} must contain a mapping")
    return AgentDescriptor.model_validate(data)


def dump_manifest(descriptor: AgentDescriptor, path: str | Path) -> None:
    """Write an AgentDescriptor as a cogit.yaml-compatible manifest."""

    manifest_path = Path(path)
    data = descriptor.model_dump(by_alias=False, mode="json", exclude_none=True)
    manifest_path.write_text(
        yaml.safe_dump(_plain(data), sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )


def _plain(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_plain(item) for item in value]
    return value
