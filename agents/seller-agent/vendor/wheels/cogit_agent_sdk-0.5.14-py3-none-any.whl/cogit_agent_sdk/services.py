"""Capability-scoped service handles injected into AgentServices.

These protocols never expose the raw operational RuntimeStore. Runtime
implementations may back them with SQL or in-memory stores.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from cogit_agent_sdk.types.artifacts import ArtifactRef
from cogit_agent_sdk.types.knowledge import KnowledgeQuery, KnowledgeResult


@runtime_checkable
class MemoryHandle(Protocol):
    """Capability-scoped memory/knowledge query surface."""

    def query(self, request: KnowledgeQuery) -> KnowledgeResult: ...


@runtime_checkable
class ArtifactHandle(Protocol):
    """Capability-scoped artifact put/get surface."""

    def put(
        self,
        *,
        name: str | None = None,
        mime_type: str | None = None,
        uri: str | None = None,
        size: int | None = None,
        case_id: str | None = None,
        execution_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        content: bytes | None = None,
    ) -> ArtifactRef: ...

    def get(self, artifact_id: str) -> ArtifactRef | None: ...


class NullMemoryHandle:
    """No-op memory handle used when no store-backed memory is configured."""

    def query(self, request: KnowledgeQuery) -> KnowledgeResult:
        from cogit_agent_sdk.types.knowledge import KnowledgeResult

        _ = request
        return KnowledgeResult(hits=[])


class NullArtifactHandle:
    """In-process artifact handle that stores metadata only."""

    def __init__(self) -> None:
        self._items: dict[str, ArtifactRef] = {}

    def put(
        self,
        *,
        name: str | None = None,
        mime_type: str | None = None,
        uri: str | None = None,
        size: int | None = None,
        case_id: str | None = None,
        execution_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        content: bytes | None = None,
    ) -> ArtifactRef:
        from uuid import uuid4

        meta = dict(metadata or {})
        if case_id is not None:
            meta.setdefault("caseId", case_id)
        if execution_id is not None:
            meta.setdefault("executionId", execution_id)
        if content is not None:
            meta.setdefault("contentBytes", len(content))
        ref = ArtifactRef(
            id=str(uuid4()),
            name=name,
            mime_type=mime_type,
            size=size if size is not None else (len(content) if content else None),
            uri=uri,
            metadata=meta or None,
        )
        self._items[ref.id] = ref
        return ref

    def get(self, artifact_id: str) -> ArtifactRef | None:
        return self._items.get(artifact_id)
