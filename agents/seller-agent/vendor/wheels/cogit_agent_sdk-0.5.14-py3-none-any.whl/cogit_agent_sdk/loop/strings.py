"""Default frozen prompt strings (spec §9.5).

Prompt-visible strings are versioned API. Product adapters may override them
only by supplying a named replacement set on `AgentLoopConfig.frozen_strings`;
any field left unset falls back to these defaults.
"""

from __future__ import annotations

from cogit_agent_sdk.types import FrozenPromptStrings

DEFAULT_FROZEN_STRINGS = FrozenPromptStrings(
    budget_warning=(
        "Budget notice: this run is approaching its turn budget. "
        "Prioritize finishing the task; avoid speculative tool calls."
    ),
    critical_budget_warning=(
        "Critical budget notice: this is the final turn before the run is "
        "stopped. Produce your best final answer now without further tool calls."
    ),
    tool_error_recovery=(
        "The tool call failed. Review the error, adjust the arguments or "
        "approach, and try again if the task still requires it."
    ),
    terminal_tool_accepted="Terminal tool accepted",
    continuation_after_max_tokens=(
        "Your previous message was truncated at the token limit. "
        "Continue exactly where you stopped without repeating content."
    ),
    provider_repair=(
        "The previous model response was malformed and has been repaired. "
        "Continue the task from the current conversation state."
    ),
)


def resolve_frozen_strings(overrides: FrozenPromptStrings) -> FrozenPromptStrings:
    """Merge an override set over the defaults; unset fields keep the default."""

    merged = DEFAULT_FROZEN_STRINGS.model_dump()
    merged.update(overrides.model_dump(exclude_none=True))
    return FrozenPromptStrings.model_validate(merged)
