"""Deterministic LLM -> tool -> LLM loop engine."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import UTC, datetime
from itertools import islice
from threading import Lock
from time import monotonic, sleep
from typing import Any, Literal, cast

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from jsonschema.exceptions import ValidationError as SchemaValidationError

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.contracts import RunHandle
from cogit_agent_sdk.coordination import CoordinationFailure, raise_coordination_failure
from cogit_agent_sdk.loop._validation import (
    MAX_VALIDATION_ERRORS,
    format_validation_details,
    validation_field,
    validation_tool_name,
)
from cogit_agent_sdk.loop.coordination import CoordinationCancellation
from cogit_agent_sdk.loop.state import ensure_reconciled_state
from cogit_agent_sdk.loop.strings import resolve_frozen_strings
from cogit_agent_sdk.loop.tool_execution import execute_tool_binding, raise_operation_key_error
from cogit_agent_sdk.operations.contract import OperationInvocation
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.types import (
    AgentLoopConfig,
    AgentLoopResult,
    AgentLoopState,
    ArtifactRef,
    ArtifactSlot,
    AssistantMessage,
    Cancellation,
    ContentBlock,
    Context,
    ErrorInfo,
    EstimatedCost,
    FrozenPromptStrings,
    LoopHookSet,
    Message,
    ModelCallReservation,
    ModelCallUsage,
    ModelClient,
    ModelRequest,
    ModelResponse,
    RunEvent,
    TextContent,
    ToolCall,
    ToolDescriptor,
    ToolResult,
    ToolResultMessage,
    Usage,
    estimate_cost,
)

RunEventType = Literal[
    "run_started",
    "run_completed",
    "run_failed",
    "message_started",
    "message_delta",
    "message_completed",
    "tool_call_started",
    "tool_call_updated",
    "tool_call_completed",
    "step_recorded",
    "attention_required",
]
Emit = Callable[[RunEventType, JsonObject | None], None]


class NoopCancellation:
    """Cancellation signal that is never cancelled."""

    @property
    def cancelled(self) -> bool:
        return False

    def throw_if_cancelled(self) -> None:
        return None


@dataclass(frozen=True)
class _DeadlineCancellation:
    delegate: Cancellation
    deadline: float | None

    @property
    def cancelled(self) -> bool:
        return self.delegate.cancelled or (
            self.deadline is not None and monotonic() >= self.deadline
        )

    @property
    def remaining_seconds(self) -> float | None:
        remaining = None if self.deadline is None else max(0.0, self.deadline - monotonic())
        delegated = getattr(self.delegate, "remaining_seconds", None)
        if not isinstance(delegated, int | float):
            return remaining
        delegated_remaining = max(0.0, float(delegated))
        return delegated_remaining if remaining is None else min(remaining, delegated_remaining)

    def throw_if_cancelled(self) -> None:
        self.delegate.throw_if_cancelled()
        if self.deadline is not None and monotonic() >= self.deadline:
            raise TimeoutError("Loop wall-clock deadline exceeded")


# Matches the ExecutionStepRecord data limit (spec §2.11): tool output fed back
# to the model is truncated at the same bound the platform enforces on records.
_MAX_TOOL_TEXT_BYTES = 50 * 1024

# Transient model-error retry policy (spec §9.3 `on_model_error` default).
_MODEL_RETRY_ATTEMPTS = 2
_MODEL_RETRY_BACKOFF_SECONDS = 0.5
_MAX_PARALLEL_TOOL_WORKERS = 8
_TRANSIENT_STATUS_CODES = {408, 429, 500, 502, 503, 504, 529}
_TRANSIENT_ERROR_MARKERS = ("timeout", "connection", "ratelimit", "rate_limit", "overloaded")
_SCHEMA_VALIDATION_GUIDANCE = {
    "required": "required field is missing",
    "additionalProperties": "unexpected field; use only declared properties",
    "unevaluatedProperties": "unexpected field; use only declared properties",
    "type": "must match the declared type",
    "enum": "must be one of the declared allowed values",
    "const": "must match the declared value",
    "minimum": "must be at least the declared minimum",
    "exclusiveMinimum": "must be greater than the declared minimum",
    "maximum": "must be at most the declared maximum",
    "exclusiveMaximum": "must be less than the declared maximum",
    "multipleOf": "must be a multiple of the declared value",
    "minLength": "is shorter than the declared minimum",
    "maxLength": "is longer than the declared maximum",
    "pattern": "must match the declared pattern",
    "minItems": "has fewer items than the declared minimum",
    "maxItems": "has more items than the declared maximum",
    "uniqueItems": "must contain unique items",
}


def _format_descriptor_validation_errors(
    tool_name: str, errors: Iterable[SchemaValidationError], fields: set[str]
) -> str | None:
    details: list[str] = []
    for index, error in enumerate(islice(errors, MAX_VALIDATION_ERRORS + 1)):
        if index == MAX_VALIDATION_ERRORS:
            return format_validation_details(tool_name, details, omitted=True)
        rule = error.validator if isinstance(error.validator, str) else ""
        guidance = _SCHEMA_VALIDATION_GUIDANCE.get(rule, "must satisfy the declared input schema")
        label = rule if rule in _SCHEMA_VALIDATION_GUIDANCE else "invalid_value"
        location = tuple(islice(error.absolute_path, 5))
        details.append(f"{validation_field(location, fields)}: {guidance} ({label})")
    return format_validation_details(tool_name, details, omitted=False) if details else None


def _truncate_text_block(block: ContentBlock) -> ContentBlock:
    if not isinstance(block, TextContent):
        return block
    encoded = block.text.encode("utf-8")
    if len(encoded) <= _MAX_TOOL_TEXT_BYTES:
        return block
    preview = encoded[:_MAX_TOOL_TEXT_BYTES].decode("utf-8", errors="ignore")
    return TextContent(text=f"{preview}\n\n[truncated {len(encoded)} bytes to SDK limit]")


def _is_transient_model_error(exc: Exception) -> bool:
    status_code = getattr(exc, "status_code", None)
    if isinstance(status_code, int):
        return status_code in _TRANSIENT_STATUS_CODES
    label = f"{type(exc).__name__} {exc}".lower()
    return any(marker in label for marker in _TRANSIENT_ERROR_MARKERS)


class DefaultLoopHooks:
    """Conservative default hooks (spec §9.3).

    - `before_tool_call` fails closed on tools whose descriptor requires an
      approval decision, because the standalone loop has no approval channel.
    - `after_tool_call` is identity by default; use
      :class:`SdkTruncationHooks` for hard truncation after agent redaction.
    - Everything else is identity/no-op.
    """

    def __init__(self, descriptors: dict[str, ToolDescriptor] | None = None) -> None:
        self._descriptors = descriptors or {}

    def transform_messages(
        self,
        messages: list[Message | AssistantMessage | ToolResultMessage],
        context: Context,
    ) -> list[Message | AssistantMessage | ToolResultMessage]:
        return messages

    def convert_to_model(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelRequest:
        return ModelRequest(
            messages=state.messages,
            tools=config.tools or [],
            model=config.model_descriptor,
        )

    def transform_tools(
        self,
        tools: list[ToolDescriptor],
        context: Context,
    ) -> list[ToolDescriptor]:
        return tools

    def prepare_next_turn(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> AgentLoopState:
        """Inject frozen budget-warning strings near the turn limit (spec §9.3)."""

        strings = resolve_frozen_strings(config.frozen_strings)
        limit = config.max_turns
        if config.budget is not None and config.budget.max_iterations is not None:
            limit = min(limit, config.budget.max_iterations)
        remaining = limit - state.current_turn
        if remaining == 2 and strings.budget_warning:
            state.messages.append(
                Message(role="user", content=[TextContent(text=strings.budget_warning)]),
            )
        elif remaining == 1 and strings.critical_budget_warning:
            state.messages.append(
                Message(role="user", content=[TextContent(text=strings.critical_budget_warning)]),
            )
        return state

    def before_tool_call(
        self,
        tool_call: ToolCall,
        context: Context,
    ) -> bool:
        descriptor = self._descriptors.get(tool_call.tool_name)
        if descriptor is not None and descriptor.requires_approval:
            return False
        return True

    def after_tool_call(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Context,
    ) -> ToolResult:
        _ = tool_call, context
        return result

    def on_event(self, event: RunEvent) -> None:
        return None

    def on_model_error(
        self,
        error: ErrorInfo,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelResponse | None:
        return None

    def on_artifact_declared(self, slot: ArtifactSlot) -> None:
        return None

    def on_artifact_finalized(self, ref: ArtifactRef) -> None:
        return None

    def on_model_call_reserved(self, reservation: ModelCallReservation) -> None:
        return None

    def on_model_call_settled(
        self,
        reservation: ModelCallReservation,
        usage: ModelCallUsage,
    ) -> None:
        return None


class SdkTruncationHooks:
    """Hard truncation layer applied after agent redaction hooks."""

    def after_tool_call(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Context,
    ) -> ToolResult:
        _ = tool_call, context
        content = [_truncate_text_block(block) for block in result.content]
        if content == result.content:
            return result
        return result.model_copy(update={"content": content})


class _StandaloneDefaultHooks:
    """Default hooks + truncation for standalone AgentLoopEngine use."""

    def __init__(self, descriptors: dict[str, ToolDescriptor] | None = None) -> None:
        self._defaults = DefaultLoopHooks(descriptors)
        self._truncation = SdkTruncationHooks()

    def transform_messages(
        self,
        messages: list[Message | AssistantMessage | ToolResultMessage],
        context: Context,
    ) -> list[Message | AssistantMessage | ToolResultMessage]:
        return self._defaults.transform_messages(messages, context)

    def convert_to_model(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelRequest:
        return self._defaults.convert_to_model(state, config)

    def transform_tools(
        self,
        tools: list[ToolDescriptor],
        context: Context,
    ) -> list[ToolDescriptor]:
        return self._defaults.transform_tools(tools, context)

    def prepare_next_turn(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> AgentLoopState:
        return self._defaults.prepare_next_turn(state, config)

    def before_tool_call(self, tool_call: ToolCall, context: Context) -> bool:
        return self._defaults.before_tool_call(tool_call, context)

    def after_tool_call(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Context,
    ) -> ToolResult:
        return self._truncation.after_tool_call(
            tool_call,
            self._defaults.after_tool_call(tool_call, result, context),
            context,
        )

    def on_event(self, event: RunEvent) -> None:
        self._defaults.on_event(event)

    def on_model_error(
        self,
        error: ErrorInfo,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelResponse | None:
        return self._defaults.on_model_error(error, state, config)

    def on_artifact_declared(self, slot: ArtifactSlot) -> None:
        self._defaults.on_artifact_declared(slot)

    def on_artifact_finalized(self, ref: ArtifactRef) -> None:
        self._defaults.on_artifact_finalized(ref)

    def on_model_call_reserved(self, reservation: ModelCallReservation) -> None:
        self._defaults.on_model_call_reserved(reservation)

    def on_model_call_settled(
        self,
        reservation: ModelCallReservation,
        usage: ModelCallUsage,
    ) -> None:
        self._defaults.on_model_call_settled(reservation, usage)


@dataclass(frozen=True)
class _LoopRuntime:
    model_client: ModelClient
    bindings_by_name: dict[str, ToolBinding[Any, Any]]
    hooks: LoopHookSet
    cancellation: Cancellation


class AgentLoopEngine:
    """Owns the single shared LLM/tool turn loop."""

    def __init__(
        self,
        model_client: ModelClient,
        tools: Iterable[ToolBinding[Any, Any]] = (),
        hooks: LoopHookSet | None = None,
        cancellation: Cancellation | None = None,
        sleeper: Callable[[float], None] = sleep,
    ) -> None:
        bindings_by_name = {binding.descriptor.name: binding for binding in tools}
        self._runtime = _LoopRuntime(
            model_client=model_client,
            bindings_by_name=bindings_by_name,
            hooks=hooks
            or _StandaloneDefaultHooks(
                descriptors={
                    name: binding.descriptor for name, binding in bindings_by_name.items()
                },
            ),
            cancellation=cancellation or NoopCancellation(),
        )
        self._sleeper = sleeper

    def run(self, state: AgentLoopState, config: AgentLoopConfig) -> AgentLoopResult:
        """Run model/tool turns until completion or a configured stop condition."""

        ensure_reconciled_state(state)

        events: list[RunEvent] = []
        sequence = 0
        event_lock = Lock()
        turns_used = 0
        tool_calls_used = 0
        total_usage = Usage()
        started = monotonic()
        duration_limits = [
            value
            for value in (
                config.wall_clock_timeout_seconds,
                config.budget.max_duration_seconds if config.budget is not None else None,
            )
            if value is not None
        ]
        deadline = started + min(duration_limits) if duration_limits else None
        model_cancellation = _DeadlineCancellation(
            self._runtime.cancellation,
            deadline,
        )
        current_state = state
        strings = resolve_frozen_strings(config.frozen_strings)

        def emit(event_type: RunEventType, payload: JsonObject | None = None) -> None:
            nonlocal sequence
            with event_lock:
                sequence += 1
                event = RunEvent(
                    execution_id=self._execution_id(current_state.context),
                    sequence=sequence,
                    timestamp=datetime.now(tz=UTC),
                    type=event_type,
                    payload=payload or {},
                )
                events.append(event)
            self._runtime.hooks.on_event(event)

        emit("run_started", {"label": config.label})

        while turns_used < config.max_turns:
            if self._runtime.cancellation.cancelled:
                emit("run_failed", {"reason": "cancelled"})
                return self._result(
                    state=current_state,
                    stop_reason="cancelled",
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                    error=ErrorInfo(code="CANCELLED", message="Run was cancelled", retryable=False),
                )
            self._runtime.cancellation.throw_if_cancelled()

            budget_error = self._budget_error(
                config,
                started,
                tool_calls_used,
                turns_used,
                total_usage,
            )
            if budget_error is not None:
                emit("run_failed", {"reason": "budget_exceeded", "code": budget_error.code})
                return self._result(
                    state=current_state,
                    stop_reason="budget_exceeded",
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                    error=budget_error,
                )

            current_state = self._runtime.hooks.prepare_next_turn(current_state, config)
            messages = self._runtime.hooks.transform_messages(
                current_state.messages,
                current_state.context,
            )
            advertised = (
                config.tools
                if config.tools is not None
                else [binding.descriptor for binding in self._runtime.bindings_by_name.values()]
            )
            tools = self._runtime.hooks.transform_tools(advertised, current_state.context)
            allowed_tool_names = {tool.name for tool in tools}
            descriptors_by_name = {tool.name: tool for tool in tools}
            request = self._runtime.hooks.convert_to_model(
                AgentLoopState(
                    messages=messages,
                    context=current_state.context,
                    current_turn=current_state.current_turn,
                    session_id=current_state.session_id,
                    queued_input=current_state.queued_input,
                    metadata=current_state.metadata,
                ),
                AgentLoopConfig(
                    label=config.label,
                    model_descriptor=config.model_descriptor,
                    tools=tools,
                    terminal_tools=config.terminal_tools,
                    max_turns=config.max_turns,
                    wall_clock_timeout_seconds=config.wall_clock_timeout_seconds,
                    budget=config.budget,
                    frozen_strings=config.frozen_strings,
                    metadata=config.metadata,
                ),
            )

            emit("message_started", {"turn": turns_used + 1})
            try:
                response = self._generate_with_retry(request, model_cancellation)
            except Exception as exc:
                raise_coordination_failure(exc)
                if self._runtime.cancellation.cancelled:
                    error = ErrorInfo(
                        code="CANCELLED",
                        message="Run was cancelled",
                        retryable=False,
                    )
                    emit("run_failed", {"reason": "cancelled"})
                    return self._result(
                        state=current_state,
                        stop_reason="cancelled",
                        turns_used=turns_used,
                        usage=total_usage,
                        events=events,
                        error=error,
                    )
                deadline_error = self._budget_error(
                    config,
                    started,
                    tool_calls_used,
                    turns_used,
                    total_usage,
                )
                if deadline_error is not None:
                    emit(
                        "run_failed",
                        {
                            "reason": "budget_exceeded",
                            "code": deadline_error.code,
                        },
                    )
                    return self._result(
                        state=current_state,
                        stop_reason="budget_exceeded",
                        turns_used=turns_used,
                        usage=total_usage,
                        events=events,
                        error=deadline_error,
                    )
                error = ErrorInfo(
                    code="MODEL_ERROR",
                    message=f"Model request failed ({type(exc).__name__})",
                    retryable=_is_transient_model_error(exc),
                )
                repaired = self._runtime.hooks.on_model_error(error, current_state, config)
                if repaired is None:
                    emit("run_failed", {"reason": "model_error", "message": error.message})
                    return self._result(
                        state=current_state,
                        stop_reason="model_error",
                        turns_used=turns_used,
                        usage=total_usage,
                        events=events,
                        error=error,
                    )
                response = repaired

            if self._runtime.cancellation.cancelled:
                error = ErrorInfo(
                    code="CANCELLED",
                    message="Run was cancelled",
                    retryable=False,
                )
                emit("run_failed", {"reason": "cancelled"})
                return self._result(
                    state=current_state,
                    stop_reason="cancelled",
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                    error=error,
                )
            post_generation_error = self._budget_error(
                config,
                started,
                tool_calls_used,
                turns_used,
                total_usage,
            )
            if post_generation_error is not None:
                emit(
                    "run_failed",
                    {
                        "reason": "budget_exceeded",
                        "code": post_generation_error.code,
                    },
                )
                return self._result(
                    state=current_state,
                    stop_reason="budget_exceeded",
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                    error=post_generation_error,
                )

            turns_used += 1
            turn_usage = response.usage or response.message.usage
            rates = config.model_descriptor.cost
            if turn_usage is not None and rates is not None:
                turn_usage = turn_usage.model_copy(
                    update={"estimated_cost": estimate_cost(turn_usage, rates)},
                )
            total_usage = self._add_usage(total_usage, turn_usage)
            assistant_message = response.message
            current_state.messages.append(assistant_message)
            current_state.current_turn = turns_used
            emit(
                "message_completed",
                {
                    "turn": turns_used,
                    "stopReason": response.stop_reason or assistant_message.stop_reason,
                },
            )

            tool_calls = assistant_message.tool_calls or []
            if not tool_calls:
                emit("run_completed", {"reason": "completed"})
                return self._result(
                    state=current_state,
                    stop_reason="completed",
                    output=self._assistant_text(assistant_message),
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                )

            duplicate_tool_call_ids = self._duplicate_tool_call_ids(tool_calls)
            if duplicate_tool_call_ids:
                error = ErrorInfo(
                    code="INVALID_TOOL_CALL_IDS",
                    message="Model returned duplicate tool call identifiers",
                    retryable=False,
                )
                emit(
                    "run_failed",
                    {"reason": "model_error", "code": error.code},
                )
                return self._result(
                    state=current_state,
                    stop_reason="model_error",
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                    error=error,
                )

            available_tool_calls = self._available_tool_calls(config, tool_calls_used)
            budget_limited = (
                available_tool_calls is not None and len(tool_calls) > available_tool_calls
            )
            permitted_tool_calls = (
                tool_calls[:available_tool_calls]
                if available_tool_calls is not None
                else tool_calls
            )

            terminal_result, terminal_errors = self._terminal_results(
                permitted_tool_calls,
                config,
                strings,
                descriptors_by_name,
                current_state.context,
                emit,
            )
            if terminal_result is not None:
                tool_calls_used += 1
                emit(
                    "run_completed",
                    {"reason": "terminal_tool", "toolName": terminal_result.tool_name},
                )
                return self._result(
                    state=current_state,
                    stop_reason="terminal_tool",
                    terminal_result=terminal_result,
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                )

            executable_calls = [
                call for call in permitted_tool_calls if call.id not in terminal_errors
            ]
            try:
                executed_results = self._execute_tool_calls(
                    executable_calls,
                    current_state.context,
                    emit,
                    strings,
                    allowed_tool_names,
                    model_cancellation,
                )
            except Exception as exc:
                raise_coordination_failure(exc)
                if self._runtime.cancellation.cancelled:
                    error = ErrorInfo(
                        code="CANCELLED",
                        message="Run was cancelled",
                        retryable=False,
                    )
                    emit("run_failed", {"reason": "cancelled"})
                    return self._result(
                        state=current_state,
                        stop_reason="cancelled",
                        turns_used=turns_used,
                        usage=total_usage,
                        events=events,
                        error=error,
                    )
                deadline_error = self._budget_error(
                    config,
                    started,
                    tool_calls_used,
                    turns_used,
                    total_usage,
                )
                if deadline_error is not None:
                    emit(
                        "run_failed",
                        {
                            "reason": "budget_exceeded",
                            "code": deadline_error.code,
                        },
                    )
                    return self._result(
                        state=current_state,
                        stop_reason="budget_exceeded",
                        turns_used=turns_used,
                        usage=total_usage,
                        events=events,
                        error=deadline_error,
                    )
                raise
            results_by_id = {result.tool_call_id: result for result in executed_results}
            results_by_id.update(terminal_errors)
            tool_results = [results_by_id[call.id] for call in permitted_tool_calls]
            tool_results.extend(
                ToolResult(
                    tool_call_id=call.id,
                    tool_name=call.tool_name,
                    content=[TextContent(text="Tool call skipped because budget was exhausted")],
                    is_error=True,
                    details={"code": "BUDGET_TOOL_CALLS"},
                )
                for call in tool_calls[len(permitted_tool_calls) :]
            )
            tool_calls_used += len(permitted_tool_calls)
            for result in tool_results:
                total_usage = self._add_usage(total_usage, result.usage)
                current_state.messages.append(
                    ToolResultMessage(
                        tool_call_id=result.tool_call_id,
                        tool_name=result.tool_name,
                        content=result.content,
                        is_error=result.is_error,
                        details=result.details,
                    ),
                )
            if budget_limited:
                budget_error = ErrorInfo(
                    code="BUDGET_TOOL_CALLS",
                    message="Tool call budget exceeded",
                    retryable=False,
                )
                emit(
                    "run_failed",
                    {"reason": "budget_exceeded", "code": budget_error.code},
                )
                return self._result(
                    state=current_state,
                    stop_reason="budget_exceeded",
                    turns_used=turns_used,
                    usage=total_usage,
                    events=events,
                    error=budget_error,
                )

        emit("run_failed", {"reason": "max_turns"})
        return self._result(
            state=current_state,
            stop_reason="max_turns",
            turns_used=turns_used,
            usage=total_usage,
            events=events,
            error=ErrorInfo(code="MAX_TURNS", message="Maximum loop turns reached", retryable=True),
        )

    def _generate_with_retry(
        self,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> ModelResponse:
        """Call the model, retrying transient provider failures with backoff.

        Auth and other non-transient failures propagate immediately to the
        `on_model_error` hook (spec §9.3 default policy).
        """

        attempt = 0
        while True:
            try:
                return self._runtime.model_client.generate(
                    request,
                    cancellation,
                )
            except CoordinationFailure:
                raise
            except Exception as exc:
                if cancellation.cancelled:
                    raise
                if attempt >= _MODEL_RETRY_ATTEMPTS or not _is_transient_model_error(exc):
                    raise
                attempt += 1
                self._sleep_before_retry(
                    _MODEL_RETRY_BACKOFF_SECONDS * attempt,
                    cancellation,
                )

    def _sleep_before_retry(self, delay: float, cancellation: Cancellation) -> None:
        """Wait for a retry while polling cooperative cancellation and deadlines."""

        cancellation.throw_if_cancelled()
        if self._sleeper is not sleep:
            self._sleeper(delay)
            cancellation.throw_if_cancelled()
            return

        remaining = delay
        while remaining > 0:
            interval = min(0.1, remaining)
            self._sleeper(interval)
            remaining -= interval
            cancellation.throw_if_cancelled()

    def _execute_tool_calls(
        self,
        tool_calls: list[ToolCall],
        context: Context,
        emit: Emit,
        strings: FrozenPromptStrings,
        allowed_tool_names: set[str],
        cancellation: Cancellation,
    ) -> list[ToolResult]:
        sequential = [call for call in tool_calls if self._execution_mode_for(call) == "sequential"]
        parallel = [call for call in tool_calls if call not in sequential]
        results: list[ToolResult] = []

        for call in sequential:
            results.append(
                self._execute_one_tool(
                    call,
                    context,
                    emit,
                    strings,
                    allowed_tool_names,
                    cancellation,
                )
            )

        if parallel:
            batch_cancellation = CoordinationCancellation(cancellation)
            with ThreadPoolExecutor(
                max_workers=min(len(parallel), _MAX_PARALLEL_TOOL_WORKERS)
            ) as executor:
                futures = {
                    executor.submit(
                        self._execute_parallel_tool,
                        call,
                        context,
                        emit,
                        strings,
                        allowed_tool_names,
                        batch_cancellation,
                    ): call.id
                    for call in parallel
                }
                completed = self._collect_parallel_results(futures, batch_cancellation)
                results.extend(completed[call.id] for call in parallel)

        return results

    @staticmethod
    def _collect_parallel_results(
        futures: dict[Future[ToolResult], str], cancellation: CoordinationCancellation
    ) -> dict[str, ToolResult]:
        completed: dict[str, ToolResult] = {}
        for future in as_completed(futures):
            try:
                completed[futures[future]] = future.result()
            except BaseException as exc:
                cancellation.stop(exc)
        # Executor shutdown alone waits but does not inspect later failures.
        # Consume every worker before choosing the original host failure.
        cancellation.raise_if_failed()
        return completed

    def _execute_parallel_tool(
        self,
        tool_call: ToolCall,
        context: Context,
        emit: Emit,
        strings: FrozenPromptStrings,
        allowed_tool_names: set[str],
        cancellation: CoordinationCancellation,
    ) -> ToolResult:
        try:
            return self._execute_one_tool(
                tool_call, context, emit, strings, allowed_tool_names, cancellation
            )
        except BaseException as exc:
            cancellation.stop(exc)
            raise

    def _execute_one_tool(
        self,
        tool_call: ToolCall,
        context: Context,
        emit: Emit,
        strings: FrozenPromptStrings,
        allowed_tool_names: set[str],
        cancellation: Cancellation,
    ) -> ToolResult:
        cancellation.throw_if_cancelled()
        emit(
            "tool_call_started",
            {"toolCallId": tool_call.id, "toolName": tool_call.tool_name},
        )
        if tool_call.tool_name not in allowed_tool_names:
            result = ToolResult(
                tool_call_id=tool_call.id,
                tool_name=tool_call.tool_name,
                content=[TextContent(text="Tool is not available for this turn")],
                is_error=True,
                details={"code": "TOOL_NOT_ALLOWED"},
            )
            emit("tool_call_completed", {"toolCallId": tool_call.id, "isError": True})
            return result

        binding = self._runtime.bindings_by_name.get(tool_call.tool_name)
        if binding is None:
            result = ToolResult(
                tool_call_id=tool_call.id,
                tool_name=tool_call.tool_name,
                content=[TextContent(text=f"Unknown tool: {tool_call.tool_name}")],
                is_error=True,
                details={"code": "UNKNOWN_TOOL"},
            )
            emit("tool_call_completed", {"toolCallId": tool_call.id, "isError": True})
            return result

        if not self._allows_tool_call(tool_call, context, binding.descriptor):
            if binding.descriptor.requires_approval:
                blocked_text = "Tool requires an approval decision before it can run"
                blocked_code = "APPROVAL_REQUIRED"
            else:
                blocked_text = "Tool call blocked by policy"
                blocked_code = "TOOL_BLOCKED"
            result = ToolResult(
                tool_call_id=tool_call.id,
                tool_name=tool_call.tool_name,
                content=[TextContent(text=blocked_text)],
                is_error=True,
                details={"code": blocked_code},
            )
            emit("tool_call_completed", {"toolCallId": tool_call.id, "isError": True})
            return result

        tool_cancellation: Cancellation = cancellation
        if binding.descriptor.timeout_seconds is not None:
            tool_cancellation = _DeadlineCancellation(
                cancellation,
                monotonic() + binding.descriptor.timeout_seconds,
            )

        handle = RunHandle(
            execution_id=self._execution_id(context),
            context=context,
        )
        invocation = OperationInvocation(
            context=context,
            handle=handle,
            cancellation=tool_cancellation,
        )

        try:
            tool_cancellation.throw_if_cancelled()
            result = execute_tool_binding(
                binding,
                raw_arguments=tool_call.arguments,
                context=context,
                invocation=invocation,
                tool_call_id=tool_call.id,
                on_progress=lambda event: emit("tool_call_updated", event.payload),
            )
            tool_cancellation.throw_if_cancelled()
        except TimeoutError as exc:
            raise_coordination_failure(exc)
            if cancellation.cancelled:
                raise
            result = ToolResult(
                tool_call_id=tool_call.id,
                tool_name=tool_call.tool_name,
                content=[TextContent(text="Tool execution timed out")],
                is_error=True,
                details={"code": "TOOL_TIMEOUT"},
            )
        except Exception as exc:
            raise_operation_key_error(exc)
            raise_coordination_failure(exc)
            if cancellation.cancelled:
                raise
            error_text = f"Tool execution failed ({type(exc).__name__})"
            if strings.tool_error_recovery:
                error_text = f"{error_text}\n\n{strings.tool_error_recovery}"
            result = ToolResult(
                tool_call_id=tool_call.id,
                tool_name=tool_call.tool_name,
                content=[TextContent(text=error_text)],
                is_error=True,
                details={"code": "TOOL_ERROR"},
            )

        normalized = self._runtime.hooks.after_tool_call(tool_call, result, context)
        if normalized.tool_call_id != tool_call.id:
            normalized = normalized.model_copy(update={"tool_call_id": tool_call.id})
        emit(
            "tool_call_completed",
            {
                "toolCallId": tool_call.id,
                "toolName": tool_call.tool_name,
                "isError": normalized.is_error,
            },
        )
        return normalized

    def _execution_mode_for(self, tool_call: ToolCall) -> Literal["parallel", "sequential"]:
        binding = self._runtime.bindings_by_name.get(tool_call.tool_name)
        if binding is None:
            return "parallel"
        return binding.descriptor.execution_mode

    def _terminal_results(
        self,
        tool_calls: list[ToolCall],
        config: AgentLoopConfig,
        strings: FrozenPromptStrings,
        descriptors_by_name: dict[str, ToolDescriptor],
        context: Context,
        emit: Emit,
    ) -> tuple[ToolResult | None, dict[str, ToolResult]]:
        terminal_names = set(config.terminal_tools)
        if not terminal_names:
            return None, {}
        errors: dict[str, ToolResult] = {}
        for call in tool_calls:
            descriptor = descriptors_by_name.get(call.tool_name)
            if call.tool_name not in terminal_names or descriptor is None:
                continue
            emit(
                "tool_call_started",
                {"toolCallId": call.id, "toolName": call.tool_name},
            )
            if not self._allows_tool_call(call, context, descriptor):
                blocked_code = (
                    "APPROVAL_REQUIRED" if descriptor.requires_approval else "TOOL_BLOCKED"
                )
                blocked_text = (
                    "Tool requires an approval decision before it can run"
                    if descriptor.requires_approval
                    else "Tool call blocked by policy"
                )
                errors[call.id] = ToolResult(
                    tool_call_id=call.id,
                    tool_name=call.tool_name,
                    content=[TextContent(text=blocked_text)],
                    is_error=True,
                    details={"code": blocked_code},
                )
                emit("tool_call_completed", {"toolCallId": call.id, "isError": True})
                continue
            validation_message = self._descriptor_validation_error(descriptor, call.arguments)
            if validation_message is not None:
                errors[call.id] = ToolResult(
                    tool_call_id=call.id,
                    tool_name=call.tool_name,
                    content=[TextContent(text=validation_message)],
                    is_error=True,
                    details={"code": "INVALID_ARGUMENTS"},
                )
                emit("tool_call_completed", {"toolCallId": call.id, "isError": True})
                continue
            terminal_result = self._runtime.hooks.after_tool_call(
                call,
                ToolResult(
                    tool_call_id=call.id,
                    tool_name=call.tool_name,
                    content=[TextContent(text=strings.terminal_tool_accepted or "")],
                    details=call.arguments,
                ),
                context,
            )
            if terminal_result.tool_call_id != call.id:
                terminal_result = terminal_result.model_copy(update={"tool_call_id": call.id})
            emit(
                "tool_call_completed",
                {"toolCallId": call.id, "isError": terminal_result.is_error},
            )
            if terminal_result.is_error:
                errors[call.id] = terminal_result
                continue
            return (
                terminal_result,
                errors,
            )
        return None, errors

    def _allows_tool_call(
        self,
        tool_call: ToolCall,
        context: Context,
        descriptor: ToolDescriptor,
    ) -> bool:
        hooks = self._runtime.hooks
        if descriptor.requires_approval and type(hooks).before_tool_call in {
            DefaultLoopHooks.before_tool_call,
            _StandaloneDefaultHooks.before_tool_call,
        }:
            return False
        return hooks.before_tool_call(tool_call, context)

    @staticmethod
    def _descriptor_validation_error(
        descriptor: ToolDescriptor,
        arguments: JsonObject,
    ) -> str | None:
        try:
            Draft202012Validator.check_schema(descriptor.input_schema)
            validator = Draft202012Validator(descriptor.input_schema)
        except SchemaError:
            return f"Tool {validation_tool_name(descriptor.name)} has an invalid input schema"
        properties: object = descriptor.input_schema.get("properties", {})
        fields = (
            {name for name in properties if isinstance(name, str)}
            if isinstance(properties, dict)
            else set()
        )
        return _format_descriptor_validation_errors(
            descriptor.name, validator.iter_errors(arguments), fields
        )

    @staticmethod
    def _available_tool_calls(
        config: AgentLoopConfig,
        tool_calls_used: int,
    ) -> int | None:
        if config.budget is None or config.budget.max_tool_calls is None:
            return None
        return max(0, config.budget.max_tool_calls - tool_calls_used)

    @staticmethod
    def _duplicate_tool_call_ids(tool_calls: list[ToolCall]) -> set[str]:
        seen: set[str] = set()
        duplicates: set[str] = set()
        for call in tool_calls:
            if call.id in seen:
                duplicates.add(call.id)
            seen.add(call.id)
        return duplicates

    def _budget_error(
        self,
        config: AgentLoopConfig,
        started: float,
        tool_calls_used: int,
        turns_used: int,
        usage: Usage,
    ) -> ErrorInfo | None:
        if (
            config.wall_clock_timeout_seconds is not None
            and monotonic() - started >= config.wall_clock_timeout_seconds
        ):
            return ErrorInfo(code="WALL_CLOCK_TIMEOUT", message="Loop wall-clock timeout exceeded")
        if config.budget is None:
            return None
        if (
            config.budget.max_duration_seconds is not None
            and monotonic() - started >= config.budget.max_duration_seconds
        ):
            return ErrorInfo(code="BUDGET_DURATION", message="Run duration budget exceeded")
        if (
            config.budget.max_tool_calls is not None
            and tool_calls_used >= config.budget.max_tool_calls
        ):
            return ErrorInfo(code="BUDGET_TOOL_CALLS", message="Tool call budget exceeded")
        if config.budget.max_iterations is not None and turns_used >= config.budget.max_iterations:
            return ErrorInfo(code="BUDGET_ITERATIONS", message="Iteration budget exceeded")
        if (
            config.budget.max_cost is not None
            and usage.estimated_cost is not None
            and usage.estimated_cost.total >= config.budget.max_cost
        ):
            return ErrorInfo(
                code="BUDGET_COST",
                message=(
                    f"Estimated cost {usage.estimated_cost.total:.4f} reached "
                    f"the budget of {config.budget.max_cost:.4f}"
                ),
            )
        return None

    def _result(
        self,
        state: AgentLoopState,
        stop_reason: str,
        turns_used: int,
        usage: Usage,
        events: list[RunEvent],
        output: str | JsonObject | None = None,
        terminal_result: ToolResult | None = None,
        error: ErrorInfo | None = None,
    ) -> AgentLoopResult:
        return AgentLoopResult(
            state=state,
            stop_reason=cast(
                Literal[
                    "completed",
                    "terminal_tool",
                    "max_turns",
                    "budget_exceeded",
                    "cancelled",
                    "model_error",
                    "tool_error",
                ],
                stop_reason,
            ),
            output=output,
            terminal_result=terminal_result,
            turns_used=turns_used,
            usage=usage,
            events=events,
            error=error,
        )

    @staticmethod
    def _assistant_text(message: AssistantMessage) -> str:
        return "\n".join(block.text for block in message.content if isinstance(block, TextContent))

    @staticmethod
    def _execution_id(context: Context) -> str:
        return context.execution_id or context.correlation_id

    @staticmethod
    def _add_usage(total: Usage, usage: Usage | None) -> Usage:
        if usage is None:
            return total
        return Usage(
            input_tokens=total.input_tokens + usage.input_tokens,
            output_tokens=total.output_tokens + usage.output_tokens,
            cache_read_tokens=total.cache_read_tokens + usage.cache_read_tokens,
            cache_write_tokens=total.cache_write_tokens + usage.cache_write_tokens,
            estimated_cost=AgentLoopEngine._add_cost(total.estimated_cost, usage.estimated_cost),
            model=usage.model or total.model,
            provider=usage.provider or total.provider,
        )

    @staticmethod
    def _add_cost(
        total: EstimatedCost | None,
        cost: EstimatedCost | None,
    ) -> EstimatedCost | None:
        if total is None:
            return cost
        if cost is None:
            return total
        return EstimatedCost(
            input=total.input + cost.input,
            output=total.output + cost.output,
            cache_read=total.cache_read + cost.cache_read,
            cache_write=total.cache_write + cost.cache_write,
            total=total.total + cost.total,
        )
