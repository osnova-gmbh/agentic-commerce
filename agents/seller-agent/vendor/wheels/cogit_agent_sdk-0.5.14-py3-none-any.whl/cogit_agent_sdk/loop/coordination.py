"""Cooperatively stop a parallel tool batch after host coordination fails."""

from __future__ import annotations

from threading import Lock

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import Cancellation


class CoordinationCancellation:
    """Share the first host failure with queued and cooperative tool calls."""

    def __init__(self, delegate: Cancellation) -> None:
        self._delegate = delegate
        self._error: BaseException | None = None
        self._failure: CoordinationFailure | None = None
        self._lock = Lock()

    def stop(self, error: BaseException) -> None:
        with self._lock:
            if self._error is None:
                self._error = error
            if isinstance(error, CoordinationFailure) and self._failure is None:
                self._failure = error

    @property
    def cancelled(self) -> bool:
        with self._lock:
            failed = self._error is not None
        return failed or self._delegate.cancelled

    @property
    def remaining_seconds(self) -> float | None:
        remaining = getattr(self._delegate, "remaining_seconds", None)
        return float(remaining) if isinstance(remaining, int | float) else None

    def raise_if_failed(self) -> None:
        """Give the first known coordination failure priority over sibling errors."""
        with self._lock:
            error = self._failure if self._failure is not None else self._error
        if error is not None:
            raise error

    def throw_if_cancelled(self) -> None:
        self.raise_if_failed()
        self._delegate.throw_if_cancelled()
