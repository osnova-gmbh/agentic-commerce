"""Bounded, authenticated v1 checkpoint for a normalized agent-loop transcript.

Runtime owns durable storage, effect receipts, and the integrity key. A checkpoint
contains no model client, provider credentials, Context metadata, or Python frames.
Conversation content is caller supplied and must be redacted before persistence.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from cogit_agent_sdk.types import (
    AgentLoopConfig,
    AgentLoopResult,
    AgentLoopState,
    AssistantMessage,
    Context,
    EstimatedCost,
    Message,
    TextContent,
    ToolResultMessage,
    Usage,
)
from cogit_agent_sdk.types.messages import ThinkingContent

if TYPE_CHECKING:
    from cogit_agent_sdk.loop.engine import AgentLoopEngine

CHECKPOINT_VERSION = 1
MAX_CHECKPOINT_BYTES = 1024 * 1024
MAX_CHECKPOINT_MESSAGES = 256
MAX_CHECKPOINT_TOOL_SLOTS = 256


class LoopStateError(ValueError):
    """A checkpoint cannot safely be written or restored."""


@dataclass(frozen=True)
class LoopBudgetLedger:
    """Cumulative usage restored by the host before another loop dispatch."""

    model_calls: int
    tool_calls: int
    usage: Usage
    elapsed_seconds: float = 0.0
    cost_authoritative: bool = False
    elapsed_authoritative: bool = False


@dataclass(frozen=True)
class ModelCallSlot:
    """Stable logical model call position within the normalized conversation."""

    turn: int
    message_index: int


@dataclass(frozen=True)
class ToolCallSlot:
    """Stable logical tool position and optional completed-result reference."""

    turn: int
    ordinal: int
    provider_call_id: str
    tool_name: str
    status: Literal["pending", "completed"]
    result_ref: str | None

    @property
    def logical_id(self) -> str:
        return f"tool:{self.turn}:{self.ordinal}"


@dataclass(frozen=True)
class RestoredLoopState:
    """A restored transcript; pending tools require receipt reconciliation."""

    _state: AgentLoopState
    model_slots: tuple[ModelCallSlot, ...]
    tool_slots: tuple[ToolCallSlot, ...]
    budget: LoopBudgetLedger
    pending_model_call_id: str | None = None

    @property
    def pending_tool_slots(self) -> tuple[ToolCallSlot, ...]:
        return tuple(slot for slot in self.tool_slots if slot.status == "pending")

    @property
    def state(self) -> AgentLoopState:
        """Return an isolated state; the engine guards unresolved call slots."""

        return self._state.model_copy(deep=True)

    def with_completed_result(
        self,
        result: ToolResultMessage,
        *,
        logical_id: str,
    ) -> RestoredLoopState:
        """Reconcile the exact pending logical slot with its durable result."""

        matches = [
            slot
            for slot in self.pending_tool_slots
            if slot.logical_id == logical_id
            and slot.provider_call_id == result.tool_call_id
            and slot.tool_name == result.tool_name
        ]
        if len(matches) != 1:
            raise LoopStateError("result does not match exactly one pending tool slot")
        state = self._state.model_copy(deep=True)
        state.messages.append(result.model_copy(deep=True))
        model_slots, tool_slots = _slots(state.messages)
        state.set_recovery_pending(
            self.pending_model_call_id,
            [slot.provider_call_id for slot in tool_slots if slot.status == "pending"],
        )
        return RestoredLoopState(
            state,
            model_slots,
            tool_slots,
            LoopBudgetLedger(
                self.budget.model_calls,
                self.budget.tool_calls + 1,
                self.budget.usage,
                self.budget.elapsed_seconds,
                False,
                False,
            ),
            self.pending_model_call_id,
        )

    def with_completed_model_call(
        self,
        call_slot_id: str,
        message: AssistantMessage,
    ) -> RestoredLoopState:
        """Accept an authoritative model result for one uncertain R10 call slot."""

        if call_slot_id != self.pending_model_call_id or self.pending_tool_slots:
            raise LoopStateError("model result does not match the pending call slot")
        _dump_message(message)
        state = self._state.model_copy(deep=True)
        state.messages.append(message.model_copy(deep=True))
        model_slots, tool_slots = _slots(state.messages)
        state.set_recovery_pending(
            None,
            [slot.provider_call_id for slot in tool_slots if slot.status == "pending"],
        )
        return RestoredLoopState(
            state,
            model_slots,
            tool_slots,
            LoopBudgetLedger(
                self.budget.model_calls + 1,
                self.budget.tool_calls,
                _add_usage(self.budget.usage, message.usage),
                self.budget.elapsed_seconds,
                self.budget.cost_authoritative
                and message.usage is not None
                and message.usage.estimated_cost is not None,
                False,
            ),
        )

    def with_authoritative_budget(self, budget: LoopBudgetLedger) -> RestoredLoopState:
        """Apply Runtime's cumulative ledger after durable result reconciliation."""

        _check_budget(budget, _derived_budget(self._state.messages))
        if (
            budget.model_calls < self.budget.model_calls
            or budget.tool_calls < self.budget.tool_calls
            or budget.elapsed_seconds < self.budget.elapsed_seconds
            or budget.usage.input_tokens < self.budget.usage.input_tokens
            or budget.usage.output_tokens < self.budget.usage.output_tokens
            or budget.usage.cache_read_tokens < self.budget.usage.cache_read_tokens
            or budget.usage.cache_write_tokens < self.budget.usage.cache_write_tokens
        ):
            raise LoopStateError("authoritative ledger rolls back completed work")
        old_cost = self.budget.usage.estimated_cost
        new_cost = budget.usage.estimated_cost
        if old_cost is not None and (new_cost is None or new_cost.total < old_cost.total):
            raise LoopStateError("authoritative ledger rolls back completed cost")
        trusted = LoopBudgetLedger(
            budget.model_calls,
            budget.tool_calls,
            budget.usage,
            budget.elapsed_seconds,
            True,
            True,
        )
        return RestoredLoopState(
            self._state.model_copy(deep=True),
            self.model_slots,
            self.tool_slots,
            trusted,
            self.pending_model_call_id,
        )


def dump_loop_state(
    state: AgentLoopState,
    *,
    integrity_key: bytes,
    budget: LoopBudgetLedger | None = None,
    pending_model_call_id: str | None = None,
) -> bytes:
    """Encode a canonical v1 checkpoint authenticated with the host's secret key."""

    _check_key(integrity_key)
    if state.metadata:
        raise LoopStateError("opaque loop metadata cannot be checkpointed")
    if len(state.messages) > MAX_CHECKPOINT_MESSAGES:
        raise LoopStateError("too many messages for a loop checkpoint")
    messages = [_dump_message(message) for message in state.messages]
    model_slots, tool_slots = _slots(state.messages)
    if len(tool_slots) > MAX_CHECKPOINT_TOOL_SLOTS:
        raise LoopStateError("too many tool slots for a loop checkpoint")
    derived = _derived_budget(state.messages)
    ledger = budget if budget is not None else derived
    _check_budget(ledger, derived)
    if not 0 <= state.current_turn <= 10_000:
        raise LoopStateError("invalid loop turn counter")
    pending_model_call_id = _pending_model_id(
        state.recovery_pending_model_call_id,
        pending_model_call_id,
        tool_slots,
    )
    pending_tool_ids = [slot.provider_call_id for slot in tool_slots if slot.status == "pending"]
    if state.recovery_pending_tool_call_ids and state.recovery_pending_tool_call_ids != tuple(
        pending_tool_ids
    ):
        raise LoopStateError("pending tool slots disagree with conversation")
    payload: dict[str, Any] = {
        "identity": _identity(state.context),
        "messages": messages,
        "modelSlots": [_model_slot_wire(slot) for slot in model_slots],
        "toolSlots": [_tool_slot_wire(slot) for slot in tool_slots],
        "budget": _budget_wire(ledger),
        "currentTurn": state.current_turn,
        "sessionId": state.session_id,
        "queuedInput": state.queued_input,
        "pendingModelCallId": pending_model_call_id,
    }
    signed = {"version": CHECKPOINT_VERSION, "payload": payload}
    mac = hmac.new(integrity_key, _canonical(signed), hashlib.sha256).hexdigest()
    data = _canonical({**signed, "mac": mac})
    if len(data) > MAX_CHECKPOINT_BYTES:
        raise LoopStateError("loop checkpoint exceeds size limit")
    return data


def _pending_model_id(
    recovered_id: str | None,
    requested_id: str | None,
    tool_slots: tuple[ToolCallSlot, ...],
) -> str | None:
    if requested_id is not None and recovered_id is not None and requested_id != recovered_id:
        raise LoopStateError("pending model call slot disagrees with recovered state")
    resolved = requested_id if requested_id is not None else recovered_id
    if resolved is not None:
        if type(resolved) is not str or not resolved.strip():
            raise LoopStateError("invalid pending model call slot")
        if len(resolved.encode("utf-8")) > 256 or any(
            slot.status == "pending" for slot in tool_slots
        ):
            raise LoopStateError("invalid pending model call slot")
    return resolved


def load_loop_state(
    data: bytes,
    *,
    context: Context,
    integrity_key: bytes,
) -> RestoredLoopState:
    """Verify and restore a checkpoint using a freshly supplied request Context."""

    _check_key(integrity_key)
    payload = _verified_payload(data, integrity_key)
    _validate_payload_identity(payload, context)
    messages = _checkpoint_messages(payload)
    model_slots, tool_slots = _slots(messages)
    _validate_wire_slots(payload, model_slots, tool_slots)
    turn, pending_model_call_id = _validated_recovery_fields(payload, tool_slots)
    ledger = _load_budget(payload["budget"])
    _check_budget(ledger, _derived_budget(messages))
    pending_tool_ids = [slot.provider_call_id for slot in tool_slots if slot.status == "pending"]
    state = AgentLoopState(
        messages=messages,
        context=context,
        current_turn=turn,
        session_id=payload["sessionId"],
        queued_input=payload["queuedInput"],
    )
    state.set_recovery_pending(pending_model_call_id, pending_tool_ids)
    return RestoredLoopState(state, model_slots, tool_slots, ledger, pending_model_call_id)


def _verified_payload(data: bytes, integrity_key: bytes) -> dict[str, Any]:
    if type(data) is not bytes or len(data) > MAX_CHECKPOINT_BYTES:
        raise LoopStateError("loop checkpoint exceeds size limit or is not bytes")
    try:
        envelope = json.loads(
            data.decode("utf-8"),
            object_pairs_hook=_no_duplicate_keys,
            parse_constant=lambda _: _invalid_json_constant(),
        )
    except (UnicodeError, ValueError, TypeError, RecursionError) as exc:
        raise LoopStateError("invalid loop checkpoint JSON") from exc
    if not isinstance(envelope, dict) or set(envelope) != {"version", "payload", "mac"}:
        raise LoopStateError("invalid loop checkpoint envelope")
    if envelope["version"] != CHECKPOINT_VERSION or type(envelope["version"]) is not int:
        raise LoopStateError("unsupported loop checkpoint version")
    if not isinstance(envelope["payload"], dict) or not isinstance(envelope["mac"], str):
        raise LoopStateError("invalid loop checkpoint envelope")
    if data != _canonical(envelope):
        raise LoopStateError("noncanonical loop checkpoint")
    expected = hmac.new(
        integrity_key,
        _canonical({"version": CHECKPOINT_VERSION, "payload": envelope["payload"]}),
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(envelope["mac"], expected):
        raise LoopStateError("loop checkpoint integrity check failed")
    return envelope["payload"]


def _validate_payload_identity(payload: dict[str, Any], context: Context) -> None:
    if set(payload) != {
        "identity",
        "messages",
        "modelSlots",
        "toolSlots",
        "budget",
        "currentTurn",
        "sessionId",
        "queuedInput",
        "pendingModelCallId",
    }:
        raise LoopStateError("unsupported loop checkpoint payload")
    if payload["identity"] != _identity(context):
        raise LoopStateError("loop checkpoint context identity mismatch")


def _checkpoint_messages(
    payload: dict[str, Any],
) -> list[Message | AssistantMessage | ToolResultMessage]:
    raw_messages = payload["messages"]
    if not isinstance(raw_messages, list) or len(raw_messages) > MAX_CHECKPOINT_MESSAGES:
        raise LoopStateError("invalid loop checkpoint messages")
    return [_load_message(value) for value in raw_messages]


def _validate_wire_slots(
    payload: dict[str, Any],
    model_slots: tuple[ModelCallSlot, ...],
    tool_slots: tuple[ToolCallSlot, ...],
) -> None:
    if len(tool_slots) > MAX_CHECKPOINT_TOOL_SLOTS:
        raise LoopStateError("too many tool slots for a loop checkpoint")
    if payload["modelSlots"] != [_model_slot_wire(slot) for slot in model_slots]:
        raise LoopStateError("loop checkpoint model slots disagree with conversation")
    if payload["toolSlots"] != [_tool_slot_wire(slot) for slot in tool_slots]:
        raise LoopStateError("loop checkpoint tool slots disagree with conversation")


def _validated_recovery_fields(
    payload: dict[str, Any],
    tool_slots: tuple[ToolCallSlot, ...],
) -> tuple[int, str | None]:
    turn = payload["currentTurn"]
    if type(turn) is not int or not 0 <= turn <= 10_000:
        raise LoopStateError("invalid loop turn counter")
    if payload["sessionId"] is not None and not isinstance(payload["sessionId"], str):
        raise LoopStateError("invalid loop session identifier")
    if payload["queuedInput"] is not None and not isinstance(payload["queuedInput"], str):
        raise LoopStateError("invalid queued input")
    pending_model_call_id = _pending_model_id(None, payload["pendingModelCallId"], tool_slots)
    return turn, pending_model_call_id


def remaining_loop_config(config: AgentLoopConfig, budget: LoopBudgetLedger) -> AgentLoopConfig:
    """Apply restored model/tool/cost spending to a fresh loop dispatch budget."""

    _check_budget(budget, LoopBudgetLedger(0, 0, Usage()))
    updated = config.model_copy(deep=True)
    updated.max_turns = max(0, config.max_turns - budget.model_calls)
    updated.wall_clock_timeout_seconds = _remaining_duration(
        updated.wall_clock_timeout_seconds,
        budget,
    )
    if updated.budget is not None:
        limits = updated.budget.model_copy(deep=True)
        if limits.max_iterations is not None:
            limits.max_iterations = max(0, limits.max_iterations - budget.model_calls)
        limits.max_duration_seconds = _remaining_duration(limits.max_duration_seconds, budget)
        if limits.max_tool_calls is not None:
            limits.max_tool_calls = max(0, limits.max_tool_calls - budget.tool_calls)
        limits.max_cost = _remaining_cost(limits.max_cost, budget)
        updated.budget = limits
    return updated


def _remaining_duration(limit: int | None, budget: LoopBudgetLedger) -> int | None:
    if limit is None:
        return None
    if not budget.elapsed_authoritative:
        raise LoopStateError("duration-bound recovery requires Runtime's authoritative ledger")
    if budget.elapsed_seconds >= limit:
        raise LoopStateError("recovery duration budget exhausted")
    return max(0, int(limit - budget.elapsed_seconds))


def _remaining_cost(limit: float | None, budget: LoopBudgetLedger) -> float | None:
    if limit is None:
        return None
    if not budget.cost_authoritative:
        raise LoopStateError("cost-bound recovery requires Runtime's authoritative ledger")
    cost = budget.usage.estimated_cost
    if cost is None:
        raise LoopStateError("cost-bound recovery requires known cumulative cost")
    if cost.total >= limit:
        raise LoopStateError("recovery cost budget exhausted")
    return max(0.0, limit - cost.total)


def run_restored_loop(
    engine: AgentLoopEngine,
    restored: RestoredLoopState,
    config: AgentLoopConfig,
) -> AgentLoopResult:
    """Resume only a fully reconciled state under remaining configured budgets."""

    state = restored.state
    ensure_reconciled_state(state)
    if state.messages:
        last = state.messages[-1]
        if isinstance(last, AssistantMessage) and not last.tool_calls:
            output = "\n".join(
                block.text for block in last.content if isinstance(block, TextContent)
            )
            return AgentLoopResult(
                state=state,
                stop_reason="completed",
                output=output,
                turns_used=0,
                usage=restored.budget.usage,
            )
    state.current_turn = 0
    return engine.run(state, remaining_loop_config(config, restored.budget))


def ensure_reconciled_state(state: AgentLoopState) -> None:
    """Fail before dispatch while a recovered model/tool call remains uncertain."""

    if state.recovery_pending_model_call_id or state.recovery_pending_tool_call_ids:
        raise LoopStateError("unresolved checkpoint call slots require Runtime reconciliation")


def _check_key(key: bytes) -> None:
    if type(key) is not bytes or len(key) < 32:
        raise LoopStateError("integrity key must be at least 32 bytes")


def _canonical(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, RecursionError) as exc:
        raise LoopStateError("non-JSON loop checkpoint content") from exc


def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for key, value in pairs:
        if key in output:
            raise ValueError("duplicate checkpoint field")
        output[key] = value
    return output


def _invalid_json_constant() -> None:
    raise ValueError("non-finite checkpoint number")


def _identity(context: Context) -> dict[str, Any]:
    return {
        "tenantId": context.tenant_id,
        "organizationId": context.organization_id,
        "agentId": context.agent_id,
        "principal": (
            {"kind": context.principal.kind, "id": context.principal.id}
            if context.principal is not None
            else None
        ),
        "executionId": context.execution_id,
        "caseId": context.case_id,
        "queueItemId": context.queue_item_id,
        "sessionId": context.session_id,
    }


def _dump_message(message: Message | AssistantMessage | ToolResultMessage) -> dict[str, Any]:
    if message.metadata:
        raise LoopStateError("opaque message metadata cannot be checkpointed")
    if any(isinstance(block, ThinkingContent) for block in message.content):
        raise LoopStateError("thinking content cannot be checkpointed")
    if isinstance(message, AssistantMessage):
        kind = "assistant"
    elif isinstance(message, ToolResultMessage):
        kind = "toolResult"
    elif type(message) is Message:
        kind = "message"
    else:
        raise LoopStateError("unsupported loop message")
    return {
        "kind": kind,
        "value": message.model_dump(mode="json", by_alias=True, exclude_none=True),
    }


def _load_message(value: Any) -> Message | AssistantMessage | ToolResultMessage:
    if not isinstance(value, dict) or set(value) != {"kind", "value"}:
        raise LoopStateError("invalid loop message envelope")
    wire = value["value"]
    if not isinstance(wire, dict):
        raise LoopStateError("invalid loop message")
    try:
        kind = value["kind"]
        if kind == "assistant":
            message: Message | AssistantMessage | ToolResultMessage = (
                AssistantMessage.model_validate(wire)
            )
        elif kind == "toolResult":
            message = ToolResultMessage.model_validate(wire)
        elif kind == "message":
            message = Message.model_validate(wire)
        else:
            raise LoopStateError("unsupported loop message kind")
    except LoopStateError:
        raise
    except ValueError as exc:
        raise LoopStateError("invalid loop message") from exc
    if _dump_message(message) != value:
        raise LoopStateError("noncanonical or unsupported loop message")
    return message


def _slots(
    messages: list[Message | AssistantMessage | ToolResultMessage],
) -> tuple[tuple[ModelCallSlot, ...], tuple[ToolCallSlot, ...]]:
    models: list[ModelCallSlot] = []
    tools: list[ToolCallSlot] = []
    pending: dict[str, int] = {}
    for index, message in enumerate(messages):
        if isinstance(message, AssistantMessage):
            if pending:
                raise LoopStateError("assistant turn follows an unresolved tool call")
            turn = len(models) + 1
            models.append(ModelCallSlot(turn, index))
            for ordinal, call in enumerate(message.tool_calls or [], start=1):
                if not call.id or not call.tool_name or call.id in pending:
                    raise LoopStateError(
                        "missing or repeated provider tool call identifier in a turn"
                    )
                pending[call.id] = len(tools)
                tools.append(ToolCallSlot(turn, ordinal, call.id, call.tool_name, "pending", None))
        elif isinstance(message, ToolResultMessage):
            slot_index = pending.pop(message.tool_call_id, None)
            if slot_index is None:
                raise LoopStateError("orphan or repeated tool result")
            slot = tools[slot_index]
            if slot.tool_name != message.tool_name:
                raise LoopStateError("tool result name does not match its call")
            ref = "sha256:" + hashlib.sha256(_canonical(_dump_message(message))).hexdigest()
            tools[slot_index] = ToolCallSlot(
                slot.turn,
                slot.ordinal,
                slot.provider_call_id,
                slot.tool_name,
                "completed",
                ref,
            )
        elif pending:
            raise LoopStateError("conversation advances before tool results are reconciled")
    return tuple(models), tuple(tools)


def _model_slot_wire(slot: ModelCallSlot) -> dict[str, Any]:
    return {"turn": slot.turn, "messageIndex": slot.message_index}


def _tool_slot_wire(slot: ToolCallSlot) -> dict[str, Any]:
    return {
        "logicalId": slot.logical_id,
        "providerCallId": slot.provider_call_id,
        "toolName": slot.tool_name,
        "status": slot.status,
        "resultRef": slot.result_ref,
    }


def _derived_budget(
    messages: list[Message | AssistantMessage | ToolResultMessage],
) -> LoopBudgetLedger:
    model_calls = 0
    tool_calls = 0
    input_tokens = 0
    output_tokens = 0
    cache_read_tokens = 0
    cache_write_tokens = 0
    cost = 0.0
    known_cost = True
    for message in messages:
        if isinstance(message, AssistantMessage):
            model_calls += 1
            if message.usage is not None:
                input_tokens += message.usage.input_tokens
                output_tokens += message.usage.output_tokens
                cache_read_tokens += message.usage.cache_read_tokens
                cache_write_tokens += message.usage.cache_write_tokens
                if message.usage.estimated_cost is not None:
                    cost += message.usage.estimated_cost.total
                else:
                    known_cost = False
            else:
                known_cost = False
        elif isinstance(message, ToolResultMessage):
            tool_calls += 1
    return LoopBudgetLedger(
        model_calls,
        tool_calls,
        Usage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            estimated_cost=EstimatedCost(total=cost) if known_cost else None,
        ),
    )


def _add_usage(total: Usage, added: Usage | None) -> Usage:
    if added is None:
        return total.model_copy(update={"estimated_cost": None})
    total_cost = total.estimated_cost
    added_cost = added.estimated_cost
    cost = None
    if total_cost is not None and added_cost is not None:
        first = total_cost or EstimatedCost()
        second = added_cost or EstimatedCost()
        cost = EstimatedCost(
            input=first.input + second.input,
            output=first.output + second.output,
            cache_read=first.cache_read + second.cache_read,
            cache_write=first.cache_write + second.cache_write,
            total=first.total + second.total,
        )
    return Usage(
        input_tokens=total.input_tokens + added.input_tokens,
        output_tokens=total.output_tokens + added.output_tokens,
        cache_read_tokens=total.cache_read_tokens + added.cache_read_tokens,
        cache_write_tokens=total.cache_write_tokens + added.cache_write_tokens,
        estimated_cost=cost,
        model=added.model or total.model,
        provider=added.provider or total.provider,
    )


def _check_budget(budget: LoopBudgetLedger, derived: LoopBudgetLedger) -> None:
    if (
        type(budget.model_calls) is not int
        or type(budget.tool_calls) is not int
        or budget.model_calls < derived.model_calls
        or budget.tool_calls < derived.tool_calls
        or budget.model_calls > 10_000
        or budget.tool_calls > 10_000
    ):
        raise LoopStateError("invalid loop budget counters")
    _check_budget_authority(budget)
    if type(budget.elapsed_seconds) not in (int, float) or not (
        0 <= budget.elapsed_seconds < 1_000_000_000
    ):
        raise LoopStateError("invalid elapsed loop budget")
    if any(
        type(value) is not int or value < 0 or value > 1_000_000_000
        for value in (
            budget.usage.input_tokens,
            budget.usage.output_tokens,
            budget.usage.cache_read_tokens,
            budget.usage.cache_write_tokens,
        )
    ):
        raise LoopStateError("invalid loop token usage")
    if any(
        actual < minimum
        for actual, minimum in (
            (budget.usage.input_tokens, derived.usage.input_tokens),
            (budget.usage.output_tokens, derived.usage.output_tokens),
            (budget.usage.cache_read_tokens, derived.usage.cache_read_tokens),
            (budget.usage.cache_write_tokens, derived.usage.cache_write_tokens),
        )
    ):
        raise LoopStateError("loop usage understates recorded model usage")
    if budget.usage.estimated_cost is not None:
        value = budget.usage.estimated_cost.total
        if not 0 <= value < 1_000_000_000:
            raise LoopStateError("invalid loop cost usage")
    derived_cost = derived.usage.estimated_cost
    if derived_cost is not None and derived_cost.total > 0:
        actual_cost = budget.usage.estimated_cost
        if actual_cost is None or actual_cost.total < derived_cost.total:
            raise LoopStateError("loop cost understates recorded model usage")


def _check_budget_authority(budget: LoopBudgetLedger) -> None:
    if type(budget.cost_authoritative) is not bool:
        raise LoopStateError("invalid loop cost authority marker")
    if type(budget.elapsed_authoritative) is not bool:
        raise LoopStateError("invalid loop duration authority marker")


def _budget_wire(budget: LoopBudgetLedger) -> dict[str, Any]:
    return {
        "modelCalls": budget.model_calls,
        "toolCalls": budget.tool_calls,
        "elapsedSeconds": budget.elapsed_seconds,
        "costAuthoritative": budget.cost_authoritative,
        "elapsedAuthoritative": budget.elapsed_authoritative,
        "usage": budget.usage.model_dump(mode="json", by_alias=True, exclude_none=True),
    }


def _load_budget(value: Any) -> LoopBudgetLedger:
    if not isinstance(value, dict) or set(value) != {
        "modelCalls",
        "toolCalls",
        "elapsedSeconds",
        "costAuthoritative",
        "elapsedAuthoritative",
        "usage",
    }:
        raise LoopStateError("invalid loop budget ledger")
    if not isinstance(value["usage"], dict):
        raise LoopStateError("invalid loop usage")
    try:
        usage = Usage.model_validate(value["usage"])
    except ValueError as exc:
        raise LoopStateError("invalid loop usage") from exc
    ledger = LoopBudgetLedger(
        value["modelCalls"],
        value["toolCalls"],
        usage,
        value["elapsedSeconds"],
        value["costAuthoritative"],
        value["elapsedAuthoritative"],
    )
    if _budget_wire(ledger) != value:
        raise LoopStateError("noncanonical loop usage")
    return ledger
