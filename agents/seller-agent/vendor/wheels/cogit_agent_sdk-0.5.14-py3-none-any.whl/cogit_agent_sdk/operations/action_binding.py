"""Action binding pairs an operation with exposure metadata."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Generic

from cogit_agent_sdk.operations.contract import (
    InputT,
    OperationContract,
    OperationInvocation,
    OutputT,
)
from cogit_agent_sdk.operations.schema_parity import assert_descriptor_schemas_match_operation
from cogit_agent_sdk.types import ActionDescriptor, Context
from cogit_agent_sdk.types.requirements import require_capabilities


@dataclass(frozen=True)
class ActionBinding(Generic[InputT, OutputT]):
    """Pairs one operation with one action descriptor."""

    operation: OperationContract[InputT, OutputT]
    descriptor: ActionDescriptor
    key_for: Callable[[InputT, Context], str] | None = None

    def __post_init__(self) -> None:
        assert_descriptor_schemas_match_operation(
            self.operation,
            self.descriptor,
            name=self.descriptor.name,
        )

    def invoke(
        self, request: InputT, invocation: OperationInvocation
    ) -> OutputT | Awaitable[OutputT]:
        """Run via the binding after a portable fail-closed capability preflight.

        Hosts must still refresh canonical grants immediately before an effect.
        """

        require_capabilities(
            self.descriptor.required_capabilities,
            invocation.context.permissions,
        )
        return self.operation(request, invocation)
