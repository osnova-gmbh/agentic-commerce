"""Action and tool binding helpers and operation factories."""

from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from typing import Any, Generic, Literal, cast, get_args, get_origin, get_type_hints

from pydantic import BaseModel

from cogit_agent_sdk.operations.action_binding import ActionBinding
from cogit_agent_sdk.operations.contract import (
    InputT,
    OperationContract,
    OperationInvocation,
    OutputT,
)
from cogit_agent_sdk.operations.schema import derive_model_schema
from cogit_agent_sdk.operations.tool_binding import PrepareArguments, ToolBinding
from cogit_agent_sdk.types import ActionDescriptor, Context, ToolDescriptor
from cogit_agent_sdk.types._immutable import thaw_value
from cogit_agent_sdk.types.actions import IdempotencyLevel, RiskLevel
from cogit_agent_sdk.types.requirements import (
    CapabilityNeed,
    OperationRequirements,
    normalize_required_capabilities,
)

OperationCallable = Callable[[InputT, OperationInvocation], OutputT | Awaitable[OutputT]]
ExecutionMode = Literal["parallel", "sequential"]


def _requirements(
    *,
    risk: RiskLevel,
    idempotency: IdempotencyLevel,
    required_capabilities: Sequence[CapabilityNeed],
    requires_approval: bool,
) -> OperationRequirements:
    return OperationRequirements(
        risk=risk,
        idempotency=idempotency,
        required_capabilities=normalize_required_capabilities(tuple(required_capabilities)),
        requires_approval=requires_approval,
    )


def bind_action(
    operation: OperationContract[InputT, OutputT],
    *,
    name: str,
    description: str,
    risk: RiskLevel = "read",
    idempotency: IdempotencyLevel = "inherent",
    required_capabilities: Sequence[CapabilityNeed] = (),
    requires_approval: bool = False,
    key_for: Callable[[InputT, Context], str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> ActionBinding[InputT, OutputT]:
    """Create an action binding; key_for resolves a stable key from validated input."""

    _verify_operation_annotations(operation)
    requirements = _requirements(
        risk=risk,
        idempotency=idempotency,
        required_capabilities=required_capabilities,
        requires_approval=requires_approval,
    )
    descriptor = ActionDescriptor.model_validate(
        {
            "name": name,
            "description": description,
            "input_schema": derive_model_schema(operation.input_model),
            "output_schema": derive_model_schema(operation.output_model),
            "risk": requirements.risk,
            "idempotency": requirements.idempotency,
            "required_capabilities": list(requirements.required_capabilities),
            "requires_approval": requirements.requires_approval,
            "metadata": metadata,
        },
    )
    return ActionBinding(operation=operation, descriptor=descriptor, key_for=key_for)


def bind_tool(
    operation: OperationContract[InputT, OutputT],
    *,
    name: str,
    description: str,
    risk: RiskLevel = "read",
    idempotency: IdempotencyLevel = "inherent",
    required_capabilities: Sequence[CapabilityNeed] = (),
    requires_approval: bool = False,
    execution_mode: ExecutionMode = "parallel",
    timeout_seconds: int | None = None,
    prepare_arguments: PrepareArguments | None = None,
    key_for: Callable[[InputT, Context], str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> ToolBinding[InputT, OutputT]:
    """Create a tool binding; key_for resolves a stable key from validated input."""

    _verify_operation_annotations(operation)
    requirements = _requirements(
        risk=risk,
        idempotency=idempotency,
        required_capabilities=required_capabilities,
        requires_approval=requires_approval,
    )
    descriptor = ToolDescriptor.model_validate(
        {
            "name": name,
            "description": description,
            "input_schema": derive_model_schema(operation.input_model),
            "output_schema": derive_model_schema(operation.output_model),
            "risk": requirements.risk,
            "idempotency": requirements.idempotency,
            "required_capabilities": list(requirements.required_capabilities),
            "requires_approval": requirements.requires_approval,
            "execution_mode": execution_mode,
            "timeout_seconds": timeout_seconds,
            "metadata": metadata,
        },
    )
    return ToolBinding(
        operation=operation,
        descriptor=descriptor,
        prepare_arguments=prepare_arguments,
        key_for=key_for,
    )


def bind_tool_from_action(
    action_binding: ActionBinding[InputT, OutputT],
    *,
    name: str | None = None,
    description: str | None = None,
    execution_mode: ExecutionMode,
    timeout_seconds: int | None = None,
) -> ToolBinding[InputT, OutputT]:
    """Derive a tool binding from an action binding without weakening requirements."""

    action_desc = action_binding.descriptor
    descriptor = ToolDescriptor.model_validate(
        {
            "name": name or action_desc.name,
            "description": description or action_desc.description,
            "input_schema": thaw_value(action_desc.input_schema),
            "output_schema": thaw_value(action_desc.output_schema),
            "risk": action_desc.risk,
            "idempotency": action_desc.idempotency,
            "required_capabilities": list(action_desc.required_capabilities),
            "requires_approval": action_desc.requires_approval,
            "execution_mode": execution_mode,
            "timeout_seconds": timeout_seconds,
            "metadata": thaw_value(action_desc.metadata)
            if action_desc.metadata is not None
            else None,
        },
    )
    if descriptor.requirements != action_desc.requirements:
        raise ValueError("derived tool binding weakened shared operation requirements")
    if derive_model_schema(action_binding.operation.input_model) != dict(
        descriptor.input_schema
    ) or derive_model_schema(action_binding.operation.output_model) != dict(
        descriptor.output_schema
    ):
        raise ValueError("derived tool binding must reuse action operation schemas")
    return ToolBinding(
        operation=action_binding.operation,
        descriptor=descriptor,
        key_for=action_binding.key_for,
    )


@dataclass(frozen=True)
class _FunctionOperation(Generic[InputT, OutputT]):
    input_model: type[InputT]
    output_model: type[OutputT]
    _func: Callable[..., Any]

    def __call__(
        self,
        request: InputT,
        invocation: OperationInvocation,
    ) -> OutputT | Awaitable[OutputT]:
        return self._func(request, invocation)


def operation(
    func: OperationCallable[InputT, OutputT],
) -> OperationContract[InputT, OutputT]:
    """Wrap a typed callable as an :class:`OperationContract`."""

    input_model, output_model = _infer_operation_models(func)
    _verify_callable_annotations(func, input_model, output_model)
    return cast(
        OperationContract[InputT, OutputT],
        _FunctionOperation(
            input_model=input_model,
            output_model=output_model,
            _func=func,
        ),
    )


def _infer_operation_models(
    func: Callable[..., Any],
) -> tuple[type[BaseModel], type[BaseModel]]:
    hints = get_type_hints(func)
    signature = inspect.signature(func)
    parameters = list(signature.parameters.values())
    if len(parameters) < 2:
        raise TypeError(
            f"Operation {func.__qualname__!r} must accept (request, invocation)",
        )
    request_hint = hints.get(parameters[0].name)
    return_hint = hints.get("return")
    if request_hint is None or not _is_base_model_type(request_hint):
        raise TypeError(
            f"Operation {func.__qualname__!r} request parameter must be a BaseModel subclass",
        )
    if return_hint is None:
        raise TypeError(f"Operation {func.__qualname__!r} must declare a return type")
    output_model = _unwrap_output_model(return_hint)
    if output_model is None:
        raise TypeError(
            f"Operation {func.__qualname__!r} return type must be a BaseModel subclass "
            "or Awaitable[BaseModel subclass]",
        )
    return request_hint, output_model


def _verify_operation_annotations(operation: OperationContract[Any, Any]) -> None:
    underlying = getattr(operation, "_func", None)
    if underlying is not None:
        _verify_callable_annotations(
            underlying,
            operation.input_model,
            operation.output_model,
        )
        return
    call = operation.__call__
    if not callable(call):
        raise TypeError("OperationContract implementation must be callable")
    _verify_callable_annotations(call, operation.input_model, operation.output_model)


def _verify_callable_annotations(
    func: Callable[..., Any],
    input_model: type[BaseModel],
    output_model: type[BaseModel],
) -> None:
    hints = get_type_hints(func)
    signature = inspect.signature(func)
    parameters = list(signature.parameters.values())
    if len(parameters) < 2:
        raise TypeError(
            f"Operation {func.__qualname__!r} must accept (request, invocation)",
        )
    request_hint = hints.get(parameters[0].name)
    if request_hint is not input_model:
        raise TypeError(
            f"Operation {func.__qualname__!r} request annotation {request_hint!r} "
            f"does not match input_model {input_model!r}",
        )
    return_hint = hints.get("return")
    resolved_output = _unwrap_output_model(return_hint) if return_hint is not None else None
    if resolved_output is not output_model:
        raise TypeError(
            f"Operation {func.__qualname__!r} return annotation {return_hint!r} "
            f"does not match output_model {output_model!r}",
        )


def _unwrap_output_model(return_hint: Any) -> type[BaseModel] | None:
    if _is_base_model_type(return_hint):
        return return_hint
    origin = get_origin(return_hint)
    if origin is not None:
        args = get_args(return_hint)
        if origin is Awaitable and len(args) == 1 and _is_base_model_type(args[0]):
            return args[0]
    return None


def _is_base_model_type(value: Any) -> bool:
    return isinstance(value, type) and issubclass(value, BaseModel)
