"""Operation registration and schema parity errors."""


class ActionRegistrationError(Exception):
    """Base error for action registration failures."""


class ToolRegistrationError(Exception):
    """Base error for tool registration failures."""


class SchemaMismatchError(ActionRegistrationError, ToolRegistrationError):
    """Raised when descriptor schemas do not match the bound operation models."""

    def __init__(self, name: str, *, field: str) -> None:
        self.name = name
        self.field = field
        super().__init__(
            f"{field} for {name!r} does not match the bound operation model schema",
        )
