"""JSON Schema derivation from Pydantic v2 models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


def derive_model_schema(model: type[BaseModel]) -> dict[str, Any]:
    """Derive JSON Schema from a Pydantic model, preserving aliases and ``$defs``."""

    return model.model_json_schema(by_alias=True)
