"""Core operation protocol types (descriptor-independent)."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, TypeVar, runtime_checkable

from pydantic import BaseModel

from cogit_agent_sdk.contracts import RunHandle
from cogit_agent_sdk.types import Cancellation, Context, ErrorInfo

if TYPE_CHECKING:
    from cogit_agent_sdk.types import RunEvent

InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


@dataclass(frozen=True)
class OperationInvocation:
    """Runtime context passed to every operation invocation."""

    context: Context
    handle: RunHandle
    cancellation: Cancellation
    idempotency_key: str | None = None
    emit_progress: Callable[[RunEvent], None] | None = None


@runtime_checkable
class OperationContract(Protocol[InputT, OutputT]):
    """Typed executable behavior independent of action exposure metadata."""

    input_model: type[InputT]
    output_model: type[OutputT]

    def __call__(
        self,
        request: InputT,
        invocation: OperationInvocation,
    ) -> OutputT | Awaitable[OutputT]: ...


class OperationError(Exception):
    """Expected operation failure carrying redacted ErrorInfo."""

    def __init__(self, error: ErrorInfo) -> None:
        self.error = error
        super().__init__(error.message)
