"""Deterministic action contract export from explicit bindings."""

from __future__ import annotations

import json
import os
import tempfile
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from cogit_agent_sdk.operations.action_binding import ActionBinding
from cogit_agent_sdk.operations.errors import ActionRegistrationError
from cogit_agent_sdk.types import ActionDescriptor
from cogit_agent_sdk.types.actions import canonicalize_action_descriptor

ACTION_CONTRACT_SCHEMA_VERSION = "v1"
_ALLOWED_TOP_LEVEL_KEYS = frozenset({"schema_version", "actions"})


class ActionContractExportError(ActionRegistrationError):
    """Raised when action contract export or validation fails."""


def action_descriptors_from_bindings(
    bindings: Sequence[ActionBinding[Any, Any]],
) -> tuple[ActionDescriptor, ...]:
    """Return canonical action descriptors sorted by stable action name."""

    seen: set[str] = set()
    descriptors: list[ActionDescriptor] = []
    for binding in bindings:
        name = binding.descriptor.name
        if name in seen:
            raise ActionContractExportError(f"duplicate action name {name!r}")
        seen.add(name)
        descriptors.append(canonicalize_action_descriptor(binding.descriptor))
    return tuple(sorted(descriptors, key=lambda item: item.name))


def export_action_contract(
    bindings: Sequence[ActionBinding[Any, Any]],
) -> dict[str, Any]:
    """Build the versioned action contract mapping."""

    actions = [
        descriptor.model_dump(mode="json", by_alias=False)
        for descriptor in action_descriptors_from_bindings(bindings)
    ]
    return {
        "schema_version": ACTION_CONTRACT_SCHEMA_VERSION,
        "actions": actions,
    }


def export_action_contract_json(
    bindings: Sequence[ActionBinding[Any, Any]],
    *,
    indent: int = 2,
) -> str:
    """Serialize the action contract as deterministic JSON."""

    payload = export_action_contract(bindings)
    if indent <= 0:
        return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return json.dumps(payload, indent=indent, sort_keys=True, ensure_ascii=False)


def parse_action_contract(data: object) -> tuple[ActionDescriptor, ...]:
    """Validate and canonicalize a versioned action contract payload."""

    if not isinstance(data, dict):
        raise ActionContractExportError("action contract must be a JSON object")

    unknown_keys = set(data.keys()) - _ALLOWED_TOP_LEVEL_KEYS
    if unknown_keys:
        unknown = ", ".join(sorted(unknown_keys))
        raise ActionContractExportError(
            f"action contract contains unknown top-level keys: {unknown}",
        )

    if "schema_version" not in data:
        raise ActionContractExportError("action contract must contain schema_version")

    schema_version = data["schema_version"]
    if schema_version != ACTION_CONTRACT_SCHEMA_VERSION:
        raise ActionContractExportError(
            f"unsupported action contract schema version {schema_version!r}",
        )

    actions_obj = data.get("actions")
    if not isinstance(actions_obj, list):
        raise ActionContractExportError("action contract must contain an actions array")

    try:
        descriptors = [
            canonicalize_action_descriptor(ActionDescriptor.model_validate(item))
            for item in actions_obj
        ]
    except (TypeError, ValidationError, ValueError) as exc:
        raise ActionContractExportError("action contract contains an invalid action") from exc

    names = [descriptor.name for descriptor in descriptors]
    if len(names) != len(set(names)):
        raise ActionContractExportError("action contract contains duplicate action names")
    return tuple(sorted(descriptors, key=lambda item: item.name))


def write_action_contract_artifact(
    path: str | Path,
    bindings: Sequence[ActionBinding[Any, Any]],
) -> Path:
    """Write the action contract JSON artifact atomically."""

    target = Path(path)
    content = export_action_contract_json(bindings) + "\n"
    target.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, raw_tmp_path = tempfile.mkstemp(
        dir=target.parent,
        prefix=f".{target.name}.",
        suffix=".tmp",
        text=True,
    )
    tmp_path = Path(raw_tmp_path)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        _replace_with_retry(tmp_path, target)
    except BaseException:
        tmp_path.unlink(missing_ok=True)
        raise
    return target


def _replace_with_retry(source: Path, target: Path) -> None:
    for attempt in range(10):
        try:
            os.replace(source, target)
            return
        except PermissionError:
            if attempt == 9:
                raise
            time.sleep(0.01 * (attempt + 1))
