"""Tool binding pairs an operation with model-facing exposure metadata."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Generic

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.operations.contract import InputT, OperationContract, OutputT
from cogit_agent_sdk.operations.schema_parity import assert_descriptor_schemas_match_operation
from cogit_agent_sdk.types import Context, ToolDescriptor
from cogit_agent_sdk.types.requirements import require_capabilities

PrepareArguments = Callable[[JsonObject, Context], JsonObject]


@dataclass(frozen=True)
class ToolBinding(Generic[InputT, OutputT]):
    """Pairs one operation with one tool descriptor."""

    operation: OperationContract[InputT, OutputT]
    descriptor: ToolDescriptor
    prepare_arguments: PrepareArguments | None = None
    key_for: Callable[[InputT, Context], str] | None = None

    def __post_init__(self) -> None:
        assert_descriptor_schemas_match_operation(
            self.operation,
            self.descriptor,
            name=self.descriptor.name,
        )

    def require_permissions(self, context: Context) -> None:
        """Check the binding against exact resolved Context grants before execution."""

        require_capabilities(self.descriptor.required_capabilities, context.permissions)
