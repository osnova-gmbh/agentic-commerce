"""Descriptor schema parity checks against operation models."""

from __future__ import annotations

from typing import Any

from cogit_agent_sdk.operations.contract import OperationContract
from cogit_agent_sdk.operations.errors import SchemaMismatchError
from cogit_agent_sdk.operations.schema import derive_model_schema
from cogit_agent_sdk.types._immutable import thaw_value


def _schema_dict(value: Any) -> dict[str, Any]:
    if hasattr(value, "items"):
        return dict(thaw_value(value) if not isinstance(value, dict) else value)
    raise TypeError("schema value must be a JSON object")


def assert_descriptor_schemas_match_operation(
    operation: OperationContract[Any, Any],
    descriptor: Any,
    *,
    name: str,
) -> None:
    """Ensure descriptor schemas exactly equal model-derived schemas."""

    expected_input = derive_model_schema(operation.input_model)
    expected_output = derive_model_schema(operation.output_model)
    actual_input = _schema_dict(descriptor.input_schema)
    actual_output = _schema_dict(descriptor.output_schema)
    if actual_input != expected_input:
        raise SchemaMismatchError(name, field="input_schema")
    if actual_output != expected_output:
        raise SchemaMismatchError(name, field="output_schema")
