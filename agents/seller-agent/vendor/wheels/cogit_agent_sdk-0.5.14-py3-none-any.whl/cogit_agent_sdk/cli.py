"""Agent-declared CLI command groups and reserved-name validation (Proposal 011).

This is the SDK half of custom CLI commands. An agent declares command groups
as data; the runtime (``cogit-runtime``) consumes them and turns each group
into an ``argparse`` subparser. ``validate_command_groups`` is a pure function
the runtime imports and calls at agent-construction time — before it starts
adding subparsers — to reject names that would collide with the runtime's own
built-in commands.

This module intentionally imports nothing else from the SDK so that the
runtime and ``contracts`` can import it without forming a cycle.
"""

from __future__ import annotations

import argparse
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "RESERVED_COMMAND_NAMES",
    "CliArgument",
    "CliCommand",
    "CliCommandGroup",
    "CliHandler",
    "ReservedCommandNameError",
    "validate_command_groups",
]


# Subcommand names owned by the cogit runtime itself. An agent-declared group
# may not reuse any of these — doing so would shadow a built-in command.
RESERVED_COMMAND_NAMES: frozenset[str] = frozenset(
    {"serve", "work", "eval", "migrate", "register"},
)


# First argument is an ``AgentServices`` instance (typed as ``Any`` here to
# avoid a circular import with ``cogit_agent_sdk.resident``); the second is the
# parsed argparse namespace. Returns the process exit code.
CliHandler = Callable[[Any, argparse.Namespace], int]


@dataclass
class CliArgument:
    """A single ``argparse`` argument, mirroring ``add_argument`` kwargs."""

    flags: tuple[str, ...]
    default: Any = None
    action: str | None = None
    type: Callable[..., Any] | None = None
    required: bool = False
    help: str | None = None

    def apply(self, subparser: argparse.ArgumentParser) -> None:
        """Add this argument to ``subparser``, passing only kwargs that are set.

        Unset options are omitted entirely (rather than passed as ``None``) so
        that ``argparse``'s own defaults remain in effect.
        """

        kwargs: dict[str, Any] = {}
        if self.default is not None:
            kwargs["default"] = self.default
        if self.action is not None:
            kwargs["action"] = self.action
        if self.type is not None:
            kwargs["type"] = self.type
        if self.required:
            kwargs["required"] = True
        if self.help is not None:
            kwargs["help"] = self.help
        subparser.add_argument(*self.flags, **kwargs)


@dataclass
class CliCommand:
    """A single CLI subcommand declared by an agent."""

    name: str
    help: str = ""
    arguments: list[CliArgument] = field(default_factory=list)
    # ``handler`` is placed last per the Proposal 011 shape; it therefore needs
    # a default (dataclasses forbid a non-default field after defaulted ones).
    # It is semantically required — runtime callers always supply it.
    handler: CliHandler | None = None


@dataclass
class CliCommandGroup:
    """A named group of related CLI subcommands."""

    name: str
    help: str = ""
    commands: list[CliCommand] = field(default_factory=list)


class ReservedCommandNameError(Exception):
    """Raised when an agent-declared command group reuses a reserved name."""

    def __init__(self, name: str, agent_class_name: str) -> None:
        self.name = name
        self.agent_class_name = agent_class_name
        super().__init__(
            f"Agent {agent_class_name!r} declares a reserved CLI command group "
            f"{name!r}; reserved names are: {sorted(RESERVED_COMMAND_NAMES)}.",
        )


def validate_command_groups(
    groups: list[CliCommandGroup],
    *,
    agent_class_name: str,
) -> None:
    """Reject any command group whose name collides with a reserved runtime command.

    Pure and side-effect free (no argparse dependency beyond
    :data:`RESERVED_COMMAND_NAMES`) so the runtime can import and call it
    directly at agent-construction time.
    """

    for group in groups:
        if group.name in RESERVED_COMMAND_NAMES:
            raise ReservedCommandNameError(group.name, agent_class_name)
