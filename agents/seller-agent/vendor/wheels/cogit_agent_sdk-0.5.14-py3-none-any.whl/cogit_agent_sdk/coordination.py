"""Portable failures that require the execution host's coordination policy."""


class CoordinationFailure(Exception):
    """An uncertain effect or lost execution authority must escape SDK handling.

    Host adapters subclass this marker for failures requiring reconciliation or
    fresh authority. The SDK preserves the original exception instead of turning
    it into a domain/tool result, model recovery, or a blind retry. The host owns
    that decision; this marker adds no persistence, retry policy, or wire fields.
    Subclasses remain responsible for redacting their messages and evidence.
    """


def raise_coordination_failure(error: Exception) -> None:
    """Preserve host failures before an existing domain-error handler runs."""
    if isinstance(error, CoordinationFailure):
        raise error
