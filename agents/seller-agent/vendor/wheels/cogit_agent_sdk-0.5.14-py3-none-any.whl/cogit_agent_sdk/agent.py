"""Stateful Agent facade over the deterministic loop engine."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Any

from cogit_agent_sdk.loop import AgentLoopEngine
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.types import (
    AgentLoopConfig,
    AgentLoopResult,
    AgentLoopState,
    Cancellation,
    Context,
    LoopHookSet,
    Message,
    ModelClient,
    RunEvent,
    TextContent,
)


class Agent:
    """Small stateful facade that delegates all turns to `AgentLoopEngine`."""

    def __init__(
        self,
        config: AgentLoopConfig,
        model_client: ModelClient,
        tools: Iterable[ToolBinding[Any, Any]] = (),
        hooks: LoopHookSet | None = None,
        cancellation: Cancellation | None = None,
    ) -> None:
        self._config = config
        self._engine = AgentLoopEngine(
            model_client=model_client,
            tools=tools,
            hooks=hooks,
            cancellation=cancellation,
        )
        self._state: AgentLoopState | None = None
        self._subscribers: dict[str, list[Callable[[RunEvent], None]]] = {}

    def prompt(self, input: str, context: Context) -> AgentLoopResult:
        """Start a new transcript and run one loop."""

        self._state = AgentLoopState(
            messages=[Message(role="user", content=[TextContent(text=input)])],
            context=context,
            session_id=context.session_id,
        )
        return self._run()

    def continue_(self, input: str, context: Context | None = None) -> AgentLoopResult:
        """Continue the current transcript with another user message."""

        if self._state is None:
            if context is None:
                raise RuntimeError("Cannot continue before prompt() without a context")
            return self.prompt(input, context)

        if context is not None:
            self._state.context = context
        self._state.messages.append(Message(role="user", content=[TextContent(text=input)]))
        self._state.queued_input = input
        return self._run()

    def abort(self, reason: str) -> None:
        """Record an abort reason in the current snapshot metadata."""

        if self._state is None:
            return
        metadata = dict(self._state.metadata or {})
        metadata["abortReason"] = reason
        self._state.metadata = metadata

    def on(self, event_kind: str, consumer: Callable[[RunEvent], None]) -> None:
        """Subscribe to emitted events after each loop run."""

        self._subscribers.setdefault(event_kind, []).append(consumer)

    def snapshot(self) -> AgentLoopState:
        """Return the current loop state."""

        if self._state is None:
            raise RuntimeError("Agent has no state yet")
        return self._state.model_copy(deep=True)

    def restore(self, snapshot: AgentLoopState) -> None:
        """Restore a previous loop state."""

        self._state = snapshot.model_copy(deep=True)

    def _run(self) -> AgentLoopResult:
        if self._state is None:
            raise RuntimeError("Agent has no state")
        result = self._engine.run(self._state, self._config)
        self._state = result.state
        self._publish(result.events)
        return result

    def _publish(self, events: list[RunEvent]) -> None:
        for event in events:
            for consumer in self._subscribers.get(event.type, []):
                consumer(event)
            for consumer in self._subscribers.get("*", []):
                consumer(event)
