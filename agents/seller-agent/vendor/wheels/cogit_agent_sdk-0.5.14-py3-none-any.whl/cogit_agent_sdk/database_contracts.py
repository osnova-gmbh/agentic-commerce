"""Package-owned typed exports over the generic, fenced database transport."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, TypeVar

from pydantic import BaseModel, JsonValue, TypeAdapter

from cogit_agent_sdk.database_seams import DatabaseSeams
from cogit_agent_sdk.types.database import DatabaseKey

Input = TypeVar("Input", bound=BaseModel)
Output = TypeVar("Output", bound=BaseModel)
_JSON_OBJECT = TypeAdapter(dict[str, JsonValue])
_KEY = TypeAdapter(DatabaseKey)


@dataclass(frozen=True)
class _DatabaseExport(Generic[Input, Output]):
    module_key: str
    export_key: str
    contract_id: str
    input_model: type[Input]
    output_model: type[Output]

    def __post_init__(self) -> None:
        for key in (self.module_key, self.export_key, self.contract_id):
            _KEY.validate_python(key)

    def _input(self, value: Input) -> dict[str, JsonValue]:
        if not isinstance(value, self.input_model):
            raise TypeError(f"Expected {self.input_model.__name__}")
        # Revalidate serialized data, including models made with model_construct.
        checked = self.input_model.model_validate_json(value.model_dump_json(by_alias=True))
        return _JSON_OBJECT.validate_json(checked.model_dump_json(by_alias=True))


@dataclass(frozen=True)
class DatabaseQuery(_DatabaseExport[Input, Output]):
    """The domain package supplies concrete input/output models and export names."""

    def invoke(self, handle: DatabaseSeams, payload: Input) -> Output:
        result = handle.module_query(
            self.module_key, self.export_key, self._input(payload), contract_id=self.contract_id
        )
        return self.output_model.model_validate(result)


@dataclass(frozen=True)
class DatabaseCommand(_DatabaseExport[Input, Output]):
    """Typed command; the host still supplies admitted pins and execution authority."""

    def invoke(self, handle: DatabaseSeams, payload: Input, *, idempotency_key: str) -> Output:
        if not idempotency_key.strip():
            raise ValueError("A database command requires a nonempty idempotency key")
        result = handle.module_command(
            self.module_key,
            self.export_key,
            self._input(payload),
            contract_id=self.contract_id,
            idempotency_key=idempotency_key,
        )
        return self.output_model.model_validate(result)
