"""Fail-closed provider coordination seams implemented by the active Runtime."""

from cogit_agent_sdk.types.action_intents import ActionIntent, ActionKey, ActionRef


class ActionSeams:
    def prepare_action(self, intent: ActionIntent) -> ActionRef:
        """Prepare a durable intent; approval and dispatch remain host decisions."""
        validated = ActionIntent.model_validate(intent.model_dump())
        return self._perform_prepare_action(validated)

    def lookup_action(self, key: ActionKey) -> ActionRef | None:
        """Find a prior committed intent scoped to the current work."""
        return self._perform_lookup_action(ActionKey.model_validate(key.model_dump()))

    def _perform_lookup_action(self, key: ActionKey) -> ActionRef | None:
        raise NotImplementedError("The active runtime does not support durable actions")

    def get_action(self, action_id: str) -> ActionRef:
        """Read an action authorized for the current work identity."""
        return self._perform_get_action(action_id)

    def _perform_prepare_action(self, intent: ActionIntent) -> ActionRef:
        raise NotImplementedError("The active runtime does not support durable actions")

    def _perform_get_action(self, action_id: str) -> ActionRef:
        raise NotImplementedError("The active runtime does not support durable actions")
