"""Base agent, service, run-handle, and evaluator contracts."""

from __future__ import annotations

from collections.abc import Callable, Generator, Sequence
from contextlib import contextmanager
from datetime import UTC, datetime
from threading import Condition, RLock, local
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable
from uuid import uuid4

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.action_seams import ActionSeams
from cogit_agent_sdk.cli import CliCommandGroup
from cogit_agent_sdk.client import CogitClient
from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.database_seams import DatabaseSeams
from cogit_agent_sdk.policy_seams import PolicySeams
from cogit_agent_sdk.seam_hooks import ArtifactModelCallSeams
from cogit_agent_sdk.types import (
    AgentDescriptor,
    AgentLoopConfig,
    AttentionItem,
    Context,
    Decision,
    ErrorInfo,
    EvalItemResult,
    EvalRecord,
    ExecutionStepRecord,
    LoopHookSet,
    PipelineDescriptor,
    QueryRequest,
    QueryResult,
    RunEvent,
    RunRequest,
    RunResult,
    Usage,
    WorkOutcome,
)

if TYPE_CHECKING:
    from cogit_agent_sdk.operations.action_binding import ActionBinding
    from cogit_agent_sdk.operations.tool_binding import ToolBinding

DecisionProvider = Callable[[AttentionItem], Decision]
StepRecorder = Callable[[ExecutionStepRecord], None]


class StepScope:
    """Mutable scope returned by RunHandle.step()."""

    def __init__(self, record: ExecutionStepRecord) -> None:
        self.record = record
        self.data: JsonObject | None = None
        self.summary: str | None = record.summary

    def set_summary(self, summary: str) -> None:
        self.summary = summary

    def set_data(self, data: JsonObject) -> None:
        self.data = data


class RunHandle(ArtifactModelCallSeams, ActionSeams, DatabaseSeams, PolicySeams):
    """Agent-facing handle for observability and cooperative run state.

    Step callbacks are delivered synchronously in record order. A callback
    must not record another step on the same handle or wait for another thread
    to do so.

    Bind an optional ``LoopHookSet`` with ``hooks=`` or :meth:`bind_hooks`.
    Existing constructors stay valid. Successful artifact and model-call
    seams emit the matching observer once; failed operations emit nothing.
    Hook sets that omit the new observers keep the ``DefaultLoopHooks``
    no-op.
    """

    def __init__(
        self,
        execution_id: str,
        context: Context,
        *,
        client: CogitClient | None = None,
        decision_provider: DecisionProvider | None = None,
        step_recorder: StepRecorder | None = None,
        hooks: LoopHookSet | None = None,
    ) -> None:
        self.execution_id = execution_id
        self.context = context
        self.client = client
        self.decision_provider = decision_provider
        self.step_recorder = step_recorder
        self.steps: list[ExecutionStepRecord] = []
        self.events: list[RunEvent] = []
        self.usage = Usage()
        self.outcome_label: str | None = None
        self.work_outcome: WorkOutcome | None = None
        self.cancelled = False
        self._hooks: object | None = hooks
        self._step_order = 0
        self._lock = RLock()
        self._step_lock = RLock()
        self._step_delivery_condition = Condition()
        self._step_delivery_sequence = 0
        self._next_step_delivery = 1
        self._step_delivery_state = local()

    @contextmanager
    def step(
        self,
        kind: str,
        name: str | None = None,
        summary: str | None = None,
    ) -> Generator[StepScope, None, None]:
        """Record a running/completed/failed step around a block of work."""

        if getattr(self._step_delivery_state, "active", False):
            raise RuntimeError("Step recorder callbacks cannot record nested steps")
        with self._step_lock:
            with self._lock:
                self._step_order += 1
                record = ExecutionStepRecord(
                    id=str(uuid4()),
                    execution_id=self.execution_id,
                    order=self._step_order,
                    kind=kind,  # type: ignore[arg-type]
                    name=name,
                    status="running",
                    started_at=datetime.now(tz=UTC),
                    summary=summary,
                )
                self.steps.append(record)
            delivery_sequence = self._reserve_step_delivery()
        self._deliver_step(record, delivery_sequence)
        scope = StepScope(record)
        try:
            yield scope
        except CoordinationFailure:
            raise
        except Exception as exc:
            failed = record.model_copy(
                update={
                    "status": "failed",
                    "completed_at": datetime.now(tz=UTC),
                    "summary": scope.summary,
                    "data": scope.data,
                    "error": ErrorInfo(
                        code="STEP_ERROR",
                        message=f"Step failed ({type(exc).__name__})",
                        retryable=False,
                    ),
                }
            )
            self._record_step(failed)
            raise
        completed = record.model_copy(
            update={
                "status": "completed",
                "completed_at": datetime.now(tz=UTC),
                "summary": scope.summary,
                "data": scope.data,
            }
        )
        self._record_step(completed)

    def log(self, message: str, data: JsonObject | None = None) -> None:
        with self._lock:
            event = RunEvent(
                execution_id=self.execution_id,
                sequence=len(self.events) + 1,
                timestamp=datetime.now(tz=UTC),
                type="step_recorded",
                payload={"message": message, "data": data or {}},
            )
            self.events.append(event)

    def add_usage(self, usage: Usage) -> None:
        with self._lock:
            self.usage = Usage(
                input_tokens=self.usage.input_tokens + usage.input_tokens,
                output_tokens=self.usage.output_tokens + usage.output_tokens,
                cache_read_tokens=self.usage.cache_read_tokens + usage.cache_read_tokens,
                cache_write_tokens=self.usage.cache_write_tokens + usage.cache_write_tokens,
                model=usage.model or self.usage.model,
                provider=usage.provider or self.usage.provider,
            )

    def set_outcome(self, outcome_label: str) -> None:
        with self._lock:
            self.outcome_label = outcome_label

    def set_work_outcome(self, outcome: WorkOutcome) -> None:
        """Report a durable item's disposition; Runtime owns fenced settlement."""
        validated = WorkOutcome.model_validate(outcome)
        with self._lock:
            self.work_outcome = validated

    def emit(self, event: RunEvent) -> None:
        with self._lock:
            self.events.append(event)

    def request_decision(self, item: AttentionItem) -> Decision:
        if self.decision_provider is not None:
            return self.decision_provider(item)
        return Decision(
            id=str(uuid4()),
            attention_item_id=item.id,
            action="abort",
            rationale="No decision provider configured",
            decided_by="sdk:auto",
            decided_at=datetime.now(tz=UTC),
        )

    def heartbeat(self) -> None:
        self.log("heartbeat", {"executionId": self.execution_id})

    def cancel(self) -> None:
        with self._lock:
            self.cancelled = True

    def _record_step(self, record: ExecutionStepRecord) -> None:
        with self._step_lock:
            with self._lock:
                self.steps.append(record)
            delivery_sequence = self._reserve_step_delivery()
        self._deliver_step(record, delivery_sequence)

    def _reserve_step_delivery(self) -> int:
        self._step_delivery_sequence += 1
        return self._step_delivery_sequence

    def _deliver_step(self, record: ExecutionStepRecord, delivery_sequence: int) -> None:
        with self._step_delivery_condition:
            while delivery_sequence != self._next_step_delivery:
                self._step_delivery_condition.wait()
        self._step_delivery_state.active = True
        try:
            if self.step_recorder is not None:
                self.step_recorder(record)
                return
            if self.client is not None:
                self.client.executions.append_step(record, self.context, fire_and_forget=True)
        finally:
            self._step_delivery_state.active = False
            with self._step_delivery_condition:
                self._next_step_delivery += 1
                self._step_delivery_condition.notify_all()


@runtime_checkable
class AgentBase(Protocol):
    """Contract implemented by resident agent repositories."""

    descriptor: AgentDescriptor
    client: CogitClient

    def configure(self, services: Any) -> None: ...

    def health(self) -> JsonObject: ...

    def handle_run(self, request: RunRequest, context: Context, handle: RunHandle) -> RunResult: ...

    def handle_query(
        self,
        request: QueryRequest,
        context: Context,
        handle: RunHandle,
    ) -> QueryResult: ...

    def register_action(self, binding: ActionBinding[Any, Any]) -> None: ...

    def freeze_action_registration(self) -> None: ...

    def action_bindings(self) -> Sequence[ActionBinding[Any, Any]]: ...

    def register_tool(self, binding: ToolBinding[Any, Any]) -> None: ...

    def freeze_tool_registration(self) -> None: ...

    def tool_bindings(self) -> Sequence[ToolBinding[Any, Any]]: ...

    def pipelines(self) -> list[PipelineDescriptor]: ...

    def commands(self) -> list[CliCommandGroup]: ...

    def loop_config(self, context: Context) -> AgentLoopConfig: ...

    def system_prompt(self, context: Context) -> str: ...

    def startup(self) -> None: ...

    def shutdown(self) -> None: ...

    def loop_hooks(self, context: Context) -> LoopHookSet | None: ...


@runtime_checkable
class ServiceBase(Protocol):
    """Slim multi-tenant reusable backend contract."""

    descriptor: AgentDescriptor

    def health(self) -> JsonObject: ...


@runtime_checkable
class EvaluatorContract(Protocol):
    """Contract for black-box evaluator implementations."""

    suite: str

    def load_items(self) -> list[JsonObject]: ...

    def evaluate_item(self, item: JsonObject, black_box_agent: AgentBase) -> EvalItemResult: ...

    def run(self, black_box_agent: AgentBase) -> EvalRecord: ...
