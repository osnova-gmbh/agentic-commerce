"""Inert universal-policy receipts. Only the effect-owning service grants authority."""

from __future__ import annotations

import hashlib
import json
from typing import Annotated, Literal, Self
from uuid import UUID

from pydantic import AwareDatetime, ConfigDict, Field, model_validator

from cogit_agent_sdk.types._base import SdkModel, to_camel

Identifier = Annotated[str, Field(strict=True, min_length=1, max_length=256)]
Sha256 = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]


class PolicyValue(SdkModel):
    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        populate_by_name=True,
        alias_generator=to_camel,
        revalidate_instances="always",
    )


class ProtectedTarget(PolicyValue):
    kind: Literal["action"]
    id: UUID
    version: Annotated[str, Field(strict=True, min_length=1, max_length=32)]


class ProtectedSubject(PolicyValue):
    action_id: UUID
    tenant_id: UUID
    actor_principal_id: UUID
    agent_id: UUID | None
    represented_user_principal_id: UUID | None
    installation_id: UUID | None
    action: Literal["invoice.approve"]
    operation_key: Sha256
    target: ProtectedTarget
    payload_sha256: Sha256

    @model_validator(mode="after")
    def _same_target(self) -> Self:
        if self.target.id != self.action_id:
            raise ValueError("Protected action and target must match")
        return self


class PolicyRequirement(PolicyValue):
    binding_id: UUID
    policy_id: UUID
    policy_version_id: UUID
    scope: Literal["platform", "organization", "agent", "agent_user"]
    evaluator_key: Literal["deny.v1", "required_capability.v1", "required_review.v1", "semantic.v1"]
    evaluator_version: Annotated[int, Field(strict=True, ge=1, le=1)]
    criteria_sha256: Sha256 | None


class ApplicablePolicySet(PolicyValue):
    revision: Sha256
    sha256: Sha256
    requirements: tuple[PolicyRequirement, ...] = Field(max_length=1024)


class RequiredEvaluation(PolicyValue):
    binding_id: UUID
    policy_version_id: UUID
    evaluation_id: UUID
    outcome: Literal["pass", "deny", "review", "unavailable"]
    evidence_id: UUID | None
    observed_at: AwareDatetime
    expires_at: AwareDatetime | None


class RequiredReview(PolicyValue):
    requirement_key: Annotated[str, Field(strict=True, min_length=1, max_length=128)]
    policy_version_id: UUID
    decision_id: UUID | None
    status: Literal["pending", "approved", "rejected", "expired"]


class UniversalPolicyDecision(PolicyValue):
    """A fresh preflight result, never a reusable approval or bearer grant."""

    contract_version: Literal["universal-policy.v1"]
    operation_id: UUID
    decision_id: UUID
    outcome: Literal["allow", "deny", "review", "unavailable"]
    applicability: Literal["policies", "no_applicable_policy"]
    subject: ProtectedSubject
    policy_set: ApplicablePolicySet
    facts_revision: Sha256
    evaluations: tuple[RequiredEvaluation, ...] = Field(max_length=1024)
    reviews: tuple[RequiredReview, ...] = Field(max_length=1024)
    evaluated_at: AwareDatetime
    expires_at: AwareDatetime | None

    @model_validator(mode="after")
    def _complete_set(self) -> Self:
        required = {(r.binding_id, r.policy_version_id) for r in self.policy_set.requirements}
        observed = {(e.binding_id, e.policy_version_id) for e in self.evaluations}
        if len(required) != len(self.policy_set.requirements):
            raise ValueError("Policy set contains duplicate requirements")
        if observed != required or len(observed) != len(self.evaluations):
            raise ValueError("Receipt does not cover the complete policy set")
        if len({e.evaluation_id for e in self.evaluations}) != len(self.evaluations):
            raise ValueError("An evaluation receipt cannot be reused across requirement bindings")
        empty = not required
        if empty != (self.applicability == "no_applicable_policy"):
            raise ValueError("Applicability must distinguish an explicit empty policy set")
        review_bindings = {
            self._review_requirement_key(r): r.policy_version_id
            for r in self.policy_set.requirements
        }
        keys = {r.requirement_key for r in self.reviews}
        if len(keys) != len(self.reviews) or any(
            review_bindings.get(r.requirement_key) != r.policy_version_id for r in self.reviews
        ):
            raise ValueError("Review requirements do not match the selected policy set")
        if self.outcome == "allow":
            self._validate_allow()
        return self

    def _validate_allow(self) -> None:
        if any(r.status != "approved" or r.decision_id is None for r in self.reviews):
            raise ValueError("Allow requires every review to be approved")
        if len({r.decision_id for r in self.reviews}) != len(self.reviews):
            raise ValueError("A review decision cannot be reused across requirement bindings")
        if any(e.outcome in {"deny", "unavailable"} for e in self.evaluations):
            raise ValueError("Allow cannot omit an unsatisfied requirement")
        review_needed = {
            (e.binding_id, e.policy_version_id) for e in self.evaluations if e.outcome == "review"
        }
        reviewed_keys = {r.requirement_key for r in self.reviews}
        for requirement in self.policy_set.requirements:
            if (
                requirement.evaluator_key == "required_review.v1"
                or (requirement.binding_id, requirement.policy_version_id) in review_needed
            ) and self._review_requirement_key(requirement) not in reviewed_keys:
                raise ValueError("Allow requires an approved review for every required binding")

    def _review_requirement_key(self, requirement: PolicyRequirement) -> str:
        # These five ASCII strings have the same compact JSON and RFC8785 encoding.
        material = json.dumps(
            [
                str(self.subject.action_id),
                str(requirement.binding_id),
                str(requirement.policy_version_id),
                self.facts_revision,
                self.policy_set.sha256,
            ],
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return "up." + hashlib.sha256(material.encode("utf-8")).hexdigest()


class UniversalPolicyRequest(PolicyValue):
    contract_version: Literal["universal-policy.v1"] = "universal-policy.v1"
    action_id: UUID
