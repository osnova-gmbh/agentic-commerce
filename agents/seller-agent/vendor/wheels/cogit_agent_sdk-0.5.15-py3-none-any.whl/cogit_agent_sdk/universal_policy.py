"""Bounded host transport for current policy; approval still rechecks atomically."""

from __future__ import annotations

from datetime import UTC, datetime
from time import monotonic
from typing import Protocol, runtime_checkable
from urllib.parse import urlsplit
from uuid import UUID, uuid4

import httpx
from pydantic import ValidationError

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types.universal_policy import UniversalPolicyDecision, UniversalPolicyRequest


class PolicyAuthorityUnavailable(CoordinationFailure):
    """Absent, malformed or unavailable authority stops protected effects."""


class PolicyApprovalDenied(CoordinationFailure):
    """The complete current policy set denies the protected action."""


class PolicyReviewRequired(CoordinationFailure):
    """The action remains blocked until its exact durable reviews are satisfied."""


@runtime_checkable
class UniversalPolicyAuthority(Protocol):
    def evaluate(self, action_id: UUID) -> UniversalPolicyDecision: ...


def require_protected_approval(
    authority: UniversalPolicyAuthority,
    *,
    action_id: UUID,
    action_version: str,
    payload_sha256: str,
    tenant_id: UUID | None = None,
) -> UniversalPolicyDecision:
    """Require one fresh bound result. Never cache this as approval authority."""
    try:
        decision = UniversalPolicyDecision.model_validate(authority.evaluate(action_id))
    except CoordinationFailure:
        raise
    except Exception:
        raise PolicyAuthorityUnavailable("Protected policy authority is unavailable") from None
    subject = decision.subject
    if (
        subject.action_id != action_id
        or subject.target.version != action_version
        or subject.payload_sha256 != payload_sha256
        or (tenant_id is not None and subject.tenant_id != tenant_id)
    ):
        raise PolicyAuthorityUnavailable("Protected policy receipt binding does not match")
    now = datetime.now(UTC)
    expiries = [decision.expires_at, *(e.expires_at for e in decision.evaluations)]
    if any(expiry is not None and expiry <= now for expiry in expiries):
        raise PolicyAuthorityUnavailable("Protected policy receipt has expired")
    if decision.outcome == "review":
        raise PolicyReviewRequired("Protected action requires review")
    if decision.outcome == "deny":
        raise PolicyApprovalDenied("Protected action denied by current policy")
    if decision.outcome != "allow":
        raise PolicyAuthorityUnavailable("Protected policy authority could not decide")
    return decision


class UniversalPolicyClient:
    """Separate host credential, no redirects/retries, bounded response and deadline."""

    def __init__(
        self,
        url: str,
        token: str,
        *,
        transport: httpx.BaseTransport | None = None,
        timeout_seconds: float = 30,
        max_response_bytes: int = 1_048_576,
    ) -> None:
        parsed = urlsplit(url)
        local = parsed.hostname in {"localhost", "127.0.0.1", "::1"}
        if (
            parsed.scheme not in {"http", "https"}
            or (parsed.scheme == "http" and not local)
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
            or not token.strip()
            or "\r" in token
            or "\n" in token
            or not 0 < timeout_seconds <= 120
            or not 1 <= max_response_bytes <= 1_048_576
        ):
            raise ValueError("Invalid protected policy transport configuration")
        self._url = url.rstrip("/") + "/v1/universal-policy/evaluations"
        self._token = token
        self._transport = transport
        self._timeout = timeout_seconds
        self._maximum = max_response_bytes

    def evaluate(self, action_id: UUID) -> UniversalPolicyDecision:
        request = UniversalPolicyRequest(action_id=action_id)
        deadline = monotonic() + self._timeout
        try:
            with (
                httpx.Client(
                    transport=self._transport,
                    timeout=httpx.Timeout(self._timeout, read=min(self._timeout, 1.0)),
                    follow_redirects=False,
                    trust_env=False,
                ) as client,
                client.stream(
                    "POST",
                    self._url,
                    json=request.model_dump(mode="json", by_alias=True),
                    headers={
                        "Authorization": "Bearer " + self._token,
                        "Accept-Encoding": "identity",
                        "Idempotency-Key": str(uuid4()),
                        "X-AgentDb-Correlation-Id": str(uuid4()),
                    },
                ) as response,
            ):
                self._require_deadline(deadline)
                if (
                    response.status_code != 200
                    or response.headers.get("Content-Encoding", "identity").strip().lower()
                    != "identity"
                ):
                    raise PolicyAuthorityUnavailable("Protected policy service rejected evaluation")
                content = bytearray()
                for chunk in response.iter_bytes():
                    self._require_deadline(deadline)
                    if len(content) + len(chunk) > self._maximum:
                        raise PolicyAuthorityUnavailable(
                            "Protected policy response exceeds its limit"
                        )
                    content.extend(chunk)
                decision = UniversalPolicyDecision.model_validate_json(content)
                self._require_deadline(deadline)
                return decision
        except CoordinationFailure:
            raise
        except (httpx.HTTPError, ValidationError, ValueError, OSError):
            raise PolicyAuthorityUnavailable(
                "Protected policy authority returned no valid receipt"
            ) from None

    @staticmethod
    def _require_deadline(deadline: float) -> None:
        if monotonic() >= deadline:
            raise PolicyAuthorityUnavailable("Protected policy exceeded its total deadline")
