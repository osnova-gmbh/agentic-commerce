"""Serialized owner dispatch with supervisor-held profile and process-tree lifetime."""

from __future__ import annotations

import multiprocessing
import threading
import time
from collections.abc import Callable
from typing import TypeVar

from cogit_tool_core import Model, ToolError, Workspace

from ._ownership import BrowserOwnership
from ._worker import BrowserConfig, Request, Response, worker
from .scripts import ScriptProgram
from .settings import BrowserScope, BrowserSessionSettings, profile_path

ResultT = TypeVar("ResultT", bound=Model)


class BrowserClient:
    def __init__(
        self,
        workspace: Workspace,
        settings: BrowserSessionSettings,
        scope: BrowserScope | None,
    ) -> None:
        self.settings = settings
        profile = None
        if settings.mode == "persistent":
            if scope is None:
                raise ToolError("missing_scope", "Persistent browser requires a trusted scope")
            profile = profile_path(settings, scope, workspace.root)
        self._ownership = BrowserOwnership(profile)
        self._lock = threading.RLock()
        self._cancelled: Callable[[], bool] | None = None
        self._closed = False
        self._cleanup_error: str | None = None
        context = multiprocessing.get_context("spawn")
        self._connection, child = context.Pipe()
        config = BrowserConfig(
            workspace.root,
            settings.timeout_ms,
            settings.max_artifact_bytes,
            settings.trace_path,
            settings.headless,
            settings.max_tabs,
            profile,
            settings.channel,
        )
        self._process = context.Process(
            target=worker,
            args=(child, config),
            name="cogit-owned-browser",
            daemon=False,
        )
        try:
            self._process.start()
            child.close()
            if self._receive(30).kind != "waiting":
                raise ToolError("browser_start_failed", "Worker failed ownership handshake")
            self._ownership.attach(self._process)
            self._connection.send(Request("start", None))
            response = self._receive(max(30, settings.timeout_ms / 1000 + 5))
            self._check(response)
            if response.kind != "ready":
                raise ToolError("browser_start_failed", "Owned worker did not become ready")
        except BaseException:
            self.abort()
            child.close()
            raise

    def _receive(self, seconds: float) -> Response:
        deadline = time.monotonic() + seconds
        while not self._connection.poll(min(0.1, max(0, deadline - time.monotonic()))):
            if self._cancelled is not None and self._cancelled():
                self.abort()
                raise ToolError(
                    "browser_cancelled", "Browser cancelled; effects unknown; session retired"
                )
            if time.monotonic() >= deadline:
                break
        else:
            value: object = self._connection.recv()
            if isinstance(value, Response):
                return value
            self.abort()
            raise ToolError("browser_error", "Invalid response from owned worker")
        if time.monotonic() >= deadline:
            self.abort()
            raise ToolError(
                "browser_unresponsive",
                "Browser deadline exceeded; effects may have occurred. "
                "Session retired; do not automatically retry. Trace may be incomplete."
                + (f" {self._cleanup_error}" if self._cleanup_error else ""),
            )
        raise ToolError("browser_error", "Unreachable browser dispatch state")

    def invoke(self, handler: Callable[[], ResultT], cancelled: Callable[[], bool]) -> ResultT:
        with self._lock:
            if cancelled():
                raise ToolError("browser_cancelled", "Browser invocation cancelled before dispatch")
            self._cancelled = cancelled
            try:
                return handler()
            finally:
                self._cancelled = None

    @staticmethod
    def _check(response: Response) -> None:
        if response.error is not None:
            raise ToolError(*response.error)

    def call(
        self, operation: str, request: Model | ScriptProgram, result: type[ResultT]
    ) -> ResultT:
        with self._lock:
            if self._closed:
                raise ToolError("browser_closed", "Browser session is closed; create a new service")
            timeout = (
                self.settings.script_timeout_ms
                if operation == "run_script"
                else self.settings.timeout_ms + 5000
            ) / 1000
            try:
                self._connection.send(Request(operation, request))
                response = self._receive(timeout)
            except (EOFError, BrokenPipeError, OSError):
                self.abort()
                raise ToolError(
                    "browser_disconnected", "Owned browser worker disconnected; effects unknown"
                ) from None
            if response.error and response.error[0] == "browser_session_invalidated":
                self.abort()
            self._check(response)
            if not isinstance(response.value, result):
                raise ToolError("browser_error", "Unexpected browser output type")
            return response.value

    @property
    def retired(self) -> bool:
        return self._closed and self._cleanup_error is None

    def abort(self) -> None:
        """May run on cancellation while the dispatch thread waits for worker output."""
        self._closed = True
        self._cleanup_error = self._ownership.retire(self._process)
        self._connection.close()

    def close(self) -> None:
        with self._lock:
            if self._closed:
                if self._cleanup_error:
                    self._cleanup_error = self._ownership.retire(self._process)
                if self._cleanup_error:
                    raise ToolError("cleanup_failed", self._cleanup_error)
                return
            self._closed = True
            error: str | None = None
            try:
                self._connection.send(Request("close", None))
                response = self._receive(self.settings.timeout_ms / 1000 + 5)
                if response.error:
                    error = response.error[1]
            except (EOFError, BrokenPipeError, OSError, ToolError) as exc:
                error = str(exc)
            finally:
                self._connection.close()
                self._process.join(timeout=2)
                self._cleanup_error = self._ownership.retire(self._process)
            failures = "; ".join(x for x in (error, self._cleanup_error) if x)
            if failures:
                raise ToolError("cleanup_failed", failures)
