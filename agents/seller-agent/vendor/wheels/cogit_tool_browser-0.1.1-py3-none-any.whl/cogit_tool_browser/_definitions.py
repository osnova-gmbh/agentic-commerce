"""One schema catalog shared by direct tools and deferred provider registration."""

from dataclasses import dataclass

from cogit_tool_core import Model

from .models import (
    ActionRequest,
    ArtifactOutput,
    CloseOutput,
    CloseRequest,
    DownloadRequest,
    EvaluateRequest,
    EvaluationOutput,
    NavigateRequest,
    Observation,
    ObserveRequest,
    ResetOutput,
    ResetRequest,
    ScreenshotRequest,
    TabsOutput,
    TabsRequest,
)
from .scripts import ScriptRequest, ScriptResult


@dataclass(frozen=True)
class Definition:
    name: str
    description: str
    input_model: type[Model]
    output_model: type[Model]
    method: str


def definitions(scripts_enabled: bool) -> tuple[Definition, ...]:
    standard = (
        Definition(
            "browser_close",
            "Close and release this invocation's owned browser when finished. "
            "Persistent login remains stored; ephemeral state is discarded. "
            "No other invocation's ephemeral browser is closed.",
            CloseRequest,
            CloseOutput,
            "close_session",
        ),
        Definition(
            "browser_reset",
            "Explicitly retire and reopen the owned session with the same host settings. "
            "Previous effects are not rolled back; inspect state before retrying actions. "
            "Persistent login is reused; ephemeral state and old tab IDs are discarded.",
            ResetRequest,
            ResetOutput,
            "reset",
        ),
        Definition(
            "browser_navigate",
            "Navigate an owned tab to an http(s) URL and observe.",
            NavigateRequest,
            Observation,
            "navigate",
        ),
        Definition(
            "browser_observe",
            "Observe bounded accessible DOM, URL and title; use semantic targets.",
            ObserveRequest,
            Observation,
            "observe",
        ),
        Definition(
            "browser_action",
            "Click/fill/select/press a unique observed semantic target; select uses labels.",
            ActionRequest,
            Observation,
            "action",
        ),
        Definition(
            "browser_tabs",
            "List/new/switch/close owned tabs; omit tab_id for the current tab.",
            TabsRequest,
            TabsOutput,
            "tabs",
        ),
        Definition(
            "browser_download",
            "Download original bytes from an observed target to a new workspace path; "
            "returns SHA256.",
            DownloadRequest,
            ArtifactOutput,
            "download",
        ),
        Definition(
            "browser_screenshot",
            "Save a PNG artifact inside workspace; not automatic model vision input.",
            ScreenshotRequest,
            ArtifactOutput,
            "screenshot",
        ),
        Definition(
            "browser_evaluate",
            "Execute an explicit page JavaScript expression/function; "
            "privileged, bounded JSON result.",
            EvaluateRequest,
            EvaluationOutput,
            "evaluate",
        ),
    )
    if not scripts_enabled:
        return standard
    return standard + (
        Definition(
            "browser_run_script",
            "Run digest-bound privileged Python in this same browser session. Define "
            "run(page, context, arguments) and return JSON. sha256 must match script bytes; "
            "arguments_json encodes an object. Do not launch another browser.",
            ScriptRequest,
            ScriptResult,
            "run_script",
        ),
    )
