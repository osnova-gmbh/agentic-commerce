"""Digest-bound privileged Python executed on the existing Playwright owner thread."""

from __future__ import annotations

import hashlib
import io
import json
from collections.abc import Callable
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import dataclass
from typing import cast

from cogit_tool_core import Model, ToolError, Workspace
from playwright.sync_api import BrowserContext, Page
from playwright.sync_api import Error as PlaywrightError
from pydantic import Field, JsonValue, field_validator

from .models import PageRequest


class ScriptRequest(PageRequest):
    path: str = Field(min_length=1, max_length=4096)
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    arguments_json: str = Field(default="{}", max_length=65536)

    @field_validator("arguments_json")
    @classmethod
    def object_arguments(cls, value: str) -> str:
        if not isinstance(json.loads(value), dict):
            raise ValueError("arguments_json must encode an object")
        return value


class ScriptResult(Model):
    sha256: str
    succeeded: bool
    value_json: str = "null"
    stdout: str = ""
    stderr: str = ""
    truncated: bool = False
    error_code: str | None = None
    error_message: str | None = None
    trace_path: str | None = None


@dataclass(frozen=True)
class ScriptProgram:
    request: ScriptRequest
    source: bytes


def prepare_script(workspace: Workspace, request: ScriptRequest) -> ScriptProgram:
    """Freeze bytes before dispatch; a parked path-only approval cannot change code."""
    try:
        with workspace.resolve(request.path).open("rb") as stream:
            source = stream.read(262145)
    except OSError as exc:
        raise ToolError("script_unreadable", f"Cannot read script: {type(exc).__name__}") from None
    if len(source) > 262144:
        raise ToolError("script_too_large", "Script exceeds 256 KiB")
    if hashlib.sha256(source).hexdigest() != request.sha256:
        raise ToolError("script_changed", "Script digest differs; submit its current digest")
    return ScriptProgram(request, source)


class _BoundedLog(io.TextIOBase):
    def __init__(self) -> None:
        self.parts: list[str] = []
        self.length = 0
        self.truncated = False

    def write(self, value: str) -> int:
        remaining = 16000 - self.length
        if remaining:
            self.parts.append(value[:remaining])
        self.length += min(remaining, len(value))
        self.truncated |= len(value) > remaining
        return len(value)

    def text(self) -> str:
        return "".join(self.parts)


def run_script(program: ScriptProgram, page: Page, context: BrowserContext) -> ScriptResult:
    """The injected raw Playwright objects confer privileged session authority."""
    stdout, stderr = _BoundedLog(), _BoundedLog()
    values: dict[str, object] = {
        "__name__": "__cogit_browser_script__",
        "__file__": program.request.path,
    }
    result: dict[str, object] = {"sha256": program.request.sha256, "succeeded": False}
    try:
        with redirect_stdout(stdout), redirect_stderr(stderr):
            exec(compile(program.source, program.request.path, "exec"), values)
            entrypoint = values.get("run")
            if not callable(entrypoint):
                raise ValueError("Define run(page, context, arguments)")
            run = cast(Callable[[Page, BrowserContext, dict[str, JsonValue]], object], entrypoint)
            arguments = cast(dict[str, JsonValue], json.loads(program.request.arguments_json))
            value = run(page, context, arguments)
            encoded = json.dumps(value, allow_nan=False, ensure_ascii=False)
            if len(encoded) > 32000:
                raise ValueError("Script JSON result exceeds 32000 characters")
            result.update(succeeded=True, value_json=encoded)
    except BaseException as exc:
        # SystemExit must not silently bypass owner cleanup. os._exit is supervised externally.
        message = (
            "Playwright operation failed; re-observe the page before repairing the script"
            if isinstance(exc, PlaywrightError)
            else f"{type(exc).__name__}: {exc}"[:1200]
        )
        result.update(error_code="script_failed", error_message=message)
    result.update(
        stdout=stdout.text(), stderr=stderr.text(), truncated=stdout.truncated or stderr.truncated
    )
    return ScriptResult.model_validate(result)
