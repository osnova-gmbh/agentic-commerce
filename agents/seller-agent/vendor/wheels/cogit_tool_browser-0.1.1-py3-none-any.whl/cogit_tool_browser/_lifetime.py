"""Playwright lifetime on its one owner thread; the supervisor owns the profile lock."""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Literal

from cogit_tool_core import ToolError, Workspace
from playwright.sync_api import Browser, BrowserContext, Page, Playwright, sync_playwright

from ._artifacts import artifact_destination, publish_artifact


class BrowserLifetime(ABC):
    def __init__(
        self,
        workspace: Workspace,
        timeout_ms: int,
        max_artifact_bytes: int,
        trace_path: str | None,
        headless: bool,
        max_tabs: int,
        profile: Path | None = None,
        channel: Literal["chrome", "msedge"] | None = None,
    ) -> None:
        self.workspace, self.timeout_ms = workspace, timeout_ms
        self.max_artifact_bytes, self.max_tabs = max_artifact_bytes, max_tabs
        self.playwright: Playwright | None = None
        self.browser: Browser | None = None
        self.context: BrowserContext | None = None
        self.trace_path: Path | None = None
        self.tracing = False
        self.invalidated = False
        self.pages: dict[str, Page] = {}
        self.active, self.next_id = "", 1
        try:
            self._start(trace_path, headless, profile, channel)
        except Exception as exc:
            failures = self.close()
            suffix = f"; cleanup: {', '.join(failures)}" if failures else ""
            raise ToolError(
                "browser_start_failed",
                f"Owned browser startup failed: {type(exc).__name__}{suffix}",
            ) from None

    def _start(
        self,
        trace_path: str | None,
        headless: bool,
        profile: Path | None,
        channel: Literal["chrome", "msedge"] | None,
    ) -> None:
        if trace_path is not None:
            self.trace_path = artifact_destination(self.workspace, trace_path)
        self.playwright = sync_playwright().start()
        if profile is None:
            self.browser = self.playwright.chromium.launch(headless=headless, channel=channel)
            self.context = self.browser.new_context(accept_downloads=True)
        else:
            self.context = self.playwright.chromium.launch_persistent_context(
                profile,
                headless=headless,
                channel=channel,
                accept_downloads=True,
                args=["--disable-sync", "--no-first-run", "--no-default-browser-check"],
            )
        self.context.set_default_timeout(self.timeout_ms)
        self.context.set_default_navigation_timeout(self.timeout_ms)
        self.context.on("page", self.register)
        self.context.on("close", self._closed_context)
        if self.trace_path is not None:
            self.context.tracing.start(screenshots=True, snapshots=True, sources=False)
            self.tracing = True
        for page in self.context.pages:
            self.register(page)
        if not self.pages:
            self.register(self.context.new_page())

    def _closed_context(self, context: BrowserContext) -> None:
        self.invalidated = True

    @abstractmethod
    def register(self, page: Page) -> None: ...

    def _finish_trace(self) -> None:
        assert self.context is not None and self.trace_path is not None
        temporary = self.workspace.resolve(
            self.trace_path.parent / f".trace-{uuid.uuid4().hex}.zip"
        )
        try:
            self.context.tracing.stop(path=temporary)
            publish_artifact(self.workspace, self.trace_path, temporary, self.max_artifact_bytes)
            self.tracing = False
        finally:
            temporary.unlink(missing_ok=True)

    def close(self) -> list[str]:
        failures: list[str] = []
        if self.context is not None and self.tracing and not self.invalidated:
            try:
                self._finish_trace()
            except Exception as exc:
                failures.append(f"trace finalization {type(exc).__name__}")
        for name, resource in (("context", self.context), ("browser", self.browser)):
            if resource is not None:
                try:
                    resource.close()
                    if name == "context":
                        self.context = None
                    else:
                        self.browser = None
                except Exception as exc:
                    failures.append(f"{name} close {type(exc).__name__}")
        if self.playwright is not None:
            try:
                self.playwright.stop()
                self.playwright = None
            except Exception as exc:
                failures.append(f"Playwright stop {type(exc).__name__}")
        return failures
