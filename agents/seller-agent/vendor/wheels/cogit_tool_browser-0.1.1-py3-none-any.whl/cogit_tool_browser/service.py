"""Synchronous typed browser API with one stable, bounded owned worker."""

from __future__ import annotations

import threading
import uuid
from collections.abc import Callable
from pathlib import Path
from typing import TypeVar, cast

from cogit_tool_core import Model, Tool, ToolError, ToolLike, Workspace

from ._client import BrowserClient
from ._definitions import definitions
from ._ownership import retry_pending_retirements
from .models import (
    ActionRequest,
    ArtifactOutput,
    CloseOutput,
    CloseRequest,
    DownloadRequest,
    EvaluateRequest,
    EvaluationOutput,
    NavigateRequest,
    Observation,
    ObserveRequest,
    ResetOutput,
    ResetRequest,
    ScreenshotRequest,
    TabsOutput,
    TabsRequest,
)
from .scripts import ScriptRequest, ScriptResult, prepare_script
from .settings import BrowserScope, BrowserSessionSettings

ResultT = TypeVar("ResultT", bound=Model)


class BrowserService:
    """Own an ephemeral or dedicated persistent session on one supervised worker."""

    def __init__(
        self,
        workspace: Path,
        *,
        headless: bool = True,
        timeout_ms: int = 10000,
        trace_path: str | None = ".browser-artifacts/trace.zip",
        max_download_bytes: int = 67108864,
        max_tabs: int = 16,
        settings: BrowserSessionSettings | None = None,
        scope: BrowserScope | None = None,
    ) -> None:
        self._gate = threading.RLock()
        self._scope = scope
        self.workspace = Workspace(workspace)
        self.settings = settings or BrowserSessionSettings(
            headless=headless,
            timeout_ms=timeout_ms,
            trace_path=trace_path,
            max_artifact_bytes=max_download_bytes,
            max_tabs=max_tabs,
        )
        self._client = BrowserClient(self.workspace, self.settings, scope)

    def _call(self, operation: str, request: Model, result: type[ResultT]) -> ResultT:
        with self._gate:
            return self._client.call(operation, request, result)

    def run_script(self, request: ScriptRequest) -> ScriptResult:
        if not self.settings.scripts_enabled:
            raise ToolError("script_disabled", "Browser script capability is not configured")
        with self._gate:
            return self._client.call(
                "run_script", prepare_script(self.workspace, request), ScriptResult
            )

    def reset(self, request: ResetRequest) -> ResetOutput:
        """Explicitly acquire a fresh owner only after confirmed retirement."""
        with self._gate:
            warning = None
            try:
                self._client.close()
            except ToolError as exc:
                if not self._client.retired:
                    raise
                warning = str(exc)
            settings = self.settings
            if settings.trace_path:
                path = Path(settings.trace_path)
                settings = settings.model_copy(
                    update={"trace_path": str(path.with_stem(f"{path.stem}-{uuid.uuid4().hex}"))}
                )
            self._client = BrowserClient(self.workspace, settings, self._scope)
            observation = self._client.call("observe", ObserveRequest(), Observation)
            return ResetOutput(
                observation=observation,
                profile_reused=self.settings.mode == "persistent",
                cleanup_warning=warning,
            )

    @property
    def retired(self) -> bool:
        return self._client.retired

    def close_session(self, request: CloseRequest) -> CloseOutput:
        self.close()
        return CloseOutput()

    def navigate(self, request: NavigateRequest) -> Observation:
        return self._call("navigate", request, Observation)

    def observe(self, request: ObserveRequest) -> Observation:
        return self._call("observe", request, Observation)

    def action(self, request: ActionRequest) -> Observation:
        return self._call("action", request, Observation)

    def tabs(self, request: TabsRequest) -> TabsOutput:
        return self._call("tabs", request, TabsOutput)

    def download(self, request: DownloadRequest) -> ArtifactOutput:
        return self._call("download", request, ArtifactOutput)

    def screenshot(self, request: ScreenshotRequest) -> ArtifactOutput:
        return self._call("screenshot", request, ArtifactOutput)

    def evaluate(self, request: EvaluateRequest) -> EvaluationOutput:
        return self._call("evaluate", request, EvaluationOutput)

    def tools(self) -> tuple[ToolLike, ...]:
        return tuple(
            Tool(
                item.name,
                item.description,
                item.input_model,
                item.output_model,
                cast(Callable[[Model], Model], getattr(self, item.method)),
            )
            for item in definitions(self.settings.scripts_enabled)
        )

    def abort(self) -> None:
        self._client.abort()

    def invoke(self, handler: Callable[[], ResultT], cancelled: Callable[[], bool]) -> ResultT:
        """Attach a trusted cancellation signal, never a model-provided scope or grant."""
        with self._gate:
            return self._client.invoke(handler, cancelled)

    @staticmethod
    def cleanup_pending() -> None:
        """Retry retained failed-start/retirement owners before host shutdown."""
        retry_pending_retirements()

    def close(self) -> None:
        with self._gate:
            self._client.close()
