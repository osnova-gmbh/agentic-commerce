"""Optional SDK provider; AgentDB/Runtime policy remains the execution authority."""

from __future__ import annotations

import asyncio
import hashlib
import threading
import uuid
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, cast

from cogit_agent_sdk.operations import OperationInvocation
from cogit_agent_sdk.types import Context
from cogit_tool_core import Model, ToolError, Workspace
from cogit_tool_core.providers import HostContext, PreparedTools, ToolProvider
from cogit_tool_core.sdk import ToolMetadata, bind_scoped_tool
from pydantic import Field

from ._definitions import Definition, definitions
from .models import CloseOutput, ObserveRequest, ResetOutput, ResetRequest
from .service import BrowserService
from .settings import BrowserScope, BrowserSessionSettings


class BrowserProviderSettings(Model):
    mode: Literal["ephemeral", "persistent"] = "ephemeral"
    profile_id: str = Field(default="default", pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$")
    headless: bool = True
    channel: Literal["chrome", "msedge"] | None = None
    timeout_ms: int = Field(default=10000, ge=100, le=120000)
    trace_path: str | None = ".browser-artifacts/trace.zip"
    max_artifact_bytes: int = Field(default=67108864, ge=1, le=268435456)
    max_tabs: int = Field(default=16, ge=1, le=64)
    scripts_enabled: bool = False
    script_timeout_ms: int = Field(default=30000, ge=100, le=120000)
    max_sessions: int = Field(default=8, ge=1, le=64)


class BrowserResources:
    def __init__(self, settings: BrowserProviderSettings, host: HostContext) -> None:
        self.settings, self.host = settings, host
        self._gate = threading.RLock()
        self._sessions: dict[str, BrowserService] = {}
        self._started = False
        if settings.mode == "persistent" and host.automation_root is None:
            raise ValueError("Persistent browser requires host automation_root")

    async def start(self) -> None:
        # The session identity exists only on trusted invocations; no model argument selects it.
        Workspace(self.host.workspace)
        self._started = True

    def _key(self, context: Context) -> str:
        if context.tenant_id != self.host.tenant_id or (
            context.agent_id is not None and context.agent_id != self.host.agent_id
        ):
            raise ToolError("scope_mismatch", "Invocation does not own this provider scope")
        if not context.execution_id and not context.session_id:
            raise ToolError("scope_missing", "Browser requires a trusted execution or session ID")
        if self.settings.mode == "persistent":
            return "profile:" + self.settings.profile_id
        # A conversation can have simultaneous executions. Only an execution is
        # known to have drained when the host calls release_scope.
        if context.execution_id:
            return "execution:" + context.execution_id
        return "session:" + str(context.session_id)

    async def release_scope(self, context: Context) -> None:
        key = self._key(context)
        if self.settings.mode == "ephemeral" and context.execution_id:
            await asyncio.to_thread(self._close_key, key)

    def session(self, invocation: OperationInvocation) -> BrowserService:
        key = self._key(invocation.context)
        with self._gate:
            if not self._started:
                raise ToolError("provider_not_started", "Browser provider is not started")
            if key not in self._sessions:
                if len(self._sessions) >= self.settings.max_sessions:
                    raise ToolError("session_limit", "Browser provider session limit reached")
                self._sessions[key] = self._open(key)
            return self._sessions[key]

    def reset_session(self, invocation: OperationInvocation) -> ResetOutput:
        key = self._key(invocation.context)
        with self._gate:
            existing = key in self._sessions
            service = self.session(invocation)

            def reset() -> ResetOutput:
                if existing:
                    return service.reset(ResetRequest())
                return ResetOutput(
                    observation=service.observe(ObserveRequest()),
                    profile_reused=self.settings.mode == "persistent",
                )

            return service.invoke(reset, lambda: invocation.cancellation.cancelled)

    def close_session(self, invocation: OperationInvocation) -> CloseOutput:
        key = self._key(invocation.context)
        self._close_key(key)
        return CloseOutput()

    def _close_key(self, key: str) -> None:
        with self._gate:
            service = self._sessions.get(key)
            if service is not None:
                try:
                    service.close()
                finally:
                    if service.retired:
                        del self._sessions[key]

    def _open(self, session_key: str) -> BrowserService:
        values = self.settings.model_dump(exclude={"max_sessions"})
        values["profile_root"] = (
            str(self.host.automation_root) if self.settings.mode == "persistent" else None
        )
        if self.settings.trace_path:
            path = Path(self.settings.trace_path)
            key = hashlib.sha256(session_key.encode()).hexdigest()[:20]
            values["trace_path"] = str(path.parent / key / uuid.uuid4().hex / path.name)
        settings = BrowserSessionSettings.model_validate(values)
        scope = BrowserScope(
            tenant_id=self.host.tenant_id, agent_id=self.host.agent_id, session_id=session_key
        )
        return BrowserService(self.host.workspace, settings=settings, scope=scope)

    def _close(self) -> None:
        with self._gate:
            self._started = False
            failures: list[str] = []
            for key, service in reversed(tuple(self._sessions.items())):
                try:
                    service.close()
                    del self._sessions[key]
                except Exception as exc:
                    failures.append(type(exc).__name__)
            try:
                BrowserService.cleanup_pending()
            except ToolError as exc:
                failures.append(str(exc))
            if failures:
                raise ToolError("cleanup_failed", ", ".join(failures))

    async def close(self) -> None:
        await asyncio.to_thread(self._close)


@dataclass(frozen=True)
class _Invoke:
    definition: Definition
    resources: BrowserResources

    def __call__(self, request: Model, invocation: OperationInvocation) -> Model:
        if self.definition.method == "reset":
            return self.resources.reset_session(invocation)
        if self.definition.method == "close_session":
            return self.resources.close_session(invocation)
        service = self.resources.session(invocation)
        operation = cast(Callable[[Model], Model], getattr(service, self.definition.method))
        return service.invoke(lambda: operation(request), lambda: invocation.cancellation.cancelled)


def prepare(
    settings: BrowserProviderSettings,
    host: HostContext,
    dependencies: Mapping[str, PreparedTools],
) -> PreparedTools:
    resources = BrowserResources(settings, host)
    startup = 30 + max(30, settings.timeout_ms // 1000 + 5)
    timeout = startup + max(settings.timeout_ms + 5000, settings.script_timeout_ms) // 1000 + 20
    reset_timeout = startup + 2 * (settings.timeout_ms // 1000 + 5) + 30
    bindings = tuple(
        bind_scoped_tool(
            item.name,
            item.description,
            item.input_model,
            item.output_model,
            _Invoke(item, resources),
            metadata=ToolMetadata(
                risk=(
                    "destructive"
                    if item.method == "run_script"
                    else "read"
                    if item.method == "observe"
                    else "write"
                ),
                idempotency="inherent" if item.method in {"observe", "close_session"} else "none",
                requires_approval=False,
                timeout_seconds=reset_timeout if item.method == "reset" else timeout,
            ),
            record=host.record,
        )
        for item in definitions(settings.scripts_enabled)
    )
    prompt = (
        "Use the owned browser tools to inspect live DOM before acting. Verify downloaded bytes. "
        "Call browser_close when browser work is finished to release this scope. "
    )
    if settings.scripts_enabled:
        prompt += (
            "For Python Playwright use browser_run_script with a workspace file and exact SHA256. "
            "Define synchronous run(page, context, arguments), return JSON, "
            "and reuse injected objects. "
            "A shell-launched browser does not share this session. Script authority is privileged. "
            "After timeout/disconnection effects are unknown. Use browser_reset deliberately "
            "to acquire a new owner, then inspect state before retrying any action."
        )
    return PreparedTools(
        bindings, (prompt,), resources.start, resources.close, resources, resources.release_scope
    )


provider = ToolProvider(BrowserProviderSettings, prepare)
