"""Supervisor-owned profile lease and process tree; failed retirement retains both."""

from __future__ import annotations

import os
import threading
import time
from collections.abc import Callable
from contextlib import suppress
from multiprocessing.process import BaseProcess
from pathlib import Path
from typing import cast

from cogit_tool_core import ToolError
from cogit_transport_browser_session.errors import ProfileInUseError
from cogit_transport_browser_session.locking import ProfileLock

from ._windows_job import WindowsJob

# A failed constructor cannot hand an owner to its caller. Keep uncertain leases
# alive until explicit cleanup confirms exit, including if the caller drops an error.
_PENDING: dict[BrowserOwnership, BaseProcess] = {}
_PENDING_GATE = threading.Lock()


class BrowserOwnership:
    def __init__(self, profile: Path | None) -> None:
        self._retirement_gate = threading.Lock()
        self._profile_lock: ProfileLock | None = None
        self._job: WindowsJob | None = None
        self._group: int | None = None
        try:
            if profile is not None:
                profile.parent.mkdir(parents=True, exist_ok=True)
                self._profile_lock = ProfileLock(profile)
                self._profile_lock.acquire()
            if os.name == "nt":
                self._job = WindowsJob()
        except ProfileInUseError:
            raise ToolError("profile_busy", "Dedicated profile already has an owner") from None
        except Exception as exc:
            self.release()
            raise ToolError("browser_ownership_failed", type(exc).__name__) from None

    def attach(self, process: BaseProcess) -> None:
        assert process.pid is not None
        if self._job is not None:
            self._job.attach(process.pid)
        else:
            self._group = process.pid

    def _empty(self) -> bool:
        if self._job is not None:
            return self._job.empty()
        if self._group is None:
            return True
        try:
            cast(Callable[[int, int], None], vars(os)["killpg"])(self._group, 0)
        except ProcessLookupError:
            return True
        return False

    def retire(self, process: BaseProcess) -> str | None:
        """Kill the owned job/group even when its original worker has already died."""
        with self._retirement_gate:
            error = self._retire(process)
            if error:
                with _PENDING_GATE:
                    _PENDING[self] = process
            return error

    def _retire(self, process: BaseProcess) -> str | None:
        try:
            if self._job is not None:
                self._job.terminate()
            elif self._group is not None:
                with suppress(ProcessLookupError):
                    cast(Callable[[int, int], None], vars(os)["killpg"])(self._group, 9)
            if process.pid is not None:
                if process.is_alive():
                    process.terminate()  # startup before job/group association
                process.join(timeout=5)
            deadline = time.monotonic() + 5
            while not self._empty() and time.monotonic() < deadline:
                time.sleep(0.025)
            if (process.pid is not None and process.is_alive()) or not self._empty():
                return "Owned browser tree termination unconfirmed; profile remains locked"
            self.release()
            return None
        except (OSError, ValueError):
            return "Owned browser tree termination failed; profile remains locked"

    def release(self) -> None:
        with _PENDING_GATE:
            _PENDING.pop(self, None)
        if self._job is not None:
            self._job.close()
            self._job = None
        self._group = None
        if self._profile_lock is not None:
            self._profile_lock.release()
            self._profile_lock = None


def retry_pending_retirements() -> None:
    """Retry only previously owned trees, retaining unconfirmed owners on failure."""
    with _PENDING_GATE:
        pending = tuple(_PENDING.items())
    errors = [error for owner, process in pending if (error := owner.retire(process))]
    if errors:
        raise ToolError("cleanup_failed", "; ".join(errors))
