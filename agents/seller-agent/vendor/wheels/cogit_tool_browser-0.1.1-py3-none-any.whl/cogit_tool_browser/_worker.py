"""Private owned-worker protocol and bounded tree retirement."""

from __future__ import annotations

import os
from dataclasses import dataclass
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Literal

from cogit_tool_core import Model, ToolError, Workspace
from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import TimeoutError as PlaywrightTimeout

from ._session import BrowserSession
from .models import (
    ActionRequest,
    DownloadRequest,
    EvaluateRequest,
    NavigateRequest,
    ObserveRequest,
    ScreenshotRequest,
    TabsRequest,
)
from .scripts import ScriptProgram


@dataclass(frozen=True)
class BrowserConfig:
    workspace: Path
    timeout_ms: int
    max_artifact_bytes: int
    trace_path: str | None
    headless: bool
    max_tabs: int
    profile: Path | None = None
    channel: Literal["chrome", "msedge"] | None = None


@dataclass(frozen=True)
class Request:
    operation: str
    value: Model | ScriptProgram | None


@dataclass(frozen=True)
class Response:
    kind: Literal["waiting", "ready", "result", "error", "closed"]
    value: Model | None = None
    error: tuple[str, str] | None = None


def dispatch(session: BrowserSession, request: Request) -> Model:
    value = request.value
    match request.operation, value:
        case "navigate", NavigateRequest():
            return session.navigate(value)
        case "observe", ObserveRequest():
            return session.observe(value)
        case "action", ActionRequest():
            return session.action(value)
        case "tabs", TabsRequest():
            return session.tabs(value)
        case "download", DownloadRequest():
            return session.download(value)
        case "screenshot", ScreenshotRequest():
            return session.screenshot(value)
        case "evaluate", EvaluateRequest():
            return session.evaluate(value)
        case "run_script", ScriptProgram():
            return session.run_script(value)
        case _:
            raise ToolError("invalid_input", "Unknown internal browser operation")


def isolate_environment() -> None:
    allowed = {
        "SYSTEMROOT",
        "SYSTEMDRIVE",
        "PROGRAMDATA",
        "ALLUSERSPROFILE",
        "WINDIR",
        "PATH",
        "PATHEXT",
        "TEMP",
        "TMP",
        "HOME",
        "USERPROFILE",
        "LOCALAPPDATA",
        "APPDATA",
        "PROGRAMFILES",
        "PROGRAMFILES(X86)",
        "COMSPEC",
        "LANG",
        "LC_ALL",
        "TZ",
        "PLAYWRIGHT_BROWSERS_PATH",
        "DISPLAY",
        "XAUTHORITY",
        "WAYLAND_DISPLAY",
        "XDG_RUNTIME_DIR",
    }
    environment = {key: value for key, value in os.environ.items() if key.upper() in allowed}
    os.environ.clear()
    os.environ.update(environment)
    os.environ["PYTHONUTF8"] = "1"


def worker(connection: Connection, config: BrowserConfig) -> None:
    if os.name != "nt":
        os.setsid()
    isolate_environment()
    os.chdir(config.workspace)
    session: BrowserSession | None = None
    try:
        connection.send(Response("waiting"))
        start: object = connection.recv()
        if not isinstance(start, Request) or start.operation != "start":
            raise ToolError("browser_start_failed", "Supervisor did not grant process ownership")
        session = BrowserSession(
            Workspace(config.workspace),
            config.timeout_ms,
            config.max_artifact_bytes,
            config.trace_path,
            config.headless,
            config.max_tabs,
            config.profile,
            config.channel,
        )
        connection.send(Response("ready"))
        worker_loop(connection, session)
    except ToolError as exc:
        connection.send(Response("error", error=(exc.code, str(exc))))
    except (EOFError, BrokenPipeError, OSError):
        pass
    except Exception as exc:
        connection.send(Response("error", error=("browser_error", type(exc).__name__)))
    finally:
        if session is not None:
            session.close()
        connection.close()


def worker_loop(connection: Connection, session: BrowserSession) -> None:
    while True:
        raw: object = connection.recv()
        if not isinstance(raw, Request):
            raise ToolError("invalid_input", "Invalid internal browser message")
        if raw.operation == "close":
            failures = session.close()
            if failures:
                connection.send(Response("error", error=("cleanup_failed", "; ".join(failures))))
            else:
                connection.send(Response("closed"))
            return
        try:
            connection.send(Response("result", value=dispatch(session, raw)))
        except ToolError as exc:
            connection.send(Response("error", error=(exc.code, str(exc))))
        except PlaywrightTimeout:
            message = (
                "Action timed out; re-observe and choose an existing unique target. "
                "Downloads require a link/button that starts a download."
            )
            connection.send(Response("error", error=("browser_timeout", message)))
        except (PlaywrightError, OSError, ValueError) as exc:
            # Browser exception text can contain request URLs/data; keep errors bounded and private.
            message = (
                f"Browser operation failed ({type(exc).__name__}); "
                "re-observe the current page and check the requested action or artifact path."
            )
            connection.send(Response("error", error=("browser_error", message)))
