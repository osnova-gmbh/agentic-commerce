"""Artifact publication within the native workspace guardrail."""

from __future__ import annotations

import hashlib
import os
import shutil
import uuid
from pathlib import Path

from cogit_tool_core import ToolError, Workspace

from .models import ArtifactOutput


def artifact_destination(workspace: Workspace, value: str) -> Path:
    path = workspace.resolve(value)
    if path.exists():
        raise ToolError("artifact_exists", "Choose a new artifact path; destination already exists")
    path.parent.mkdir(parents=True, exist_ok=True)
    return workspace.resolve(path)


def publish_artifact(
    workspace: Workspace,
    path: Path,
    source: Path | bytes,
    max_bytes: int,
    suggested_filename: str | None = None,
) -> ArtifactOutput:
    """Publish complete bytes only; an existing destination is never overwritten."""
    size = len(source) if isinstance(source, bytes) else source.stat().st_size
    if size > max_bytes:
        raise ToolError("artifact_too_large", f"Artifact exceeds {max_bytes} bytes")
    path = workspace.resolve(path)
    temporary = workspace.resolve(path.parent / f".browser-{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("xb") as output:
            if isinstance(source, bytes):
                output.write(source)
            else:
                with source.open("rb") as original:
                    shutil.copyfileobj(original, output, length=65536)
            output.flush()
            os.fsync(output.fileno())
        # Hard-link creation atomically refuses an existing file, unlike replace().
        os.link(temporary, workspace.resolve(path))
    except FileExistsError:
        raise ToolError(
            "artifact_exists", "Choose a new artifact path; destination already exists"
        ) from None
    finally:
        temporary.unlink(missing_ok=True)
    digest = hashlib.sha256()
    with path.open("rb") as artifact:
        while chunk := artifact.read(65536):
            digest.update(chunk)
    return ArtifactOutput(
        path=str(path.relative_to(workspace.root)),
        size_bytes=size,
        sha256=digest.hexdigest(),
        suggested_filename=suggested_filename,
    )
