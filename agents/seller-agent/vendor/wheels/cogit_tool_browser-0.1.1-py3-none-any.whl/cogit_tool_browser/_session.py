"""Playwright state. Every method is called on the service's single owner thread."""

from __future__ import annotations

from urllib.parse import urlsplit

from cogit_tool_core import ToolError
from playwright.sync_api import Locator, Page

from ._artifacts import artifact_destination, publish_artifact
from ._lifetime import BrowserLifetime
from .models import (
    ActionRequest,
    ArtifactOutput,
    DownloadRequest,
    EvaluateRequest,
    EvaluationOutput,
    LocatorSpec,
    NavigateRequest,
    Observation,
    ObserveRequest,
    ScreenshotRequest,
    TabInfo,
    TabsOutput,
    TabsRequest,
)
from .scripts import ScriptProgram, ScriptResult, run_script


class BrowserSession(BrowserLifetime):
    def register(self, page: Page) -> None:
        if page in self.pages.values():
            return
        if len(self.live_pages()) >= self.max_tabs:
            page.close()
            return
        tab_id = f"tab-{self.next_id}"
        self.next_id += 1
        self.pages[tab_id] = page
        self.active = tab_id
        page.on("dialog", lambda dialog: dialog.dismiss())

    def live_pages(self) -> dict[str, Page]:
        self.pages = {key: value for key, value in self.pages.items() if not value.is_closed()}
        return self.pages

    def page(self, tab_id: str | None) -> tuple[str, Page]:
        pages = self.live_pages()
        key = tab_id or self.active
        if key not in pages:
            raise ToolError(
                "missing_tab", "Tab is closed or unknown; call browser_tabs to list tabs"
            )
        return key, pages[key]

    @staticmethod
    def validate_url(url: str) -> None:
        parsed = urlsplit(url)
        if url != "about:blank" and (parsed.scheme not in {"http", "https"} or not parsed.netloc):
            raise ToolError("invalid_url", "Navigate to an http(s) URL or about:blank")

    def navigate(self, request: NavigateRequest) -> Observation:
        self.validate_url(request.url)
        _, page = self.page(request.tab_id)
        page.goto(request.url, wait_until="domcontentloaded")
        return self.observe(ObserveRequest(tab_id=request.tab_id))

    def observe(self, request: ObserveRequest) -> Observation:
        tab_id, page = self.page(request.tab_id)
        snapshot = page.locator("body").aria_snapshot(timeout=self.timeout_ms)
        return Observation(
            tab_id=tab_id,
            url=page.url[:8192],
            title=page.title()[:1024],
            snapshot=snapshot[: request.max_chars],
            truncated=len(snapshot) > request.max_chars,
        )

    def locate(self, page: Page, target: LocatorSpec) -> Locator:
        if target.role is not None:
            locator = page.get_by_role(target.role, name=target.name, exact=True)
        elif target.label is not None:
            locator = page.get_by_label(target.label, exact=True)
        elif target.text is not None:
            locator = page.get_by_text(target.text, exact=True)
        elif target.placeholder is not None:
            locator = page.get_by_placeholder(target.placeholder, exact=True)
        else:
            assert target.test_id is not None
            locator = page.get_by_test_id(target.test_id)
        count = locator.count()
        if count > 1:
            raise ToolError(
                "ambiguous_target",
                f"Target matches {count} elements; re-observe and choose a unique semantic target",
            )
        # Zero matches retain Playwright's bounded auto-wait for dynamic DOM.
        return locator

    def action(self, request: ActionRequest) -> Observation:
        tab_id, page = self.page(request.tab_id)
        locator = self.locate(page, request.target)
        match request.kind:
            case "click":
                locator.click()
            case "fill":
                locator.fill(request.value)
            case "select":
                locator.select_option(label=request.value)
            case "press":
                locator.press(request.value)
        return self.observe(ObserveRequest(tab_id=tab_id))

    def tabs(self, request: TabsRequest) -> TabsOutput:
        assert self.context is not None
        if request.operation == "new":
            if len(self.live_pages()) >= self.max_tabs:
                raise ToolError(
                    "tab_limit", f"Close a tab before opening more than {self.max_tabs}"
                )
            if request.url is not None:
                self.validate_url(request.url)
            self.register(self.context.new_page())
            if request.url is not None:
                self.navigate(NavigateRequest(url=request.url))
        elif request.operation in {"switch", "close"}:
            tab_id, page = self.page(request.tab_id)
            if request.operation == "close":
                page.close()
                self.active = next(iter(self.live_pages()), "")
            else:
                self.active = tab_id
        return TabsOutput(
            tabs=tuple(
                TabInfo(
                    tab_id=key,
                    url=page.url[:8192],
                    title=page.title()[:1024],
                    active=key == self.active,
                )
                for key, page in self.live_pages().items()
            )
        )

    def download(self, request: DownloadRequest) -> ArtifactOutput:
        destination = artifact_destination(self.workspace, request.path)
        _, page = self.page(request.tab_id)
        with page.expect_download(timeout=self.timeout_ms) as event:
            self.locate(page, request.target).click()
        download = event.value
        source = download.path()
        try:
            return publish_artifact(
                self.workspace,
                destination,
                source,
                self.max_artifact_bytes,
                download.suggested_filename[:1024],
            )
        finally:
            download.delete()

    def screenshot(self, request: ScreenshotRequest) -> ArtifactOutput:
        destination = artifact_destination(self.workspace, request.path)
        _, page = self.page(request.tab_id)
        data = page.screenshot(type="png", full_page=request.full_page, timeout=self.timeout_ms)
        return publish_artifact(self.workspace, destination, data, self.max_artifact_bytes)

    def evaluate(self, request: EvaluateRequest) -> EvaluationOutput:
        _, page = self.page(request.tab_id)
        handle = page.wait_for_function(
            """async ({source, limit}) => {
          const expression = (0, eval)(source);
          const value = await (typeof expression === 'function' ? expression() : expression);
          const json = JSON.stringify(value) ?? 'null';
          return {value_json: json.slice(0, limit), truncated: json.length > limit};
        }""",
            arg={"source": request.expression, "limit": request.max_chars},
            timeout=self.timeout_ms,
            polling=100,
        )
        try:
            return EvaluationOutput.model_validate(handle.json_value())
        finally:
            handle.dispose()

    def run_script(self, program: ScriptProgram) -> ScriptResult:
        _, page = self.page(program.request.tab_id)
        assert self.context is not None
        result = run_script(program, page, self.context)
        if self.invalidated:
            raise ToolError(
                "browser_session_invalidated", "Script closed the owned context; session retired"
            )
        path = str(self.trace_path.relative_to(self.workspace.root)) if self.trace_path else None
        return result.model_copy(update={"trace_path": path})
