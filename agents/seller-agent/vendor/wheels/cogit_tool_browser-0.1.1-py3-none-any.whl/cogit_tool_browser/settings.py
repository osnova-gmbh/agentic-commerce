"""Host-selected browser ownership; no I/O during schema preparation."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Literal, Self

from cogit_tool_core import Model, ToolError
from pydantic import Field, model_validator


class BrowserScope(Model):
    tenant_id: str = Field(min_length=1, max_length=256)
    agent_id: str = Field(min_length=1, max_length=256)
    session_id: str = Field(min_length=1, max_length=512)


class BrowserSessionSettings(Model):
    mode: Literal["ephemeral", "persistent"] = "ephemeral"
    profile_root: str | None = None
    profile_id: str = Field(default="default", pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$")
    headless: bool = True
    channel: Literal["chrome", "msedge"] | None = None
    timeout_ms: int = Field(default=10000, ge=100, le=120000)
    trace_path: str | None = ".browser-artifacts/trace.zip"
    max_artifact_bytes: int = Field(default=67108864, ge=1, le=268435456)
    max_tabs: int = Field(default=16, ge=1, le=64)
    scripts_enabled: bool = False
    script_timeout_ms: int = Field(default=30000, ge=100, le=120000)

    @model_validator(mode="after")
    def profile_selection(self) -> Self:
        if self.mode == "persistent":
            if self.profile_root is None or not Path(self.profile_root).is_absolute():
                raise ValueError("Persistent mode requires an absolute dedicated profile_root")
        elif self.profile_root is not None:
            raise ValueError("Ephemeral mode does not accept profile_root")
        return self


def profile_path(settings: BrowserSessionSettings, scope: BrowserScope, workspace: Path) -> Path:
    """Validate only supplied paths; never enumerate normal browser data/processes."""
    assert settings.profile_root is not None
    root = Path(settings.profile_root).resolve()
    home = Path.home()
    local = Path(os.environ.get("LOCALAPPDATA", str(home / "AppData/Local")))
    forbidden = (
        local / "Google/Chrome/User Data",
        local / "Microsoft/Edge/User Data",
        local / "BraveSoftware/Brave-Browser/User Data",
        home / ".config/google-chrome",
        home / ".config/chromium",
        home / "Library/Application Support/Google/Chrome",
        workspace,
    )
    if any(root == item.resolve() or root.is_relative_to(item.resolve()) for item in forbidden):
        raise ToolError("invalid_profile", "Profile root must be dedicated and outside workspace")
    identity = "\0".join((scope.tenant_id, scope.agent_id))
    key = hashlib.sha256(identity.encode()).hexdigest()
    path = (root / key / settings.profile_id).resolve()
    if not path.is_relative_to(root):
        raise ToolError("invalid_profile", "Profile path escapes its dedicated root")
    return path
