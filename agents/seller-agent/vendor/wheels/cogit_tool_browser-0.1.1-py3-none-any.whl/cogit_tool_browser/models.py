"""Bounded, strongly typed browser inputs and results."""

from __future__ import annotations

from typing import Literal, Self

from cogit_tool_core import Model
from pydantic import Field, model_validator

Role = Literal[
    "alert",
    "alertdialog",
    "application",
    "article",
    "banner",
    "blockquote",
    "button",
    "caption",
    "cell",
    "checkbox",
    "code",
    "columnheader",
    "combobox",
    "complementary",
    "contentinfo",
    "definition",
    "deletion",
    "dialog",
    "directory",
    "document",
    "emphasis",
    "feed",
    "figure",
    "form",
    "generic",
    "grid",
    "gridcell",
    "group",
    "heading",
    "img",
    "insertion",
    "link",
    "list",
    "listbox",
    "listitem",
    "log",
    "main",
    "marquee",
    "math",
    "meter",
    "menu",
    "menubar",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "navigation",
    "none",
    "note",
    "option",
    "paragraph",
    "presentation",
    "progressbar",
    "radio",
    "radiogroup",
    "region",
    "row",
    "rowgroup",
    "rowheader",
    "scrollbar",
    "search",
    "searchbox",
    "separator",
    "slider",
    "spinbutton",
    "status",
    "strong",
    "subscript",
    "superscript",
    "switch",
    "tab",
    "table",
    "tablist",
    "tabpanel",
    "term",
    "textbox",
    "time",
    "timer",
    "toolbar",
    "tooltip",
    "tree",
    "treegrid",
    "treeitem",
]


class LocatorSpec(Model):
    """Exactly one observed semantic target; role can include an exact accessible name."""

    role: Role | None = None
    name: str | None = Field(default=None, max_length=1000)
    label: str | None = Field(default=None, min_length=1, max_length=1000)
    text: str | None = Field(default=None, min_length=1, max_length=1000)
    placeholder: str | None = Field(default=None, min_length=1, max_length=1000)
    test_id: str | None = Field(default=None, min_length=1, max_length=1000)

    @model_validator(mode="after")
    def one_target(self) -> Self:
        if (
            sum(
                x is not None
                for x in (self.role, self.label, self.text, self.placeholder, self.test_id)
            )
            != 1
        ):
            raise ValueError("Choose exactly one of role, label, text, placeholder, test_id")
        if self.name is not None and self.role is None:
            raise ValueError("name requires role")
        return self


class PageRequest(Model):
    tab_id: str | None = Field(default=None, min_length=1, max_length=40)


class NavigateRequest(PageRequest):
    url: str = Field(min_length=1, max_length=8192)


class ObserveRequest(PageRequest):
    max_chars: int = Field(default=16000, ge=256, le=32000)


class ActionRequest(PageRequest):
    kind: Literal["click", "fill", "select", "press"]
    target: LocatorSpec
    value: str = Field(default="", max_length=100000)


class TabsRequest(Model):
    operation: Literal["list", "new", "switch", "close"] = "list"
    tab_id: str | None = Field(default=None, min_length=1, max_length=40)
    url: str | None = Field(default=None, min_length=1, max_length=8192)


class DownloadRequest(PageRequest):
    target: LocatorSpec
    path: str = Field(min_length=1, max_length=4096)


class ScreenshotRequest(PageRequest):
    path: str = Field(min_length=1, max_length=4096)
    full_page: bool = False


class EvaluateRequest(PageRequest):
    expression: str = Field(min_length=1, max_length=100000)
    max_chars: int = Field(default=16000, ge=256, le=32000)


class Observation(Model):
    tab_id: str
    url: str
    title: str
    snapshot: str
    truncated: bool


class TabInfo(Model):
    tab_id: str
    url: str
    title: str
    active: bool


class TabsOutput(Model):
    tabs: tuple[TabInfo, ...]


class ArtifactOutput(Model):
    path: str
    size_bytes: int
    sha256: str
    suggested_filename: str | None = None


class EvaluationOutput(Model):
    value_json: str
    truncated: bool


class ResetRequest(Model):
    """Deliberate retirement and reopening with the same host-owned settings."""


class ResetOutput(Model):
    observation: Observation
    profile_reused: bool
    cleanup_warning: str | None = None


class CloseRequest(Model):
    """Close this invocation's browser scope, retaining its persistent profile."""


class CloseOutput(Model):
    closed: bool = True
