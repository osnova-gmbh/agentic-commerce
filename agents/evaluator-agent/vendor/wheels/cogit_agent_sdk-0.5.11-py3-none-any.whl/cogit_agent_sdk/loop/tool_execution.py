"""Execute explicit tool bindings through one OperationContract invocation."""

from __future__ import annotations

import asyncio
import inspect
import json
from collections.abc import Callable, Coroutine
from typing import Any, cast

from pydantic import BaseModel, ValidationError

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.operations.contract import OperationError, OperationInvocation
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.types import Context, RunEvent, TextContent, ToolResult
from cogit_agent_sdk.types.requirements import CapabilityDenied


class OperationKeyError(ValueError):
    """A keyed operation cannot safely run with the supplied logical identity."""


def _require_matching_context(context: Context, invocation: OperationInvocation) -> None:
    if context != invocation.context:
        raise OperationKeyError("Tool context must match operation invocation context")


def _validated_operation_key(value: object) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > 256:
        raise OperationKeyError(
            "Logical idempotency key must be a nonempty string of at most 256 characters"
        )
    return value


def resolve_operation_key(
    binding: ToolBinding[Any, Any],
    request: BaseModel,
    context: Context,
    invocation: OperationInvocation,
) -> str | None:
    """Bind a validated domain or host key to the exact operation context."""

    _require_matching_context(context, invocation)
    key: object = (
        binding.key_for(request, context)
        if binding.key_for is not None
        else invocation.idempotency_key
    )
    if key is None:
        if binding.descriptor.idempotency == "keyed":
            raise OperationKeyError("Keyed operation requires a logical idempotency key")
        return None
    return _validated_operation_key(key)


def raise_operation_key_error(exc: Exception) -> None:
    """Keep key and authority failures out of model-facing tool recovery."""

    if isinstance(exc, (OperationKeyError, CapabilityDenied)):
        raise exc


def render_output_as_tool_result(
    output: BaseModel,
    *,
    tool_call_id: str,
    tool_name: str,
) -> ToolResult:
    """Render a validated operation output model as a model-facing tool result."""

    dumped = output.model_dump(mode="json")
    if set(dumped) == {"text"}:
        text = str(dumped["text"])
    elif isinstance(dumped, str):
        text = dumped
    else:
        text = json.dumps(dumped, ensure_ascii=False)
    return ToolResult(
        tool_call_id=tool_call_id,
        tool_name=tool_name,
        content=[TextContent(text=text)],
    )


def format_input_validation_error(tool_name: str, exc: ValidationError) -> str:
    details = "; ".join(
        f"{'.'.join(str(part) for part in error['loc'])}: {error['msg']}" for error in exc.errors()
    )
    return f"Invalid arguments for tool {tool_name}: {details}"


def execute_tool_binding(
    binding: ToolBinding[Any, Any],
    *,
    raw_arguments: JsonObject,
    context: Context,
    invocation: OperationInvocation,
    tool_call_id: str,
    on_progress: Callable[[RunEvent], None] | None = None,
) -> ToolResult:
    """Prepare, validate, invoke once, validate output, and render a ToolResult."""

    _require_matching_context(context, invocation)
    binding.require_permissions(context)

    prepared: JsonObject = raw_arguments
    if binding.prepare_arguments is not None:
        prepared = binding.prepare_arguments(raw_arguments, context)

    try:
        request = binding.operation.input_model.model_validate(prepared)
    except ValidationError as exc:
        return ToolResult(
            tool_call_id=tool_call_id,
            tool_name=binding.descriptor.name,
            content=[TextContent(text=format_input_validation_error(binding.descriptor.name, exc))],
            is_error=True,
            details={"code": "INVALID_ARGUMENTS"},
        )

    idempotency_key = resolve_operation_key(binding, request, context, invocation)

    call_invocation = OperationInvocation(
        context=invocation.context,
        handle=invocation.handle,
        cancellation=invocation.cancellation,
        idempotency_key=idempotency_key,
        emit_progress=on_progress,
    )

    try:
        raw_output = binding.operation(request, call_invocation)
        if inspect.isawaitable(raw_output):
            raw_output = asyncio.run(cast(Coroutine[Any, Any, Any], raw_output))
    except CoordinationFailure:
        raise
    except OperationError as exc:
        # OperationError's contract carries redacted evidence. Preserve it so
        # callers can distinguish a safe retry from an uncertain provider effect.
        details = dict(exc.error.details or {})
        details["code"] = exc.error.code
        if exc.error.retryable is not None:
            details["retryable"] = exc.error.retryable
        return ToolResult(
            tool_call_id=tool_call_id,
            tool_name=binding.descriptor.name,
            content=[TextContent(text=exc.error.message)],
            is_error=True,
            details=details,
        )

    try:
        if isinstance(raw_output, binding.operation.output_model):
            output = raw_output
        else:
            output = binding.operation.output_model.model_validate(raw_output)
    except ValidationError:
        return ToolResult(
            tool_call_id=tool_call_id,
            tool_name=binding.descriptor.name,
            content=[TextContent(text="Tool returned invalid output")],
            is_error=True,
            details={"code": "INVALID_OUTPUT"},
        )

    result = render_output_as_tool_result(
        output,
        tool_call_id=tool_call_id,
        tool_name=binding.descriptor.name,
    )
    return result
