"""Deferred synchronous resources with async host lifecycle and typed operations."""

from __future__ import annotations

from collections.abc import Callable
from typing import Generic, Protocol, TypeVar

from cogit_agent_sdk.operations import OperationInvocation, ToolBinding
from pydantic import BaseModel

from .contracts import ToolError
from .providers import HostContext, invocation_scope
from .sdk import ToolMetadata, bind_scoped_tool


class Closable(Protocol):
    def close(self) -> None: ...


ServiceT = TypeVar("ServiceT", bound=Closable)
InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


class DeferredService(Generic[ServiceT]):
    def __init__(self, factory: Callable[[], ServiceT], host: HostContext) -> None:
        self.factory, self.host = factory, host
        self._service: ServiceT | None = None
        self._closed = False

    async def start(self) -> None:
        if self._service is not None or self._closed:
            raise RuntimeError("Provider resource can be started only once")
        try:
            self._service = self.factory()
        except OSError as exc:
            raise ToolError("provider_start_failed", type(exc).__name__) from exc

    def get(self, invocation: OperationInvocation) -> ServiceT:
        invocation_scope(invocation, self.host, require_session=False)
        return self.ready()

    def ready(self) -> ServiceT:
        if self._service is None or self._closed:
            raise ToolError("provider_inactive", "Provider resource has not started or is closed")
        return self._service

    async def close(self) -> None:
        if self._service is not None:
            self._service.close()
            self._service = None
        self._closed = True

    def binding(
        self,
        name: str,
        description: str,
        input_model: type[InputT],
        output_model: type[OutputT],
        operation: Callable[[ServiceT, InputT], OutputT],
        *,
        metadata: ToolMetadata,
    ) -> ToolBinding[BaseModel, BaseModel]:
        def invoke(request: InputT, invocation: OperationInvocation) -> OutputT:
            return operation(self.get(invocation), request)

        return bind_scoped_tool(
            name,
            description,
            input_model,
            output_model,
            invoke,
            metadata=metadata,
            record=self.host.record,
        )
