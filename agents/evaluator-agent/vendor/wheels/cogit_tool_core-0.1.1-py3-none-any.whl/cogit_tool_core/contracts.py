"""One small contract shared by independent capability packages."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Generic, Protocol, TypeVar

from pydantic import BaseModel, ConfigDict, ValidationError


class Model(BaseModel):
    model_config = ConfigDict(frozen=True, strict=True, extra="forbid")


class ToolError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class ToolLike(Protocol):
    @property
    def name(self) -> str: ...
    @property
    def description(self) -> str: ...
    @property
    def input_model(self) -> type[BaseModel]: ...
    @property
    def output_model(self) -> type[BaseModel]: ...
    def invoke(self, arguments: dict[str, object]) -> BaseModel: ...


InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


@dataclass(frozen=True)
class Tool(Generic[InputT, OutputT]):
    name: str
    description: str
    input_model: type[InputT]
    output_model: type[OutputT]
    handler: Callable[[InputT], OutputT]

    def invoke(self, arguments: dict[str, object]) -> OutputT:
        try:
            request = self.input_model.model_validate(arguments)
        except ValidationError as exc:
            errors = exc.errors(include_input=False, include_url=False)
            raise ToolError("invalid_input", str(errors)) from None
        result = self.handler(request)
        if not isinstance(result, self.output_model):
            raise ToolError("invalid_output", "Handler returned an unexpected result type")
        return result
