"""Cooperative cancellation helpers for async agent code."""

from __future__ import annotations

import asyncio
from typing import Literal

from cogit_agent_sdk.types.cancellation import Cancellation

_POLL_INTERVAL_SECONDS = 0.05


class CooperativeCancellationEvent(asyncio.Event):
    """Expose SDK :class:`Cancellation` and optional upstream signals as one event.

    This adapter polls the SDK ``Cancellation`` protocol every 50ms because
    ``Cancellation`` exposes only a synchronous ``cancelled`` flag and
    ``throw_if_cancelled()`` hook, not an awaitable waiter.

    ``wait()`` follows ``asyncio.Event`` semantics: it returns ``True`` when
    cancellation is observed and does not raise. Call :func:`check_cancelled`
    when the caller should abort with an exception instead of continuing.

    Exception behavior:

    * Manual ``set()`` or upstream ``asyncio.Event`` cancellation is observed
      by ``is_set()`` and ``wait()`` only; it does not raise until
      :func:`check_cancelled` is called.
    * Upstream cancellation checked by :func:`check_cancelled` raises
      ``asyncio.CancelledError("operation cancelled")``.
    * SDK cancellation checked by :func:`check_cancelled` delegates to
      ``cancellation.throw_if_cancelled()`` and therefore raises whatever
      error the bound ``Cancellation`` implementation chooses.
    """

    def __init__(
        self,
        cancellation: Cancellation,
        upstream: asyncio.Event | None = None,
    ) -> None:
        super().__init__()
        self._cancellation = cancellation
        self._upstream = upstream

    def is_set(self) -> bool:
        if super().is_set():
            return True
        if self._cancellation.cancelled:
            return True
        return self._upstream is not None and self._upstream.is_set()

    async def wait(self) -> Literal[True]:
        while not self.is_set():
            self._cancellation.throw_if_cancelled()
            await asyncio.sleep(_POLL_INTERVAL_SECONDS)
        return True


def bind_cooperative_cancellation(
    cancellation: Cancellation,
    upstream: asyncio.Event | None = None,
) -> CooperativeCancellationEvent:
    """Create an asyncio event that tracks cooperative cancellation."""

    return CooperativeCancellationEvent(cancellation, upstream)


def check_cancelled(
    cancellation: Cancellation,
    upstream: asyncio.Event | None = None,
) -> None:
    """Raise when cancellation has been requested.

    Upstream ``asyncio.Event`` cancellation is checked first and raises
    ``asyncio.CancelledError``. Otherwise this delegates to the SDK
    ``Cancellation`` implementation via ``throw_if_cancelled()``.
    """

    if upstream is not None and upstream.is_set():
        raise asyncio.CancelledError("operation cancelled")
    cancellation.throw_if_cancelled()
