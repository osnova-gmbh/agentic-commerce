"""Shell policy is explicit; process lifecycle belongs to the injected service."""

from __future__ import annotations

import os
import shutil
from typing import Literal

from cogit_tool_core import Model, Tool, ToolError, ToolLike
from cogit_tool_execution import ProcessOutput, ProcessService, StartRequest
from pydantic import Field

ShellKind = Literal["powershell", "bash", "cmd"]


class ShellRequest(Model):
    command: str = Field(min_length=1, max_length=65536)
    cwd: str = "."
    wait_ms: int = Field(default=1000, ge=0, le=10000)
    max_runtime_seconds: float = Field(default=600.0, ge=0.1, le=3600.0)


class ShellService:
    def __init__(
        self,
        processes: ProcessService,
        *,
        kind: ShellKind | None = None,
        executable: str | None = None,
    ) -> None:
        self.processes = processes
        self.kind = kind or ("powershell" if os.name == "nt" else "bash")
        default = "pwsh" if self.kind == "powershell" else self.kind
        found = executable or shutil.which(default)
        if not found and self.kind == "powershell":
            found = shutil.which("powershell")
        if not found:
            raise ToolError("shell_unavailable", f"Shell executable unavailable: {default}")
        self.executable = found
        self._closed = False

    def run(self, request: ShellRequest) -> ProcessOutput:
        if self._closed:
            raise ToolError("service_closed", "Shell service is closed")
        if self.kind == "powershell":
            args = ["-NoLogo", "-NoProfile", "-NonInteractive", "-Command", request.command]
        elif self.kind == "bash":
            args = ["--noprofile", "--norc", "-c", request.command]
        else:
            args = ["/D", "/S", "/C", request.command]
        return self.processes.start(
            StartRequest(
                argv=[self.executable, *args],
                cwd=request.cwd,
                wait_ms=request.wait_ms,
                max_runtime_seconds=request.max_runtime_seconds,
            )
        )

    def tools(self) -> tuple[ToolLike, ...]:
        return (
            Tool(
                "shell_run",
                f"Run a {self.kind} command in the workspace with a minimal environment. "
                "Returns persistent process ID; poll/input/stop use process tools. "
                "Trusted local execution under OS permissions; not sandboxed.",
                ShellRequest,
                ProcessOutput,
                self.run,
            ),
        )

    def close(self) -> None:
        self._closed = True
