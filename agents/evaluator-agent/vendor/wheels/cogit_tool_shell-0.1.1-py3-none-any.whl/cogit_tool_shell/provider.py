"""Shell provider borrowing the selected execution instance and its scope ownership."""

from collections.abc import Mapping

from cogit_agent_sdk.operations import OperationInvocation
from cogit_tool_core import Model
from cogit_tool_core.deferred import DeferredService
from cogit_tool_core.providers import HostContext, PreparedTools, ToolProvider
from cogit_tool_core.sdk import ToolMetadata, bind_scoped_tool
from cogit_tool_execution import ProcessOutput
from cogit_tool_execution.provider import ExecutionResources

from .service import ShellKind, ShellRequest, ShellService


class ShellSettings(Model):
    kind: ShellKind | None = None
    executable: str | None = None


def prepare(
    settings: ShellSettings, host: HostContext, dependencies: Mapping[str, PreparedTools]
) -> PreparedTools:
    processes = dependencies["execution"].resource
    if not isinstance(processes, ExecutionResources):
        raise ValueError("Shell execution dependency must expose ExecutionResources")
    owner = DeferredService(
        lambda: ShellService(processes.ready(), kind=settings.kind, executable=settings.executable),
        host,
    )

    def run(request: ShellRequest, invocation: OperationInvocation) -> ProcessOutput:
        return processes.record_creation(invocation, lambda: owner.get(invocation).run(request))

    binding = bind_scoped_tool(
        "shell_run",
        "Run a shell command under OS authority with explicit host environment. "
        "Use process tools to poll/input/stop its scoped process ID.",
        ShellRequest,
        ProcessOutput,
        run,
        metadata=ToolMetadata(risk="destructive", idempotency="none"),
        record=host.record,
    )
    return PreparedTools(
        bindings=(binding,),
        prompt_fragments=(
            "Shell executes real code with OS authority. Observe failures, repair deliberately "
            "and verify outputs before reporting completion.",
        ),
        start=owner.start,
        close=owner.close,
        resource=owner,
    )


provider = ToolProvider(ShellSettings, prepare, dependencies=("execution",))
