"""SQLAlchemy models for runtime-owned persistence tables (``cogit_rt_*``).

The runtime keeps its own view of executions, events, sessions, and outbox
records so it can survive process restarts. Platform records live at the
platform boundary; the ``cogit_rt_*`` tables are runtime-local.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

import sqlalchemy as sa
from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Shared declarative base for runtime persistence models."""


class RuntimeDatabaseOwnership(Base):
    """A production SQL database belongs to exactly one tenant."""

    __tablename__ = "cogit_rt_database_ownership"
    __table_args__ = (sa.CheckConstraint("id = 1", name="ck_runtime_single_owner"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False)


class RuntimeRun(Base):
    """Local mirror of an :class:`ExecutionRecord` under the runtime's control."""

    __tablename__ = "cogit_rt_runs"

    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(128), index=True)
    organization_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    agent_id: Mapped[str] = mapped_column(String(128), index=True)
    case_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    session_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    trigger: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(32), index=True)
    outcome_label: Mapped[str | None] = mapped_column(String(128), nullable=True)
    input_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    output_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    usage: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    error: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    run_metadata: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)


class RuntimeRunEvent(Base):
    """Local mirror of a :class:`RunEvent` for polling and audit."""

    __tablename__ = "cogit_rt_run_events"
    __table_args__ = (
        UniqueConstraint(
            "execution_id",
            "sequence",
            name="uq_run_event_execution_sequence",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    execution_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("cogit_rt_runs.id", ondelete="CASCADE"),
        index=True,
    )
    case_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    sequence: Mapped[int] = mapped_column(Integer)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    type: Mapped[str] = mapped_column(String(48))
    payload: Mapped[dict[str, Any]] = mapped_column(JSON)


class RuntimeSession(Base):
    """Local session state, including trimmed transcript history."""

    __tablename__ = "cogit_rt_sessions"

    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(128), index=True)
    agent_id: Mapped[str] = mapped_column(String(128), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    messages: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    state: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    session_metadata: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)


class RuntimeAttention(Base):
    """Parked ``AttentionItem`` records with matching decisions once resolved."""

    __tablename__ = "cogit_rt_attention"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    kind: Mapped[str] = mapped_column(String(48))
    execution_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    case_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    message: Mapped[str] = mapped_column(Text)
    options: Mapped[list[dict[str, Any]] | None] = mapped_column(JSON, nullable=True)
    item_metadata: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    decision_action: Mapped[str | None] = mapped_column(String(32), nullable=True)
    decision_rationale: Mapped[str | None] = mapped_column(Text, nullable=True)
    decided_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )


class RuntimeOutbox(Base):
    """Durable outbox for platform mirror operations pending flush."""

    __tablename__ = "cogit_rt_outbox"
    __table_args__ = (
        sa.Index(
            "uq_outbox_idempotency_key",
            "idempotency_key",
            unique=True,
            postgresql_where=sa.text("idempotency_key IS NOT NULL"),
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    operation: Mapped[str] = mapped_column(String(48), index=True)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON)
    context: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    idempotency_key: Mapped[str | None] = mapped_column(String(256), nullable=True)
    enqueued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    available_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        index=True,
    )
    delivered: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    dead_lettered: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    retries: Mapped[int] = mapped_column(Integer, default=0)


class RuntimeLearning(Base):
    """Local mirror of learning records."""

    __tablename__ = "cogit_rt_learnings"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    agent_id: Mapped[str] = mapped_column(String(128), index=True)
    tenant_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    organization_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    title: Mapped[str] = mapped_column(Text)
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), default="active")
    tags: Mapped[list[str]] = mapped_column(JSON, default=list)
    source: Mapped[dict[str, Any]] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class RuntimeExperiment(Base):
    """Local mirror of improvement experiment proposals."""

    __tablename__ = "cogit_rt_experiments"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    agent_id: Mapped[str] = mapped_column(String(128), index=True)
    organization_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    hypothesis: Mapped[str] = mapped_column(Text)
    changed_surface: Mapped[str] = mapped_column(String(48))
    metrics: Mapped[dict[str, Any]] = mapped_column(JSON)
    verdict: Mapped[str] = mapped_column(String(32), default="proposed")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class RuntimeEval(Base):
    """Local mirror of eval runs."""

    __tablename__ = "cogit_rt_evals"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    agent_id: Mapped[str] = mapped_column(String(128), index=True)
    agent_version: Mapped[str] = mapped_column(String(64))
    suite_name: Mapped[str] = mapped_column(String(128))
    status: Mapped[str] = mapped_column(String(32))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    eval_metadata: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)


class RuntimeCase(Base):
    """Durable case record keyed by natural key (tenant + source_type + source_id)."""

    __tablename__ = "cogit_rt_cases"
    __table_args__ = (
        sa.UniqueConstraint(
            "tenant_id", "source_type", "source_id", name="uq_case_natural_key"
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    organization_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    agent_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    source_type: Mapped[str] = mapped_column(String(64), nullable=False)
    source_id: Mapped[str] = mapped_column(String(256), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False)
    current_goal: Mapped[str | None] = mapped_column(Text, nullable=True)
    process_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    process_version: Mapped[str | None] = mapped_column(String(64), nullable=True)
    assigned_agent_ids: Mapped[list[str] | None] = mapped_column(JSON, nullable=True)
    owner: Mapped[str | None] = mapped_column(String(128), nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    next_retry_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_attempt_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    final_outcome: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[dict[str, Any] | str | None] = mapped_column(JSON, nullable=True)
    case_metadata: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)


class RuntimeQueueItem(Base):
    """Durable queue item record."""

    __tablename__ = "cogit_rt_queue_items"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    organization_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    queue_name: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    item_type: Mapped[str] = mapped_column(String(64), nullable=False)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    addressed_to: Mapped[str | None] = mapped_column(String(128), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    case_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    source_id: Mapped[str | None] = mapped_column(String(256), nullable=True)
    idempotency_key: Mapped[str | None] = mapped_column(String(256), nullable=True)
    dedupe_key: Mapped[str | None] = mapped_column(String(256), nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_retries: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    lease_expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    heartbeat_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    error: Mapped[str | None] = mapped_column(Text, nullable=True)


class RuntimeArtifact(Base):
    """Local artifact metadata / reference record."""

    __tablename__ = "cogit_rt_artifacts"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str | None] = mapped_column(String(512), nullable=True)
    mime_type: Mapped[str | None] = mapped_column(String(128), nullable=True)
    size: Mapped[int | None] = mapped_column(Integer, nullable=True)
    uri: Mapped[str | None] = mapped_column(Text, nullable=True)
    case_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    execution_id: Mapped[str | None] = mapped_column(
        String(128), nullable=True, index=True
    )
    tenant_id: Mapped[str | None] = mapped_column(
        String(128), nullable=True, index=True
    )
    artifact_metadata: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class RuntimeFeedback(Base):
    """Local feedback record linked to a case and/or execution."""

    __tablename__ = "cogit_rt_feedback"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    case_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    execution_id: Mapped[str | None] = mapped_column(
        String(128), nullable=True, index=True
    )
    rating: Mapped[str | None] = mapped_column(String(32), nullable=True)
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    feedback_metadata: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )


class RuntimeExecutionStep(Base):
    """Durable execution step record."""

    __tablename__ = "cogit_rt_execution_steps"
    __table_args__ = (
        sa.UniqueConstraint(
            "execution_id", "order_num", name="uq_step_execution_order"
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    execution_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("cogit_rt_runs.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    case_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    order_num: Mapped[int] = mapped_column(Integer, nullable=False)
    kind: Mapped[str] = mapped_column(String(48), nullable=False)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    data: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    error: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    usage: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)


__all__ = [
    "Base",
    "RuntimeArtifact",
    "RuntimeAttention",
    "RuntimeCase",
    "RuntimeEval",
    "RuntimeExecutionStep",
    "RuntimeExperiment",
    "RuntimeFeedback",
    "RuntimeLearning",
    "RuntimeOutbox",
    "RuntimeQueueItem",
    "RuntimeRun",
    "RuntimeRunEvent",
    "RuntimeSession",
]
