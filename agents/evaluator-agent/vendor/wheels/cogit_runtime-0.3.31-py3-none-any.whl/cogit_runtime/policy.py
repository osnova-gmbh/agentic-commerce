"""Mandatory host enforcement; only the AgentDB module evaluates policy rules."""

from __future__ import annotations

import hashlib
import json
from typing import Any, Literal

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import AgentDescriptor, CapabilityRequirement
from cogit_agent_sdk.types.policy import PolicyCheckpoint, PolicyOperation
from cogit_agent_sdk.types.requirements import OperationRequirements

from cogit_runtime.agentdb.handle import AgentDbRunHandle
from cogit_runtime.errors import RuntimeConfigurationError


class PolicyDeniedError(CoordinationFailure):
    """A central decision denies continuation; no successful result may publish."""


def digest(value: object) -> str:
    try:
        data = json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, RecursionError):
        raise PolicyDeniedError("Policy commitment is not bounded JSON") from None
    if len(data) > 1048576:
        raise PolicyDeniedError("Policy commitment exceeds its byte bound")
    return hashlib.sha256(data).hexdigest()


class RuntimePolicyGate:
    """A required, immutable authority selection, never agent-supplied rules."""

    def __init__(self, descriptor: AgentDescriptor) -> None:
        self.descriptor = descriptor
        self.manifest_hash = digest(descriptor.model_dump(mode="json", by_alias=True))

    @classmethod
    def from_descriptor(cls, descriptor: AgentDescriptor) -> RuntimePolicyGate | None:
        config = (descriptor.metadata or {}).get("cogit_policy")
        if config is None:
            tools = (descriptor.metadata or {}).get("cogit_tools")
            if isinstance(tools, dict) and tools.get("providers"):
                raise RuntimeConfigurationError(
                    "Dynamic providers require central AgentDB policy"
                )
            return None
        if config != {"authority": "agentdb", "contract": "runtime.checkpoint.v1"}:
            raise RuntimeConfigurationError("Unsupported Runtime policy authority")
        if not any(
            p.module_key == "cogit.runtime-policy"
            and any(
                e.key == "checkpoint.evaluate"
                and e.contract_id == "runtime.checkpoint.v1"
                for e in p.exports
            )
            for p in descriptor.database_packages
        ):
            raise RuntimeConfigurationError(
                "Runtime policy needs its pinned database package"
            )
        return cls(descriptor)

    def operation(
        self,
        name: str,
        requirements: OperationRequirements,
        kind: Literal["action", "tool"] = "action",
    ) -> PolicyOperation:
        capabilities = tuple(
            CapabilityRequirement(name=c, module_scope=None)
            if isinstance(c, str)
            else c
            for c in requirements.required_capabilities
        )
        material: dict[str, Any] = {
            "kind": kind,
            "name": name,
            "risk": requirements.risk,
            "idempotency": requirements.idempotency,
            "requiresApproval": requirements.requires_approval,
            "requiredCapabilities": [
                c.model_dump(mode="json", by_alias=True) for c in capabilities
            ],
        }
        return PolicyOperation(
            kind=kind,
            name=name,
            agent_version=self.descriptor.version,
            descriptor_sha256=digest(material),
            risk=requirements.risk,
            idempotency=requirements.idempotency,
            required_capabilities=capabilities,
            requires_approval=requirements.requires_approval,
        )

    def require(self, handle: object, checkpoint: PolicyCheckpoint) -> bool:
        """Require a fresh decision; return whether preflight needs approval."""
        if not isinstance(handle, AgentDbRunHandle):
            raise PolicyDeniedError("Required AgentDB policy authority is unavailable")
        decision = handle.evaluate_policy(checkpoint)
        if decision.effect == "deny":
            raise PolicyDeniedError(
                "AgentDB denied policy checkpoint: " + decision.reason_code
            )
        if decision.effect == "require_approval":
            if checkpoint.phase != "pre_tool":
                raise PolicyDeniedError(
                    "This checkpoint requires operator review before continuation"
                )
            return True
        return False

    def checkpoint(
        self,
        *,
        phase: Literal["pre_tool", "post_tool", "checkpoint"],
        operation: PolicyOperation,
        payload: object,
        slot: str,
        result: object = None,
        state: Literal["not_started", "completed", "failed", "unknown"] = "not_started",
    ) -> PolicyCheckpoint:
        return PolicyCheckpoint(
            checkpoint_id=digest([slot, operation.name, phase, digest(payload)]),
            phase=phase,
            operation=operation,
            manifest_sha256=self.manifest_hash,
            input_sha256=digest(payload),
            result_sha256=None if result is None else digest(result),
            effect_state=state,
        )
