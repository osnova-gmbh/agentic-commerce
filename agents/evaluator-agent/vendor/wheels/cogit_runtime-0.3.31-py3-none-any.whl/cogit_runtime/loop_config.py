"""Compose Runtime defaults with explicitly authored SDK loop fields."""

from __future__ import annotations

from cogit_agent_sdk.types import AgentLoopConfig, RunBudget
from pydantic import ValidationError

from cogit_runtime.config import BudgetDefaultsConfig, LoopConfig
from cogit_runtime.errors import RuntimeConfigurationError


def validate_loop_config(value: object) -> AgentLoopConfig:
    """Validate custom results, retaining omission and explicit-null provenance."""
    if isinstance(value, AgentLoopConfig):
        # Revalidate model_copy/model_construct results too; model_validate alone
        # trusts existing model instances. Recursive exclusion preserves budgets.
        # Serializer warnings can echo malformed values before validation fails.
        value = value.model_dump(exclude_unset=True, warnings=False)
    try:
        return AgentLoopConfig.model_validate(value)
    except ValidationError:
        raise RuntimeConfigurationError(
            "Agent loop_config must return a valid SDK AgentLoopConfig"
        ) from None


def resolve_loop_defaults(
    base: AgentLoopConfig,
    defaults: LoopConfig,
    *,
    override_budget: RunBudget | None,
    override_max_turns: int | None,
) -> AgentLoopConfig:
    """Apply omitted defaults before whole-request budget replacement."""
    updates: dict[str, object] = {}
    if "max_turns" not in base.model_fields_set:
        updates["max_turns"] = defaults.max_turns_default
    budget = _resolve_budget_defaults(base, defaults.budget_defaults)
    if budget is not base.budget:
        updates["budget"] = budget
    if override_max_turns is not None:
        updates["max_turns"] = override_max_turns
    if override_budget is not None:
        # A request budget replaces the complete agent/default budget, including
        # omitted fields. Request null retains the established no-override meaning.
        updates["budget"] = override_budget
    return validate_loop_config(base.model_copy(update=updates))


def _resolve_budget_defaults(
    base: AgentLoopConfig, defaults: BudgetDefaultsConfig
) -> RunBudget | None:
    budget = base.budget
    if budget is None and "budget" in base.model_fields_set:
        return None
    updates: dict[str, object] = {}
    fields_set = budget.model_fields_set if budget is not None else set()
    if "max_cost" not in fields_set and defaults.max_cost is not None:
        updates["max_cost"] = defaults.max_cost
    if (
        "max_duration_seconds" not in fields_set
        and defaults.max_duration_seconds is not None
    ):
        updates["max_duration_seconds"] = defaults.max_duration_seconds
    if not updates:
        return budget
    return (budget or RunBudget()).model_copy(update=updates)
