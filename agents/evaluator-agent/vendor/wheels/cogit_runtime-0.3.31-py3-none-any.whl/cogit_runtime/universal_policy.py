"""Current-policy host boundary independent of optional legacy checkpoint modules."""

from __future__ import annotations

from uuid import UUID

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types.universal_policy import UniversalPolicyDecision
from cogit_agent_sdk.universal_policy import (
    PolicyAuthorityUnavailable,
    UniversalPolicyAuthority,
    require_protected_approval,
)

from cogit_runtime.agentdb.handle import AgentDbRunHandle


class ProtectedActionAuthority:
    """Bind the host's service transport to a live fenced execution.

    The returned preflight receipt never replaces the effect service's atomic
    current-policy check. No descriptor metadata or agent hook grants approval.
    """

    def __init__(
        self, handle: AgentDbRunHandle, authority: UniversalPolicyAuthority
    ) -> None:
        if not isinstance(handle, AgentDbRunHandle):
            raise PolicyAuthorityUnavailable(
                "Protected actions require an admitted host execution"
            )
        self._handle = handle
        self._authority = authority

    def evaluate(self, action_id: UUID) -> UniversalPolicyDecision:
        handle = self._handle
        handle._router.require_execution(handle.execution_id)
        try:
            result = UniversalPolicyDecision.model_validate(
                self._authority.evaluate(action_id)
            )
            principal = handle.context.principal
            if (
                result.subject.action_id != action_id
                or result.subject.tenant_id != UUID(handle.context.tenant_id or "")
                or principal is None
                or result.subject.actor_principal_id != UUID(principal.id)
            ):
                raise PolicyAuthorityUnavailable(
                    "Protected action belongs to another subject"
                )
        except CoordinationFailure:
            raise
        except Exception:
            raise PolicyAuthorityUnavailable(
                "Protected action authority is unavailable"
            ) from None
        handle._router.require_execution(handle.execution_id)
        return result

    def require_approval(
        self,
        *,
        action_id: UUID,
        action_version: str,
        payload_sha256: str,
    ) -> UniversalPolicyDecision:
        return require_protected_approval(
            self,
            action_id=action_id,
            action_version=action_version,
            payload_sha256=payload_sha256,
            tenant_id=UUID(self._handle.context.tenant_id or ""),
        )
