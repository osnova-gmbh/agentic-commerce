"""Offline PostgreSQL migration utilities for historical Runtime SQL data."""

from __future__ import annotations

from pathlib import Path

import sqlalchemy as sa
from alembic import command
from alembic.config import Config
from alembic.runtime.migration import MigrationContext
from alembic.script import ScriptDirectory
from sqlalchemy import Connection, Engine, create_engine
from sqlalchemy.engine import make_url
from sqlalchemy.engine.reflection import Inspector

from cogit_runtime.persistence import Base


class SchemaMigrationError(RuntimeError):
    """The selected database is not a safe Alembic upgrade target."""


def build_engine(database_url: str) -> Engine:
    """Build a PostgreSQL engine for an offline legacy database operation."""
    require_legacy_postgres(make_url(database_url).get_backend_name())

    return create_engine(database_url, future=True)


def require_legacy_postgres(dialect_name: str) -> None:
    if dialect_name != "postgresql":
        raise SchemaMigrationError("Offline legacy Runtime data requires PostgreSQL")


def create_missing_tables(engine: Engine) -> list[str]:
    """Create runtime-owned tables that do not already exist.

    Returns the list of table names that were created. Safe to call multiple
    times; existing tables are left untouched.
    """

    require_legacy_postgres(engine.dialect.name)
    before = _existing_tables(engine)
    Base.metadata.create_all(bind=engine)
    _add_compatible_columns(engine)
    after = _existing_tables(engine)
    return sorted(after - before)


def _alembic_config() -> Config:
    ini_path = Path(__file__).resolve().parent / "alembic" / "alembic.ini"
    return Config(str(ini_path))


def alembic_script_directory() -> ScriptDirectory:
    """Return the Alembic script directory for runtime migrations."""

    return ScriptDirectory.from_config(_alembic_config())


def expected_schema_head() -> str | None:
    """Return the Alembic head revision id for the runtime package."""

    return alembic_script_directory().get_current_head()


def upgrade_schema(engine: Engine) -> str:
    """Upgrade an empty or recognized versioned database to the packaged head.

    No unversioned existing tables are adopted. Alembic receives the same
    PostgreSQL connection inspected here.
    """

    require_legacy_postgres(engine.dialect.name)
    script = alembic_script_directory()
    head = script.get_current_head()
    if head is None:
        raise SchemaMigrationError("No runtime schema head is packaged")
    with engine.connect() as connection:
        current = _migration_target_revision(connection, script, head)
        if current == head:
            _verify_head_layout(connection)
            return head
        connection.rollback()
        with connection.begin():
            config = _alembic_config()
            config.attributes["connection"] = connection
            command.upgrade(config, "head")
            revisions = MigrationContext.configure(connection).get_current_heads()
            if revisions != (head,):
                raise SchemaMigrationError("Runtime schema did not reach package head")
            _verify_head_layout(connection)
        return head


def _migration_target_revision(
    connection: Connection, script: ScriptDirectory, head: str
) -> str | None:
    tables = set(sa.inspect(connection).get_table_names())
    revisions = MigrationContext.configure(connection).get_current_heads()
    if len(revisions) > 1:
        raise SchemaMigrationError("Runtime database has multiple schema revisions")
    if not revisions:
        if tables:
            raise SchemaMigrationError(
                "Runtime database is unversioned and nonempty; retain a backup "
                "and migrate a separate empty database"
            )
        return None
    current = revisions[0]
    known = {
        revision.revision for revision in script.walk_revisions(base="base", head=head)
    }
    if current not in known:
        raise SchemaMigrationError("Runtime database has an unknown schema revision")
    return current


def _verify_head_layout(connection: Connection) -> None:
    inspector = sa.inspect(connection)
    tables = set(inspector.get_table_names())
    if not set(Base.metadata.tables).issubset(tables):
        raise SchemaMigrationError("Runtime schema is missing required tables")
    for table_name, model_table in Base.metadata.tables.items():
        columns = {column["name"] for column in inspector.get_columns(table_name)}
        if not set(model_table.columns.keys()).issubset(columns):
            raise SchemaMigrationError("Runtime schema is missing required columns")
    for table_name, column_name in (
        ("cogit_rt_runs", "id"),
        ("cogit_rt_run_events", "execution_id"),
        ("cogit_rt_execution_steps", "execution_id"),
        ("cogit_rt_attention", "execution_id"),
    ):
        columns = {
            column["name"]: column for column in inspector.get_columns(table_name)
        }
        column = columns.get(column_name)
        if (
            column is None
            or not isinstance(column["type"], sa.String)
            or column["type"].length != 128
        ):
            raise SchemaMigrationError("Runtime schema has an incompatible ID column")
    outbox_columns = {
        column["name"]: column for column in inspector.get_columns("cogit_rt_outbox")
    }
    available = outbox_columns.get("available_at")
    dead = outbox_columns.get("dead_lettered")
    if (
        available is None
        or not isinstance(available["type"], sa.DateTime)
        or not available["nullable"]
    ):
        raise SchemaMigrationError("Runtime schema has an incompatible outbox column")
    if dead is None or not isinstance(dead["type"], sa.Boolean) or dead["nullable"]:
        raise SchemaMigrationError("Runtime schema has an incompatible outbox column")
    _verify_head_constraints(inspector, connection.dialect.name)


def _verify_head_constraints(inspector: Inspector, dialect_name: str) -> None:
    indexes = {
        index["name"]: index for index in inspector.get_indexes("cogit_rt_outbox")
    }
    expected = (
        ("ix_cogit_rt_outbox_available_at", "available_at", False),
        ("ix_cogit_rt_outbox_dead_lettered", "dead_lettered", False),
        ("uq_outbox_idempotency_key", "idempotency_key", True),
    )
    for name, column, unique in expected:
        index = indexes.get(name)
        if (
            index is None
            or index["column_names"] != [column]
            or bool(index["unique"]) != unique
        ):
            raise SchemaMigrationError("Runtime schema has incompatible outbox indexes")
    idempotency = indexes["uq_outbox_idempotency_key"]
    where = idempotency.get("dialect_options", {}).get(f"{dialect_name}_where")
    predicate = "" if where is None else "".join(str(where).lower().split())
    if predicate.replace('"', "").strip("()") != "idempotency_keyisnotnull":
        raise SchemaMigrationError("Runtime schema has incompatible outbox indexes")
    uniques = {
        item["name"]: item
        for item in inspector.get_unique_constraints("cogit_rt_run_events")
    }
    event_unique = uniques.get("uq_run_event_execution_sequence")
    if event_unique is None or event_unique["column_names"] != [
        "execution_id",
        "sequence",
    ]:
        raise SchemaMigrationError("Runtime schema has incompatible event uniqueness")


def current_schema_revision(engine: Engine) -> str | None:
    """Return the Alembic revision currently stamped on ``engine``."""

    require_legacy_postgres(engine.dialect.name)
    with engine.connect() as connection:
        context = MigrationContext.configure(connection)
        return context.get_current_revision()


def verify_schema_revision(engine: Engine) -> bool:
    """Return True only for the packaged head and its required physical layout."""

    require_legacy_postgres(engine.dialect.name)
    head = expected_schema_head()
    if head is None:
        return False
    with engine.connect() as connection:
        if MigrationContext.configure(connection).get_current_heads() != (head,):
            return False
        try:
            _verify_head_layout(connection)
        except SchemaMigrationError:
            return False
    return True


def stamp_schema_head_if_empty(engine: Engine) -> bool:
    """Stamp Alembic head when the database has no revision row yet.

    Used after ``create_missing_tables`` in development so readiness checks
    see a matching revision. Returns True when a stamp was applied.
    """

    if current_schema_revision(engine) is not None:
        return False
    head = expected_schema_head()
    if head is None:
        return False
    script = alembic_script_directory()
    with engine.begin() as connection:
        context = MigrationContext.configure(connection)
        context.stamp(script, head)
    return True


def ensure_dev_schema(engine: Engine) -> bool:
    """Bootstrap missing tables in development and stamp head when empty.

    Returns whether the schema revision matches package head afterwards.
    """

    create_missing_tables(engine)
    stamp_schema_head_if_empty(engine)
    return verify_schema_revision(engine)


def _add_compatible_columns(engine: Engine) -> None:
    """Apply additive bootstrap upgrades for existing create-all databases."""

    required = {
        "cogit_rt_run_events": {"case_id": sa.String(128)},
        "cogit_rt_execution_steps": {"case_id": sa.String(128)},
        "cogit_rt_outbox": {
            "available_at": sa.DateTime(timezone=True),
            "dead_lettered": sa.Boolean(),
            "idempotency_key": sa.String(256),
        },
        "cogit_rt_cases": {
            "current_goal": sa.Text(),
            "process_id": sa.String(128),
            "process_version": sa.String(64),
            "assigned_agent_ids": sa.JSON(),
            "owner": sa.String(128),
            "created_at": sa.DateTime(timezone=True),
            "updated_at": sa.DateTime(timezone=True),
            "completed_at": sa.DateTime(timezone=True),
            "final_outcome": sa.Text(),
        },
    }
    inspector = sa.inspect(engine)
    existing_tables = set(inspector.get_table_names())
    for table_name, columns in required.items():
        if table_name not in existing_tables:
            continue
        existing_columns = {
            column["name"] for column in inspector.get_columns(table_name)
        }
        for column_name, column_type in columns.items():
            if column_name in existing_columns:
                continue
            compiled_type = column_type.compile(dialect=engine.dialect)
            with engine.begin() as connection:
                connection.execute(
                    sa.text(
                        f'ALTER TABLE "{table_name}" '
                        f'ADD COLUMN "{column_name}" {compiled_type}'
                    )
                )

    for table_name in ("cogit_rt_run_events", "cogit_rt_execution_steps"):
        if table_name not in existing_tables:
            continue
        table = Base.metadata.tables[table_name]
        index_name = f"ix_{table_name}_case_id"
        index = next(
            candidate for candidate in table.indexes if candidate.name == index_name
        )
        index.create(bind=engine, checkfirst=True)

    if "cogit_rt_outbox" in existing_tables:
        outbox = Base.metadata.tables["cogit_rt_outbox"]
        for index in outbox.indexes:
            if index.name == "uq_outbox_idempotency_key":
                index.create(bind=engine, checkfirst=True)

    if "cogit_rt_run_events" in existing_tables:
        events = Base.metadata.tables["cogit_rt_run_events"]
        for constraint in events.constraints:
            if constraint.name == "uq_run_event_execution_sequence":
                try:
                    create = getattr(constraint, "create", None)
                    if callable(create):
                        create(bind=engine, checkfirst=True)
                except Exception:
                    # Duplicate rows may already exist on legacy DBs; leave for
                    # an explicit Alembic upgrade / cleanup path.
                    logger = __import__("logging").getLogger(__name__)
                    logger.debug(
                        "skip unique constraint create on legacy DB",
                        exc_info=True,
                    )

    _widen_run_id_columns(engine)


def _widen_run_id_columns(engine: Engine) -> None:
    """Widen run/checkpoint id columns for pipeline checkpoint keys."""

    if engine.dialect.name != "postgresql":
        return
    statements = (
        'ALTER TABLE "cogit_rt_runs" ALTER COLUMN "id" TYPE VARCHAR(128)',
        (
            'ALTER TABLE "cogit_rt_run_events" '
            'ALTER COLUMN "execution_id" TYPE VARCHAR(128)'
        ),
        (
            'ALTER TABLE "cogit_rt_execution_steps" '
            'ALTER COLUMN "execution_id" TYPE VARCHAR(128)'
        ),
        (
            'ALTER TABLE "cogit_rt_attention" '
            'ALTER COLUMN "execution_id" TYPE VARCHAR(128)'
        ),
    )
    inspector = sa.inspect(engine)
    existing_tables = set(inspector.get_table_names())
    with engine.begin() as connection:
        for statement in statements:
            table_name = statement.split('"')[1]
            if table_name not in existing_tables:
                continue
            connection.execute(sa.text(statement))


def _existing_tables(engine: Engine) -> set[str]:
    from sqlalchemy import inspect

    inspector = inspect(engine)
    return set(inspector.get_table_names())


__all__ = [
    "alembic_script_directory",
    "build_engine",
    "create_missing_tables",
    "current_schema_revision",
    "ensure_dev_schema",
    "expected_schema_head",
    "stamp_schema_head_if_empty",
    "verify_schema_revision",
]
