"""Inbound authentication helpers."""

from __future__ import annotations

import secrets

from fastapi import HTTPException, Request, status

from cogit_runtime.config import RuntimeEnvironment


class AgentAuthenticator:
    """Validates v0 static agent and admin API keys."""

    def __init__(self, environment: RuntimeEnvironment) -> None:
        self._environment = environment

    async def require_agent_key(self, request: Request) -> None:
        """FastAPI dependency for endpoints protected by agent-api-key auth."""

        if self._environment.dev_mode:
            return

        expected = self._environment.agent_api_key
        presented = _extract_presented_key(request)
        if expected is None or presented is None:
            raise _unauthorized()

        if not secrets.compare_digest(presented, expected):
            raise _unauthorized()

    async def require_admin_key(self, request: Request) -> None:
        """FastAPI dependency for endpoints protected by admin-api-key auth."""

        if self._environment.dev_mode:
            return

        expected = self._environment.agent_admin_key
        presented = _extract_presented_key(request)
        if expected is None or presented is None:
            raise _unauthorized()

        if not secrets.compare_digest(presented, expected):
            raise _unauthorized()


def _extract_presented_key(request: Request) -> str | None:
    header_key = request.headers.get("x-api-key")
    if header_key:
        return header_key

    authorization = request.headers.get("authorization")
    if authorization is None:
        return None

    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        return None
    return token


def _unauthorized() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Missing or invalid agent API key",
    )
