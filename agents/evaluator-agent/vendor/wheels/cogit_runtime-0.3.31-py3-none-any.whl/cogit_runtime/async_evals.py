"""Own background evaluation tasks and drain them before Runtime shutdown."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable

EvalExecutor = Callable[[], Awaitable[None]]


class AsyncEvalManager:
    def __init__(self) -> None:
        self._tasks: set[asyncio.Task[None]] = set()
        self._accepting = True

    def schedule(self, *, eval_id: str, executor: EvalExecutor) -> None:
        if not self._accepting:
            raise RuntimeError("Async eval manager is shutting down")
        task = asyncio.create_task(self._run(executor), name=f"cogit-eval-{eval_id}")
        self._tasks.add(task)
        task.add_done_callback(self._forget)

    @staticmethod
    async def _run(executor: EvalExecutor) -> None:
        await executor()

    async def shutdown(self) -> None:
        self._accepting = False
        if self._tasks:
            await asyncio.gather(*tuple(self._tasks), return_exceptions=True)

    def _forget(self, task: asyncio.Task[None]) -> None:
        self._tasks.discard(task)
        if not task.cancelled():
            task.exception()
