"""Resolve SDK manifest pipelines into executable runtime steps."""

from __future__ import annotations

from typing import Any

from cogit_agent_sdk.types import AgentDescriptor, Context, RunRequest
from cogit_agent_sdk.types.pipelines import PipelineDescriptor

from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.pipeline import OnFailure, PipelineStep, StepType


def resolve_pipeline(
    descriptor: AgentDescriptor,
    request: RunRequest,
    context: Context,
) -> PipelineDescriptor | None:
    """Select an explicit or trigger-bound pipeline for a run request."""

    pipelines = list(descriptor.pipelines or [])
    if request.pipeline:
        for pipeline in pipelines:
            if pipeline.name == request.pipeline:
                return pipeline
        raise RuntimeConfigurationError(
            f"Unknown pipeline '{request.pipeline}' for agent "
            f"'{descriptor.id or descriptor.name}'"
        )

    selectors = _automatic_selectors(request, context)
    if not selectors:
        return None
    matches = [
        pipeline
        for pipeline in pipelines
        if pipeline.applies_to and selectors.intersection(pipeline.applies_to)
    ]
    if len(matches) > 1:
        names = ", ".join(sorted(pipeline.name for pipeline in matches))
        raise RuntimeConfigurationError(
            f"Ambiguous pipeline binding for {sorted(selectors)}: {names}"
        )
    return matches[0] if matches else None


def to_runtime_steps(
    descriptor: AgentDescriptor,
    pipeline: PipelineDescriptor,
    *,
    initial_payload: dict[str, Any] | None = None,
) -> list[PipelineStep]:
    """Validate and convert SDK pipeline steps into runner steps."""

    action_names = {action.name for action in descriptor.actions or []}
    converted: list[PipelineStep] = []
    for index, step in enumerate(pipeline.steps):
        if step.kind == "deterministic" and not step.invoke:
            raise RuntimeConfigurationError(
                f"Pipeline '{pipeline.name}' step '{step.id}' requires invoke"
            )
        if step.invoke and step.invoke not in action_names:
            raise RuntimeConfigurationError(
                f"Pipeline '{pipeline.name}' step '{step.id}' invokes unknown "
                f"action '{step.invoke}'"
            )
        converted.append(
            PipelineStep(
                name=step.id,
                step_type=StepType(step.kind),
                action_name=step.invoke,
                instruction=step.instruction,
                payload=(
                    dict(initial_payload)
                    if index == 0
                    and step.kind == "deterministic"
                    and initial_payload is not None
                    else None
                ),
                on_failure=_map_failure(step.on_failure),
                timeout_seconds=step.timeout_seconds,
            )
        )
    return converted


def _automatic_selectors(request: RunRequest, context: Context) -> set[str]:
    selectors: set[str] = set()
    metadata = request.metadata or {}
    if metadata.get("pipeline_step") is True:
        return selectors
    item_type = metadata.get("item_type")
    if isinstance(item_type, str) and item_type:
        selectors.add(item_type)
    if context.trigger:
        selectors.add(context.trigger)
    return selectors


def _map_failure(value: str) -> OnFailure:
    if value == "continue":
        return OnFailure.SKIP
    if value == "escalate":
        return OnFailure.ESCALATE
    # fail_run (default) and any unknown value map to STOP
    return OnFailure.STOP


__all__ = ["resolve_pipeline", "to_runtime_steps"]
