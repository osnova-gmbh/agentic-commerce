"""Startup recovery module for the Cogit runtime.

When the runtime restarts after an unexpected shutdown, this module inspects
the durable store for incomplete work and recovers it:

- Expired queue-item leases are re-queued or dead-lettered.
- Orphaned incomplete pipeline checkpoints enqueue resume items.
- Interrupted execution runs are marked as failed.
- Outbox and attention item counts are captured for health reporting.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session as SaSession

from cogit_runtime.persistence import (
    Base,
    RuntimeAttention,
    RuntimeOutbox,
    RuntimeQueueItem,
    RuntimeRun,
)

logger = logging.getLogger(__name__)

_CHECKPOINT_PREFIX = "pipeline:checkpoint:"
_PIPELINE_RESUME_TYPE = "pipeline_resume"


@dataclass(frozen=True)
class RecoveryReport:
    """Summary of recovery actions taken at startup."""

    schema_version_ok: bool = True
    expired_leases_recovered: int = 0
    expired_leases_dead_lettered: int = 0
    interrupted_runs_handled: int = 0
    pipelines_resumed: int = 0
    outbox_pending: int = 0
    attention_items_unresolved: int = 0


class RuntimeRecovery:
    """Recovers runtime state after an unexpected shutdown.

    Works directly with a SQLAlchemy ``Engine`` by opening sessions
    against the persistence tables. The recovery is designed to be
    idempotent: running it multiple times produces the same result.

    Parameters
    ----------
    engine:
        A SQLAlchemy ``Engine`` connected to the runtime database.
    """

    def __init__(self, engine: Any) -> None:
        self._engine = engine

    def recover(self) -> RecoveryReport:
        """Run all recovery steps and return a summary report."""

        schema_ok = self._verify_schema()
        if not schema_ok:
            logger.warning(
                "recovery.schema_revision_mismatch",
                extra={
                    "detail": "Alembic revision does not match package head",
                },
            )
            return RecoveryReport(schema_version_ok=False)

        expired_recovered, expired_dead_lettered = self._recover_expired_leases()
        pipelines_resumed = self._resume_orphaned_pipelines()
        interrupted = self._handle_interrupted_runs()
        outbox_pending = self._count_outbox_pending()
        attention_unresolved = self._count_attention_unresolved()

        report = RecoveryReport(
            schema_version_ok=True,
            expired_leases_recovered=expired_recovered,
            expired_leases_dead_lettered=expired_dead_lettered,
            interrupted_runs_handled=interrupted,
            pipelines_resumed=pipelines_resumed,
            outbox_pending=outbox_pending,
            attention_items_unresolved=attention_unresolved,
        )

        logger.info(
            "recovery.completed",
            extra={
                "schema_version_ok": report.schema_version_ok,
                "expired_leases_recovered": report.expired_leases_recovered,
                "expired_leases_dead_lettered": report.expired_leases_dead_lettered,
                "interrupted_runs_handled": report.interrupted_runs_handled,
                "pipelines_resumed": report.pipelines_resumed,
                "outbox_pending": report.outbox_pending,
                "attention_items_unresolved": report.attention_items_unresolved,
            },
        )

        return report

    def _verify_schema(self) -> bool:
        """Check Alembic revision matches package head and required tables exist."""
        from sqlalchemy import inspect

        from cogit_runtime.migrations import verify_schema_revision

        if not verify_schema_revision(self._engine):
            return False
        inspector = inspect(self._engine)
        existing = set(inspector.get_table_names())
        required = {t.name for t in Base.metadata.sorted_tables}
        return required.issubset(existing)

    def _recover_expired_leases(self) -> tuple[int, int]:
        """Re-queue or dead-letter queue items whose leases expired."""
        recovered = 0
        dead_lettered = 0
        now = datetime.now(UTC)

        with SaSession(self._engine) as session:
            stmt = select(RuntimeQueueItem).where(
                RuntimeQueueItem.status == "processing",
                RuntimeQueueItem.lease_expires_at.is_not(None),
                RuntimeQueueItem.lease_expires_at <= now,
            )
            expired_rows = session.execute(stmt).scalars().all()

            for row in expired_rows:
                if row.retry_count >= row.max_retries:
                    row.status = "dead"
                    row.error = "Queue lease expired after maximum retries"
                    row.lease_expires_at = None
                    row.heartbeat_at = None
                    dead_lettered += 1
                    logger.info(
                        "recovery.lease_dead_lettered",
                        extra={"queue_item_id": row.id, "retries": row.retry_count},
                    )
                else:
                    row.status = "pending"
                    row.retry_count += 1
                    row.error = "Queue lease expired; item re-queued"
                    row.lease_expires_at = None
                    row.heartbeat_at = None
                    recovered += 1
                    logger.info(
                        "recovery.lease_requeued",
                        extra={"queue_item_id": row.id, "retries": row.retry_count},
                    )

            session.commit()

        return recovered, dead_lettered

    def _resume_orphaned_pipelines(self) -> int:
        """Enqueue resume items for incomplete pipeline checkpoints."""
        resumed = 0
        with SaSession(self._engine) as session:
            stmt = select(RuntimeRun).where(
                RuntimeRun.id.like(f"{_CHECKPOINT_PREFIX}%"),
                RuntimeRun.status == "running",
            )
            rows = session.execute(stmt).scalars().all()
            for row in rows:
                pipeline_id = row.id[len(_CHECKPOINT_PREFIX) :]
                if not pipeline_id:
                    continue
                if self._has_active_pipeline_resume(session, pipeline_id):
                    continue
                pipeline_name = pipeline_id.rsplit(":", 1)[-1]
                case_id = row.case_id
                if case_id is None and ":" in pipeline_id:
                    maybe_case = pipeline_id.rsplit(":", 1)[0]
                    if not maybe_case.startswith("pipeline"):
                        case_id = maybe_case
                item_id = f"pipeline-resume-{uuid.uuid4().hex[:12]}"
                session.add(
                    RuntimeQueueItem(
                        id=item_id,
                        tenant_id=row.tenant_id or "pipeline",
                        organization_id=row.organization_id,
                        queue_name="default",
                        item_type=_PIPELINE_RESUME_TYPE,
                        payload={
                            "instruction": f"Resume pipeline {pipeline_name}",
                            "pipeline": pipeline_name,
                            "pipeline_id": pipeline_id,
                            "input": (row.run_metadata or {}).get("input") or {},
                            "context": {
                                "tenant_id": row.tenant_id or "pipeline",
                                "organization_id": row.organization_id,
                                "agent_id": row.agent_id,
                                "case_id": case_id,
                                "correlation_id": item_id,
                                "trigger": "queue",
                            },
                        },
                        status="pending",
                        case_id=case_id,
                        source_id=pipeline_id,
                        idempotency_key=f"pipeline-resume:{pipeline_id}",
                        retry_count=0,
                        max_retries=3,
                    )
                )
                resumed += 1
                logger.info(
                    "recovery.pipeline_resume_enqueued",
                    extra={"pipeline_id": pipeline_id, "queue_item_id": item_id},
                )
            session.commit()
        return resumed

    def _has_active_pipeline_resume(
        self,
        session: SaSession,
        pipeline_id: str,
    ) -> bool:
        rows = (
            session.execute(
                select(RuntimeQueueItem).where(
                    RuntimeQueueItem.item_type == _PIPELINE_RESUME_TYPE,
                    RuntimeQueueItem.status.in_(("pending", "processing", "parked")),
                )
            )
            .scalars()
            .all()
        )
        for row in rows:
            payload = row.payload or {}
            if payload.get("pipeline_id") == pipeline_id:
                return True
            if row.source_id == pipeline_id:
                return True
        return False

    def _handle_interrupted_runs(self) -> int:
        """Mark non-checkpoint runs that were non-terminal at restart as failed."""
        count = 0
        now = datetime.now(UTC)
        non_terminal = {"running", "pending"}

        with SaSession(self._engine) as session:
            stmt = select(RuntimeRun).where(RuntimeRun.status.in_(non_terminal))
            rows = session.execute(stmt).scalars().all()

            for row in rows:
                if row.id.startswith(_CHECKPOINT_PREFIX):
                    continue
                row.status = "failed"
                row.completed_at = now
                row.outcome_label = "interrupted_by_shutdown"
                row.run_metadata = {
                    **(row.run_metadata or {}),
                    "interrupted_at": now.isoformat(),
                    "recovery_action": "marked_failed",
                }
                count += 1
                logger.info(
                    "recovery.interrupted_run",
                    extra={"run_id": row.id},
                )

            session.commit()

        return count

    def _count_outbox_pending(self) -> int:
        """Count outbox entries that have not yet been delivered."""
        with SaSession(self._engine) as session:
            stmt = select(RuntimeOutbox).where(
                RuntimeOutbox.delivered == False,  # noqa: E712
                (RuntimeOutbox.dead_lettered == False)  # noqa: E712
                | (RuntimeOutbox.dead_lettered.is_(None)),
            )
            rows = session.execute(stmt).scalars().all()
            return len(rows)

    def _count_attention_unresolved(self) -> int:
        """Count attention items that have no decision yet."""
        with SaSession(self._engine) as session:
            stmt = select(RuntimeAttention).where(
                RuntimeAttention.decision_action.is_(None)
            )
            rows = session.execute(stmt).scalars().all()
            return len(rows)


__all__ = ["RecoveryReport", "RuntimeRecovery"]
