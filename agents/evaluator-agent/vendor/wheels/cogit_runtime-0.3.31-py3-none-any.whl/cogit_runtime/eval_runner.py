"""Independent eval runner -- black-box HTTP evaluation of a running agent.

Orchestrates suite loading, concurrency, scoring, and store persistence.
HTTP item execution is delegated to ``cogit_agent_sdk.eval.BlackBoxEvalClient``.

Usage::

    runner = EvalRunner(
        endpoint="http://localhost:8000",
        suite=EvalSuiteConfig(name="smoke", items=[...]),
    )
    record = await runner.run()

Or load from a manifest + suite file::

    runner = EvalRunner.from_manifest(
        manifest_path="cogit.yaml",
        endpoint="http://localhost:8000",
        suite_name="smoke",
    )
    record = await runner.run()
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol

import httpx
from cogit_agent_sdk.eval import (
    BlackBoxEvalClient,
    EvalCheckConfig,
    EvalItemConfig,
    EvalSuiteConfig,
    run_check,
)
from cogit_agent_sdk.types.eval import EvalItemResult, EvalRecord

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Store protocol -- minimal interface for eval persistence
# ---------------------------------------------------------------------------


class _EvalStore(Protocol):
    """Minimal protocol for eval persistence."""

    def put_eval(self, record: EvalRecord) -> EvalRecord: ...


# ---------------------------------------------------------------------------
# EvalRunner
# ---------------------------------------------------------------------------


@dataclass
class _RunState:
    """Mutable state accumulated during a run."""

    results: list[EvalItemResult] = field(default_factory=list)
    items_passed: int = 0


class EvalRunner:
    """Run evaluation suites against a live agent endpoint via HTTP.

    This runner communicates exclusively through HTTP using httpx. It never
    imports or directly calls agent code, ensuring true black-box evaluation.

    Parameters
    ----------
    endpoint:
        Base URL of the running agent (e.g. ``http://localhost:8000``).
    suite:
        Suite configuration with items and check definitions.
    store:
        Optional RuntimeStore for persisting EvalRecord.
    client:
        Optional pre-configured httpx.AsyncClient (useful for testing with
        MockTransport).
    """

    def __init__(
        self,
        endpoint: str,
        suite: EvalSuiteConfig,
        *,
        store: _EvalStore | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        timeouts = [
            suite.timeout,
            *(item.timeout for item in suite.items if item.timeout is not None),
        ]
        if any(not math.isfinite(value) or value <= 0 for value in timeouts):
            raise ValueError("Eval timeouts must be positive and finite")
        self._endpoint = endpoint.rstrip("/")
        self._suite = suite
        self._store = store
        self._external_client = client

    @classmethod
    def from_manifest(
        cls,
        manifest_path: str,
        endpoint: str,
        suite_name: str,
        **kwargs: Any,
    ) -> EvalRunner:
        """Create an EvalRunner by loading a suite file relative to the manifest.

        Looks for ``evals/{suite_name}.json`` next to the manifest file.
        Agent identity defaults come from the manifest when omitted from the suite.
        """
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", suite_name):
            raise ValueError("Invalid eval suite name")
        evals_dir = Path(manifest_path).resolve().parent / "evals"
        suite_path = (evals_dir / f"{suite_name}.json").resolve()
        if not suite_path.is_relative_to(evals_dir.resolve()):
            raise ValueError("Eval suite must remain inside its configured directory")
        suite = _load_suite(suite_path, suite_name)
        suite.endpoint = endpoint
        agent_id, agent_version = _manifest_agent_defaults(manifest_path)
        if suite.agent_id == "unknown":
            suite.agent_id = agent_id
        if suite.agent_version is None:
            suite.agent_version = agent_version
        return cls(endpoint=endpoint, suite=suite, **kwargs)

    def create_record(
        self,
        *,
        eval_id: str | None = None,
        started_at: datetime | None = None,
        limit: int | None = None,
    ) -> EvalRecord:
        """Persist initial state before returning an accepted async execution."""
        if limit is not None:
            if limit < 1:
                raise ValueError("Eval limit must be positive")
            self._suite = self._suite.model_copy(
                update={"items": self._suite.items[:limit]}
            )
        record = EvalRecord(
            id=eval_id or str(uuid.uuid4()),
            agent_id=self._suite.agent_id,
            agent_version=self._suite.agent_version,
            suite_name=self._suite.name,
            started_at=started_at or datetime.now(UTC),
            status="running",
            items_total=len(self._suite.items),
        )
        if self._store is not None:
            self._store.put_eval(record)
        return record

    async def run(
        self,
        *,
        eval_id: str | None = None,
        started_at: datetime | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> EvalRecord:
        """Run suite items concurrently and persist the final scored result."""
        record = self.create_record(eval_id=eval_id, started_at=started_at)
        eval_id = record.id
        started_at = record.started_at

        state = _RunState()
        semaphore = asyncio.Semaphore(self._suite.concurrency)

        provided_client = client or self._external_client
        should_close_client = provided_client is None
        client = provided_client or httpx.AsyncClient(
            base_url=self._endpoint,
            timeout=httpx.Timeout(self._suite.timeout),
        )
        eval_client = BlackBoxEvalClient(
            self._endpoint,
            client=client,
            default_timeout=self._suite.timeout,
        )

        try:
            tasks = [
                self._run_item(eval_client, item, semaphore, state)
                for item in self._suite.items
            ]
            await asyncio.gather(*tasks)
        finally:
            if should_close_client:
                await client.aclose()

        # Compute final score
        total = len(self._suite.items)
        score = state.items_passed / total if total > 0 else 1.0

        # Determine status based on gate threshold
        if self._suite.threshold is not None and score < self._suite.threshold:
            final_status: str = "failed"
        else:
            final_status = "completed"

        completed_record = EvalRecord(
            id=eval_id,
            agent_id=self._suite.agent_id,
            agent_version=self._suite.agent_version,
            suite_name=self._suite.name,
            started_at=started_at,
            completed_at=datetime.now(UTC),
            status=final_status,
            items_total=total,
            items_passed=state.items_passed,
            score=score,
            results=state.results,
            metadata=self._suite.metadata,
        )

        # Persist final record
        if self._store is not None:
            self._store.put_eval(completed_record)

        logger.info(
            "eval_runner.completed",
            extra={
                "eval_id": eval_id,
                "suite": self._suite.name,
                "status": final_status,
                "score": score,
                "passed": state.items_passed,
                "total": total,
            },
        )

        return completed_record

    async def _run_item(
        self,
        eval_client: BlackBoxEvalClient,
        item: EvalItemConfig,
        semaphore: asyncio.Semaphore,
        state: _RunState,
    ) -> None:
        """Run a single eval item with concurrency limiting."""
        async with semaphore:
            timeout = item.timeout if item.timeout is not None else self._suite.timeout
            try:
                async with asyncio.timeout(timeout):
                    result = await eval_client.execute_item(item)
            except TimeoutError:
                result = EvalItemResult(
                    item_id=item.id,
                    passed=False,
                    score=0.0,
                    error="Evaluation request exceeded its deadline",
                )
            state.results.append(result)
            if result.passed:
                state.items_passed += 1


# ---------------------------------------------------------------------------
# Suite loading
# ---------------------------------------------------------------------------


def _manifest_agent_defaults(manifest_path: str) -> tuple[str, str | None]:
    """Read agent id/version defaults from a manifest without full validation."""
    import yaml

    try:
        raw_loaded = yaml.safe_load(Path(manifest_path).read_text(encoding="utf-8"))
    except OSError:
        return "unknown", None

    if not isinstance(raw_loaded, dict):
        return "unknown", None

    agent_id = raw_loaded.get("id") or raw_loaded.get("name") or "unknown"
    version = raw_loaded.get("version")
    return str(agent_id), str(version) if version is not None else None


def _load_suite(path: Path, suite_name: str) -> EvalSuiteConfig:
    """Load and parse an eval suite JSON file."""
    if not path.exists():
        msg = f"Eval suite file not found: {path}"
        raise FileNotFoundError(msg)

    raw_text = path.read_text(encoding="utf-8")
    try:
        raw = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        msg = f"Eval suite file is not valid JSON: {path}"
        raise ValueError(msg) from exc

    if not isinstance(raw, dict):
        msg = f"Eval suite must be a JSON object: {path}"
        raise ValueError(msg)

    # Allow the suite file to omit the name -- use the file-derived name
    raw.setdefault("name", suite_name)

    return EvalSuiteConfig.model_validate(raw)


__all__ = [
    "BlackBoxEvalClient",
    "EvalCheckConfig",
    "EvalItemConfig",
    "EvalRunner",
    "EvalSuiteConfig",
    "run_check",
]
