"""Central approval uses the operation's existing durable invocation identity."""

from __future__ import annotations

from cogit_agent_sdk.operations.contract import OperationInvocation
from cogit_agent_sdk.types.policy import PolicyCheckpoint
from cogit_agent_sdk.types.requirements import OperationRequirements
from pydantic import BaseModel

from cogit_runtime.agentdb.handle import AgentDbRunHandle
from cogit_runtime.operations.preflight import BeforeInvoke, PreflightContext
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.policy import PolicyDeniedError, RuntimePolicyGate


class UnsupportedApprovalForUnkeyedError(PolicyDeniedError):
    """No effect started: approval cannot manufacture a safe replay contract."""

    code = "unsupported_approval_for_unkeyed"


def central_approval_preflight(
    gate: RuntimePolicyGate,
    checkpoint: PolicyCheckpoint,
    invocation: OperationInvocation,
    requirements: OperationRequirements,
    original: BeforeInvoke | None,
) -> BeforeInvoke:
    if requirements.idempotency == "none":
        raise UnsupportedApprovalForUnkeyedError(
            "Unkeyed approval is unsupported; no effect started"
        )
    handle = invocation.handle
    slot = (invocation.context.metadata or {}).get("runtime_pipeline_slot")
    if not isinstance(handle, AgentDbRunHandle) or not isinstance(slot, str):
        raise PolicyDeniedError(
            "Central approval requires an admitted durable operation slot"
        )

    def before(
        validated: BaseModel, preflight: PreflightContext
    ) -> OperationExecutionResult | None:
        handle.require_human_decision(
            slot_key=slot,
            exposure=checkpoint.operation.name,
            payload=validated.model_dump(mode="json", by_alias=True),
            idempotency=requirements.idempotency,
            invocation_key=preflight.idempotency_key,
        )
        # Approval is bound to exact invocation and immutable package/version pins.
        # The fresh central policy still has precedence over the approval.
        gate.require(handle, checkpoint)
        return original(validated, preflight) if original is not None else None

    return before
