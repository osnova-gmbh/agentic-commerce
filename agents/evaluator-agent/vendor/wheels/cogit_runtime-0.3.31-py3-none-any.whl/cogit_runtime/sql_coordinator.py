"""SQL-backed coordinator that delegates queue operations to a RuntimeStore.

When a ``DATABASE_URL`` is configured the runtime uses this coordinator
instead of ``DisabledCoordinator``.  All state mutations go through the
store's queue helpers so the single source of truth lives in the store
(in-memory or SQL-backed) rather than in a platform API.
"""

from __future__ import annotations

from cogit_agent_sdk.types import QueueItem

from cogit_runtime.store import RuntimeStore


class SqlCoordinator:
    """Coordinator backed by the local runtime store's queue operations.

    Implements the :class:`cogit_runtime.coordinator.Coordinator` protocol
    by delegating ``claim`` / ``heartbeat`` / ``complete`` / ``fail`` to
    the store.
    """

    def __init__(self, store: RuntimeStore) -> None:
        self._store = store

    async def claim(
        self,
        queues: list[str],
        item_types: list[str],
        lease_seconds: int,
    ) -> QueueItem | None:
        """Claim one pending queue item matching *queues* and *item_types*."""
        return self._store.claim_queue_item(queues, item_types, lease_seconds)

    async def heartbeat(self, item_id: str) -> None:
        """Extend the active lease on *item_id*."""
        result = self._store.heartbeat_queue_item(item_id)
        if result is None:
            raise ValueError(f"Queue item not found: {item_id}")

    async def complete(self, item_id: str, outcome: dict[str, object]) -> None:
        """Complete leased work identified by *item_id*."""
        result = self._store.complete_queue_item(item_id, outcome)
        if result is None:
            raise ValueError(f"Queue item not found: {item_id}")

    async def park(self, item_id: str) -> None:
        """Release an active lease while approval is pending."""
        result = self._store.park_queue_item(item_id)
        if result is None:
            raise ValueError(f"Queue item not found: {item_id}")

    async def fail(
        self,
        item_id: str,
        error: str,
        retryable: bool,
    ) -> None:
        """Mark leased work as failed."""
        result = self._store.fail_queue_item(item_id, error, retryable)
        if result is None:
            raise ValueError(f"Queue item not found: {item_id}")
