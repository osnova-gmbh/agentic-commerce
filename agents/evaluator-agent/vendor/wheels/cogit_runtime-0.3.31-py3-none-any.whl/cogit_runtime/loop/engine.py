"""Runtime-owned loop engine that routes tools through ToolBroker."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Literal

from cogit_agent_sdk.contracts import RunHandle
from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.loop.engine import AgentLoopEngine
from cogit_agent_sdk.types import Context, TextContent, ToolCall, ToolResult
from cogit_agent_sdk.types.cancellation import Cancellation

from cogit_runtime.cancellation import RuntimeWorkDeferred, await_runtime_completion

if TYPE_CHECKING:
    from cogit_runtime.tools.broker import ToolBroker


class RuntimeAgentLoopEngine(AgentLoopEngine):
    """SDK loop engine with runtime ToolBroker execution."""

    def __init__(
        self,
        *args: Any,
        tool_broker: ToolBroker,
        execution_id: str,
        handle_factory: Callable[[str, Context], RunHandle],
        canonical_tools: Any = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._tool_broker = tool_broker
        self._runtime_execution_id = execution_id
        self._handle_factory = handle_factory
        self._canonical_tools = canonical_tools

    def _execution_mode_for(
        self, tool_call: ToolCall
    ) -> Literal["parallel", "sequential"]:
        if self._canonical_tools is not None:
            if getattr(self._canonical_tools, "policy", None) is not None:
                # Central policy can require approval even when intrinsic tool
                # metadata does not. D11 owns one decision per work item.
                return "sequential"
            binding = self._tool_broker.registry.get(tool_call.tool_name)
            if binding is not None and binding.descriptor.requires_approval:
                # D11 admits one decision per work item. Reuse the SDK's
                # sequential lane so the first pending decision stops the batch
                # before another protected request or parallel effect starts.
                return "sequential"
        return super()._execution_mode_for(tool_call)

    def _execute_one_tool(
        self,
        tool_call: ToolCall,
        context: Context,
        emit: Any,
        strings: Any,
        allowed_tool_names: set[str],
        cancellation: Cancellation,
    ) -> ToolResult:
        cancellation.throw_if_cancelled()

        emit(
            "tool_call_started",
            {"toolCallId": tool_call.id, "toolName": tool_call.tool_name},
        )

        prepared = None
        invalid_input = None
        if self._canonical_tools is not None:
            candidate = self._canonical_tools.prepare(
                tool_call, context, allowed_tool_names
            )
            if isinstance(candidate, ToolResult):
                invalid_input = candidate
            else:
                prepared = candidate
            if prepared is not None:
                cached = self._canonical_tools.cached(tool_call, prepared)
                if cached is not None:
                    emit(
                        "tool_call_completed",
                        {
                            "toolCallId": tool_call.id,
                            "toolName": tool_call.tool_name,
                            "isError": cached.is_error,
                        },
                    )
                    return cached
                context = self._canonical_tools.recovery.tool_context(
                    prepared[0], context
                )

        async def _run() -> ToolResult:
            handle = self._handle_factory(self._runtime_execution_id, context)
            try:
                return await self._tool_broker.execute(
                    tool_call.tool_name,
                    dict(tool_call.arguments),
                    context,
                    tool_call_id=tool_call.id,
                    execution_id=self._runtime_execution_id,
                    allowed_tool_names=allowed_tool_names,
                    cancellation=cancellation,
                    on_progress=lambda event: emit("tool_call_updated", event.payload),
                    handle=handle,
                    idempotency_key=prepared[1].invocation_key if prepared else None,
                    _prepared_arguments=prepared[2] if prepared else None,
                )
            except RuntimeWorkDeferred as pending:
                # Tool tasks belong to this temporary event loop. Drain before
                # asyncio.run can cancel them or the model can request an effect.
                return await await_runtime_completion(pending.completion)

        import asyncio

        try:
            cancellation.throw_if_cancelled()
            result = invalid_input if invalid_input is not None else asyncio.run(_run())
            cancellation.throw_if_cancelled()
        except CoordinationFailure:
            raise
        except Exception as exc:
            if cancellation.cancelled:
                raise

            error_text = f"Tool execution failed ({type(exc).__name__})"
            if strings.tool_error_recovery:
                error_text = f"{error_text}\n\n{strings.tool_error_recovery}"

            result = ToolResult(
                tool_call_id=tool_call.id,
                tool_name=tool_call.tool_name,
                content=[TextContent(text=error_text)],
                is_error=True,
                details={"code": "TOOL_ERROR"},
            )

        normalized = self._runtime.hooks.after_tool_call(tool_call, result, context)

        if normalized.tool_call_id != tool_call.id:
            normalized = normalized.model_copy(update={"tool_call_id": tool_call.id})

        if prepared is not None:
            assert self._canonical_tools is not None
            self._canonical_tools.complete(prepared, normalized)

        emit(
            "tool_call_completed",
            {
                "toolCallId": tool_call.id,
                "toolName": tool_call.tool_name,
                "isError": normalized.is_error,
            },
        )

        return normalized
