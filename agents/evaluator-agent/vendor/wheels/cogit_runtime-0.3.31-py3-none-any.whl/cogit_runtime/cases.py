"""Durable case linkage for queued work and retries."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, get_args
from uuid import uuid4

from cogit_agent_sdk.types import Case, QueueItem

from cogit_runtime.store import RuntimeStore


def _allowed_source_types() -> frozenset[str]:
    """SDK-owned source_type literals — do not hardcode domain values here."""

    return frozenset(
        str(value) for value in get_args(Case.model_fields["source_type"].annotation)
    )


class CaseService:
    """Create, link, and advance durable cases around queue attempts."""

    def __init__(self, store: RuntimeStore, *, default_agent_id: str) -> None:
        self._store = store
        self._default_agent_id = default_agent_id

    def ensure_queue_item(self, item: QueueItem) -> QueueItem:
        """Ensure a queue item has a durable case and persist the linkage."""

        if item.case_id:
            existing_by_id = self._store.get_case(item.case_id)
            if existing_by_id is not None:
                self._store.put_queue_item(item)
                return item

        source_type = _source_type(item)
        source_id = _source_id(item)
        case = self._store.resolve_case(
            tenant_id=item.tenant_id,
            source_type=source_type,
            source_id=source_id,
        )
        now = datetime.now(UTC)
        if case is None:
            agent_id = item.addressed_to or self._default_agent_id
            case = Case(
                id=item.case_id or str(uuid4()),
                tenant_id=item.tenant_id,
                organization_id=item.organization_id,
                agent_id=agent_id,
                source_type=source_type,  # type: ignore[arg-type]
                source_id=source_id,
                status="pending",
                assigned_agent_ids=[agent_id] if agent_id else None,
                created_at=now,
                updated_at=now,
                metadata={
                    "queue_name": item.queue_name,
                    "item_type": item.item_type,
                    "queue_payload": item.payload,
                },
            )
            self._store.put_case(case)

        linked = item.model_copy(
            update={
                "case_id": case.id,
                "source_id": item.source_id or source_id,
            }
        )
        self._store.put_queue_item(linked)
        return linked

    def begin_attempt(self, case_id: str | None) -> Case | None:
        if case_id is None:
            return None
        case = self._store.get_case(case_id)
        if case is None:
            return None
        now = datetime.now(UTC)
        updated = case.model_copy(
            update={
                "status": "processing",
                "last_attempt_at": now,
                "updated_at": now,
                "next_retry_at": None,
                "error": None,
            }
        )
        return self._store.put_case(updated)

    def mark_waiting_for_approval(self, case_id: str | None) -> Case | None:
        """Park a case while human approval is outstanding."""
        if case_id is None:
            return None
        case = self._store.get_case(case_id)
        if case is None:
            return None
        updated = case.model_copy(
            update={
                "status": "waiting_for_approval",
                "updated_at": datetime.now(UTC),
            }
        )
        return self._store.put_case(updated)

    def finish_attempt(
        self,
        case_id: str | None,
        *,
        execution_status: str,
        error: str | None = None,
        final_outcome: str | None = None,
    ) -> Case | None:
        if case_id is None:
            return None
        case = self._store.get_case(case_id)
        if case is None:
            return None
        now = datetime.now(UTC)
        if execution_status == "completed":
            status = "succeeded"
            updates: dict[str, Any] = {
                "status": status,
                "error": error,
                "updated_at": now,
                "completed_at": now,
            }
            if final_outcome is not None:
                updates["final_outcome"] = final_outcome
        elif execution_status == "failed":
            updates = {
                "status": "failed",
                "error": error,
                "updated_at": now,
                "completed_at": now,
            }
            if final_outcome is not None:
                updates["final_outcome"] = final_outcome
        elif execution_status in {"parked", "waiting", "partial"}:
            updates = {
                "status": "waiting_for_approval",
                "updated_at": now,
                "error": error,
            }
        else:
            return case
        updated = case.model_copy(update=updates)
        return self._store.put_case(updated)

    def enqueue_retry(
        self,
        case_id: str,
        *,
        request: dict[str, Any] | None = None,
    ) -> QueueItem:
        """Create a new queue attempt under an existing case."""

        case = self._store.get_case(case_id)
        if case is None:
            raise KeyError(case_id)
        request = request or {}
        metadata = dict(case.metadata or {})
        retry_number = case.retry_count + 1
        queue_name = _request_str(request, "queue_name") or str(
            metadata.get("queue_name") or "default"
        )
        item_type = _request_str(request, "item_type") or str(
            metadata.get("item_type") or case.source_type
        )
        request_payload = request.get("payload")
        if isinstance(request_payload, dict):
            queue_payload = dict(request_payload)
        else:
            stored_payload = metadata.get("queue_payload")
            queue_payload = (
                dict(stored_payload) if isinstance(stored_payload, dict) else {}
            )

        updated_case = case.model_copy(
            update={
                "status": "retrying",
                "retry_count": retry_number,
                "next_retry_at": None,
                "error": None,
                "updated_at": datetime.now(UTC),
            }
        )
        self._store.put_case(updated_case)
        item = QueueItem(
            id=str(uuid4()),
            tenant_id=case.tenant_id,
            organization_id=case.organization_id,
            queue_name=queue_name,
            item_type=item_type,
            payload=queue_payload,
            addressed_to=case.agent_id,
            status="pending",
            case_id=case.id,
            source_id=case.source_id,
            idempotency_key=f"case-retry:{case.id}:{retry_number}",
            retry_count=retry_number,
        )
        return self._store.put_queue_item(item)


def _source_type(item: QueueItem) -> str:
    """Resolve a case source type without embedding domain vocabulary.

    Allowed values live on the SDK ``Case`` model. Runtime only forwards
    values from that set; anything else becomes ``custom``.
    """

    allowed = _allowed_source_types()
    raw = item.payload.get("source_type")
    if isinstance(raw, str) and raw in allowed:
        return raw
    if item.item_type in allowed:
        return item.item_type
    return "custom"


def _source_id(item: QueueItem) -> str:
    if item.source_id:
        return item.source_id
    raw = item.payload.get("source_id")
    if isinstance(raw, str) and raw:
        return raw
    return item.dedupe_key or item.idempotency_key or item.id


def _request_str(request: dict[str, Any], key: str) -> str | None:
    value = request.get(key)
    return value if isinstance(value, str) and value else None


__all__ = ["CaseService"]
