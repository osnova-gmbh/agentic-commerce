"""Scheduler stub for manifest-declared cron/interval schedules.

The runtime does not run schedules today — it exposes an interface so a
platform scheduler or an in-process ticker can invoke ``trigger`` when a
schedule fires. The scheduler translates a ``ScheduleDescriptor`` into a
``RunRequest`` and pushes it through the same run executor as HTTP/queue
work, so scheduled runs share the same reporter, hooks, and platform mirror.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any

from cogit_agent_sdk.types import (
    Context,
    RunRequest,
    RunResult,
    ScheduleDescriptor,
)

from cogit_runtime.reporter import RunReporter

ScheduleExecutor = Callable[
    [RunRequest, Context, RunReporter, str],
    Awaitable[RunResult],
]


class ScheduleTrigger:
    """Callable object that converts a ``ScheduleDescriptor`` into a run.

    Real cron/interval evaluation belongs to whichever component decides to
    fire the schedule — the platform, a k8s CronJob, or an in-process ticker.
    The trigger here is the shared adapter for actually invoking the run.
    """

    def __init__(
        self,
        *,
        executor: ScheduleExecutor,
        reporter: RunReporter,
        default_agent_id: str,
        tenant_id: str | None = None,
    ) -> None:
        self._executor = executor
        self._reporter = reporter
        self._default_agent_id = default_agent_id
        self._tenant_id = tenant_id or "default"

    async def trigger(
        self,
        schedule: ScheduleDescriptor,
        *,
        instruction: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> RunResult:
        context = Context(
            tenant_id=self._tenant_id,
            correlation_id=f"schedule-{schedule.name}-{_iso_now()}",
            agent_id=self._default_agent_id,
            trigger="scheduled",
        )
        request = RunRequest(
            instruction=instruction or f"scheduled:{schedule.name}",
            input=payload,
            context=context,
            mode="sync",
            metadata={"schedule": schedule.name, "cron": schedule.cron},
        )
        execution = self._reporter.begin(
            context=context,
            trigger="scheduled",
            input_summary=request.instruction,
            metadata={"schedule": schedule.name},
        )
        return await self._executor(request, context, self._reporter, execution.id)


def _iso_now() -> str:
    return datetime.now(UTC).strftime("%Y%m%d%H%M%S")


__all__ = ["ScheduleTrigger"]
