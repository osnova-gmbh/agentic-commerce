"""Canonical operation preflight bypasses worker-local approval authority."""

from __future__ import annotations

from cogit_agent_sdk.types import Context
from pydantic import BaseModel

from cogit_runtime.agentdb.errors import AgentDbAuthorityError
from cogit_runtime.agentdb.handle import AgentDbRunHandle
from cogit_runtime.operations.approval_gate import ExposureDescriptor
from cogit_runtime.operations.preflight import BeforeInvoke, PreflightContext
from cogit_runtime.operations.result import OperationExecutionResult


def build_canonical_approval_preflight(
    *,
    descriptor: ExposureDescriptor,
    exposure_name: str,
    handle: AgentDbRunHandle,
    context: Context,
) -> BeforeInvoke:
    def before_invoke(
        validated: BaseModel, preflight: PreflightContext
    ) -> OperationExecutionResult | None:
        if not descriptor.requires_approval:
            return None
        slot = (context.metadata or {}).get("runtime_pipeline_slot")
        if not isinstance(slot, str):
            raise AgentDbAuthorityError(
                "Canonical approval needs a durable operation slot"
            )
        handle.require_human_decision(
            slot_key=slot,
            exposure=exposure_name,
            payload=validated.model_dump(mode="json", by_alias=True),
            idempotency=descriptor.requirements.idempotency,
            invocation_key=preflight.idempotency_key,
        )
        return None

    return before_invoke
