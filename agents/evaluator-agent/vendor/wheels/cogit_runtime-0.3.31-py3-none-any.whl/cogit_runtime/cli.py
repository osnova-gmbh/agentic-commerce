"""Command-line entry points for the runtime package."""

from __future__ import annotations

import argparse
import asyncio
import importlib
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, NoReturn, cast

import uvicorn
from cogit_agent_sdk.types import AgentDescriptor

from cogit_runtime.agentdb.coordinator import AgentDbCoordinator
from cogit_runtime.agentdb.worker import AgentDbWorker
from cogit_runtime.app import CogitRuntimeApp, RuntimeState
from cogit_runtime.config import RuntimeEnvironment, WorkerConfig
from cogit_runtime.coordinator import (
    Coordinator,
    DisabledCoordinator,
    PlatformQueuePassthrough,
)
from cogit_runtime.custom_command_lifecycle import run_custom_command
from cogit_runtime.entrypoint import resolve_agent_entrypoint
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.lifecycle import AgentLifecycleManager
from cogit_runtime.manifest import load_manifest

# Proposal 011: agent-declared custom CLI commands. These SDK symbols are added
# in parallel on the sibling ``cogit-agent-sdk`` branch; keep the import optional
# so the five canonical commands keep working even if custom-command support is
# not yet present on disk.
try:
    from cogit_agent_sdk.cli import (
        ReservedCommandNameError,
        validate_command_groups,
    )
except ImportError:  # pragma: no cover - depends on sibling SDK state
    ReservedCommandNameError = None  # type: ignore[assignment,misc]
    validate_command_groups = None  # type: ignore[assignment,misc]

CANONICAL_COMMANDS = ("serve", "work", "eval", "migrate", "register")


def main(argv: list[str] | None = None) -> int:
    """Run the ``cogit-runtime`` CLI."""

    effective_argv = argv if argv is not None else sys.argv[1:]

    parser = argparse.ArgumentParser(prog="cogit-runtime")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ---- serve ----
    serve = subparsers.add_parser("serve", help="Serve an AgentDB-backed runtime")
    serve.add_argument(
        "app",
        nargs="?",
        default=None,
        help=argparse.SUPPRESS,
    )
    serve.add_argument(
        "--manifest",
        default=None,
        help="Path to cogit.yaml manifest file",
    )
    serve.add_argument(
        "--agent",
        default=None,
        help="Import path for the resident agent class (module:ClassName)",
    )
    serve.add_argument("--host", default=None)
    serve.add_argument("--port", type=int, default=None)

    # ---- work ----
    work = subparsers.add_parser("work", help="Run the queue worker loop")
    work.add_argument(
        "--manifest",
        required=True,
        help="Path to cogit.yaml",
    )
    work.add_argument(
        "--agent",
        default=None,
        help="Resident class; defaults to cogit.yaml metadata.entrypoint",
    )
    work.add_argument(
        "--queues",
        default="default",
        help="Comma-separated queue names to poll",
    )
    work.add_argument(
        "--item-types",
        default="",
        help="Optional comma-separated item type filter",
    )
    work.add_argument(
        "--once",
        action="store_true",
        help="Poll once and exit instead of running the forever loop",
    )

    # ---- eval ----
    eval_parser = subparsers.add_parser(
        "eval",
        help="Run eval suite against a running agent",
    )
    eval_parser.add_argument("--suite", default="all", help="Suite name to run")
    eval_parser.add_argument(
        "--manifest",
        default=None,
        help="Path to cogit.yaml (used to locate evals/ directory)",
    )
    eval_parser.add_argument(
        "--endpoint",
        default=None,
        help="Agent endpoint URL (e.g. http://localhost:8000)",
    )

    # ---- migrate ----
    migrate_parser = subparsers.add_parser(
        "migrate",
        help="Check that the AgentDB runtime has no schema to migrate",
    )
    migrate_parser.add_argument(
        "--database-url",
        default=None,
        help=argparse.SUPPRESS,
    )
    migrate_parser.add_argument(
        "--manifest",
        default=None,
        help="Path to cogit.yaml (manifest)",
    )

    # ---- register ----
    register_parser = subparsers.add_parser(
        "register",
        help="Register this agent with the Cogit platform",
    )
    register_parser.add_argument(
        "--manifest",
        required=True,
        help="Path to cogit.yaml",
    )
    register_parser.add_argument(
        "--endpoint",
        default=None,
        help="Deployed agent URL to register with the platform",
    )
    register_parser.add_argument(
        "--api-url",
        default=None,
        help="Override COGIT_API_URL for registration",
    )
    register_parser.add_argument(
        "--dev",
        action="store_true",
        help="Allow registration over non-HTTPS in development",
    )

    # Proposal 011: when the first positional is not a canonical command and
    # --manifest/--agent both resolve, attach the agent's declared command
    # groups to the same subparsers so the re-parse below recognizes them.
    custom_commands: dict[str, dict[str, _CustomCommand]] | None = None
    try:
        custom_commands = _maybe_discover_custom_commands(effective_argv, subparsers)
    except Exception as exc:
        # ReservedCommandNameError surfaces as a clean non-zero exit; anything
        # else re-raises so genuine configuration errors are not swallowed.
        if ReservedCommandNameError is not None and isinstance(
            exc, ReservedCommandNameError
        ):
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        raise

    args = parser.parse_args(argv)

    # Dispatch an agent-declared custom command when the parse landed on one.
    if custom_commands:
        inner = custom_commands.get(args.command)
        if inner is not None:
            subcommand = getattr(args, "subcommand", None)
            matched = inner.get(subcommand) if subcommand else None
            if matched is not None:
                return _dispatch_custom_command(args, matched)

    if args.command == "serve":
        return _handle_serve(args)

    if args.command == "work":
        return _handle_work(args)

    if args.command == "eval":
        return _handle_eval(args)

    if args.command == "migrate":
        return _handle_migrate(args)

    if args.command == "register":
        return _handle_register(args)

    _unreachable()


# ---------------------------------------------------------------------------
# serve
# ---------------------------------------------------------------------------


def _handle_serve(args: argparse.Namespace) -> int:
    """Start an AgentDB-backed app through the verified manifest entrypoint."""
    if args.app is not None:
        raise RuntimeConfigurationError(
            "Runtime serve requires --manifest for AgentDB execution. "
            "Positional ASGI app imports are unavailable."
        )

    if args.manifest is not None:
        runtime_app = _build_runtime(manifest=args.manifest, agent_import=args.agent)
        host = args.host or runtime_app.state.config.server.host
        runtime_app.state.environment.validate_bind_host(host)
        fastapi_app = runtime_app.build()
        port = args.port or runtime_app.state.config.server.port
        uvicorn.run(
            fastapi_app,
            host=host,
            port=port,
            log_level=runtime_app.state.environment.log_level,
        )
        return 0

    print("Error: serve requires --manifest for AgentDB execution.", file=sys.stderr)
    return 1


# ---------------------------------------------------------------------------
# work
# ---------------------------------------------------------------------------


def _handle_work(args: argparse.Namespace) -> int:
    asyncio.run(
        _run_worker(
            manifest=args.manifest,
            agent_import=args.agent,
            queues=_split(args.queues),
            item_types=_split(args.item_types),
            once=args.once,
        )
    )
    return 0


# ---------------------------------------------------------------------------
# eval
# ---------------------------------------------------------------------------


def _handle_eval(args: argparse.Namespace) -> int:
    """Run an eval suite using the real EvalRunner."""
    from cogit_runtime.eval_runner import EvalRunner

    suite_name = args.suite
    endpoint = args.endpoint or "http://localhost:8000"
    manifest_path = args.manifest

    if manifest_path is not None:
        runner = EvalRunner.from_manifest(
            manifest_path=manifest_path,
            endpoint=endpoint,
            suite_name=suite_name,
        )
    else:
        from cogit_runtime.eval_runner import EvalSuiteConfig

        suite = EvalSuiteConfig(name=suite_name)
        runner = EvalRunner(endpoint=endpoint, suite=suite)

    record = asyncio.run(runner.run())

    print(
        f"Eval suite={record.suite_name} status={record.status} "
        f"score={record.score} "
        f"passed={record.items_passed}/{record.items_total}"
    )

    if record.status == "failed":
        return 1
    return 0


# ---------------------------------------------------------------------------
# migrate
# ---------------------------------------------------------------------------


def _handle_migrate(args: argparse.Namespace) -> int:
    if args.database_url is not None:
        print(
            "Runtime SQL migration is unavailable. AgentDB owns the schema.",
            file=sys.stderr,
        )
        return 1
    try:
        environment = RuntimeEnvironment.from_env()
        environment.require_agentdb_execution()
    except RuntimeConfigurationError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except Exception:
        print("Invalid runtime migration configuration.", file=sys.stderr)
        return 1
    print("AgentDB owns the schema. There is no Runtime schema to migrate.")
    return 0


# ---------------------------------------------------------------------------
# register
# ---------------------------------------------------------------------------


def _handle_register(args: argparse.Namespace) -> int:
    """Register this agent with the Cogit platform via the SDK."""
    import json
    from pathlib import Path

    from cogit_agent_sdk.client import AgentTokenAuth, ApiKeyAuth, CogitClient
    from cogit_agent_sdk.client.errors import Conflict

    from cogit_runtime.manifest import load_manifest

    environment = RuntimeEnvironment.from_env()
    api_url = args.api_url or environment.api_url

    if not api_url:
        print("Error: COGIT_API_URL is not configured. Set it or pass --api-url.")
        return 1

    if not environment.outbound_credential:
        print(
            "Error: No credentials configured. Set COGIT_AGENT_TOKEN or COGIT_API_KEY."
        )
        return 1

    if not args.dev and not api_url.startswith("https://"):
        print(
            "Error: Registration requires HTTPS. "
            "Use --dev to allow non-HTTPS endpoints in development."
        )
        return 1

    manifest = load_manifest(args.manifest)
    auth = (
        AgentTokenAuth(environment.agent_token)
        if environment.agent_token
        else ApiKeyAuth(environment.api_key)  # type: ignore[arg-type]
    )
    client = CogitClient(base_url=api_url.rstrip("/"), auth=auth)
    descriptor = manifest.descriptor
    agent_id = descriptor.id or descriptor.name
    endpoint = args.endpoint

    try:
        record = client.agents.register(descriptor, endpoint=endpoint)
    except Conflict:
        record = client.agents.update(agent_id, descriptor, endpoint=endpoint)

    registration_path = (
        Path(args.manifest).resolve().parent / ".cogit" / "registration.json"
    )
    registration_path.parent.mkdir(parents=True, exist_ok=True)
    dumped: Any = None
    if hasattr(record, "model_dump"):
        try:
            dumped = record.model_dump(mode="json")
        except TypeError:
            dumped = None
    if isinstance(dumped, dict):
        payload = dumped
    else:
        payload = {
            "id": getattr(record, "id", agent_id),
            "endpoint": endpoint,
            "name": descriptor.name,
            "version": descriptor.version,
        }
    if endpoint and not payload.get("endpoint"):
        payload["endpoint"] = endpoint
    registration_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    print(f"Registered agent {record.id} ({descriptor.name}@{descriptor.version})")
    return 0


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _build_runtime(
    *,
    manifest: str,
    agent_import: str | None,
    worker_only: bool = False,
) -> CogitRuntimeApp:
    """Build a CogitRuntimeApp from manifest path and agent import string.

    Shared by ``serve`` and ``work`` subcommands to avoid duplication.
    """
    agent_import = resolve_agent_entrypoint(manifest, agent_import)
    _preflight_agent_import(manifest, agent_import, require_agentdb=True)
    agent_class = _import_agent_class(agent_import)
    return CogitRuntimeApp.from_manifest(
        manifest,
        agent_class=agent_class,
        env={**os.environ, "COGIT_RUNTIME_ROLE": "work"} if worker_only else None,
    )


def _preflight_agent_import(
    manifest: str, agent_import: str, *, require_agentdb: bool = False
) -> None:
    """Require a verified isolated cohort before any production agent import."""
    environment = RuntimeEnvironment.from_env()
    if require_agentdb:
        environment.require_agentdb_execution()
    if environment.agentdb is not None and not environment.dev_mode:
        from cogit_runtime.agentdb.cohort import preflight_cohort
        from cogit_runtime.agentdb.errors import AgentDbConfigError

        if not sys.flags.isolated:
            raise AgentDbConfigError(
                "Canonical AgentDb workers require Python isolated mode (-I)"
            )
        receipt = environment.agentdb.cohort_receipt
        if receipt is None:
            raise AgentDbConfigError(
                "Canonical workers require COGIT_AGENTDB_COHORT_RECEIPT"
            )
        preflight_cohort(
            Path(receipt),
            manifest_path=Path(manifest),
            agent_entrypoint=agent_import,
            config=environment.agentdb,
        )


async def _run_worker(
    *,
    manifest: str,
    agent_import: str | None,
    queues: list[str],
    item_types: list[str],
    once: bool,
) -> None:
    RuntimeEnvironment.from_env().require_agentdb_execution()
    if queues != ["default"] or item_types:
        raise RuntimeConfigurationError(
            "AgentDB assigns work through the configured worker pool. "
            "Local queue filters are unavailable."
        )
    runtime_app = _build_runtime(
        manifest=manifest, agent_import=agent_import, worker_only=True
    )
    state = runtime_app.state

    coordinator: Coordinator | AgentDbCoordinator = state.coordinator
    if not isinstance(coordinator, AgentDbCoordinator):
        raise RuntimeConfigurationError(
            "Production 'work' did not resolve an AgentDb coordinator."
        )
    if state.store_kind != "agentdb":
        raise RuntimeConfigurationError(
            "Production 'work' must use the no-SQL AgentDb runtime profile."
        )
    worker_config = WorkerConfig(**state.config.worker.model_dump())
    worker: AgentDbWorker | None = None
    lifecycle_started = False
    try:
        worker = AgentDbWorker(
            coordinator=coordinator,
            config=worker_config,
            executor=state.loop_host.run,
            reporter=state.reporter,
            default_agent_id=state.descriptor.id or state.descriptor.name,
            cancel_execution=state.cancellations.cancel,
            validate_run_request=state.loop_host.validate_run_request,
        )
        if state.lifecycle is not None:
            await state.lifecycle.startup(state.agent)
            lifecycle_started = True
        if once:
            stats = await worker.poll_once()
            print(
                "Worker poll complete: "
                f"claimed={stats.claimed} "
                f"completed={stats.completed} "
                f"failed={stats.failed} "
                f"parked={stats.parked}"
            )
            return

        await worker.run_forever()
    finally:
        await _cleanup_agentdb_worker(
            state,
            worker,
            coordinator,
            lifecycle_started=lifecycle_started,
        )


async def _cleanup_agentdb_worker(
    state: RuntimeState,
    worker: AgentDbWorker | None,
    coordinator: AgentDbCoordinator,
    *,
    lifecycle_started: bool,
) -> None:
    if worker is not None:
        worker.request_stop()
    try:
        await state.loop_host.drain_deferred()
    finally:
        try:
            if lifecycle_started and state.lifecycle is not None:
                await state.lifecycle.shutdown(state.agent)
        finally:
            try:
                if state.platform.enabled:
                    await asyncio.to_thread(state.platform.flush)
            finally:
                try:
                    state.platform.close()
                finally:
                    if worker is not None:
                        await worker.close()
                    else:
                        await coordinator.close()


def _build_coordinator(environment: RuntimeEnvironment) -> Coordinator:
    if not environment.api_url or not environment.outbound_credential:
        return DisabledCoordinator()
    try:
        from cogit_agent_sdk.client import (
            AgentTokenAuth,
            ApiKeyAuth,
            CogitClient,
        )
    except ImportError:
        return DisabledCoordinator()

    auth: Any
    if environment.agent_token:
        auth = AgentTokenAuth(environment.agent_token)
    elif environment.api_key:
        auth = ApiKeyAuth(environment.api_key)
    else:
        return DisabledCoordinator()
    return PlatformQueuePassthrough(
        cast(Any, CogitClient(base_url=environment.api_url, auth=auth))
    )


def _import_agent_class(dotted: str) -> type[Any]:
    if ":" in dotted:
        module_name, attr_name = dotted.split(":", 1)
    elif "." in dotted:
        module_name, attr_name = dotted.rsplit(".", 1)
    else:
        raise ValueError(
            f"--agent must be module:ClassName or module.ClassName, got {dotted!r}"
        )
    module = importlib.import_module(module_name)
    agent_class = getattr(module, attr_name, None)
    if not isinstance(agent_class, type):
        raise ValueError(f"{dotted!r} does not resolve to a class")
    return agent_class


def _split(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def _unreachable() -> NoReturn:
    raise RuntimeError("unreachable command branch")


# ---------------------------------------------------------------------------
# Agent-declared custom commands (Proposal 011)
# ---------------------------------------------------------------------------


@dataclass
class _CustomCommand:
    """A resolved agent-declared command, ready to dispatch."""

    handler: Any
    lifecycle: AgentLifecycleManager
    agent: object
    descriptor: AgentDescriptor


def _extract_manifest_agent(argv: list[str]) -> tuple[str | None, str | None]:
    """Peek ``--manifest``/``--agent`` from argv without a full canonical parse.

    Uses a throwaway parser that only knows those two flags, so unrelated tokens
    (other subcommands and flags) never cause an error.
    """

    peek = argparse.ArgumentParser(add_help=False)
    peek.add_argument("--manifest", default=None)
    peek.add_argument("--agent", default=None)
    known, _extras = peek.parse_known_args(argv)
    return known.manifest, known.agent


def _first_positional(argv: list[str]) -> str | None:
    """Return the first non-flag token in argv (the candidate subcommand)."""

    peek = argparse.ArgumentParser(add_help=False)
    peek.add_argument("--manifest", default=None)
    peek.add_argument("--agent", default=None)
    _known, extras = peek.parse_known_args(argv)
    for token in extras:
        if not token.startswith("-"):
            return token
    return None


def _agent_commands(agent: object) -> list[Any]:
    """Return the agent's declared command groups (``[]`` if none/absent)."""

    commands_fn = getattr(agent, "commands", None)
    if callable(commands_fn):
        result = commands_fn()
        if isinstance(result, list):
            return result
    return []


def _maybe_discover_custom_commands(
    argv: list[str],
    subparsers: argparse._SubParsersAction,
) -> dict[str, dict[str, _CustomCommand]] | None:
    """Attach agent-declared command subparsers when applicable.

    Returns a dispatch map ``{group: {command: _CustomCommand}}`` when a custom
    command set was discovered and wired into ``subparsers``, or ``None`` when
    the canonical argparse path should handle the invocation instead (canonical
    command, unresolved ``--manifest``/``--agent``, absent SDK support, or an
    agent/manifest that cannot be resolved). ``ReservedCommandNameError`` is
    intentionally allowed to propagate to :func:`main` for a clean exit code.
    """

    if _first_positional(argv) in CANONICAL_COMMANDS:
        return None

    manifest_path, agent_import = _extract_manifest_agent(argv)
    if not manifest_path:
        environment = RuntimeEnvironment.from_env()
        if environment.agentdb is not None and not environment.dev_mode:
            from cogit_runtime.agentdb.errors import AgentDbConfigError

            raise AgentDbConfigError(
                "Canonical AgentDb commands require --manifest and --agent"
            )
        return None

    if validate_command_groups is None:  # SDK custom-command support absent
        return None

    try:
        agent_import = resolve_agent_entrypoint(manifest_path, agent_import)
        _preflight_agent_import(manifest_path, agent_import)
        agent_class = _import_agent_class(agent_import)
        descriptor = load_manifest(manifest_path).descriptor
        lifecycle = AgentLifecycleManager(
            agent_class,
            descriptor,
            RuntimeEnvironment.from_env(),
        )
        agent = lifecycle.construct()
        groups = _agent_commands(agent)
    except (ValueError, ImportError, RuntimeConfigurationError):
        return None

    # validate_command_groups may raise ReservedCommandNameError; let it
    # propagate so main() can print it and exit non-zero.
    validate_command_groups(groups, agent_class_name=agent_class.__name__)

    dispatch: dict[str, dict[str, _CustomCommand]] = {}
    for group in groups:
        group_parser = subparsers.add_parser(group.name)
        group_subparsers = group_parser.add_subparsers(
            dest="subcommand",
            required=True,
        )
        inner: dict[str, _CustomCommand] = {}
        for command in group.commands:
            command_parser = group_subparsers.add_parser(command.name)
            # Mirror work/register: require --manifest/--agent on the re-parse.
            command_parser.add_argument(
                "--manifest",
                required=True,
                help="Path to cogit.yaml",
            )
            command_parser.add_argument(
                "--agent",
                default=None,
                help="Resident class; defaults to cogit.yaml metadata.entrypoint",
            )
            for argument in command.arguments:
                argument.apply(command_parser)
            inner[command.name] = _CustomCommand(
                handler=command.handler,
                lifecycle=lifecycle,
                agent=agent,
                descriptor=descriptor,
            )
        dispatch[group.name] = inner
    return dispatch


def _dispatch_custom_command(
    args: argparse.Namespace,
    custom: _CustomCommand,
) -> int:
    """Run a single agent-declared command through the agent lifecycle.

    Per Proposal 011 D5, declared commands do not get durable-store access, so
    services are injected without a store/artifacts handle (and no model client
    or configured logger beyond the default).
    """

    return asyncio.run(
        run_custom_command(
            agent=custom.agent,
            lifecycle=custom.lifecycle,
            descriptor=custom.descriptor,
            handler=custom.handler,
            args=args,
        )
    )
