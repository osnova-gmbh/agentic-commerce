"""Background execution scheduler for ``POST /runs`` in async mode."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from threading import RLock

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import Context, RunRequest, RunResult

from cogit_runtime.cancellation import (
    CancellationRegistry,
    RuntimeCancellation,
    RuntimeWorkDeferred,
    await_runtime_completion,
)
from cogit_runtime.coordination import finish_cleanup
from cogit_runtime.reporter import RunReporter

RunExecutor = Callable[..., Awaitable[RunResult]]


class AsyncRunManager:
    """Owns background tasks for async ``/runs`` executions.

    The manager schedules the run executor on the running asyncio loop and
    reserves cancellation before scheduling so ``/runs/{id}/cancel`` can
    signal even before the coroutine starts. Running tasks are never force
    settled while owned thread work may still be active.
    """

    def __init__(
        self,
        *,
        executor: RunExecutor,
        reporter: RunReporter,
        cancellations: CancellationRegistry,
    ) -> None:
        self._executor = executor
        self._reporter = reporter
        self._cancellations = cancellations
        self._lock = RLock()
        self._tasks: dict[str, asyncio.Task[RunResult]] = {}
        self._accepting = True
        self._coordination_failure: CoordinationFailure | None = None

    def schedule(
        self,
        *,
        execution_id: str,
        request: RunRequest,
        context: Context,
    ) -> None:
        with self._lock:
            if not self._accepting:
                raise RuntimeError("Async run manager is shutting down")
            cancellation = self._cancellations.create(execution_id)
            try:
                task = asyncio.create_task(
                    self._safe_run(execution_id, request, context, cancellation),
                    name=f"cogit-run-{execution_id}",
                )
            except Exception:
                self._cancellations.release(execution_id)
                raise
            self._tasks[execution_id] = task
        task.add_done_callback(lambda done: self._forget(execution_id, done))

    def cancel(self, execution_id: str) -> bool:
        return self._cancellations.cancel(execution_id)

    async def shutdown(self) -> None:
        with self._lock:
            self._accepting = False
            tasks = list(self._tasks.items())
        failure: BaseException | None = None
        caller_cancellation: asyncio.CancelledError | None = None
        for execution_id, _task in tasks:
            try:
                self._cancellations.cancel(execution_id)
            except BaseException as exc:
                if isinstance(exc, CoordinationFailure):
                    if self._coordination_failure is None:
                        self._coordination_failure = exc
                elif failure is None:
                    failure = exc
        if tasks:
            completion = asyncio.gather(
                *(task for _execution_id, task in tasks),
                return_exceptions=True,
            )
            try:
                outcomes = await asyncio.shield(completion)
            except asyncio.CancelledError as exc:
                caller_cancellation = exc
                outcomes = await await_runtime_completion(completion)
            for outcome in outcomes:
                if isinstance(outcome, CoordinationFailure):
                    if self._coordination_failure is None:
                        self._coordination_failure = outcome
                elif isinstance(outcome, Exception) and failure is None:
                    failure = outcome
        if self._coordination_failure is not None:
            raise self._coordination_failure
        if caller_cancellation is not None:
            raise caller_cancellation
        if failure is not None:
            raise failure

    async def _safe_run(
        self,
        execution_id: str,
        request: RunRequest,
        context: Context,
        cancellation: RuntimeCancellation,
    ) -> RunResult:
        try:
            return await self._executor(
                request,
                context,
                self._reporter,
                execution_id,
                reserved_cancellation=cancellation,
            )
        except CoordinationFailure:
            raise
        except RuntimeWorkDeferred as pending:
            return await await_runtime_completion(pending.completion)
        except asyncio.CancelledError:
            cancellation.cancel()
            self._reporter.complete(
                execution_id,
                status="cancelled",
                output_summary="Async run cancelled",
                outcome_label="cancelled",
            )
            raise
        except Exception as exc:
            from cogit_agent_sdk.types import ErrorInfo

            self._reporter.complete(
                execution_id,
                status="failed",
                output_summary=f"Async run failed ({type(exc).__name__})",
                outcome_label="unhandled_exception",
                error=ErrorInfo(
                    code="ASYNC_RUN_ERROR",
                    message=f"Async run failed ({type(exc).__name__})",
                    retryable=False,
                ),
            )
            raise
        finally:
            finish_cleanup(lambda: self._cancellations.release(execution_id))

    def _forget(
        self,
        execution_id: str,
        task: asyncio.Task[RunResult],
    ) -> None:
        with self._lock:
            self._tasks.pop(execution_id, None)
        try:
            failure = task.exception()
            if (
                isinstance(failure, CoordinationFailure)
                and self._coordination_failure is None
            ):
                self._coordination_failure = failure
        except asyncio.CancelledError:
            pass
