"""Bound optional SDK RunHandle diagnostics without changing delivered steps.

``events`` and ``steps`` are worker-local observation caches.  In particular,
their event sequences are local cursors. Required AgentDb audit observations
use an explicit sink and durable identities independently of these caches.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from cogit_agent_sdk.client.platform import CogitClient
from cogit_agent_sdk.contracts import DecisionProvider, RunHandle, StepRecorder
from cogit_agent_sdk.types import Context, ExecutionStepRecord, RunEvent
from cogit_agent_sdk.types.loop import LoopHookSet

from cogit_runtime.config import DiagnosticHistoryLimits


class BoundedRunHandle(RunHandle):
    """Keep finite, best-effort local notes around exact SDK step delivery."""

    def __init__(
        self,
        execution_id: str,
        context: Context,
        *,
        client: CogitClient | None = None,
        decision_provider: DecisionProvider | None = None,
        step_recorder: StepRecorder | None = None,
        hooks: LoopHookSet | None = None,
        diagnostic_limits: DiagnosticHistoryLimits | None = None,
    ) -> None:
        self._diagnostic_limits = diagnostic_limits or DiagnosticHistoryLimits()
        self._next_local_event_sequence = 1
        self._dropped_local_events = 0
        self._dropped_local_steps = 0
        super().__init__(
            execution_id,
            context,
            client=client,
            decision_provider=decision_provider,
            step_recorder=step_recorder,
            hooks=hooks,
        )

    def log(self, message: str, data: dict[str, Any] | None = None) -> None:
        self._cache_event(
            RunEvent(
                execution_id=self.execution_id,
                sequence=0,
                timestamp=datetime.now(UTC),
                type="step_recorded",
                payload={"message": message, "data": data or {}},
            )
        )

    def emit(self, event: RunEvent) -> None:
        self._cache_event(event)

    def _cache_event(self, event: RunEvent) -> None:
        """Cache a local copy; never raise for optional serialization failure."""

        with self._lock:
            sequence = max(event.sequence, self._next_local_event_sequence)
            self._next_local_event_sequence = sequence + 1
            try:
                stored = event.model_copy(deep=True, update={"sequence": sequence})
                if _json_bytes(stored) is None:
                    self._dropped_local_events += 1
                    return
                self.events.append(stored)
                self._trim_local_events()
            except Exception:
                # Public SDK cache lists can contain caller-owned values.  A
                # broken optional list must not abort a canonical effect.
                self._dropped_local_events += len(self.events) + 1
                self.events.clear()

    def _trim_local_events(self) -> None:
        limits = self._diagnostic_limits
        count_limit = min(limits.events_per_run, limits.events_total)
        byte_limit = min(limits.event_bytes_per_run, limits.event_bytes_total)
        retained: list[RunEvent] = []
        sizes: list[int] = []
        for event in self.events:
            try:
                copied = event.model_copy(deep=True)
                size = _json_bytes(copied)
            except Exception:
                size = None
            if size is None or size > byte_limit:
                self._dropped_local_events += 1
                continue
            retained.append(copied)
            sizes.append(size)
        total = sum(sizes)
        while retained and (len(retained) > count_limit or total > byte_limit):
            retained.pop(0)
            total -= sizes.pop(0)
            self._dropped_local_events += 1
        self.events[:] = retained

    def _deliver_step(
        self, record: ExecutionStepRecord, delivery_sequence: int
    ) -> None:
        try:
            super()._deliver_step(record, delivery_sequence)
        finally:
            # The SDK has already delivered the exact record to its callback
            # before local truncation.  Never replace a required callback error.
            self._trim_local_steps()

    def _trim_local_steps(self) -> None:
        try:
            with self._step_lock, self._lock:
                limits = self._diagnostic_limits
                count_limit = min(limits.steps_per_run, limits.steps_total)
                byte_limit = min(limits.step_bytes_per_run, limits.step_bytes_total)
                retained: list[ExecutionStepRecord] = []
                sizes: list[int] = []
                uncacheable_terminal_ids: set[str] = set()
                for step in self.steps:
                    try:
                        copied = step.model_copy(deep=True)
                        size = _json_bytes(copied)
                    except Exception:
                        size = None
                    if size is None or size > byte_limit:
                        self._dropped_local_steps += 1
                        if step.status != "running":
                            # The SDK retains both running and terminal
                            # versions.  Never leave a stale running copy
                            # after its terminal update could not be cached.
                            uncacheable_terminal_ids.add(step.id)
                        continue
                    retained.append(copied)
                    sizes.append(size)
                if uncacheable_terminal_ids:
                    kept: list[tuple[ExecutionStepRecord, int]] = []
                    for step, size in zip(retained, sizes, strict=True):
                        if step.id in uncacheable_terminal_ids:
                            self._dropped_local_steps += 1
                        else:
                            kept.append((step, size))
                    retained = [step for step, _ in kept]
                    sizes = [size for _, size in kept]
                total = sum(sizes)
                while retained and (len(retained) > count_limit or total > byte_limit):
                    retained.pop(0)
                    total -= sizes.pop(0)
                    self._dropped_local_steps += 1
                self.steps[:] = retained
        except Exception:
            with self._lock:
                self._dropped_local_steps += len(self.steps)
                self.steps.clear()

    def local_diagnostic_snapshot(self) -> dict[str, int]:
        """Expose measured optional cache use, separate from durable history."""

        with self._step_lock, self._lock:
            return {
                "events": len(self.events),
                "event_bytes": sum(_json_bytes(event) or 0 for event in self.events),
                "dropped_events": self._dropped_local_events,
                "next_event_sequence": self._next_local_event_sequence,
                "steps": len(self.steps),
                "step_bytes": sum(_json_bytes(step) or 0 for step in self.steps),
                "dropped_steps": self._dropped_local_steps,
            }


def _json_bytes(record: RunEvent | ExecutionStepRecord) -> int | None:
    try:
        return len(record.model_dump_json().encode("utf-8"))
    except Exception:
        return None
