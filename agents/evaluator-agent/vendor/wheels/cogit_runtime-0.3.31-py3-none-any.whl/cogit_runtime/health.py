"""Runtime-owned health response models."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict

HealthStatus = Literal["ok", "degraded", "error"]


class HealthComponent(BaseModel):
    """Health for one runtime or agent component."""

    model_config = ConfigDict(frozen=True)

    status: HealthStatus
    detail: str | None = None


class VersionInfo(BaseModel):
    """Version information exposed by ``GET /health``."""

    model_config = ConfigDict(frozen=True)

    agent: str
    runtime: str
    sdk: str


class HealthReport(BaseModel):
    """Runtime-owned health response shape."""

    model_config = ConfigDict(frozen=True)

    status: HealthStatus
    version: VersionInfo
    dev_mode: bool
    components: dict[str, HealthComponent]
