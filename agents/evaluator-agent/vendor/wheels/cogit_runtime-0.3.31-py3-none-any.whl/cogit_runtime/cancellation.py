"""Cooperative cancellation registry for runtime-managed runs."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from threading import Event, RLock
from time import monotonic
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types.cancellation import Cancellation

from cogit_runtime.coordination import finish_cleanup


class RuntimeCancelledError(RuntimeError):
    """Raised when a run is cancelled cooperatively."""


class RuntimeWorkDeferred(asyncio.CancelledError):
    """Cancellation returned while owned worker cleanup continues."""

    def __init__(self, completion: asyncio.Future[Any]) -> None:
        super().__init__("Cancellation is waiting for worker shutdown")
        self.completion = RuntimeCompletion(completion)


class RuntimeCompletion(asyncio.Future[Any]):
    """Non-cancellable proxy for runtime-owned cleanup."""

    def __init__(self, source: asyncio.Future[Any]) -> None:
        super().__init__()
        self._source = source
        source.add_done_callback(self._transfer)

    def cancel(self, msg: object | None = None) -> bool:
        _ = msg
        return False

    def _transfer(self, source: asyncio.Future[Any]) -> None:
        if self.done():
            return
        if source.cancelled():
            self.set_exception(asyncio.CancelledError())
            return
        exception = source.exception()
        if exception is not None:
            self.set_exception(exception)
            return
        self.set_result(source.result())


async def await_runtime_completion(completion: asyncio.Future[Any]) -> Any:
    """Wait through task cancellation until owned work actually exits."""

    while not completion.done():
        try:
            await asyncio.shield(completion)
        except asyncio.CancelledError:
            current = asyncio.current_task()
            if current is not None:
                current.uncancel()
    return completion.result()


class RuntimeCancellation:
    """Per-run cancellation signal implementing the SDK ``Cancellation`` protocol."""

    def __init__(
        self,
        parent: RuntimeCancellation | None = None,
        *,
        on_cancel: Callable[[], None] | None = None,
        deadline: float | None = None,
    ) -> None:
        self._event = Event()
        self._parent = parent
        self._on_cancel = on_cancel
        self._children: set[RuntimeCancellation] = set()
        self._deadline = deadline
        self._lock = RLock()
        if parent is not None:
            parent._add_child(self)

    @property
    def cancelled(self) -> bool:
        if self._event.is_set():
            return True
        if self._deadline is not None and monotonic() >= self._deadline:
            return True
        return self._parent is not None and self._parent.cancelled

    def cancel(self) -> None:
        with self._lock:
            first_request = not self._event.is_set()
            self._event.set()
            callback = self._on_cancel if first_request else None
            children = list(self._children)
        finish_cleanup(
            *((callback,) if callback is not None else ()),
            *(child.cancel for child in children),
        )

    def throw_if_cancelled(self) -> None:
        if self.cancelled:
            if self._deadline is not None and monotonic() >= self._deadline:
                raise TimeoutError("Operation timed out")
            raise RuntimeCancelledError("Run was cancelled")

    def bind(self, on_cancel: Callable[[], None]) -> None:
        """Attach the run handle after an async cancellation was reserved."""

        with self._lock:
            self._on_cancel = on_cancel
            cancelled = self.cancelled
        if cancelled:
            on_cancel()

    def close(self) -> None:
        if self._parent is not None:
            self._parent._remove_child(self)
        with self._lock:
            self._on_cancel = None

    def _add_child(self, child: RuntimeCancellation) -> None:
        with self._lock:
            self._children.add(child)
            cancelled = self.cancelled
        if cancelled:
            child.cancel()

    def _remove_child(self, child: RuntimeCancellation) -> None:
        with self._lock:
            self._children.discard(child)


class RuntimeLinkedCancellation(RuntimeCancellation):
    """Link an external SDK cancellation into the runtime cancellation tree."""

    def __init__(
        self,
        delegate: Cancellation,
        *,
        parent: RuntimeCancellation | None = None,
        on_cancel: Callable[[], None] | None = None,
        deadline: float | None = None,
    ) -> None:
        super().__init__(parent=parent, on_cancel=on_cancel, deadline=deadline)
        self._delegate = delegate

    @property
    def cancelled(self) -> bool:
        return super().cancelled or self._delegate.cancelled

    def throw_if_cancelled(self) -> None:
        delegate_error: BaseException | None = None
        try:
            self._delegate.throw_if_cancelled()
        except CoordinationFailure:
            raise
        except BaseException as exc:
            delegate_error = exc
        super().throw_if_cancelled()
        if delegate_error is not None:
            raise delegate_error


def operation_cancellation(
    cancellation: Cancellation | RuntimeCancellation,
    *,
    parent: RuntimeCancellation | None = None,
    on_cancel: Callable[[], None] | None = None,
    timeout_seconds: float | None = None,
) -> RuntimeCancellation:
    """Build a runtime-owned cancellation boundary for one operation."""

    deadline = None if timeout_seconds is None else monotonic() + float(timeout_seconds)
    if (
        isinstance(cancellation, RuntimeCancellation)
        and parent is None
        and on_cancel is None
        and deadline is None
    ):
        return cancellation

    effective_parent = (
        cancellation if isinstance(cancellation, RuntimeCancellation) else parent
    )
    if not isinstance(cancellation, RuntimeCancellation):
        return RuntimeLinkedCancellation(
            cancellation,
            parent=effective_parent,
            on_cancel=on_cancel,
            deadline=deadline,
        )
    return RuntimeCancellation(
        parent=cancellation,
        on_cancel=on_cancel,
        deadline=deadline,
    )


class CancellationRegistry:
    """Tracks cancellation handles by execution id."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._handles: dict[str, RuntimeCancellation] = {}

    def create(
        self,
        execution_id: str,
        *,
        parent: RuntimeCancellation | None = None,
        on_cancel: Callable[[], None] | None = None,
    ) -> RuntimeCancellation:
        with self._lock:
            if execution_id in self._handles:
                raise RuntimeError(
                    f"Cancellation for execution '{execution_id}' already exists."
                )
            handle = RuntimeCancellation(parent=parent, on_cancel=on_cancel)
            self._handles[execution_id] = handle
        return handle

    def get(self, execution_id: str) -> RuntimeCancellation | None:
        with self._lock:
            return self._handles.get(execution_id)

    def cancel(self, execution_id: str) -> bool:
        with self._lock:
            handle = self._handles.get(execution_id)
        if handle is None:
            return False
        handle.cancel()
        return True

    def release(self, execution_id: str) -> None:
        with self._lock:
            handle = self._handles.pop(execution_id, None)
        if handle is not None:
            handle.close()
