"""Run the Runtime CLI with ``python -I -m cogit_runtime``."""

from cogit_runtime.cli import main

raise SystemExit(main())
