"""Platform reporter: mirror runtime records to the Cogit platform.

The reporter writes ``ExecutionRecord`` state transitions, execution steps,
and learning/experiment/eval records to the platform through the SDK
``CogitClient`` when platform credentials are configured. When credentials
are missing or the platform is unreachable, records are queued in the
runtime store and retried later. SQL-backed runtimes therefore retain mirror
operations across process restarts.
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from typing import Any, Literal

from cogit_agent_sdk.client import (
    AgentTokenAuth,
    ApiKeyAuth,
    AuthStrategy,
    CogitClient,
    DevAuth,
)
from cogit_agent_sdk.types import (
    Context,
    EvalRecord,
    ExecutionRecord,
    ExecutionStepRecord,
    ExperimentRecord,
    LearningRecord,
)

from cogit_runtime.config import RuntimeEnvironment
from cogit_runtime.store import InMemoryRuntimeStore, OutboxRecord, RuntimeStore

OutboxOperation = Literal[
    "execution_create",
    "execution_complete",
    "execution_step",
    "learning_record",
    "experiment_record",
    "eval_record",
]


class PlatformReporter:
    """Mirrors runtime records to the platform through a durable outbox.

    The reporter is safe to call even when the platform client is not
    configured: entries are persisted and can be flushed after credentials
    become available or after a process restart.
    """

    def __init__(
        self,
        environment: RuntimeEnvironment,
        *,
        store: RuntimeStore | None = None,
        client_factory: Callable[[], CogitClient | None] | None = None,
        outbox_capacity: int = 1024,
    ) -> None:
        self._environment = environment
        self._store = store or InMemoryRuntimeStore()
        self._flush_lock = threading.Lock()
        _ = outbox_capacity  # Kept for constructor compatibility.
        self._client_factory = client_factory or _default_client_factory(environment)
        self._client: CogitClient | None = None
        self._enabled = _has_platform_config(environment)
        self._degraded_reason: str | None = (
            None if self._enabled else "no COGIT_API_URL / credentials configured"
        )

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def degraded_reason(self) -> str | None:
        return self._degraded_reason

    @property
    def outbox_depth(self) -> int:
        return self._store.count_pending_outbox()

    def record_execution_started(
        self,
        record: ExecutionRecord,
        context: Context | None = None,
    ) -> None:
        self._enqueue("execution_create", record, context)
        self._try_flush()

    def record_execution_completed(
        self,
        record: ExecutionRecord,
        context: Context | None = None,
    ) -> None:
        self._enqueue("execution_complete", record, context)
        self._try_flush()

    def build_outbox_record(
        self,
        operation: OutboxOperation,
        payload: object,
        context: Context | None = None,
    ) -> OutboxRecord:
        """Build an outbox row for paired store+outbox transactions."""

        dumped = _dump_payload(payload)
        return OutboxRecord(
            operation=operation,
            payload=dumped,
            context=(
                context.model_dump(by_alias=True, mode="json", exclude_none=True)
                if context is not None
                else None
            ),
            idempotency_key=_outbox_idempotency_key(operation, dumped),
        )

    def flush_pending(self) -> int:
        """Public flush entry used after paired store writes."""

        return self.flush() if self._enabled else 0

    def record_step(
        self,
        step: ExecutionStepRecord,
        context: Context | None = None,
    ) -> None:
        self._enqueue("execution_step", step, context)
        self._try_flush()

    def record_learning(
        self,
        record: LearningRecord,
        context: Context | None = None,
    ) -> None:
        self._enqueue("learning_record", record, context)
        self._try_flush()

    def record_experiment(
        self,
        record: ExperimentRecord,
        context: Context | None = None,
    ) -> None:
        self._enqueue("experiment_record", record, context)
        self._try_flush()

    def record_eval(
        self,
        record: EvalRecord,
        context: Context | None = None,
    ) -> None:
        self._enqueue("eval_record", record, context)
        self._try_flush()

    def flush(self) -> int:
        """Attempt to flush pending outbox entries. Returns number flushed."""
        client = self._resolve_client()
        if client is None:
            return 0
        flushed = 0
        with self._flush_lock:
            while entries := self._store.list_pending_outbox(limit=100):
                for entry in entries:
                    if entry.id is None:
                        raise RuntimeError("Persisted outbox entry has no id")
                    try:
                        _dispatch(client, entry)
                    except Exception as exc:
                        self._store.mark_outbox_failed(entry.id, str(exc))
                        self._degraded_reason = f"platform mirror failed: {exc}"
                        return flushed
                    self._store.mark_outbox_delivered(entry.id)
                    flushed += 1
            self._degraded_reason = None
        return flushed

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def _enqueue(
        self,
        operation: OutboxOperation,
        payload: object,
        context: Context | None,
    ) -> None:
        dumped = _dump_payload(payload)
        self._store.enqueue_outbox(
            OutboxRecord(
                operation=operation,
                payload=dumped,
                context=(
                    context.model_dump(by_alias=True, mode="json", exclude_none=True)
                    if context is not None
                    else None
                ),
                idempotency_key=_outbox_idempotency_key(operation, dumped),
            )
        )

    def _try_flush(self) -> None:
        if not self._enabled:
            return
        self.flush()

    def resolve_client(self) -> CogitClient | None:
        """Resolve (and cache) the platform ``CogitClient``, if configured."""
        if self._client is not None:
            return self._client
        if not self._enabled:
            return None
        client = self._client_factory()
        if client is None:
            self._degraded_reason = "platform client factory returned None"
            return None
        self._client = client
        return client

    def _resolve_client(self) -> CogitClient | None:
        return self.resolve_client()


def _dispatch(client: CogitClient, entry: OutboxRecord) -> None:
    context = (
        Context.model_validate(entry.context) if entry.context is not None else None
    )
    if entry.operation == "execution_create":
        record = ExecutionRecord.model_validate(entry.payload)
        client.executions.create(record, context)
        return
    if entry.operation == "execution_complete":
        record = ExecutionRecord.model_validate(entry.payload)
        payload = record.model_dump(by_alias=True, mode="json", exclude_none=True)
        client.executions.complete(record.id, payload, context)
        return
    if entry.operation == "execution_step":
        step = ExecutionStepRecord.model_validate(entry.payload)
        client.executions.append_step(step, context)
        return
    if entry.operation == "learning_record":
        client.learnings.record(LearningRecord.model_validate(entry.payload), context)
        return
    if entry.operation == "experiment_record":
        client.experiments.record(
            ExperimentRecord.model_validate(entry.payload),
            context,
        )
        return
    if entry.operation == "eval_record":
        client.evals.report(EvalRecord.model_validate(entry.payload), context)
        return
    raise ValueError(f"Unknown outbox operation: {entry.operation}")


def _dump_payload(value: object) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        payload = value.model_dump(  # type: ignore[union-attr]
            by_alias=True,
            mode="json",
            exclude_none=True,
        )
        if isinstance(payload, dict):
            return payload
    raise TypeError(f"Outbox payload is not a serializable SDK model: {type(value)!r}")


def _outbox_idempotency_key(
    operation: OutboxOperation,
    payload: dict[str, Any],
) -> str | None:
    stable_id = payload.get("id")
    if isinstance(stable_id, str) and stable_id:
        return f"{operation}:{stable_id}"
    return None


def _has_platform_config(environment: RuntimeEnvironment) -> bool:
    if not environment.api_url:
        return False
    return bool(environment.outbound_credential)


def _default_client_factory(
    environment: RuntimeEnvironment,
) -> Callable[[], CogitClient | None]:
    def factory() -> CogitClient | None:
        if not environment.api_url:
            return None
        auth = _resolve_auth(environment)
        if auth is None:
            return None
        return CogitClient(base_url=environment.api_url, auth=auth)

    return factory


def _resolve_auth(environment: RuntimeEnvironment) -> AuthStrategy | None:
    if environment.agent_token:
        return AgentTokenAuth(environment.agent_token)
    if environment.api_key:
        return ApiKeyAuth(environment.api_key)
    if environment.dev_mode:
        return DevAuth()
    return None
