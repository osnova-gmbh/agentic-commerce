"""Loop-host protocol used by the runtime endpoints.

The concrete implementation lives in :mod:`cogit_runtime.loop_host`
(:class:`SdkLoopHost`), which drives the SDK ``AgentLoopEngine``. This module
only defines the shape the runtime depends on so tests and alternative hosts
can be swapped in without importing the engine.
"""

from __future__ import annotations

import asyncio
from typing import Any, Protocol

from cogit_agent_sdk.types import (
    ActionDescriptor,
    Context,
    QueryRequest,
    QueryResult,
    RunRequest,
    RunResult,
)

from cogit_runtime.cancellation import RuntimeCancellation
from cogit_runtime.operations.approval_gate import ApprovalSource
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.reporter import RunReporter


class LoopHost(Protocol):
    """Boundary for the SDK agent loop hosted by the runtime."""

    def validate_query_request(self, request: QueryRequest, context: Context) -> None:
        """Validate query options before an execution record is created."""

        raise NotImplementedError

    async def query(
        self,
        request: QueryRequest,
        context: Context,
        reporter: RunReporter,
        execution_id: str,
    ) -> QueryResult:
        """Execute a query through the hosted loop."""
        raise NotImplementedError

    async def run(
        self,
        request: RunRequest,
        context: Context,
        reporter: RunReporter,
        execution_id: str,
    ) -> RunResult:
        """Execute a run through the hosted loop."""
        raise NotImplementedError

    def validate_run_request(self, request: RunRequest, context: Context) -> None:
        """Validate pipeline selection before an execution record is created."""
        raise NotImplementedError

    def prompt_run_metadata(self, context: Context) -> dict[str, Any]:
        """Return system-prompt metadata for ``reporter.begin``."""
        raise NotImplementedError

    async def action(
        self,
        action_name: str,
        payload: dict[str, Any],
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        *,
        parent_cancellation: RuntimeCancellation | None = None,
        idempotency_key: str | None = None,
        approval_id: str | None = None,
        approval_source: ApprovalSource = "action",
    ) -> Any:
        """Execute an exposed action through the hosted action boundary."""
        raise NotImplementedError

    async def execute_bound_action(
        self,
        action_name: str,
        payload: dict[str, Any],
        context: Context,
        execution_id: str,
        *,
        parent_cancellation: RuntimeCancellation | None = None,
        idempotency_key: str | None = None,
        approval_id: str | None = None,
        approval_source: ApprovalSource = "action",
        reporter: RunReporter | None = None,
    ) -> OperationExecutionResult:
        """Execute a bound action through the shared approval gate and executor."""
        raise NotImplementedError

    async def execute_action_for_worker(
        self,
        action_name: str,
        payload: dict[str, Any],
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        approval_id: str | None,
    ) -> OperationExecutionResult:
        """Worker adapter that routes continuations through the shared gate."""
        raise NotImplementedError

    def action_descriptor(self, action_name: str) -> ActionDescriptor | None:
        """Return the canonical descriptor for an action name."""
        raise NotImplementedError

    def track_deferred_task(self, task: asyncio.Task[Any]) -> asyncio.Task[Any]:
        """Retain an owned task until its worker and settlement complete."""
        raise NotImplementedError

    async def drain_deferred(self) -> None:
        """Wait for all owned deferred work before runtime shutdown."""
        raise NotImplementedError
