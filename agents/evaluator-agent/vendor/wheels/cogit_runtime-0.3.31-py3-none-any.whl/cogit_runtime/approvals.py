"""Approval parking for actions and steps that require attention.

When an action is declared with ``requires_approval: true`` (or the loop
requests a decision), the runtime parks the request as an
``AttentionItem`` and returns a ``202 Accepted``-style payload. A subsequent
admin call to ``POST /attention/{id}/decision`` resumes the parked work.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from cogit_agent_sdk.types import AttentionItem, Context, Decision

from cogit_runtime.store import ApprovalRecord, InMemoryRuntimeStore, RuntimeStore


class ApprovalStore:
    """Store-backed parked attention items and matching decisions."""

    def __init__(self, store: RuntimeStore | None = None) -> None:
        self._store = store or InMemoryRuntimeStore()

    def park(
        self,
        *,
        kind: str,
        message: str,
        context: Context,
        payload: dict[str, Any] | None = None,
        execution_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AttentionItem:
        item_id = str(uuid4())
        item = AttentionItem(
            id=item_id,
            kind=_kind_or_default(kind),
            execution_id=execution_id,
            case_id=context.case_id,
            message=message,
            metadata=metadata,
        )
        self._store.put_approval(
            ApprovalRecord(
                item=item,
                context=context,
                payload=dict(payload or {}),
            )
        )
        return item

    def get(self, item_id: str) -> AttentionItem | None:
        record = self._store.get_approval(item_id)
        return record.item if record is not None else None

    def record_for(self, item_id: str) -> ApprovalRecord | None:
        """Read one trusted parked record for worker continuation validation."""
        return self._store.get_approval(item_id)

    def list_pending(self) -> list[AttentionItem]:
        return [record.item for record in self._store.list_pending_approvals()]

    def pending_for_execution(self, execution_id: str) -> list[AttentionItem]:
        return [
            record.item
            for record in self._store.list_pending_approvals()
            if record.item.execution_id == execution_id
        ]

    def context_for(self, item_id: str) -> Context | None:
        record = self._store.get_approval(item_id)
        return record.context if record is not None else None

    def payload_for(self, item_id: str) -> dict[str, Any] | None:
        record = self._store.get_approval(item_id)
        return dict(record.payload) if record is not None else None

    def decide(
        self,
        *,
        item_id: str,
        action: str,
        rationale: str | None = None,
        decided_by: str,
    ) -> Decision:
        record = self._store.get_approval(item_id)
        if record is None:
            raise KeyError(item_id)
        if record.decision is not None:
            return record.decision
        decision = Decision(
            id=str(uuid4()),
            attention_item_id=item_id,
            action=_action_or_abort(action),
            rationale=rationale,
            decided_by=decided_by,
            decided_at=datetime.now(UTC),
        )
        stored = self._store.put_approval(
            ApprovalRecord(
                item=record.item,
                context=record.context,
                payload=record.payload,
                created_at=record.created_at,
                decision=decision,
            )
        )
        if stored.decision is None:
            raise RuntimeError("Approval decision could not be recorded")
        return stored.decision

    def decision_for(self, item_id: str) -> Decision | None:
        record = self._store.get_approval(item_id)
        return record.decision if record is not None else None

    def find_pending_park(
        self,
        *,
        execution_id: str | None,
        action_name: str,
        source: str,
        payload: dict[str, Any],
    ) -> AttentionItem | None:
        """Return an existing undecided park for the same execution/action/payload."""

        for record in self._store.list_pending_approvals():
            if record.decision is not None:
                continue
            item = record.item
            if execution_id is not None:
                if item.execution_id != execution_id:
                    continue
            elif item.execution_id is not None:
                continue
            metadata = item.metadata or {}
            if metadata.get("action") != action_name:
                continue
            if metadata.get("source") != source:
                continue
            if record.payload != payload:
                continue
            return item
        return None

    def consume(self, item_id: str) -> bool:
        """Atomically claim this approval for one execution.

        Returns ``True`` the first time this is called for ``item_id``
        (the caller may proceed to execute), ``False`` on every subsequent
        call -- an approval authorizes exactly one execution.
        """

        return self._store.consume_approval(item_id)


def _kind_or_default(value: str) -> Any:
    allowed = {
        "approval_required",
        "node_failed",
        "gate_failed",
        "clarification_needed",
        "human_review",
        "terminal_review",
    }
    if value in allowed:
        return value
    return "approval_required"


def _action_or_abort(value: str) -> Any:
    allowed = {
        "continue",
        "retry",
        "patch",
        "approve",
        "reject",
        "abort",
        "request_changes",
    }
    if value in allowed:
        return value
    return "abort"
