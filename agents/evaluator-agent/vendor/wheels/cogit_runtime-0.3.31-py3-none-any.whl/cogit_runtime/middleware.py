"""Runtime middleware for transport-level protections."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass

from starlette.datastructures import Headers
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

_CORRELATION_HEADER = "x-cogit-correlation-id"


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    """Echo or create ``X-Cogit-Correlation-Id`` for every response."""

    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        correlation_id = _header_value(request.headers, _CORRELATION_HEADER)
        if correlation_id is None:
            correlation_id = str(uuid.uuid4())
        request.state.cogit_correlation_id = correlation_id

        response = await call_next(request)
        response.headers["X-Cogit-Correlation-Id"] = correlation_id
        return response


class BodySizeLimitMiddleware:
    """Bound actual request bytes before a handler can perform an operation."""

    def __init__(self, app: ASGIApp, *, limit_bytes: int) -> None:
        self.app = app
        self._limit_bytes = limit_bytes

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        content_length = _header_value(Headers(scope=scope), "content-length")
        declared_size = _parse_int(content_length)
        if declared_size is not None and declared_size > self._limit_bytes:
            await self._reject(scope, receive, send)
            return
        buffer = bytearray()
        size = 0
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            size += len(message.get("body", b""))
            if size > self._limit_bytes:
                await self._reject(scope, receive, send)
                return
            buffer.extend(message.get("body", b""))
            if not message.get("more_body", False):
                break
        buffered: Message = {
            "type": "http.request",
            "body": bytes(buffer),
            "more_body": False,
        }
        del buffer
        delivered = False

        async def replay() -> Message:
            nonlocal delivered
            if delivered:
                return await receive()
            delivered = True
            return buffered

        await self.app(scope, replay, send)

    async def _reject(self, scope: Scope, receive: Receive, send: Send) -> None:
        response = JSONResponse(
            status_code=413,
            content={
                "detail": "Request body too large",
                "limit_bytes": self._limit_bytes,
            },
        )
        await response(scope, receive, send)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Bounded client rate limiter that does not trust credential headers."""

    _MAX_BUCKETS = 1024

    def __init__(
        self,
        app: ASGIApp,
        *,
        requests_per_minute: int,
        burst: int,
    ) -> None:
        super().__init__(app)
        self._requests_per_minute = requests_per_minute
        self._burst = burst
        self._buckets: dict[str, _RateBucket] = {}
        self._next_cleanup = 0.0

    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        if request.url.path == "/health":
            return await call_next(request)

        key = _rate_limit_key(request)
        now = time.monotonic()
        if now >= self._next_cleanup:
            self._buckets = {
                existing_key: value
                for existing_key, value in self._buckets.items()
                if now < value.reset_at
            }
            self._next_cleanup = now + 60
        if key not in self._buckets and len(self._buckets) >= self._MAX_BUCKETS - 1:
            key = "client:overflow"
        bucket = self._buckets.get(key)
        if bucket is None or now >= bucket.reset_at:
            bucket = _RateBucket(
                remaining=self._requests_per_minute + self._burst - 1,
                reset_at=now + 60,
            )
            self._buckets[key] = bucket
            return await call_next(request)

        if bucket.remaining <= 0:
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded"},
                headers={"Retry-After": str(max(1, int(bucket.reset_at - now)))},
            )

        bucket.remaining -= 1
        return await call_next(request)


@dataclass
class _RateBucket:
    remaining: int
    reset_at: float


def _header_value(headers: Headers, name: str) -> str | None:
    value = headers.get(name)
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def _rate_limit_key(request: Request) -> str:
    if request.client is None:
        return "client:unknown"
    return f"client:{request.client.host}"


def _parse_int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None
