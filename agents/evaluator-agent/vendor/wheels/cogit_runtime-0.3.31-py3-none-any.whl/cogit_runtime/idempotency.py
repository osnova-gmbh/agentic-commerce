"""Idempotency-Key tracking for runtime write endpoints."""

from __future__ import annotations

from threading import RLock


class IdempotencyStore:
    """Thread-safe map from idempotency key to a stored execution id.

    The runtime uses this to return the same run id when a client retries a
    ``POST /runs`` with the same ``Idempotency-Key`` header before the request
    has been evicted. The store is in-memory; a durable version will land with
    the persistence slice.
    """

    def __init__(self) -> None:
        self._lock = RLock()
        self._keys: dict[str, str] = {}

    def get(self, key: str) -> str | None:
        with self._lock:
            return self._keys.get(key)

    def put(self, key: str, execution_id: str) -> str:
        with self._lock:
            existing = self._keys.get(key)
            if existing is not None:
                return existing
            self._keys[key] = execution_id
            return execution_id

    def scoped_key(self, tenant_id: str, agent_id: str, key: str) -> str:
        return f"{tenant_id}::{agent_id}::{key}"
