"""Structured JSON logging and optional OTEL export for the runtime."""

from __future__ import annotations

import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any, ClassVar

from cogit_runtime.config import ObservabilityConfig, RuntimeEnvironment


class JsonLogFormatter(logging.Formatter):
    """Formatter that emits a stable JSON envelope per log record.

    The runtime prefers structured logs so downstream ingest can filter by
    ``correlation_id`` and ``execution_id``. Extra fields attached with
    ``logger.info(msg, extra=...)`` land under ``ctx``.
    """

    default_fields: ClassVar[set[str]] = {
        "levelname",
        "levelno",
        "pathname",
        "filename",
        "module",
        "exc_info",
        "exc_text",
        "stack_info",
        "lineno",
        "funcName",
        "created",
        "msecs",
        "relativeCreated",
        "thread",
        "threadName",
        "processName",
        "process",
        "message",
        "name",
        "args",
        "asctime",
    }

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.now(UTC).isoformat(),
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": record.getMessage(),
        }
        ctx: dict[str, Any] = {}
        for key, value in record.__dict__.items():
            if key in self.default_fields or key.startswith("_"):
                continue
            ctx[key] = value
        if ctx:
            payload["ctx"] = ctx
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=_json_default, ensure_ascii=False)


def configure_logging(
    config: ObservabilityConfig,
    environment: RuntimeEnvironment,
) -> logging.Logger:
    """Install the runtime JSON log handler and return the runtime logger."""

    level_name = (environment.log_level or config.log_level).upper()
    level = getattr(logging, level_name, logging.INFO)

    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setFormatter(JsonLogFormatter())

    root = logging.getLogger()
    for existing in list(root.handlers):
        root.removeHandler(existing)
    root.addHandler(handler)
    root.setLevel(level)

    runtime_logger = logging.getLogger("cogit_runtime")
    runtime_logger.setLevel(level)
    return runtime_logger


def _json_default(value: object) -> object:
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


__all__ = ["JsonLogFormatter", "configure_logging"]
