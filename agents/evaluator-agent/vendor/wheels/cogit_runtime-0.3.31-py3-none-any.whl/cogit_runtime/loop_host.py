"""SDK-backed loop host used by the runtime endpoints.

Wires the runtime's request/context/reporter machinery into the SDK loop
engine with explicit action and tool registries. Falls back to agent-provided
``handle_query`` and ``handle_run`` when declared on the resident agent;
otherwise runs the deterministic loop with the resolved model client and tool
bindings.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import logging
from collections.abc import Callable
from dataclasses import replace
from datetime import UTC, datetime
from threading import RLock
from typing import Any, Literal, cast

from cogit_agent_sdk.contracts import RunHandle
from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.loop import DefaultLoopHooks, SdkTruncationHooks
from cogit_agent_sdk.operations.contract import OperationInvocation
from cogit_agent_sdk.resident import CogitAgent
from cogit_agent_sdk.types import (
    ActionDescriptor,
    AgentDescriptor,
    AgentLoopConfig,
    AgentLoopResult,
    AgentLoopState,
    Context,
    ErrorInfo,
    ExecutionRecord,
    ExecutionStepRecord,
    Message,
    ModelClient,
    ModelDescriptor,
    QueryRequest,
    QueryResult,
    RunBudget,
    RunRequest,
    RunResult,
    TextContent,
    ToolDescriptor,
    Usage,
)

from cogit_runtime.agentdb.errors import AgentDbError
from cogit_runtime.agentdb.handle import AgentDbRunHandle
from cogit_runtime.approvals import ApprovalStore
from cogit_runtime.cancellation import (
    CancellationRegistry,
    RuntimeCancellation,
    RuntimeCancelledError,
    RuntimeWorkDeferred,
    await_runtime_completion,
)
from cogit_runtime.canonical_approval import build_canonical_approval_preflight
from cogit_runtime.config import RuntimeConfig
from cogit_runtime.cooperative_worker import (
    WorkerStillRunningError,
    call_maybe_async,
    to_thread_cooperatively,
)
from cogit_runtime.coordination import finish_cleanup_async
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.hooks import (
    CompositeLoopHooks,
    RuntimeReporterHooks,
)
from cogit_runtime.loop.engine import RuntimeAgentLoopEngine
from cogit_runtime.loop_config import resolve_loop_defaults, validate_loop_config
from cogit_runtime.model import resolve_model_descriptor
from cogit_runtime.model_diagnostics import capture_model_diagnostics
from cogit_runtime.operations.approval_gate import ApprovalSource
from cogit_runtime.operations.errors import OperationExecutionError
from cogit_runtime.operations.executor import OperationExecutor
from cogit_runtime.operations.executor_support import invoke_operation_callable
from cogit_runtime.operations.preflight import build_approval_preflight
from cogit_runtime.operations.registry import (
    RuntimeActionRegistry,
    RuntimeToolRegistry,
    freeze_agent_tool_registration,
)
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.pipeline import PipelineResult, PipelineRunner, PipelineStep
from cogit_runtime.pipeline_completion import complete_pipeline
from cogit_runtime.pipeline_resolve import resolve_pipeline, to_runtime_steps
from cogit_runtime.readiness import ModelInvocationPolicy
from cogit_runtime.reporter import RunReporter
from cogit_runtime.run_output import serialize_run_output
from cogit_runtime.runtime_handle import RuntimeRunHandle
from cogit_runtime.store import RuntimeStore
from cogit_runtime.tools.broker import ToolBroker

RunStatus = Literal["completed", "failed", "partial", "cancelled", "waiting"]
logger = logging.getLogger(__name__)


class SdkLoopHost:
    """Loop host that runs the SDK ``AgentLoopEngine`` under the runtime."""

    def __init__(
        self,
        *,
        agent: object,
        descriptor: AgentDescriptor,
        config: RuntimeConfig,
        reporter: RunReporter,
        model_client: ModelClient,
        model_policy: ModelInvocationPolicy | None = None,
        cancellations: CancellationRegistry,
        store: RuntimeStore | None = None,
        approvals: ApprovalStore | None = None,
        dev_mode: bool = False,
        handle_factory: Callable[[str, Context], RunHandle] | None = None,
        external_execution: bool = False,
        loop_integrity_key: bytes | None = None,
        action_registry: RuntimeActionRegistry | None = None,
        tool_registry: RuntimeToolRegistry | None = None,
    ) -> None:
        self._agent = agent
        self._descriptor = descriptor
        self._config = config
        self._reporter = reporter
        self._model_client = model_client
        self._model_policy = model_policy
        self._cancellations = cancellations
        self._store = store
        self._approvals = approvals
        self._dev_mode = dev_mode
        self._handle_factory = handle_factory
        self._external_execution = external_execution
        self._loop_integrity_key = loop_integrity_key
        self._registry = action_registry or RuntimeActionRegistry.from_agent(agent)
        freeze_agent_tool_registration(agent)
        self._tool_registry = tool_registry or RuntimeToolRegistry.from_agent(agent)
        from cogit_runtime.policy import RuntimePolicyGate

        self._policy = RuntimePolicyGate.from_descriptor(descriptor)
        self._executor = OperationExecutor(
            invoke=invoke_operation_callable, policy=self._policy
        )
        self._tool_broker = ToolBroker(
            registry=self._tool_registry,
            executor=self._executor,
            approvals=approvals,
            reporter=reporter,
            track_deferred_task=self.track_deferred_task,
        )
        self._actions_by_name: dict[str, ActionDescriptor] = (
            self._registry.descriptors_by_name()
        )
        self._tools_by_name: dict[str, ToolDescriptor] = (
            self._tool_registry.descriptors_by_name()
        )
        self._handles: dict[str, RunHandle] = {}
        self._active_handles: set[str] = set()
        self._handles_lock = RLock()
        self._deferred_tasks: set[asyncio.Task[Any]] = set()
        self._deferred_coordination_failure: CoordinationFailure | None = None

    async def query(
        self,
        request: QueryRequest,
        context: Context,
        reporter: RunReporter,
        execution_id: str,
    ) -> QueryResult:
        if self._policy is None:
            return await self._query_unchecked(request, context, reporter, execution_id)
        from cogit_runtime.policy_run import RunPolicyBoundary

        boundary = RunPolicyBoundary(
            self._policy,
            self._make_handle(
                execution_id, self._context_with_execution(context, execution_id)
            ),
            request.model_dump(mode="json"),
        )

        async def call() -> QueryResult:
            result = await self._query_unchecked(
                request, context, reporter, execution_id
            )
            boundary.after(result.model_dump(mode="json"), succeeded=True)
            return result

        return await boundary.run(call, reporter)

    async def _query_unchecked(
        self,
        request: QueryRequest,
        context: Context,
        reporter: RunReporter,
        execution_id: str,
    ) -> QueryResult:
        self.validate_query_request(request, context)
        handle = self._begin_handle(
            execution_id,
            self._context_with_execution(context, execution_id),
        )
        owns_cancellation = False
        deferred_cleanup = False
        try:
            cancellation = self._cancellations.create(
                execution_id,
                on_cancel=handle.cancel,
            )
            owns_cancellation = True
            cancellation.throw_if_cancelled()
            override = self._agent_method("handle_query")
            if override is not None:
                result = await call_maybe_async(
                    override,
                    request,
                    context,
                    handle,
                    cancellation=cancellation,
                )
                cancellation.throw_if_cancelled()
                return _coerce_query_result(result, request.query)

            loop_result = await to_thread_cooperatively(
                self._run_engine,
                cooperative_cancellation=cancellation,
                text_input=request.query,
                context=self._context_with_execution(context, execution_id),
                execution_id=execution_id,
                cancellation=cancellation,
                override_budget=None,
                override_max_turns=None,
            )
            return _loop_result_to_query(loop_result)
        except CoordinationFailure:
            raise
        except WorkerStillRunningError as pending:
            deferred_cleanup = True
            completion = self._defer_cancelled_execution(
                pending.task,
                reporter,
                execution_id,
                operation="Query",
            )
            raise RuntimeWorkDeferred(completion) from None
        except RuntimeCancelledError:
            reporter.complete(
                execution_id,
                status="cancelled",
                output_summary="Query cancelled",
                outcome_label="cancelled",
                error=_cancelled_error(),
            )
            raise
        except asyncio.CancelledError:
            cancellation.cancel()
            reporter.complete(
                execution_id,
                status="cancelled",
                output_summary="Query cancelled",
                outcome_label="cancelled",
                error=_cancelled_error(),
            )
            raise
        except Exception as exc:
            reporter.complete(
                execution_id,
                status="failed",
                output_summary=f"Query failed ({type(exc).__name__})",
                outcome_label="unhandled_exception",
                error=ErrorInfo(
                    code="QUERY_ERROR",
                    message=f"Query failed ({type(exc).__name__})",
                    retryable=False,
                ),
            )
            raise
        finally:
            if not deferred_cleanup:
                await finish_cleanup_async(
                    lambda: (
                        self._cancellations.release(execution_id)
                        if owns_cancellation
                        else None
                    ),
                    lambda: self._end_handle(execution_id),
                )

    def validate_query_request(self, request: QueryRequest, context: Context) -> None:
        """Reject unsupported query options before a run record is opened."""

        if self._model_policy is not None:
            self._model_policy.require_query(request, context)

    def validate_run_request(self, request: RunRequest, context: Context) -> None:
        """Validate manifest pipeline selection and action references."""
        if self._model_policy is not None:
            self._model_policy.require_run(request, context)
        pipeline = resolve_pipeline(self._descriptor, request, context)
        if pipeline is not None:
            to_runtime_steps(
                self._descriptor,
                pipeline,
                initial_payload=request.input,
            )
        elif (
            self._model_policy is not None
            and self._model_policy.profile.kind == "disabled"
            and self._agent_method("handle_run") is None
        ):
            raise RuntimeConfigurationError(
                "Disabled model profile requires a matching deterministic pipeline"
            )

    async def run(
        self,
        request: RunRequest,
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        *,
        parent_cancellation: RuntimeCancellation | None = None,
        reserved_cancellation: RuntimeCancellation | None = None,
    ) -> RunResult:
        if self._policy is None:
            return await self._run_unchecked(
                request,
                context,
                reporter,
                execution_id,
                parent_cancellation=parent_cancellation,
                reserved_cancellation=reserved_cancellation,
            )
        from cogit_runtime.policy_run import RunPolicyBoundary

        boundary = RunPolicyBoundary(
            self._policy,
            self._make_handle(
                execution_id, self._context_with_execution(context, execution_id)
            ),
            request.model_dump(mode="json"),
        )
        return await boundary.run(
            lambda: self._run_unchecked(
                request,
                context,
                reporter,
                execution_id,
                parent_cancellation=parent_cancellation,
                reserved_cancellation=reserved_cancellation,
            ),
            reporter,
        )

    async def _run_unchecked(
        self,
        request: RunRequest,
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        *,
        parent_cancellation: RuntimeCancellation | None = None,
        reserved_cancellation: RuntimeCancellation | None = None,
    ) -> RunResult:
        self.validate_run_request(request, context)
        pipeline = resolve_pipeline(self._descriptor, request, context)
        if pipeline is not None:
            try:
                return await self._run_manifest_pipeline(
                    request,
                    context,
                    reporter,
                    execution_id,
                    pipeline_name=pipeline.name,
                    parent_cancellation=parent_cancellation,
                    reserved_cancellation=reserved_cancellation,
                )
            except RuntimeWorkDeferred as pending:
                completion = self._defer_pipeline_settlement(
                    pending.completion,
                    reporter,
                    execution_id,
                    pipeline_name=pipeline.name,
                )
                raise RuntimeWorkDeferred(completion) from None
            except CoordinationFailure:
                raise
            except RuntimeCancelledError:
                completed = reporter.complete(
                    execution_id,
                    status="cancelled",
                    output_summary="Run cancelled",
                    outcome_label="cancelled",
                    error=_cancelled_error(),
                )
                return _cancelled_run_result(completed)
            except Exception as exc:
                reporter.complete(
                    execution_id,
                    status="failed",
                    output_summary=f"Run failed ({type(exc).__name__})",
                    outcome_label="unhandled_exception",
                    error=_safe_run_error(exc),
                )
                raise

        handle = self._begin_handle(
            execution_id,
            self._context_with_execution(context, execution_id),
        )
        owns_cancellation = False
        deferred_cleanup = False
        try:
            if reserved_cancellation is not None:
                cancellation = reserved_cancellation
                cancellation.bind(handle.cancel)
            else:
                cancellation = self._cancellations.create(
                    execution_id,
                    parent=parent_cancellation,
                    on_cancel=handle.cancel,
                )
                owns_cancellation = True
            cancellation.throw_if_cancelled()
            override = self._agent_method("handle_run")
            if override is not None:
                agent_result = await call_maybe_async(
                    override,
                    request,
                    context,
                    handle,
                    cancellation=cancellation,
                )
                cancellation.throw_if_cancelled()
                if isinstance(agent_result, RunResult):
                    completed = reporter.complete(
                        execution_id,
                        status=agent_result.status,
                        output_summary=serialize_run_output(agent_result.output),
                        outcome_label=agent_result.outcome_label,
                        usage=agent_result.usage,
                        error=agent_result.error,
                    )
                    return agent_result.model_copy(
                        update={
                            "execution_record": completed,
                            "work_outcome": agent_result.work_outcome
                            or handle.work_outcome,
                        }
                    )
                usage = _handle_usage_or_none(handle.usage)
                record = reporter.complete(
                    execution_id,
                    status="completed",
                    output_summary=serialize_run_output(agent_result),
                    outcome_label=handle.outcome_label or "handle_run",
                    usage=usage,
                )
                return RunResult(
                    execution_record=record,
                    output=agent_result,
                    status="completed",
                    outcome_label=handle.outcome_label or "handle_run",
                    usage=usage,
                    work_outcome=handle.work_outcome,
                )

            loop_result = await to_thread_cooperatively(
                self._run_engine,
                cooperative_cancellation=cancellation,
                text_input=request.instruction,
                context=self._context_with_execution(context, execution_id),
                execution_id=execution_id,
                cancellation=cancellation,
                override_budget=request.budget,
                override_max_turns=None,
                override_model=_coerce_request_model(request.model),
            )

            status_value, outcome_label = _loop_to_run_status(loop_result)
            if cancellation.cancelled:
                status_value = "cancelled"
                outcome_label = "cancelled"
            if (
                status_value != "cancelled"
                and self._approvals is not None
                and self._approvals.pending_for_execution(execution_id)
            ):
                status_value = "waiting"
                outcome_label = "waiting_for_approval"
            output = loop_result.output
            terminal = loop_result.terminal_result
            if (
                output is None
                and status_value == "completed"
                and loop_result.stop_reason == "terminal_tool"
                and terminal is not None
                and not terminal.is_error
            ):
                output = terminal.details
            completed = reporter.complete(
                execution_id,
                status=status_value,
                output_summary=serialize_run_output(output),
                outcome_label=outcome_label,
                usage=loop_result.usage,
                error=loop_result.error,
            )
            return RunResult(
                execution_record=completed,
                output=output,
                status=status_value,
                outcome_label=outcome_label,
                usage=loop_result.usage,
                error=loop_result.error,
                work_outcome=handle.work_outcome,
            )
        except CoordinationFailure:
            raise
        except WorkerStillRunningError as pending:
            deferred_cleanup = True
            completion = self._defer_cancelled_execution(
                pending.task,
                reporter,
                execution_id,
                operation="Run",
            )
            raise RuntimeWorkDeferred(completion) from None
        except RuntimeCancelledError:
            completed = reporter.complete(
                execution_id,
                status="cancelled",
                output_summary="Run cancelled",
                outcome_label="cancelled",
                error=_cancelled_error(),
            )
            return _cancelled_run_result(completed)
        except asyncio.CancelledError:
            cancellation.cancel()
            reporter.complete(
                execution_id,
                status="cancelled",
                output_summary="Run cancelled",
                outcome_label="cancelled",
                error=_cancelled_error(),
            )
            raise
        except Exception as exc:
            completed = reporter.complete(
                execution_id,
                status="failed",
                output_summary=f"Run failed ({type(exc).__name__})",
                outcome_label="unhandled_exception",
                error=_safe_run_error(exc),
            )
            if (
                handle.work_outcome is not None
                and handle.work_outcome.outcome != "completed"
                and not isinstance(exc, AgentDbError)
            ):
                return RunResult(
                    execution_record=completed,
                    status="failed",
                    error=_safe_run_error(exc),
                    work_outcome=handle.work_outcome,
                )
            raise
        finally:
            if not deferred_cleanup:
                await finish_cleanup_async(
                    lambda: (
                        self._cancellations.release(execution_id)
                        if owns_cancellation
                        else None
                    ),
                    lambda: self._end_handle(execution_id),
                )

    async def _run_manifest_pipeline(
        self,
        request: RunRequest,
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        *,
        pipeline_name: str,
        parent_cancellation: RuntimeCancellation | None = None,
        reserved_cancellation: RuntimeCancellation | None = None,
    ) -> RunResult:
        pipeline = resolve_pipeline(self._descriptor, request, context)
        if pipeline is None or pipeline.name != pipeline_name:
            raise RuntimeConfigurationError(
                f"Pipeline '{pipeline_name}' could not be resolved"
            )
        steps = to_runtime_steps(
            self._descriptor,
            pipeline,
            initial_payload=request.input,
        )
        pipeline_owner = (
            context.queue_item_id
            if self._external_execution
            else context.case_id or execution_id
        )
        if self._external_execution:
            from cogit_runtime.agentdb.handle import AgentDbRunHandle

            canonical_handle = self._make_handle(execution_id, context)
            if isinstance(canonical_handle, AgentDbRunHandle):
                pipeline_owner = str(canonical_handle.continuation.original_work_id)
        pipeline_result = await self.run_pipeline(
            steps,
            context,
            reporter,
            execution_id,
            parent_cancellation=parent_cancellation,
            reserved_cancellation=reserved_cancellation,
            pipeline_id=(
                str((request.metadata or {}).get("pipeline_id"))
                if (request.metadata or {}).get("pipeline_id")
                else f"{pipeline_owner}:{pipeline.name}"
            ),
        )

        return complete_pipeline(
            pipeline_result,
            reporter,
            execution_id,
            pipeline_name=pipeline.name,
            waiting_for_approval=bool(
                self._approvals and self._approvals.pending_for_execution(execution_id)
            ),
        )

    async def action(
        self,
        action_name: str,
        payload: dict[str, Any],
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        *,
        parent_cancellation: RuntimeCancellation | None = None,
        idempotency_key: str | None = None,
        approval_id: str | None = None,
        approval_source: ApprovalSource = "action",
    ) -> Any:
        result = await self.execute_bound_action(
            action_name,
            payload,
            context,
            execution_id,
            parent_cancellation=parent_cancellation,
            idempotency_key=idempotency_key,
            approval_id=approval_id,
            approval_source=approval_source,
            reporter=reporter,
        )
        if result.status == "succeeded":
            return result.output
        if result.status == "cancelled":
            message = (
                result.error.message
                if result.error is not None
                else "Operation was cancelled"
            )
            raise RuntimeCancelledError(message)
        raise OperationExecutionError(result)

    async def execute_action_for_worker(
        self,
        action_name: str,
        payload: dict[str, Any],
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        approval_id: str | None,
        *,
        idempotency_key: str | None = None,
    ) -> OperationExecutionResult:
        """Worker adapter that routes continuations through the shared approval gate."""

        if (
            idempotency_key is None
            and approval_id is not None
            and self._approvals is not None
        ):
            from cogit_runtime.operations.approval_gate import idempotency_key_from_item

            idempotency_key = idempotency_key_from_item(
                self._approvals.get(approval_id)
            )

        return await self.execute_bound_action(
            action_name,
            payload,
            context,
            execution_id,
            approval_id=approval_id,
            approval_source="continuation" if approval_id else "action",
            idempotency_key=idempotency_key,
            reporter=reporter,
        )

    async def execute_bound_action(
        self,
        action_name: str,
        payload: dict[str, Any],
        context: Context,
        execution_id: str,
        *,
        parent_cancellation: RuntimeCancellation | None = None,
        idempotency_key: str | None = None,
        cancellation: RuntimeCancellation | None = None,
        manage_lifecycle: bool = True,
        approval_id: str | None = None,
        approval_source: ApprovalSource = "action",
        reporter: RunReporter | None = None,
        key_source: Literal["caller", "generated"] = "caller",
    ) -> OperationExecutionResult:
        if self._model_policy is not None:
            self._model_policy.require_context(context)
        binding = self._registry.require(action_name)
        descriptor = binding.descriptor
        exec_context = self._context_with_execution(context, execution_id)
        if manage_lifecycle:
            handle = self._begin_handle(execution_id, exec_context)
        else:
            handle = self._make_handle(execution_id, exec_context)
        owns_cancellation = False
        deferred_cleanup = False
        try:
            if cancellation is None:
                cancellation = self._cancellations.create(
                    execution_id,
                    parent=parent_cancellation,
                    on_cancel=handle.cancel,
                )
                owns_cancellation = True
            elif isinstance(cancellation, RuntimeCancellation):
                cancellation.bind(handle.cancel)
            invocation = OperationInvocation(
                context=exec_context,
                handle=handle,
                cancellation=cancellation,
                idempotency_key=idempotency_key,
            )
            before_invoke = build_approval_preflight(
                descriptor=descriptor,
                exposure_name=action_name,
                context=context,
                execution_id=execution_id,
                approval_id=approval_id,
                idempotency_key=idempotency_key,
                approvals=self._approvals,
                reporter=reporter or self._reporter,
                source=approval_source,
            )
            if isinstance(handle, AgentDbRunHandle):
                before_invoke = build_canonical_approval_preflight(
                    descriptor=descriptor,
                    exposure_name=action_name,
                    handle=handle,
                    context=exec_context,
                )

            with capture_model_diagnostics(reporter or self._reporter, execution_id):
                result = await self._executor.execute(
                    binding.operation,
                    descriptor.requirements,
                    descriptor.name,
                    payload,
                    invocation,
                    cancellation=cancellation,
                    before_invoke=before_invoke,
                    key_for=binding.key_for,
                    key_source=key_source,
                )
            return replace(result, work_outcome=handle.work_outcome)
        except CoordinationFailure:
            raise
        except WorkerStillRunningError as pending:
            deferred_cleanup = True
            completion = self._defer_cancelled_execution(
                pending.task,
                self._reporter,
                execution_id,
                operation="Action",
            )
            raise RuntimeWorkDeferred(completion) from None
        except asyncio.CancelledError:
            if isinstance(cancellation, RuntimeCancellation):
                cancellation.cancel()
            return OperationExecutionResult(
                status="cancelled",
                error=_cancelled_error(),
                invocation_started=True,
            )
        finally:
            if not deferred_cleanup:
                await finish_cleanup_async(
                    lambda: (
                        self._cancellations.release(execution_id)
                        if owns_cancellation
                        else None
                    ),
                    lambda: (
                        self._end_handle(execution_id) if manage_lifecycle else None
                    ),
                )

    def action_descriptor(self, action_name: str) -> ActionDescriptor | None:
        return self._actions_by_name.get(action_name)

    def resolve_pipeline_key(
        self,
        action_name: str,
        payload: dict[str, Any],
        context: Context,
        generated: str,
    ) -> str | None:
        from cogit_agent_sdk.operations.contract import OperationError

        from cogit_runtime.operations.executor_support import (
            missing_capabilities,
            resolve_idempotency_key,
        )

        binding = self._registry.require(action_name)
        descriptor = binding.descriptor
        capability_error = missing_capabilities(
            descriptor.requirements, action_name, context
        )
        if capability_error is not None:
            raise OperationError(capability_error)
        request = binding.operation.input_model.model_validate(payload)
        key, error = resolve_idempotency_key(
            key_for=binding.key_for,
            request=request,
            context=context,
            supplied_key=generated if descriptor.idempotency == "keyed" else None,
            key_source="generated",
            idempotency=descriptor.idempotency,
            exposure_name=action_name,
        )
        if error is not None:
            raise OperationError(error)
        return key

    async def run_pipeline(
        self,
        steps: list[PipelineStep],
        context: Context,
        reporter: RunReporter,
        execution_id: str,
        *,
        parent_cancellation: RuntimeCancellation | None = None,
        reserved_cancellation: RuntimeCancellation | None = None,
        pipeline_id: str | None = None,
    ) -> PipelineResult:
        """Execute a pipeline of steps with checkpoint/recovery.

        Parameters
        ----------
        steps:
            Ordered list of pipeline steps.
        context:
            Request context â€” ``case_id`` is propagated to each step.
        reporter:
            Run reporter for execution tracking.
        execution_id:
            Unique ID for this pipeline execution.
        pipeline_id:
            Optional explicit pipeline ID for checkpoint recovery.

        Returns
        -------
        PipelineResult
            Aggregate result with per-step outcomes.

        Raises
        ------
        RuntimeError
            If no store is configured (required for checkpointing).
        """
        if self._model_policy is not None:
            self._model_policy.require_context(context)
        if self._store is None:
            msg = "PipelineRunner requires a runtime store for checkpointing"
            raise RuntimeError(msg)

        handle = self._begin_handle(
            execution_id,
            self._context_with_execution(context, execution_id),
        )
        owns_cancellation = False
        deferred_cleanup = False
        try:
            from cogit_runtime.agentdb.handle import AgentDbRunHandle
            from cogit_runtime.canonical_pipeline import CanonicalPipelineRunner

            runner_options: dict[str, Any] = {
                "steps": steps,
                "store": self._store,
                "pipeline_id": pipeline_id,
                "approvals": self._approvals,
                "external_execution": self._external_execution,
                "agent_version": self._descriptor.version,
            }
            runner = (
                CanonicalPipelineRunner(handle=handle, **runner_options)
                if self._external_execution and isinstance(handle, AgentDbRunHandle)
                else PipelineRunner(**runner_options)
            )
            if reserved_cancellation is not None:
                cancellation = reserved_cancellation
                cancellation.bind(handle.cancel)
            else:
                cancellation = self._cancellations.create(
                    execution_id,
                    parent=parent_cancellation,
                    on_cancel=handle.cancel,
                )
                owns_cancellation = True
            cancellation.throw_if_cancelled()
            result = await runner.execute(
                loop_host=self,
                context=context,
                reporter=reporter,
                execution_id=execution_id,
                cancellation=cancellation,
            )
            return result
        except RuntimeWorkDeferred as pending:
            deferred_cleanup = True
            completion = self._defer_pipeline_cleanup(
                pending.completion,
                execution_id,
            )
            raise RuntimeWorkDeferred(completion) from None
        finally:
            if not deferred_cleanup:
                await finish_cleanup_async(
                    lambda: (
                        self._cancellations.release(execution_id)
                        if owns_cancellation
                        else None
                    ),
                    lambda: self._end_handle(execution_id),
                )

    async def run_canonical_step(
        self,
        *,
        instruction: str,
        context: Context,
        execution_id: str,
        cancellation: RuntimeCancellation | None,
        timeout_seconds: int | None,
    ) -> Any:
        from cogit_runtime.agentdb.errors import AgentDbAuthorityError
        from cogit_runtime.agentdb.handle import AgentDbRunHandle

        handle = self._make_handle(execution_id, context)
        if (
            not self._external_execution
            or not isinstance(handle, AgentDbRunHandle)
            or cancellation is None
        ):
            raise AgentDbAuthorityError(
                "Mixed pipeline requires its admitted canonical execution"
            )
        result = await to_thread_cooperatively(
            self._run_engine,
            cooperative_cancellation=cancellation,
            text_input=instruction,
            context=self._context_with_execution(context, execution_id),
            execution_id=execution_id,
            cancellation=cancellation,
            override_budget=None,
            override_max_turns=None,
            override_timeout_seconds=timeout_seconds,
        )
        status, _ = _loop_to_run_status(result)
        if status == "cancelled":
            raise RuntimeCancelledError("Canonical pipeline loop was cancelled")
        if status != "completed":
            raise RuntimeError(
                f"Canonical pipeline loop stopped ({result.stop_reason})"
            )
        return result.output

    # -- engine plumbing ------------------------------------------------

    def _run_engine(
        self,
        *,
        text_input: str,
        context: Context,
        execution_id: str,
        cancellation: RuntimeCancellation,
        override_budget: RunBudget | None,
        override_max_turns: int | None,
        override_model: ModelDescriptor | None = None,
        override_timeout_seconds: int | None = None,
    ) -> AgentLoopResult:
        cancellation.throw_if_cancelled()
        tool_bindings = self._tool_bindings()
        loop_config = self._resolve_loop_config(
            context=context,
            override_budget=override_budget,
            override_max_turns=override_max_turns,
            override_model=override_model,
            advertised_tools=[binding.descriptor for binding in tool_bindings],
        )
        if override_timeout_seconds is not None:
            existing = loop_config.wall_clock_timeout_seconds
            loop_config = loop_config.model_copy(
                update={
                    "wall_clock_timeout_seconds": min(
                        existing, override_timeout_seconds
                    )
                    if existing is not None
                    else override_timeout_seconds
                }
            )
        if self._model_policy is not None:
            self._model_policy.require_loop_config(loop_config, context)
        history = self._materialize_history(context)
        user_message = Message(
            role="user",
            content=[TextContent(text=text_input)],
            timestamp=datetime.now(UTC),
        )
        state = AgentLoopState(
            messages=[*history, user_message],
            context=context,
            session_id=context.session_id,
        )
        model_client = self._model_client
        model_hooks: list[object] = []
        recovery = None
        canonical_tools = None
        if self._model_policy is not None and self._model_policy.profile.canonical:
            from cogit_runtime.agentdb.handle import AgentDbRunHandle
            from cogit_runtime.agentdb.loop_model import CanonicalLoopModel
            from cogit_runtime.agentdb.loop_recovery import CanonicalLoopRecovery
            from cogit_runtime.agentdb.loop_tools import CanonicalLoopTools
            from cogit_runtime.model import GuardedModelClient

            handle = self._make_handle(execution_id, context)
            if not isinstance(handle, AgentDbRunHandle) or not isinstance(
                model_client, GuardedModelClient
            ):
                raise RuntimeConfigurationError(
                    "Canonical SDK loop requires an admitted handle"
                )
            prefix = (context.metadata or {}).get(
                "runtime_pipeline_slot", "sdk-loop/v1"
            )
            if not isinstance(prefix, str) or self._loop_integrity_key is None:
                raise RuntimeConfigurationError(
                    "Canonical SDK loop requires configured recovery"
                )
            recovery = CanonicalLoopRecovery(
                handle=handle,
                prefix=prefix,
                integrity_key=self._loop_integrity_key,
                config=loop_config,
                initial=state,
                definition={
                    "instruction": text_input,
                    "system_prompt": self._resolve_system_prompt(context)[0],
                    "agent_version": self._descriptor.version,
                },
                cancellation=cancellation,
            )
            state = recovery.state
            cancellation = recovery.cancellation
            canonical_tools = CanonicalLoopTools(
                recovery, self._tool_broker, self._policy
            )
            model_client = CanonicalLoopModel(
                handle, model_client, prefix=prefix, recovery=recovery
            )
            model_hooks.append(model_client)
        if self._policy is not None:
            from cogit_runtime.policy_run import RunPolicyBoundary

            model_hooks.append(
                RunPolicyBoundary(
                    self._policy,
                    self._make_handle(execution_id, context),
                    text_input,
                )
            )
        hooks = self._build_hooks(
            context=context, execution_id=execution_id, final_layers=model_hooks
        )
        engine = RuntimeAgentLoopEngine(
            model_client=model_client,
            tools=tool_bindings,
            hooks=hooks,
            cancellation=cancellation,
            tool_broker=self._tool_broker,
            execution_id=execution_id,
            handle_factory=self._make_handle,
            canonical_tools=canonical_tools,
        )
        try:
            with capture_model_diagnostics(self._reporter, execution_id):
                result = engine.run(state, loop_config)
        finally:
            if recovery is not None:
                recovery.cancellation.close()
        cancellation.throw_if_cancelled()
        self._persist_session_messages(
            context,
            result.state.messages,
            history_len=len(history),
        )
        return result

    def prompt_run_metadata(self, context: Context) -> dict[str, Any]:
        """Metadata for ``reporter.begin`` including the system prompt hash."""
        _, prompt_hash = self._resolve_system_prompt(context)
        metadata: dict[str, Any] = {}
        if prompt_hash is not None:
            metadata["prompt_hash"] = prompt_hash
        if self._config.policy_prompt:
            metadata["policy_prompt"] = True
        return metadata

    def _resolve_system_prompt(
        self,
        context: Context,
    ) -> tuple[str | None, str | None]:
        parts: list[str] = []
        system_prompt_method = self._agent_method("system_prompt")
        if system_prompt_method is not None:
            try:
                prompt_result = system_prompt_method(context)
                if prompt_result:
                    parts.append(str(prompt_result))
            except CoordinationFailure:
                raise
            except Exception:
                logger.exception(
                    "agent.system_prompt() failed for %r",
                    type(self._agent).__name__,
                )

        if self._config.policy_prompt:
            parts.append(self._config.policy_prompt)

        if not parts:
            return None, None
        text = "\n\n".join(parts)
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return text, digest

    def _build_hooks(
        self,
        *,
        context: Context,
        execution_id: str,
        final_layers: list[object] | None = None,
    ) -> CompositeLoopHooks:
        system_text, _prompt_hash = self._resolve_system_prompt(context)

        sdk_hooks = DefaultLoopHooks()
        agent_hooks_instance = None
        agent_hooks_method = self._agent_method("loop_hooks")
        if agent_hooks_method is not None:
            try:
                agent_hooks_instance = agent_hooks_method(context)
            except CoordinationFailure:
                raise
            except Exception:
                logger.exception(
                    "agent.loop_hooks() failed for %r",
                    type(self._agent).__name__,
                )

        reporter_hooks = RuntimeReporterHooks(
            reporter=self._reporter,
            execution_id=execution_id,
        )

        layers: list[object] = [sdk_hooks]
        if agent_hooks_instance is not None:
            layers.append(agent_hooks_instance)
        layers.extend(
            [
                SdkTruncationHooks(),
                reporter_hooks,
            ]
        )
        layers.extend(final_layers or [])

        return CompositeLoopHooks(layers=layers, system_prompt=system_text)

    def _materialize_history(self, context: Context) -> list[Message]:
        if not context.session_id or self._store is None:
            return []
        session = self._store.get_session(context.session_id)
        if session is None:
            return []
        max_history = self._config.session.max_history_messages
        if max_history <= 0:
            return []
        return list(session.messages[-max_history:])

    def _persist_session_messages(
        self,
        context: Context,
        messages: list[Message | Any],
        *,
        history_len: int,
    ) -> None:
        if not context.session_id or self._store is None:
            return
        max_history = self._config.session.max_history_messages
        # Everything after the prepended history is new to this run.
        new_messages = messages[history_len:]
        if not new_messages:
            return
        self._store.get_or_create_session(
            session_id=context.session_id,
            tenant_id=context.tenant_id,
            agent_id=context.agent_id or self._descriptor.id or self._descriptor.name,
        )
        self._store.append_session_messages(
            context.session_id,
            new_messages,
            max_history=max_history,
        )

    def _resolve_loop_config(
        self,
        *,
        context: Context,
        override_budget: RunBudget | None,
        override_max_turns: int | None,
        override_model: ModelDescriptor | None = None,
        advertised_tools: list[ToolDescriptor],
    ) -> AgentLoopConfig:
        method = self._agent_method("loop_config")
        selected = self._model_policy.selected_model if self._model_policy else None
        model_descriptor = (
            selected.descriptor()
            if selected is not None
            else resolve_model_descriptor(
                request_model=override_model,
                descriptor=self._descriptor.model,
                runtime=self._config.model,
            )
            or _default_model_descriptor()
        )
        local_echo = bool(
            self._model_policy
            and self._model_policy.profile.dev_mode
            and selected
            and selected.provider == "runtime"
        )
        if local_echo:
            # Echo produces text only. Direct operation endpoints retain their
            # registry, but the local model request must not advertise tools.
            advertised_tools = []
        elif not advertised_tools:
            advertised_tools = list(self._descriptor.tools)
        if method is not None:
            base = validate_loop_config(method(context))
            if self._model_policy is not None and base.model_descriptor is not None:
                declared = self._descriptor.model
                current = base.model_descriptor
                current_pair = (current.provider, current.model)
                selected_pair = (model_descriptor.provider, model_descriptor.model)
                declared_pair = (
                    (declared.provider, declared.model)
                    if declared is not None
                    else None
                )
                if current_pair not in {selected_pair, declared_pair}:
                    raise RuntimeConfigurationError(
                        "Custom loop model differs from the verified provider client"
                    )
                if current_pair == selected_pair:
                    self._model_policy.require_model(current)
                elif (
                    current.supports_tools and not model_descriptor.supports_tools
                ) or (
                    current.supports_streaming
                    and not model_descriptor.supports_streaming
                ):
                    raise RuntimeConfigurationError(
                        "Selected fallback lacks custom loop model capabilities"
                    )
            if (
                self._model_policy is not None
                or override_model is not None
                or base.model_descriptor is None
            ):
                base = base.model_copy(update={"model_descriptor": model_descriptor})
            if base.tools is None:
                base = base.model_copy(update={"tools": advertised_tools})
        else:
            base = AgentLoopConfig(
                label=self._descriptor.name,
                model_descriptor=model_descriptor,
                tools=advertised_tools,
            )
        return resolve_loop_defaults(
            base,
            self._config.loop,
            override_budget=override_budget,
            override_max_turns=override_max_turns,
        )

    def _tool_bindings(self) -> list[Any]:
        return list(self._tool_registry.bindings)

    @property
    def tool_broker(self) -> ToolBroker:
        return self._tool_broker

    @property
    def tool_registry(self) -> RuntimeToolRegistry:
        return self._tool_registry

    def _make_handle(self, execution_id: str, context: Context) -> RunHandle:
        with self._handles_lock:
            existing = self._handles.get(execution_id)
            if existing is not None:
                self._validate_handle_context(existing, context)
                return existing

            client = getattr(self._agent, "client", None)

            def _record_step(step: ExecutionStepRecord) -> None:
                self._reporter.record_step(step)

            if self._handle_factory is not None:
                handle = self._handle_factory(execution_id, context)
            else:
                handle = RuntimeRunHandle(
                    execution_id=execution_id,
                    context=context,
                    client=client,
                    step_recorder=_record_step,
                    diagnostic_limits=self._config.diagnostic_history,
                )
            if self._model_policy is not None:
                if not isinstance(handle, RuntimeRunHandle):
                    raise RuntimeConfigurationError(
                        "Hosted RunHandle must provide the Runtime model policy"
                    )
                handle.bind_model_policy(self._model_policy)
            self._handles[execution_id] = handle
            return handle

    def _begin_handle(self, execution_id: str, context: Context) -> RunHandle:
        with self._handles_lock:
            if execution_id in self._active_handles:
                raise RuntimeConfigurationError(
                    f"Execution '{execution_id}' is already active."
                )
            if (
                self._external_execution
                and len(self._active_handles)
                >= self._config.diagnostic_history.active_executions
            ):
                raise RuntimeConfigurationError(
                    "Worker-local active execution capacity is exhausted"
                )
            handle = self._make_handle(execution_id, context)
            self._active_handles.add(execution_id)
            return handle

    async def _end_handle(self, execution_id: str) -> None:
        with self._handles_lock:
            handle = self._handles.get(execution_id)
        try:
            callback = self._agent_method("execution_finished")
            if handle is not None and callback is not None:
                result = callback(handle.context)
                if inspect.isawaitable(result):
                    await result
        finally:
            with self._handles_lock:
                self._active_handles.discard(execution_id)
                self._handles.pop(execution_id, None)

    def _defer_cancelled_execution(
        self,
        worker_task: asyncio.Task[Any],
        reporter: RunReporter,
        execution_id: str,
        *,
        operation: str,
    ) -> asyncio.Task[None]:
        async def drain() -> None:
            uncertain = False
            try:
                await await_runtime_completion(worker_task)
            except CoordinationFailure:
                uncertain = True
                raise
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                logger.debug(
                    "%s worker exited after deferred cancellation (%s)",
                    operation,
                    type(exc).__name__,
                )
            finally:
                if not uncertain and reporter.get(execution_id) is not None:
                    reporter.complete(
                        execution_id,
                        status="cancelled",
                        output_summary=f"{operation} cancelled",
                        outcome_label="cancelled",
                        error=_cancelled_error(),
                    )
                await finish_cleanup_async(
                    lambda: self._cancellations.release(execution_id),
                    lambda: self._end_handle(execution_id),
                )

        return self.track_deferred_task(
            asyncio.create_task(
                drain(),
                name=f"cogit-drain-{execution_id}",
            )
        )

    def _defer_pipeline_cleanup(
        self,
        completion: asyncio.Future[Any],
        execution_id: str,
    ) -> asyncio.Task[Any]:
        async def drain() -> Any:
            try:
                return await await_runtime_completion(completion)
            finally:
                await finish_cleanup_async(
                    lambda: self._cancellations.release(execution_id),
                    lambda: self._end_handle(execution_id),
                )

        return self.track_deferred_task(
            asyncio.create_task(
                drain(),
                name=f"cogit-pipeline-drain-{execution_id}",
            )
        )

    def _defer_pipeline_settlement(
        self,
        completion: asyncio.Future[Any],
        reporter: RunReporter,
        execution_id: str,
        *,
        pipeline_name: str,
    ) -> asyncio.Task[RunResult]:
        async def settle() -> RunResult:
            try:
                pipeline_result = await await_runtime_completion(completion)
            except asyncio.CancelledError:
                logger.error(
                    "Pipeline checkpoint finalization was cancelled for %s",
                    execution_id,
                )
                raise
            except Exception as exc:
                logger.error(
                    "Pipeline checkpoint finalization failed for %s (%s)",
                    execution_id,
                    type(exc).__name__,
                )
                raise
            if not isinstance(pipeline_result, PipelineResult):
                logger.error(
                    "Deferred pipeline returned an invalid result for %s",
                    execution_id,
                )
                raise TypeError(
                    "Deferred pipeline completion returned an invalid result"
                )
            return complete_pipeline(
                pipeline_result,
                reporter,
                execution_id,
                pipeline_name=pipeline_name,
                waiting_for_approval=bool(
                    self._approvals
                    and self._approvals.pending_for_execution(execution_id)
                ),
            )

        return self.track_deferred_task(
            asyncio.create_task(
                settle(),
                name=f"cogit-pipeline-settle-{execution_id}",
            )
        )

    def track_deferred_task(self, task: asyncio.Task[Any]) -> asyncio.Task[Any]:
        if task.done():
            self._remember_deferred_failure(task)
            return task
        self._deferred_tasks.add(task)

        def finished(done: asyncio.Task[Any]) -> None:
            self._deferred_tasks.discard(done)
            self._remember_deferred_failure(done)

        task.add_done_callback(finished)
        return task

    def _remember_deferred_failure(self, task: asyncio.Task[Any]) -> None:
        if not task.cancelled():
            failure = task.exception()
            if (
                isinstance(failure, CoordinationFailure)
                and self._deferred_coordination_failure is None
            ):
                self._deferred_coordination_failure = failure

    async def drain_deferred(self) -> None:
        while self._deferred_tasks:
            pending = list(self._deferred_tasks)
            for task in pending:
                try:
                    await await_runtime_completion(task)
                except CoordinationFailure as exc:
                    if self._deferred_coordination_failure is None:
                        self._deferred_coordination_failure = exc
                except asyncio.CancelledError:
                    pass
                except Exception as exc:
                    logger.debug(
                        "Deferred runtime task exited with %s",
                        type(exc).__name__,
                    )
                finally:
                    self._deferred_tasks.discard(task)
        if self._deferred_coordination_failure is not None:
            raise self._deferred_coordination_failure

    @staticmethod
    def _validate_handle_context(handle: RunHandle, context: Context) -> None:
        identity = (
            "tenant_id",
            "correlation_id",
            "organization_id",
            "agent_id",
            "principal",
            "execution_id",
            "case_id",
            "queue_item_id",
            "session_id",
        )
        if any(
            getattr(handle.context, field) != getattr(context, field)
            for field in identity
        ):
            raise RuntimeConfigurationError(
                f"Execution '{handle.execution_id}' was reused "
                "with a different context."
            )

    def _agent_method(self, name: str) -> Any:
        class_method = getattr(type(self._agent), name, None)
        if class_method is getattr(CogitAgent, name, None):
            return None
        method = getattr(self._agent, name, None)
        return method if callable(method) else None

    @staticmethod
    def _context_with_execution(context: Context, execution_id: str) -> Context:
        if context.execution_id == execution_id:
            return context
        return context.model_copy(update={"execution_id": execution_id})


def _default_model_descriptor() -> ModelDescriptor:
    return ModelDescriptor(
        provider="runtime",
        model="echo",
        supports_tools=False,
        supports_streaming=False,
    )


def _coerce_request_model(value: Any) -> ModelDescriptor | None:
    if value is None:
        return None
    if isinstance(value, ModelDescriptor):
        return value
    if isinstance(value, dict):
        return ModelDescriptor.model_validate(value)
    return None


def _coerce_query_result(result: Any, query_text: str) -> QueryResult:
    if isinstance(result, QueryResult):
        return result
    if isinstance(result, str):
        return QueryResult(answer=result, interpretation=query_text)
    if isinstance(result, dict):
        data = cast(dict[str, Any], result)
        return QueryResult(data=data, interpretation=query_text)
    return QueryResult(data=result, interpretation=query_text)


def _loop_result_to_query(result: AgentLoopResult) -> QueryResult:
    answer = _stringify_output(result.output)
    return QueryResult(
        answer=answer,
        usage=result.usage,
        error=result.error,
    )


def _loop_to_run_status(
    result: AgentLoopResult,
) -> tuple[RunStatus, str]:
    if result.error is not None:
        if result.stop_reason == "cancelled":
            return "cancelled", "cancelled"
        return "failed", result.stop_reason
    if result.stop_reason == "completed":
        return "completed", "completed"
    if result.stop_reason == "terminal_tool":
        terminal = result.terminal_result
        label = terminal.tool_name if terminal is not None else "terminal_tool"
        return "completed", label
    return "partial", result.stop_reason


def _stringify_output(output: Any) -> str | None:
    if output is None:
        return None
    if isinstance(output, str):
        return output
    return str(output)


def _cancelled_error() -> ErrorInfo:
    return ErrorInfo(code="CANCELLED", message="Run was cancelled", retryable=False)


def _cancelled_run_result(record: ExecutionRecord) -> RunResult:
    return RunResult(
        execution_record=record,
        status="cancelled",
        outcome_label="cancelled",
        error=_cancelled_error(),
    )


def _safe_run_error(exc: Exception) -> ErrorInfo:
    return ErrorInfo(
        code="RUN_ERROR",
        message=f"Run failed ({type(exc).__name__})",
        retryable=False,
    )


def _handle_usage_or_none(usage: Usage) -> Usage | None:
    if usage.input_tokens or usage.output_tokens:
        return usage
    return None


__all__ = [
    "AgentLoopResult",
    "ErrorInfo",
    "PipelineResult",
    "PipelineStep",
    "SdkLoopHost",
    "Usage",
]
