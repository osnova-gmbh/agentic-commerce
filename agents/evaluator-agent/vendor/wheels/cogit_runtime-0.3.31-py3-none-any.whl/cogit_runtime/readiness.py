"""Production model profiles and guards shared by every execution entry."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

from cogit_agent_sdk.resident import CogitAgent
from cogit_agent_sdk.types import (
    AgentDescriptor,
    AgentLoopConfig,
    Context,
    ModelClient,
    ModelDescriptor,
    QueryRequest,
    RunBudget,
    RunRequest,
)

from cogit_runtime.agentdb.spend_policy import parse_spend, require_admitted_budget
from cogit_runtime.config import RuntimeConfig, RuntimeEnvironment
from cogit_runtime.errors import RuntimeConfigurationError

ModelProfileKind = Literal["sdk", "external", "disabled"]
_CAP_KEYS = frozenset(
    {
        "maxcost",
        "maxcostamount",
        "costbudget",
        "spendcap",
        "monetarycap",
        "admittedcap",
        "admittedcostcap",
        "modelbudget",
    }
)
_CLAIM_CAP_KEYS = _CAP_KEYS | {
    "budget",
    "spendcommitment",
    "modelspendcommitment",
    "pricecommitment",
    "modelspend",
}


@dataclass(frozen=True)
class ReadyModel:
    """Immutable identity and required capabilities of one configured model."""

    provider: str
    model: str
    supports_tools: bool
    supports_streaming: bool
    _descriptor_json: str | None = field(default=None, compare=False, repr=False)
    openai_api: Literal["chat_completions", "responses"] | None = None

    @classmethod
    def from_descriptor(cls, value: ModelDescriptor) -> ReadyModel:
        return cls(
            provider=value.provider.strip().lower(),
            model=value.model.strip(),
            supports_tools=value.supports_tools,
            supports_streaming=value.supports_streaming,
            _descriptor_json=value.model_dump_json(),
            openai_api=value.openai_api,
        )

    def descriptor(self) -> ModelDescriptor:
        if self._descriptor_json is not None:
            original = ModelDescriptor.model_validate_json(self._descriptor_json)
            return original.model_copy(
                update={
                    "provider": self.provider,
                    "model": self.model,
                    "supports_tools": self.supports_tools,
                    "supports_streaming": self.supports_streaming,
                    "openai_api": self.openai_api,
                }
            )
        return ModelDescriptor(
            provider=self.provider,
            model=self.model,
            supports_tools=self.supports_tools,
            supports_streaming=self.supports_streaming,
            openai_api=self.openai_api,
        )

    def require_model_api(self, requested: ModelDescriptor) -> None:
        if requested.openai_api is not None and requested.openai_api != (
            self.openai_api or "chat_completions"
        ):
            raise RuntimeConfigurationError(
                "Requested OpenAI API differs from the selected provider client"
            )


@dataclass(frozen=True)
class RuntimeModelProfile:
    """Read-only profile passed to a resident's class-level readiness hook."""

    kind: ModelProfileKind
    models: tuple[ReadyModel, ...]
    canonical: bool
    dev_mode: bool


def prepare_model_profile(
    descriptor: AgentDescriptor,
    config: RuntimeConfig,
    environment: RuntimeEnvironment,
    agent_class: type[Any],
) -> RuntimeModelProfile:
    """Validate immutable declarations before opening stores or constructing agents."""

    environment.validate_boot(config, worker_only=environment.runtime_role == "work")
    canonical = environment.agentdb is not None and not environment.dev_mode
    kind = config.model.profile
    if kind is None:
        if not environment.dev_mode:
            raise RuntimeConfigurationError(
                "Production runtime.model.profile must be sdk, external or disabled"
            )
        kind = "sdk"

    if (
        not environment.dev_mode
        and not canonical
        and config.loop.budget_defaults.max_cost is not None
    ):
        raise RuntimeConfigurationError(
            "Production max_cost declarations require canonical model reservations"
        )
    if canonical:
        protected_tools = any(tool.requires_approval for tool in descriptor.tools)
        protected_actions = any(
            action.requires_approval for action in descriptor.actions
        )
        if (protected_tools or protected_actions) and (
            environment.agentdb is None
            or environment.agentdb.approval_decider_id is None
            or (
                protected_tools
                and (kind != "sdk" or environment.agentdb.loop_integrity_key is None)
            )
        ):
            raise RuntimeConfigurationError(
                "Canonical approval declarations require supported resume decisions"
            )
        for pipeline in descriptor.pipelines or ():
            if pipeline.on_failure == "escalate" or any(
                step.on_failure == "escalate" for step in pipeline.steps
            ):
                raise RuntimeConfigurationError(
                    "Canonical pipeline escalation requires supported resume decisions"
                )
            if any(step.kind == "agentic" for step in pipeline.steps) and (
                kind != "sdk"
                or environment.agentdb is None
                or environment.agentdb.loop_integrity_key is None
            ):
                raise RuntimeConfigurationError(
                    "Canonical agentic pipelines require supported mixed-step recovery"
                )

    declared = descriptor.model
    if (
        not environment.dev_mode
        and declared is not None
        and (
            declared.provider == "runtime" or declared.model in {"echo", "runtime-echo"}
        )
    ):
        raise RuntimeConfigurationError(
            "Runtime echo is allowed only in explicit local mode"
        )

    models: list[ReadyModel] = []
    if kind == "disabled":
        if (
            declared is not None
            or config.model.fallbacks
            or config.model.allowed_models
        ):
            raise RuntimeConfigurationError(
                "A disabled model profile cannot declare models or fallbacks"
            )
    elif kind == "external":
        if declared is not None:
            raise RuntimeConfigurationError(
                "External model profiles cannot advertise an SDK loop model"
            )
        if not config.model.allowed_models or config.model.fallbacks:
            raise RuntimeConfigurationError(
                "External model profiles require allowed_models and no SDK fallbacks"
            )
        models = [
            ReadyModel.from_descriptor(
                ModelDescriptor(
                    provider=item.provider,
                    model=item.model.strip(),
                    supports_tools=item.supports_tools,
                    supports_streaming=item.supports_streaming,
                    context_window=item.context_window,
                    max_output_tokens=item.max_output_tokens,
                )
            )
            for item in config.model.allowed_models
        ]
    else:
        if config.model.allowed_models:
            raise RuntimeConfigurationError(
                "SDK model profiles cannot declare external allowed_models"
            )
        if declared is None:
            if not environment.dev_mode:
                raise RuntimeConfigurationError(
                    "Production SDK model profiles require a concrete model descriptor"
                )
            models = [ReadyModel("runtime", "echo", False, False)]
        else:
            models = [ReadyModel.from_descriptor(declared)]
            if not environment.dev_mode and config.model.adapter not in {
                "custom",
                models[0].provider,
            }:
                raise RuntimeConfigurationError(
                    "Runtime adapter and SDK model provider must agree"
                )
        for fallback in config.model.fallbacks or ():
            if isinstance(fallback, str):
                if not environment.dev_mode:
                    raise RuntimeConfigurationError(
                        "Production fallbacks require an explicit provider and model"
                    )
                continue
            models.append(
                ReadyModel.from_descriptor(
                    ModelDescriptor(
                        provider=fallback.adapter,
                        model=fallback.model.strip(),
                        supports_tools=fallback.supports_tools,
                        supports_streaming=fallback.supports_streaming,
                        context_window=fallback.context_window,
                        max_output_tokens=fallback.max_output_tokens,
                    )
                )
            )

    if len({(item.provider, item.model) for item in models}) != len(models):
        raise RuntimeConfigurationError(
            "Model allow-list contains duplicate provider/model"
        )
    for item in models:
        if not item.model or not item.provider:
            raise RuntimeConfigurationError("Model provider and name must be concrete")
        if item.provider not in {"runtime", "openai", "anthropic", "openrouter"}:
            raise RuntimeConfigurationError("Model provider is unsupported by Runtime")
        if item.provider == "runtime" and not environment.dev_mode:
            raise RuntimeConfigurationError(
                "Runtime echo is allowed only in explicit local mode"
            )
        if item.provider == "runtime" and item.model not in {"echo", "runtime-echo"}:
            raise RuntimeConfigurationError(
                "Runtime local model must be echo or runtime-echo"
            )
        if item.provider == "runtime" and (
            item.supports_tools or item.supports_streaming
        ):
            raise RuntimeConfigurationError(
                "Runtime echo cannot advertise tool or streaming capability"
            )
        if item.provider == "openrouter" and (
            item.supports_tools or item.supports_streaming
        ):
            raise RuntimeConfigurationError(
                "OpenRouter model capabilities require a verified "
                "model-specific profile"
            )
        if (
            descriptor.tools
            and kind == "sdk"
            and not item.supports_tools
            and not (environment.dev_mode and item.provider == "runtime")
        ):
            raise RuntimeConfigurationError(
                "Selected model cannot support declared SDK tools"
            )

    if (
        canonical
        and kind == "sdk"
        and (
            environment.agentdb is None
            or environment.agentdb.loop_integrity_key is None
        )
    ):
        raise RuntimeConfigurationError(
            "Canonical SDK loops require a stable deployment loop integrity key"
        )

    profile = RuntimeModelProfile(
        kind=kind,
        models=tuple(models),
        canonical=canonical,
        dev_mode=environment.dev_mode,
    )
    if canonical and kind in {"external", "disabled"}:
        run_handler = getattr(agent_class, "handle_run", None)
        if not callable(run_handler) or run_handler is CogitAgent.handle_run:
            queue_pipelines = [
                pipeline
                for pipeline in descriptor.pipelines or ()
                if "queue" in (pipeline.applies_to or ())
            ]
            if kind != "disabled" or len(queue_pipelines) != 1:
                raise RuntimeConfigurationError(
                    "Canonical non-SDK profiles require a concrete handle_run "
                    "or a disabled deterministic queue pipeline"
                )
            from cogit_runtime.pipeline_resolve import to_runtime_steps

            to_runtime_steps(descriptor, queue_pipelines[0])
    if kind == "external":
        hook = getattr(agent_class, "runtime_model_readiness", None)
        if not callable(hook):
            raise RuntimeConfigurationError(
                "External model profile requires class-level runtime_model_readiness"
            )
        try:
            result = hook(profile)
        except Exception as exc:
            raise RuntimeConfigurationError(
                "External model readiness failed before agent construction"
            ) from exc
        if result is not True:
            raise RuntimeConfigurationError("External model readiness was denied")
    return profile


class ModelInvocationPolicy:
    """One boot-verified model selection reused at every effect boundary."""

    def __init__(
        self,
        profile: RuntimeModelProfile,
        client: ModelClient,
        ready_models: tuple[ReadyModel, ...],
        selected_model: ReadyModel | None,
    ) -> None:
        self.profile = profile
        self.client = client
        self.ready_models = ready_models
        self.selected_model = selected_model

    def require_context(self, context: Context) -> None:
        metadata = dict(context.metadata or {})
        metadata.pop("model_spend", None)
        if self.profile.canonical and _contains_cap(metadata):
            raise RuntimeConfigurationError(
                "Canonical monetary-cap claims require model reservation support"
            )
        if self.profile.canonical and self.profile.kind != "disabled":
            require_admitted_budget(context, None)

    def require_run(self, request: RunRequest, context: Context) -> None:
        self.require_context(context)
        self._require_budget(request.budget, context)
        if _contains_cap(request.metadata):
            raise RuntimeConfigurationError(
                "Run monetary-cap metadata requires model reservation support"
            )
        if request.model is not None:
            if not isinstance(request.model, ModelDescriptor):
                try:
                    override = ModelDescriptor.model_validate(request.model)
                except Exception as exc:
                    raise RuntimeConfigurationError(
                        "Run model override is invalid"
                    ) from exc
            else:
                override = request.model
            self.require_model(override)

    def require_query(self, request: QueryRequest, context: Context) -> None:
        self.require_context(context)
        if _contains_cap(request.options):
            raise RuntimeConfigurationError(
                "Query monetary-cap overrides require model reservation support"
            )
        if isinstance(request.options, Mapping) and "model" in request.options:
            raise RuntimeConfigurationError(
                "Query model overrides require a verified provider selection"
            )

    def require_loop_config(
        self, config: AgentLoopConfig, context: Context | None = None
    ) -> None:
        self._require_budget(config.budget, context)
        if self.profile.kind != "sdk":
            raise RuntimeConfigurationError(
                "This model profile cannot dispatch the SDK model loop"
            )
        self.require_model(config.model_descriptor)
        if (
            config.tools
            and self.selected_model
            and not self.selected_model.supports_tools
        ):
            raise RuntimeConfigurationError("Selected model cannot dispatch tools")

    def require_model(self, descriptor: ModelDescriptor) -> None:
        selected = self.selected_model
        if selected is None or (descriptor.provider, descriptor.model) != (
            selected.provider,
            selected.model,
        ):
            raise RuntimeConfigurationError(
                "Requested model differs from the selected provider client"
            )
        selected.require_model_api(descriptor)
        if descriptor.supports_tools and not selected.supports_tools:
            raise RuntimeConfigurationError(
                "Requested model tool capability is unavailable"
            )
        if descriptor.supports_streaming and not selected.supports_streaming:
            raise RuntimeConfigurationError(
                "Requested model streaming capability is unavailable"
            )

    def require_external_model_dispatch(
        self,
        *,
        client: ModelClient,
        provider: str,
        model: str,
        budget: RunBudget | None = None,
        context: Context,
    ) -> None:
        self.require_context(context)
        self._require_budget(budget, context)
        if self.profile.kind != "external" or client is not self.client:
            raise RuntimeConfigurationError(
                "Direct model dispatch requires the Runtime-injected guarded client"
            )
        if (provider, model) not in {
            (item.provider, item.model) for item in self.ready_models
        }:
            raise RuntimeConfigurationError(
                "Direct model dispatch is outside the verified "
                "provider/model allow-list"
            )
        route_check = getattr(client, "require_ready_route", None)
        if not callable(route_check):
            raise RuntimeConfigurationError(
                "Direct model dispatch requires a verified Runtime route"
            )
        route_check(provider, model)

    def _require_budget(
        self, budget: RunBudget | None, context: Context | None = None
    ) -> None:
        if (
            budget is not None
            and budget.max_cost is not None
            and not self.profile.dev_mode
        ):
            if self.profile.canonical and context is not None:
                require_admitted_budget(context, budget)
                return
            raise RuntimeConfigurationError(
                "Monetary caps require canonical model reservation support"
            )


def _normalized_key(key: object) -> str:
    return str(key).replace("_", "").replace("-", "").lower()


def _contains_cap(value: Any, keys: frozenset[str] = _CAP_KEYS) -> bool:
    """Find cap fields in nested mappings and sequences without expanding text."""

    if isinstance(value, Mapping):
        return any(
            (_normalized_key(key) in keys and nested is not None)
            or _contains_cap(nested, keys)
            for key, nested in value.items()
        )
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return any(_contains_cap(nested, keys) for nested in value)
    return False


def reject_unreserved_claim_cap(claim: Any) -> None:
    """Accept only the strict canonical D12 admission; reject cap lookalikes."""

    raw: dict[str, Any] = {}
    if isinstance(claim, Mapping):
        raw.update(claim)
    else:
        attributes = getattr(claim, "__dict__", None)
        if isinstance(attributes, dict):
            raw.update(attributes)
        extras = getattr(claim, "model_extra", None)
        if isinstance(extras, Mapping):
            raw.update(extras)
        to_dict = getattr(claim, "to_dict", None)
        if callable(to_dict):
            serialized = to_dict()
            if isinstance(serialized, Mapping):
                raw.update(serialized)
    # Business input is not an admission claim; invoice payloads can contain
    # their own monetary fields without granting model spend authority.
    raw.pop("input", None)
    for key in ("modelSpend", "model_spend"):
        spend = raw.get(key)
        if spend is not None:
            parsed = parse_spend(spend)
            route = getattr(claim, "route", None) or getattr(claim, "derived", None)
            if route is not None and (
                parsed.installation_id != route.installation_id
                or parsed.run_id
                != getattr(claim, "run_id", getattr(route, "run_id", None))
            ):
                raise RuntimeConfigurationError("Model admission differs from claim")
            raw.pop(key)
    if _contains_cap(raw, frozenset(_CLAIM_CAP_KEYS)):
        raise RuntimeConfigurationError(
            "Canonical monetary-cap claim requires model reservation support"
        )


def _zero_model_spend(value: Any) -> bool:
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        value = to_dict()
    if not isinstance(value, Mapping):
        return False
    if set(value) - {
        "runId",
        "installationId",
        "settingsVersionId",
        "settingsSha256",
        "priceVersion",
        "currency",
        "cap",
        "spent",
        "outstanding",
        "available",
    }:
        return False
    return all(
        type(value.get(key)) is str and re.fullmatch(r"0(?:\.0{1,12})?", value[key])
        for key in ("cap", "spent", "outstanding", "available")
    )
