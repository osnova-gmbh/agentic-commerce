"""Agent lifecycle manager — construct, configure, startup, shutdown."""

from __future__ import annotations

import inspect
import logging
from typing import Any
from uuid import uuid4

from cogit_agent_sdk.client import CogitClient
from cogit_agent_sdk.resident import AgentServices
from cogit_agent_sdk.services import (
    ArtifactHandle,
    MemoryHandle,
    NullArtifactHandle,
    NullMemoryHandle,
)
from cogit_agent_sdk.types import AgentDescriptor, ArtifactRef

from cogit_runtime.config import RuntimeEnvironment
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.store import RuntimeStore

logger = logging.getLogger(__name__)


class StoreArtifactHandle:
    """Artifact handle backed by :class:`RuntimeStore`."""

    def __init__(self, store: RuntimeStore) -> None:
        self._store = store

    def put(
        self,
        *,
        name: str | None = None,
        mime_type: str | None = None,
        uri: str | None = None,
        size: int | None = None,
        case_id: str | None = None,
        execution_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        content: bytes | None = None,
    ) -> ArtifactRef:
        meta = dict(metadata or {})
        if case_id is not None:
            meta.setdefault("caseId", case_id)
        if execution_id is not None:
            meta.setdefault("executionId", execution_id)
        if content is not None:
            meta.setdefault("contentBytes", len(content))
        ref = ArtifactRef(
            id=str(uuid4()),
            name=name,
            mime_type=mime_type,
            size=size if size is not None else (len(content) if content else None),
            uri=uri,
            metadata=meta or None,
        )
        return self._store.put_artifact(ref)

    def get(self, artifact_id: str) -> ArtifactRef | None:
        return self._store.get_artifact(artifact_id)


class AgentLifecycleManager:
    """Orchestrates the resident agent lifecycle."""

    def __init__(
        self,
        agent_class: type[Any],
        descriptor: AgentDescriptor,
        environment: RuntimeEnvironment,
        *,
        client: CogitClient | None = None,
    ) -> None:
        self._agent_class = agent_class
        self._descriptor = descriptor
        self._environment = environment
        self._client = client
        self.ready: bool = False
        self.configured: bool = False
        self.startup_error: Exception | None = None

    def construct(self) -> object:
        try:
            agent = self._agent_class()
        except TypeError as exc:
            msg = (
                f"agent_class {self._agent_class.__name__!r} must be instantiable "
                "without constructor arguments"
            )
            raise RuntimeConfigurationError(msg) from exc

        if hasattr(agent, "descriptor"):
            try:
                agent.descriptor = self._descriptor
            except (AttributeError, TypeError):
                pass

        if hasattr(agent, "client") and self._client is not None:
            try:
                agent.client = self._client
            except (AttributeError, TypeError):
                pass

        return agent

    def inject_services(
        self,
        agent: object,
        *,
        model_client: Any = None,
        logger_instance: logging.Logger | None = None,
        memory: MemoryHandle | None = None,
        artifacts: ArtifactHandle | None = None,
        store: RuntimeStore | None = None,
    ) -> AgentServices:
        _ = agent
        if artifacts is None and store is not None:
            artifacts = StoreArtifactHandle(store)
        services = AgentServices(
            client=self._client,
            model_client=model_client,
            logger=logger_instance or logging.getLogger(self._agent_class.__name__),
            environment={
                "dev_mode": "1" if self._environment.dev_mode else "0",
            },
            memory=memory if memory is not None else NullMemoryHandle(),
            artifacts=artifacts if artifacts is not None else NullArtifactHandle(),
        )
        return services

    def configure(self, agent: object, services: AgentServices) -> None:
        configure_fn = getattr(agent, "configure", None)
        if configure_fn is None or not callable(configure_fn):
            self.configured = True
            return

        try:
            configure_fn(services)
        except Exception as exc:
            msg = f"agent.configure() failed for {self._agent_class.__name__!r}: {exc}"
            raise RuntimeConfigurationError(msg) from exc

        self.configured = True

    async def startup(self, agent: object) -> None:
        startup_fn = getattr(agent, "startup", None)
        if startup_fn is None or not callable(startup_fn):
            self.ready = True
            return

        try:
            result = startup_fn()
            if inspect.isawaitable(result):
                await result
        except Exception as exc:
            self.startup_error = exc
            logger.error(
                "agent.startup() failed for %r: %s",
                self._agent_class.__name__,
                exc,
            )
            raise
        else:
            self.ready = True

    async def shutdown(self, agent: object) -> None:
        shutdown_fn = getattr(agent, "shutdown", None)
        if shutdown_fn is None or not callable(shutdown_fn):
            return

        try:
            result = shutdown_fn()
            if inspect.isawaitable(result):
                await result
        except Exception:
            logger.exception(
                "agent.shutdown() failed for %r (suppressed)",
                self._agent_class.__name__,
            )
