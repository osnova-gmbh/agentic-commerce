"""Preserve machine-readable run results across status reads and restarts."""

from __future__ import annotations

import json
from typing import Any

from cogit_agent_sdk.types import ExecutionRecord

from cogit_runtime.store import RuntimeStore


def serialize_run_output(output: Any) -> str | None:
    if output is None:
        return None
    try:
        return json.dumps(output, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError):
        return str(output)


def durable_run_output(record: ExecutionRecord, store: RuntimeStore) -> Any | None:
    output = _decode(record.output_summary)
    if output is not None:
        return output
    # SDK summaries can be truncated when read back from durable storage.
    # The terminal event retains the original result produced by the agent.
    for event in reversed(store.list_events(record.id, after_seq=0)):
        if event.type in {"run_completed", "run_failed"}:
            raw_summary = event.payload.get("output_summary")
            if isinstance(raw_summary, str):
                return _decode(raw_summary)
    return None


def _decode(summary: str | None) -> Any | None:
    if summary is None:
        return None
    try:
        return json.loads(summary)
    except (TypeError, ValueError):
        return None
