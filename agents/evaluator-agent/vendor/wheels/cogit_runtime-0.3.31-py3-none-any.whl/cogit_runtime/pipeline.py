"""Pipeline runner with checkpoint/recovery support.

Executes a sequence of pipeline steps, where each step is either:
- **deterministic**: executed via ``loop_host.action()``
- **agentic**: executed via ``loop_host.run()``
- **terminal**: stops pipeline execution after completing

Checkpoint recovery allows a pipeline to resume from the last completed step
after a failure or restart, using an ``InMemoryRuntimeStore`` for persistence.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Literal

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import (
    ActionDescriptor,
    Context,
    ErrorInfo,
    ExecutionStepRecord,
    RunRequest,
    RunResult,
    WorkOutcome,
)

from cogit_runtime.approvals import ApprovalStore
from cogit_runtime.cancellation import (
    RuntimeCancellation,
    RuntimeCancelledError,
    RuntimeWorkDeferred,
    await_runtime_completion,
)
from cogit_runtime.coordination import finish_cleanup
from cogit_runtime.operations.errors import OperationExecutionError
from cogit_runtime.reporter import RunReporter
from cogit_runtime.store import RuntimeStore

_CANCELLATION_GRACE_SECONDS = 1.0


async def _finish_cancelled_step(
    task: asyncio.Task[Any],
    stop_error: BaseException | None,
    interrupted: asyncio.CancelledError,
) -> Any:
    try:
        await await_runtime_completion(task)
    except CoordinationFailure:
        raise
    except RuntimeWorkDeferred as pending:
        try:
            await await_runtime_completion(pending.completion)
        except CoordinationFailure:
            raise
        except BaseException:
            if stop_error is not None:
                raise stop_error from None
            raise interrupted from None
    except BaseException:
        if stop_error is not None:
            raise stop_error from None
        raise interrupted from None
    if stop_error is not None:
        raise stop_error
    raise interrupted


class StepType(Enum):
    """The kind of step in a pipeline."""

    DETERMINISTIC = "deterministic"
    AGENTIC = "agentic"
    TERMINAL = "terminal"


class OnFailure(Enum):
    """What to do when a step fails."""

    STOP = "stop"
    SKIP = "skip"
    RETRY = "retry"
    ESCALATE = "escalate"


@dataclass
class PipelineStep:
    """A single step in a pipeline definition."""

    name: str
    step_type: StepType
    action_name: str | None = None
    instruction: str | None = None
    payload: dict[str, Any] | None = None
    on_failure: OnFailure = OnFailure.STOP
    max_retries: int = 1
    timeout_seconds: int | None = None
    key_version: str = "1"


@dataclass
class StepResult:
    """Result of executing a single pipeline step."""

    step_name: str
    status: Literal["completed", "failed", "skipped", "escalated", "cancelled"]
    output: Any = None
    error: str | None = None
    attention_item_id: str | None = None


@dataclass
class PipelineCheckpoint:
    """Checkpoint record persisted to the store."""

    pipeline_id: str
    completed_steps: list[str] = field(default_factory=list)
    step_results: dict[str, Any] = field(default_factory=dict)
    attempt_counts: dict[str, int] = field(default_factory=dict)
    deferred_errors: dict[str, str] = field(default_factory=dict)
    started_at: str = ""
    updated_at: str = ""
    work_outcome: WorkOutcome | None = None


@dataclass
class PipelineResult:
    """Result of running a complete pipeline."""

    pipeline_id: str
    status: Literal["completed", "failed", "stopped", "waiting", "cancelled"]
    step_results: list[StepResult] = field(default_factory=list)
    error: str | None = None
    attention_item_id: str | None = None
    work_outcome: WorkOutcome | None = None


class PipelineRunner:
    """Executes pipeline steps with checkpoint/recovery.

    Parameters
    ----------
    steps:
        Ordered list of pipeline steps to execute.
    store:
        Runtime store for checkpoint persistence.
    pipeline_id:
        Pipeline identity. External keyed pipelines require an explicit value
        stable for the admitted work across replacement attempts; manifest
        pipelines derive it from the admitted work item and pipeline name.
        Local pipelines auto-generate one when omitted.
    approvals:
        Optional approval store used for ``on_failure=escalate``.
    """

    def __init__(
        self,
        *,
        steps: list[PipelineStep],
        store: RuntimeStore,
        pipeline_id: str | None = None,
        approvals: ApprovalStore | None = None,
        external_execution: bool = False,
        agent_version: str | None = None,
    ) -> None:
        self._steps = steps
        self._store = store
        self._explicit_pipeline_id = (
            isinstance(pipeline_id, str)
            and bool(pipeline_id.strip())
            and pipeline_id == pipeline_id.strip()
        )
        self._pipeline_id = pipeline_id or uuid.uuid4().hex[:16]
        self._approvals = approvals
        self._external_execution = external_execution
        self._agent_version = agent_version
        self._checkpoint = self._load_or_create_checkpoint()

    @property
    def pipeline_id(self) -> str:
        return self._pipeline_id

    async def execute(
        self,
        loop_host: Any,
        context: Context,
        reporter: Any,
        execution_id: str,
        *,
        cancellation: RuntimeCancellation | None = None,
    ) -> PipelineResult:
        """Run all pipeline steps in order, checkpointing after each.

        Parameters
        ----------
        loop_host:
            An object with ``action()`` and ``run()`` methods matching
            :class:`SdkLoopHost` signatures.
        context:
            Request context — ``case_id`` is propagated to each step.
        reporter:
            Run reporter for execution tracking.
        execution_id:
            Unique ID for this execution.
        cancellation:
            Optional cooperative cancellation handle checked between steps.

        Returns
        -------
        PipelineResult
            Aggregate result with per-step outcomes.
        """
        results: list[StepResult] = []

        for order, step in enumerate(self._steps):
            if cancellation is not None and cancellation.cancelled:
                self._finalize_checkpoint("cancelled")
                results.append(
                    StepResult(
                        step_name=step.name,
                        status="cancelled",
                        error="Pipeline cancelled",
                    )
                )
                return PipelineResult(
                    pipeline_id=self._pipeline_id,
                    work_outcome=self._checkpoint.work_outcome,
                    status="cancelled",
                    step_results=results,
                    error="Pipeline cancelled",
                )

            # Recovery: skip already-completed steps
            if step.name in self._checkpoint.completed_steps:
                cached = self._checkpoint.step_results.get(step.name)
                results.append(
                    StepResult(
                        step_name=step.name,
                        status="completed",
                        output=cached,
                    )
                )
                continue

            step_result = await self._execute_step(
                step=step,
                loop_host=loop_host,
                context=context,
                reporter=reporter,
                execution_id=execution_id,
                order=order,
                cancellation=cancellation,
            )
            results.append(step_result)

            if step_result.status == "completed":
                self._checkpoint.completed_steps.append(step.name)
                self._checkpoint.step_results[step.name] = step_result.output
                self._save_checkpoint()

            if step_result.status == "cancelled":
                self._finalize_checkpoint("cancelled")
                return PipelineResult(
                    pipeline_id=self._pipeline_id,
                    work_outcome=self._checkpoint.work_outcome,
                    status="cancelled",
                    step_results=results,
                    error=step_result.error or "Pipeline cancelled",
                )

            # Terminal steps stop the pipeline after execution
            if (
                step.step_type == StepType.TERMINAL
                and step_result.status == "completed"
            ):
                self._finalize_checkpoint("completed")
                return PipelineResult(
                    pipeline_id=self._pipeline_id,
                    work_outcome=self._checkpoint.work_outcome,
                    status="stopped",
                    step_results=results,
                )

            if step_result.status == "escalated":
                self._save_checkpoint()
                return PipelineResult(
                    pipeline_id=self._pipeline_id,
                    work_outcome=self._checkpoint.work_outcome,
                    status="waiting",
                    step_results=results,
                    error=step_result.error,
                    attention_item_id=step_result.attention_item_id,
                )

            if step_result.status == "failed":
                if step.on_failure == OnFailure.STOP:
                    self._finalize_checkpoint("failed")
                    return PipelineResult(
                        pipeline_id=self._pipeline_id,
                        work_outcome=self._checkpoint.work_outcome,
                        status="failed",
                        step_results=results,
                        error=step_result.error,
                    )
                if step.on_failure == OnFailure.ESCALATE:
                    attention_id = self._escalate_failure(
                        step=step,
                        context=context,
                        execution_id=execution_id,
                        error=step_result.error,
                    )
                    results[-1] = StepResult(
                        step_name=step.name,
                        status="escalated",
                        error=step_result.error,
                        attention_item_id=attention_id,
                    )
                    self._save_checkpoint()
                    return PipelineResult(
                        pipeline_id=self._pipeline_id,
                        work_outcome=self._checkpoint.work_outcome,
                        status="waiting",
                        step_results=results,
                        error=step_result.error,
                        attention_item_id=attention_id,
                    )
                if step.on_failure == OnFailure.RETRY:
                    self._finalize_checkpoint("failed")
                    return PipelineResult(
                        pipeline_id=self._pipeline_id,
                        work_outcome=self._checkpoint.work_outcome,
                        status="failed",
                        step_results=results,
                        error=step_result.error,
                    )
                # OnFailure.SKIP: continue to next step

        self._finalize_checkpoint("completed")
        return PipelineResult(
            pipeline_id=self._pipeline_id,
            work_outcome=self._checkpoint.work_outcome,
            status="completed",
            step_results=results,
        )

    async def _execute_step(
        self,
        *,
        step: PipelineStep,
        loop_host: Any,
        context: Context,
        reporter: Any,
        execution_id: str,
        order: int,
        cancellation: RuntimeCancellation | None,
    ) -> StepResult:
        """Execute a single step, handling retries if configured."""
        started_at = datetime.now(UTC)
        step_record_id = str(
            uuid.uuid5(uuid.NAMESPACE_URL, f"{execution_id}:{order}:{step.name}")
        )
        self._record_step(
            reporter,
            ExecutionStepRecord(
                id=step_record_id,
                execution_id=execution_id,
                case_id=context.case_id,
                order=order,
                kind=_step_record_kind(step.step_type),
                name=step.name,
                status="running",
                started_at=started_at,
                data={"case_id": context.case_id} if context.case_id else None,
            ),
        )
        max_attempts = step.max_retries if step.on_failure == OnFailure.RETRY else 1
        attempts_used = self._checkpoint.attempt_counts.get(step.name, 0)
        last_error = self._checkpoint.deferred_errors.pop(step.name, None)
        attempts = (
            max(0, max_attempts - attempts_used)
            if last_error is not None
            else max_attempts
        )

        for local_attempt in range(attempts):
            attempt_number = self._checkpoint.attempt_counts.get(step.name, 0) + 1
            self._checkpoint.attempt_counts[step.name] = attempt_number
            self._save_checkpoint()
            try:
                output = await self._dispatch_step(
                    step=step,
                    loop_host=loop_host,
                    context=context,
                    reporter=reporter,
                    execution_id=execution_id,
                    cancellation=cancellation,
                    attempt=attempt_number,
                )
                result = StepResult(
                    step_name=step.name,
                    status="completed",
                    output=output,
                )
                self._checkpoint.deferred_errors.pop(step.name, None)
                self._record_step(
                    reporter,
                    ExecutionStepRecord(
                        id=step_record_id,
                        execution_id=execution_id,
                        case_id=context.case_id,
                        order=order,
                        kind=_step_record_kind(step.step_type),
                        name=step.name,
                        status="completed",
                        started_at=started_at,
                        completed_at=datetime.now(UTC),
                        data=_step_record_data(output, context.case_id),
                    ),
                )
                return result
            except CoordinationFailure:
                raise
            except TimeoutError as exc:
                last_error = f"TimeoutError: {exc}"
                if local_attempt < attempts - 1:
                    continue
            except RuntimeCancelledError as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                self._record_step(
                    reporter,
                    ExecutionStepRecord(
                        id=step_record_id,
                        execution_id=execution_id,
                        case_id=context.case_id,
                        order=order,
                        kind=_step_record_kind(step.step_type),
                        name=step.name,
                        status="failed",
                        started_at=started_at,
                        completed_at=datetime.now(UTC),
                        data={"case_id": context.case_id} if context.case_id else None,
                        error=ErrorInfo(
                            code="CANCELLED",
                            message=str(exc),
                            retryable=False,
                        ),
                    ),
                )
                return StepResult(
                    step_name=step.name,
                    status="cancelled",
                    error=last_error,
                )
            except OperationExecutionError as exc:
                if (
                    exc.result.error is not None
                    and exc.result.error.code == "APPROVAL_REQUIRED"
                ):
                    return StepResult(
                        step_name=step.name,
                        status="escalated",
                        error=exc.result.error.message,
                        attention_item_id=exc.result.attention_item_id,
                    )
                if exc.result.status == "cancelled":
                    last_error = (
                        exc.result.error.message
                        if exc.result.error is not None
                        else "Operation cancelled"
                    )
                    return StepResult(
                        step_name=step.name,
                        status="cancelled",
                        error=last_error,
                    )
                last_error = (
                    exc.result.error.message
                    if exc.result.error is not None
                    else "Operation failed"
                )
                if exc.result.invocation_started and _disable_retry_after_invoke(
                    loop_host,
                    step.action_name or step.name,
                ):
                    break
                if local_attempt < attempts - 1:
                    continue
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if local_attempt < attempts - 1:
                    continue

        result = StepResult(
            step_name=step.name,
            status="failed",
            error=last_error,
        )
        self._record_step(
            reporter,
            ExecutionStepRecord(
                id=step_record_id,
                execution_id=execution_id,
                case_id=context.case_id,
                order=order,
                kind=_step_record_kind(step.step_type),
                name=step.name,
                status="failed",
                started_at=started_at,
                completed_at=datetime.now(UTC),
                data={"case_id": context.case_id} if context.case_id else None,
                error=ErrorInfo(
                    code="PIPELINE_STEP_FAILED",
                    message=last_error or "Pipeline step failed",
                    retryable=step.on_failure == OnFailure.RETRY,
                ),
            ),
        )
        return result

    async def _dispatch_step(
        self,
        *,
        step: PipelineStep,
        loop_host: Any,
        context: Context,
        reporter: Any,
        execution_id: str,
        cancellation: RuntimeCancellation | None,
        attempt: int,
    ) -> Any:
        """Dispatch to the appropriate loop_host method based on step type."""
        step_cancellation = RuntimeCancellation(parent=cancellation)
        try:
            coro = self._dispatch_step_uncapped(
                step=step,
                loop_host=loop_host,
                context=context,
                reporter=reporter,
                execution_id=execution_id,
                cancellation=step_cancellation,
                attempt=attempt,
            )
            if step.timeout_seconds is None:
                return await coro
            task = asyncio.create_task(coro)
            interrupted: asyncio.CancelledError | None = None
            try:
                done, _pending = await asyncio.wait(
                    {task}, timeout=float(step.timeout_seconds)
                )
            except asyncio.CancelledError as exc:
                interrupted = exc
                done = set()
            if task in done:
                return task.result()
            stop_error: BaseException | None = None
            try:
                step_cancellation.cancel()
            except BaseException as exc:
                stop_error = exc
            if interrupted is not None:
                task.cancel()
            done, _pending = await await_runtime_completion(
                asyncio.create_task(
                    asyncio.wait({task}, timeout=_CANCELLATION_GRACE_SECONDS)
                )
            )
            if task not in done:
                if interrupted is not None:
                    raise RuntimeWorkDeferred(
                        asyncio.create_task(
                            _finish_cancelled_step(task, stop_error, interrupted)
                        )
                    )
                timeout_error = (
                    f"TimeoutError: Step '{step.name}' timed out after "
                    f"{step.timeout_seconds}s"
                )
                self._checkpoint.deferred_errors[step.name] = timeout_error
                self._save_checkpoint()
                raise RuntimeWorkDeferred(
                    self._continue_deferred_pipeline(
                        task,
                        loop_host=loop_host,
                        context=context,
                        reporter=reporter,
                        execution_id=execution_id,
                        cancellation=cancellation,
                        stop_error=stop_error,
                    )
                )
            if not task.cancelled():
                failure = task.exception()
                if isinstance(failure, CoordinationFailure):
                    raise failure
                if isinstance(failure, RuntimeWorkDeferred):
                    raise failure
            if stop_error is not None:
                raise stop_error
            if interrupted is not None:
                raise interrupted
            msg = f"Step '{step.name}' timed out after {step.timeout_seconds}s"
            raise TimeoutError(msg)
        finally:
            finish_cleanup(step_cancellation.close)

    async def _dispatch_step_uncapped(
        self,
        *,
        step: PipelineStep,
        loop_host: Any,
        context: Context,
        reporter: Any,
        execution_id: str,
        cancellation: RuntimeCancellation | None,
        attempt: int,
    ) -> Any:
        # Propagate case_id from context into sub-calls
        step_execution_id = f"{execution_id}:{step.name}:attempt-{attempt}"

        if step.step_type in (StepType.DETERMINISTIC, StepType.TERMINAL):
            if step.step_type == StepType.TERMINAL and step.action_name is None:
                return step.payload or {"terminal": True}
            action_name = step.action_name or step.name
            payload = step.payload or {}
            descriptor_fn = getattr(loop_host, "action_descriptor", None)
            descriptor = (
                descriptor_fn(action_name)
                if callable(descriptor_fn)
                and not inspect.iscoroutinefunction(descriptor_fn)
                else None
            )
            idempotency_key = (
                self._step_key(context, execution_id, step)
                if isinstance(descriptor, ActionDescriptor)
                and descriptor.idempotency == "keyed"
                else None
            )
            execution_options: dict[str, Any] = {}
            if self._external_execution:
                # The server admits one execution for the attempt. Step IDs stay
                # local to scheduling; they cannot replace durable authority.
                step_execution_id = execution_id
                execution_options = {
                    "manage_lifecycle": False,
                    "cancellation": cancellation,
                }
            elif isinstance(reporter, RunReporter):
                reporter.begin(
                    context=context.model_copy(
                        update={"execution_id": step_execution_id}
                    ),
                    trigger="pipeline",
                    input_summary=action_name,
                    metadata={
                        "parent_execution_id": execution_id,
                        "pipeline_id": self._pipeline_id,
                        "step": step.name,
                    },
                )
            result = await loop_host.execute_bound_action(
                action_name,
                payload,
                context,
                step_execution_id,
                parent_cancellation=cancellation,
                idempotency_key=idempotency_key,
                key_source="generated",
                approval_source="pipeline",
                reporter=reporter if isinstance(reporter, RunReporter) else None,
                **execution_options,
            )
            if not self._external_execution and isinstance(reporter, RunReporter):
                reporter.complete(
                    step_execution_id,
                    status=(
                        "completed"
                        if result.status == "succeeded"
                        else "waiting"
                        if result.error is not None
                        and result.error.code == "APPROVAL_REQUIRED"
                        else "cancelled"
                        if result.status == "cancelled"
                        else "failed"
                    ),
                    error=result.error,
                )
            if result.work_outcome is not None:
                self._checkpoint.work_outcome = result.work_outcome
            if result.error is not None and result.error.code == "APPROVAL_REQUIRED":
                raise OperationExecutionError(result)
            if result.status == "succeeded":
                return result.output
            if result.status == "cancelled":
                raise RuntimeCancelledError(
                    result.error.message
                    if result.error is not None
                    else "Operation cancelled",
                )
            raise OperationExecutionError(result)

        if step.step_type == StepType.AGENTIC:
            if self._external_execution:
                raise RuntimeError(
                    "Nested agentic steps require server lifecycle support"
                )
            instruction = step.instruction or f"Execute step: {step.name}"
            step_context = context.model_copy(
                update={"execution_id": step_execution_id}
            )
            run_request = RunRequest(
                instruction=instruction,
                context=step_context,
                metadata={"pipeline_step": True},
            )
            nested_execution_id = step_execution_id
            if isinstance(reporter, RunReporter):
                nested = reporter.begin(
                    context=step_context,
                    trigger="pipeline",
                    input_summary=instruction,
                    metadata={
                        "parent_execution_id": execution_id,
                        "pipeline_id": self._pipeline_id,
                        "step": step.name,
                    },
                )
                nested_execution_id = nested.id
            run_result: RunResult = await loop_host.run(
                run_request,
                step_context,
                reporter,
                nested_execution_id,
                parent_cancellation=cancellation,
            )
            if run_result.work_outcome is not None:
                self._checkpoint.work_outcome = run_result.work_outcome
            if run_result.status == "cancelled":
                raise RuntimeCancelledError("Pipeline child run was cancelled")
            if run_result.status != "completed":
                error_code = (
                    run_result.error.code
                    if run_result.error is not None
                    else run_result.status
                )
                raise RuntimeError(
                    f"Pipeline child run did not complete ({error_code})"
                )
            return run_result.output

        msg = f"Unknown step type: {step.step_type}"
        raise ValueError(msg)

    def _step_key(self, context: Context, execution_id: str, step: PipelineStep) -> str:
        """Bind a deterministic step to admitted work, never to its attempt."""

        if self._external_execution:
            work_id = context.queue_item_id
            if not work_id or not self._agent_version or not self._explicit_pipeline_id:
                raise ValueError(
                    "A keyed AgentDb pipeline needs admitted work, agent version, "
                    "and a stable explicit pipeline ID"
                )
        else:
            work_id = execution_id
        if not work_id:
            raise ValueError("A keyed pipeline needs a stable work identity")
        if (
            not isinstance(step.key_version, str)
            or not step.key_version.strip()
            or step.key_version != step.key_version.strip()
        ):
            raise ValueError("A keyed pipeline needs a non-empty step key version")
        material = json.dumps(
            [
                context.tenant_id,
                context.agent_id,
                self._agent_version,
                work_id,
                self._pipeline_id,
                step.name,
                step.step_type.value,
                step.action_name or step.name,
                step.key_version,
            ],
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return "cogit:step:v1:" + hashlib.sha256(material.encode("utf-8")).hexdigest()

    def _escalate_failure(
        self,
        *,
        step: PipelineStep,
        context: Context,
        execution_id: str,
        error: str | None,
    ) -> str | None:
        """Park an attention item and mark the case waiting for approval."""
        attention_id: str | None = None
        if self._approvals is not None:
            item = self._approvals.park(
                kind="node_failed",
                message=(
                    f"Pipeline step '{step.name}' failed and requires escalation"
                    + (f": {error}" if error else "")
                ),
                context=context,
                payload={
                    "pipeline_id": self._pipeline_id,
                    "step": step.name,
                    "error": error,
                },
                execution_id=execution_id,
                metadata={
                    "source": "pipeline",
                    "pipeline_id": self._pipeline_id,
                    "step": step.name,
                    "on_failure": "escalate",
                },
            )
            attention_id = item.id

        if context.case_id:
            case = self._store.get_case(context.case_id)
            if case is not None:
                updated = case.model_copy(
                    update={
                        "status": "waiting_for_approval",
                        "updated_at": datetime.now(UTC),
                        "error": error,
                    }
                )
                self._store.put_case(updated)
        return attention_id

    def _record_step(
        self,
        reporter: Any,
        step: ExecutionStepRecord,
    ) -> None:
        if isinstance(reporter, RunReporter):
            reporter.record_step(step)
            return
        self._store.put_execution_step(step)

    # -- Checkpoint persistence -------------------------------------------

    def _checkpoint_key(self) -> str:
        return f"pipeline:checkpoint:{self._pipeline_id}"

    def _continue_deferred_pipeline(
        self,
        completion: asyncio.Task[Any],
        *,
        loop_host: Any,
        context: Context,
        reporter: Any,
        execution_id: str,
        cancellation: RuntimeCancellation | None,
        stop_error: BaseException | None = None,
    ) -> asyncio.Task[PipelineResult]:
        async def resume() -> PipelineResult:
            try:
                await await_runtime_completion(completion)
            except CoordinationFailure:
                raise
            except asyncio.CancelledError:
                self._checkpoint.deferred_errors.setdefault(
                    "pipeline",
                    "Deferred child task was cancelled",
                )
            except Exception as exc:
                self._checkpoint.deferred_errors.setdefault(
                    "pipeline",
                    f"Deferred child failed ({type(exc).__name__})",
                )
            if stop_error is not None:
                raise stop_error
            while True:
                try:
                    return await self.execute(
                        loop_host,
                        context,
                        reporter,
                        execution_id,
                        cancellation=cancellation,
                    )
                except RuntimeWorkDeferred as nested:
                    nested_result = await await_runtime_completion(nested.completion)
                    if isinstance(nested_result, PipelineResult):
                        return nested_result

        return asyncio.create_task(
            resume(),
            name=f"cogit-pipeline-resume-{self._pipeline_id}",
        )

    def _load_or_create_checkpoint(self) -> PipelineCheckpoint:
        """Load an existing checkpoint from the store, or create a fresh one."""
        # Canonical checkpoints need AgentDb authority. Worker-local diagnostics
        # cannot represent a second active execution or provide durable recovery.
        run = (
            None
            if self._external_execution
            else self._store.get_run(self._checkpoint_key())
        )
        if run is not None and run.metadata:
            meta = run.metadata
            return PipelineCheckpoint(
                pipeline_id=self._pipeline_id,
                completed_steps=meta.get("completed_steps", []),
                step_results=meta.get("step_results", {}),
                attempt_counts=meta.get("attempt_counts", {}),
                deferred_errors=meta.get("deferred_errors", {}),
                started_at=meta.get("started_at", ""),
                updated_at=meta.get("updated_at", ""),
                work_outcome=WorkOutcome.model_validate(meta["work_outcome"])
                if meta.get("work_outcome") is not None
                else None,
            )
        now = datetime.now(UTC).isoformat()
        return PipelineCheckpoint(
            pipeline_id=self._pipeline_id,
            started_at=now,
            updated_at=now,
        )

    def _save_checkpoint(self) -> None:
        """Persist checkpoint state to the store using an ExecutionRecord."""
        if self._external_execution:
            return
        from cogit_agent_sdk.types import ExecutionRecord

        now = datetime.now(UTC)
        record = ExecutionRecord(
            id=self._checkpoint_key(),
            agent_id="pipeline",
            tenant_id="pipeline",
            trigger="api",
            started_at=now,
            status="running",
            case_id=(
                self._pipeline_id.rsplit(":", 1)[0]
                if ":" in self._pipeline_id
                else None
            ),
            metadata={
                "completed_steps": self._checkpoint.completed_steps,
                "step_results": self._checkpoint.step_results,
                "attempt_counts": self._checkpoint.attempt_counts,
                "deferred_errors": self._checkpoint.deferred_errors,
                "started_at": self._checkpoint.started_at,
                "updated_at": now.isoformat(),
                "pipeline_id": self._pipeline_id,
                "work_outcome": self._checkpoint.work_outcome.model_dump(mode="json")
                if self._checkpoint.work_outcome is not None
                else None,
            },
        )
        self._store.put_run(record)

    def _finalize_checkpoint(self, status: str) -> None:
        """Mark the durable checkpoint as terminal so recovery does not re-enqueue."""
        if self._external_execution:
            return
        from cogit_agent_sdk.types import ExecutionRecord

        now = datetime.now(UTC)
        existing = self._store.get_run(self._checkpoint_key())
        metadata = dict(existing.metadata or {}) if existing is not None else {}
        metadata.update(
            {
                "completed_steps": self._checkpoint.completed_steps,
                "step_results": self._checkpoint.step_results,
                "attempt_counts": self._checkpoint.attempt_counts,
                "deferred_errors": self._checkpoint.deferred_errors,
                "started_at": self._checkpoint.started_at,
                "updated_at": now.isoformat(),
                "pipeline_id": self._pipeline_id,
                "work_outcome": self._checkpoint.work_outcome.model_dump(mode="json")
                if self._checkpoint.work_outcome is not None
                else None,
            }
        )
        # Map pipeline terminal labels onto ExecutionRecord statuses.
        record_status: Literal[
            "running", "waiting", "completed", "failed", "partial", "cancelled"
        ]
        if status == "cancelled":
            record_status = "cancelled"
        elif status == "failed":
            record_status = "failed"
        elif status == "waiting":
            record_status = "waiting"
        else:
            record_status = "completed"
        record = ExecutionRecord(
            id=self._checkpoint_key(),
            agent_id=(existing.agent_id if existing is not None else "pipeline"),
            tenant_id=(existing.tenant_id if existing is not None else "pipeline"),
            trigger=(existing.trigger if existing is not None else "api"),
            started_at=(existing.started_at if existing is not None else now),
            completed_at=None if record_status == "waiting" else now,
            status=record_status,
            case_id=(
                existing.case_id
                if existing is not None
                else (
                    self._pipeline_id.rsplit(":", 1)[0]
                    if ":" in self._pipeline_id
                    else None
                )
            ),
            metadata=metadata,
        )
        self._store.put_run(record)


def _step_record_kind(
    step_type: StepType,
) -> Literal["model", "action", "system"]:
    if step_type == StepType.AGENTIC:
        return "model"
    if step_type == StepType.DETERMINISTIC:
        return "action"
    return "system"


def _step_record_data(output: Any, case_id: str | None) -> dict[str, Any] | None:
    data: dict[str, Any] = {}
    if case_id is not None:
        data["case_id"] = case_id
    if isinstance(output, dict):
        data["output"] = output
    elif output is not None:
        data["output"] = str(output)
    return data or None


def _disable_retry_after_invoke(loop_host: Any, action_name: str) -> bool:
    descriptor_fn = getattr(loop_host, "action_descriptor", None)
    if not callable(descriptor_fn):
        return False
    descriptor = descriptor_fn(action_name)
    if not isinstance(descriptor, ActionDescriptor):
        return False
    return descriptor.idempotency == "none"


__all__ = [
    "OnFailure",
    "PipelineCheckpoint",
    "PipelineResult",
    "PipelineRunner",
    "PipelineStep",
    "StepResult",
    "StepType",
]
