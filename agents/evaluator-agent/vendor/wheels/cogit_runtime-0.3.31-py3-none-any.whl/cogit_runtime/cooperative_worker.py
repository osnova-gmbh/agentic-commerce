"""Cooperative worker-thread invocation shared by loop and operation paths."""

from __future__ import annotations

import asyncio
import inspect
import logging
from typing import Any, cast

from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.cancellation import RuntimeCancellation, await_runtime_completion

logger = logging.getLogger(__name__)


class WorkerStillRunningError(Exception):
    def __init__(
        self, task: asyncio.Task[Any], *, interruption: BaseException | None = None
    ) -> None:
        super().__init__("Worker did not stop within the cancellation grace period")
        self.task = task
        self.interruption = interruption


def retain_stop_failure(
    task: asyncio.Task[Any], stop_error: BaseException | None
) -> asyncio.Task[Any]:
    """Keep a stop callback failure attached to the worker it cannot yet settle."""
    if stop_error is None:
        return task

    async def inspect() -> Any:
        try:
            await await_runtime_completion(task)
        except CoordinationFailure:
            raise
        except BaseException:
            if not isinstance(stop_error, CoordinationFailure):
                raise
        raise stop_error

    return asyncio.create_task(inspect())


async def call_maybe_async(
    method: Any,
    *args: object,
    cancellation: RuntimeCancellation,
) -> Any:
    if inspect.iscoroutinefunction(method):
        return await method(*args)
    result = await to_thread_cooperatively(
        method,
        *args,
        cooperative_cancellation=cancellation,
    )
    if inspect.isawaitable(result):
        return await cast(Any, result)
    return result


async def to_thread_cooperatively(
    function: Any,
    *args: object,
    cooperative_cancellation: RuntimeCancellation,
    **kwargs: object,
) -> Any:
    """Wait for worker exit before propagating task cancellation."""

    task = asyncio.create_task(asyncio.to_thread(function, *args, **kwargs))
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        stop_error: BaseException | None = None
        try:
            cooperative_cancellation.cancel()
        except BaseException as exc:
            stop_error = exc
        done, _pending = await await_runtime_completion(
            asyncio.create_task(asyncio.wait({task}, timeout=1.0))
        )
        if task not in done:
            raise WorkerStillRunningError(
                retain_stop_failure(task, stop_error)
            ) from None
        try:
            task.result()
        except CoordinationFailure:
            raise
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.debug(
                "Worker exited after cancellation (%s)",
                type(exc).__name__,
            )
        if stop_error is not None:
            raise stop_error from None
        raise
