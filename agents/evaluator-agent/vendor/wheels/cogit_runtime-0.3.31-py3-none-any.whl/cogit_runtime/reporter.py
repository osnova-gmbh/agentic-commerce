"""Run reporter backed by the local runtime store."""

from __future__ import annotations

import logging
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from threading import RLock
from typing import TYPE_CHECKING, Any, Literal

from cogit_agent_sdk.types import (
    Context,
    ErrorInfo,
    ExecutionRecord,
    ExecutionStepRecord,
    RunEvent,
    Usage,
)

from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.store import RuntimeStore

if TYPE_CHECKING:
    from cogit_runtime.platform import PlatformReporter

_logger = logging.getLogger("cogit_runtime.reporter")


class RunReporter:
    """Creates execution records and emits pollable run events."""

    def __init__(
        self,
        store: RuntimeStore,  # Accepts any RuntimeStore implementation
        *,
        platform: PlatformReporter | None = None,
    ) -> None:
        self._store = store
        self._platform = platform
        self._contexts: dict[str, Context] = {}
        self._begin_lock = RLock()
        self._complete_lock = RLock()
        self._completion_guards: dict[str, Callable[[ExecutionRecord], None]] = {}

    def bind_completion_guard(
        self,
        execution_id: str,
        guard: Callable[[ExecutionRecord], None] | None,
    ) -> None:
        """Install a host-owned mandatory boundary before completion publication."""
        with self._complete_lock:
            if guard is None:
                self._completion_guards.pop(execution_id, None)
            elif execution_id in self._completion_guards:
                raise RuntimeConfigurationError("Run already has a completion guard")
            else:
                self._completion_guards[execution_id] = guard

    def begin(
        self,
        *,
        context: Context,
        trigger: str,
        input_summary: str,
        metadata: dict[str, Any] | None = None,
    ) -> ExecutionRecord:
        execution_id = context.execution_id or str(uuid.uuid4())
        record = ExecutionRecord(
            id=execution_id,
            tenant_id=context.tenant_id,
            organization_id=context.organization_id,
            agent_id=context.agent_id or "unknown",
            case_id=context.case_id,
            session_id=context.session_id,
            trigger=context.trigger or trigger,
            status="running",
            started_at=datetime.now(UTC),
            input_summary=input_summary,
            metadata=metadata,
        )
        with self._begin_lock:
            outbox = (
                self._platform.build_outbox_record(
                    "execution_create",
                    record,
                    context,
                )
                if self._platform is not None
                else None
            )
            if not self._store.create_run_if_absent(record, outbox):
                raise RuntimeConfigurationError(
                    f"Execution '{execution_id}' already exists."
                )
            self._contexts[record.id] = context
            if self._platform is not None:
                self._platform.flush_pending()
        _logger.info(
            "run.started",
            extra={
                "execution_id": record.id,
                "tenant_id": record.tenant_id,
                "agent_id": record.agent_id,
                "trigger": record.trigger,
                "correlation_id": context.correlation_id,
            },
        )
        self.emit(
            execution_id=record.id,
            event_type="run_started",
            payload={"trigger": record.trigger, "input_summary": record.input_summary},
        )
        return record

    def get(self, execution_id: str) -> ExecutionRecord | None:
        return self._store.get_run(execution_id)

    def release_local_run(self, execution_id: str) -> None:
        """Drop a drained AgentDb worker's optional local ownership state."""

        with self._begin_lock:
            self._contexts.pop(execution_id, None)
        release = getattr(self._store, "release_local_run", None)
        if release is not None:
            try:
                release(execution_id)
            except Exception as exc:
                _logger.warning(
                    "worker-local diagnostic cleanup failed (%s)",
                    type(exc).__name__,
                )

    def complete(
        self,
        execution_id: str,
        *,
        status: Literal["completed", "failed", "partial", "cancelled", "waiting"],
        output_summary: str | None = None,
        outcome_label: str | None = None,
        usage: Usage | None = None,
        error: ErrorInfo | None = None,
    ) -> ExecutionRecord:
        with self._complete_lock:
            existing = self._require_run(execution_id)
            if existing.status != "running":
                return existing
            completed = existing.model_copy(
                update={
                    "status": status,
                    "completed_at": datetime.now(UTC),
                    "output_summary": output_summary,
                    "outcome_label": outcome_label,
                    "usage": usage,
                    "error": error,
                }
            )
            guard = self._completion_guards.get(execution_id)
            if guard is not None:
                guard(completed)
            context = self._contexts.get(completed.id)
            outbox = (
                self._platform.build_outbox_record(
                    "execution_complete",
                    completed,
                    context,
                )
                if self._platform is not None
                else None
            )
            if not self._store.complete_run_if_running(completed, outbox):
                return self._require_run(execution_id)
            self._contexts.pop(completed.id, None)
            if self._platform is not None:
                self._platform.flush_pending()
        _logger.info(
            "run.completed",
            extra={
                "execution_id": completed.id,
                "status": completed.status,
                "outcome_label": completed.outcome_label,
            },
        )
        event_type: Literal["run_completed", "run_failed"]
        event_type = "run_failed" if status == "failed" else "run_completed"
        self.emit(
            execution_id=completed.id,
            event_type=event_type,
            payload={
                "status": completed.status,
                "output_summary": completed.output_summary,
                "outcome_label": completed.outcome_label,
            },
        )
        return completed

    def emit(
        self,
        *,
        execution_id: str,
        event_type: RunEventType,
        payload: dict[str, Any] | None = None,
    ) -> RunEvent:
        run = self._store.get_run(execution_id)
        event = RunEvent(
            execution_id=execution_id,
            case_id=run.case_id if run is not None else None,
            sequence=self._store.next_event_sequence(execution_id),
            timestamp=datetime.now(UTC),
            type=event_type,
            payload=payload or {},
        )
        return self._store.append_event(event)

    def record_step(self, step: ExecutionStepRecord) -> ExecutionStepRecord:
        """Persist and mirror a pipeline execution step."""
        stored = self._store.put_execution_step(step)
        if step.status != "running":
            if self._platform is not None:
                self._platform.record_step(
                    stored,
                    self._contexts.get(step.execution_id),
                )
            self.emit(
                execution_id=step.execution_id,
                event_type="step_recorded",
                payload={
                    "step_id": step.id,
                    "order": step.order,
                    "name": step.name,
                    "kind": step.kind,
                    "status": step.status,
                    "case_id": (step.data or {}).get("case_id"),
                },
            )
        return stored

    def _require_run(self, execution_id: str) -> ExecutionRecord:
        record = self._store.get_run(execution_id)
        if record is None:
            raise KeyError(execution_id)
        return record


RunEventType = Literal[
    "run_started",
    "run_completed",
    "run_failed",
    "message_started",
    "message_delta",
    "message_completed",
    "tool_call_started",
    "tool_call_updated",
    "tool_call_completed",
    "step_recorded",
    "attention_required",
]
