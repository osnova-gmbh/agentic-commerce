"""Schedule authenticated local evaluations without holding the launch request."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import httpx
from fastapi import FastAPI

from cogit_runtime.async_evals import AsyncEvalManager
from cogit_runtime.eval_runner import EvalRunner
from cogit_runtime.platform import PlatformReporter
from cogit_runtime.store import RuntimeStore


def launch_eval(
    *,
    manifest: Path,
    suite: str,
    endpoint: str,
    app: FastAPI,
    store: RuntimeStore,
    platform: PlatformReporter,
    manager: AsyncEvalManager,
    api_key: str | None,
    limit: int | None,
) -> str:
    runner = EvalRunner.from_manifest(
        str(manifest),
        endpoint,
        suite,
        store=store,
    )
    running = runner.create_record(limit=limit)

    async def execute() -> None:
        headers = {"X-API-Key": api_key} if api_key else {}
        try:
            async with httpx.AsyncClient(
                transport=httpx.ASGITransport(app=app),
                base_url=endpoint,
                headers=headers,
            ) as client:
                completed = await runner.run(
                    eval_id=running.id,
                    started_at=running.started_at,
                    client=client,
                )
        except Exception as exc:
            completed = running.model_copy(
                update={
                    "status": "failed",
                    "completed_at": datetime.now(UTC),
                    "metadata": {"error_type": type(exc).__name__},
                }
            )
            store.put_eval(completed)
        platform.record_eval(completed)

    manager.schedule(eval_id=running.id, executor=execute)
    return running.id
