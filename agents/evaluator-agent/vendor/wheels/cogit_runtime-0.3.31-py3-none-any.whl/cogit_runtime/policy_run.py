"""Run and continuation boundaries independent of optional agent hook layers."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TypeVar

from cogit_agent_sdk.contracts import RunHandle
from cogit_agent_sdk.types import AgentLoopConfig, AgentLoopState, ExecutionRecord
from cogit_agent_sdk.types.policy import PolicyCheckpoint, PolicyOperation

from cogit_runtime.cancellation import RuntimeWorkDeferred, await_runtime_completion
from cogit_runtime.policy import RuntimePolicyGate, digest
from cogit_runtime.reporter import RunReporter

T = TypeVar("T")


class RunPolicyBoundary:
    def __init__(
        self, policy: RuntimePolicyGate, handle: RunHandle, payload: object
    ) -> None:
        self.policy, self.handle = policy, handle
        self.input_hash = digest(payload)
        self.operation = PolicyOperation(
            kind="run",
            name="agent.run",
            agent_version=policy.descriptor.version,
            descriptor_sha256=policy.manifest_hash,
            risk="read",
            idempotency="none",
            required_capabilities=(),
            requires_approval=False,
        )

    def before(self) -> None:
        self.policy.require(
            self.handle,
            PolicyCheckpoint(
                checkpoint_id=digest(
                    [self.handle.execution_id, "pre_run", self.input_hash]
                ),
                phase="pre_run",
                operation=self.operation,
                manifest_sha256=self.policy.manifest_hash,
                input_sha256=self.input_hash,
                effect_state="not_started",
            ),
        )

    def complete(self, record: ExecutionRecord) -> None:
        self.after(
            {"status": record.status, "output": record.output_summary},
            succeeded=record.status == "completed",
        )

    def after(self, result: object, *, succeeded: bool) -> None:
        self.policy.require(
            self.handle,
            PolicyCheckpoint(
                checkpoint_id=digest(
                    [self.handle.execution_id, "post_run", self.input_hash]
                ),
                phase="post_run",
                operation=self.operation,
                manifest_sha256=self.policy.manifest_hash,
                input_sha256=self.input_hash,
                result_sha256=digest(result),
                effect_state="completed" if succeeded else "unknown",
            ),
        )

    def prepare_next_turn(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> AgentLoopState:
        self.policy.require(
            self.handle,
            self.policy.checkpoint(
                phase="checkpoint",
                operation=self.operation,
                payload=state.model_dump(mode="json"),
                slot=self.handle.execution_id,
            ),
        )
        return state

    async def run(self, call: Callable[[], Awaitable[T]], reporter: RunReporter) -> T:
        self.before()
        reporter.bind_completion_guard(self.handle.execution_id, self.complete)
        deferred = False
        try:
            return await call()
        except RuntimeWorkDeferred as pending:
            deferred = True
            completion = pending.completion

            async def finish() -> object:
                try:
                    return await await_runtime_completion(completion)
                finally:
                    reporter.bind_completion_guard(self.handle.execution_id, None)

            import asyncio

            raise RuntimeWorkDeferred(asyncio.create_task(finish())) from None
        finally:
            if not deferred:
                reporter.bind_completion_guard(self.handle.execution_id, None)
