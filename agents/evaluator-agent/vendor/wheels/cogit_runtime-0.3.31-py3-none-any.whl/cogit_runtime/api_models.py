"""Runtime-owned API models for non-SDK response envelopes."""

from __future__ import annotations

from typing import Any

from cogit_agent_sdk.types import ExecutionRecord
from pydantic import BaseModel, ConfigDict, Field


class AcceptedRun(BaseModel):
    """Response for async run acceptance."""

    model_config = ConfigDict(frozen=True)

    run_id: str
    status: str = "accepted"


class RunStatusRecord(ExecutionRecord):
    """Durable execution status with its machine-readable run output."""

    output: Any | None = None


class CancelResult(BaseModel):
    """Response for cooperative cancellation requests."""

    model_config = ConfigDict(frozen=True)

    execution_id: str
    status: str


class EvalRunRequest(BaseModel):
    """Runtime-owned eval launch request."""

    model_config = ConfigDict(extra="forbid")

    suite: str | None = Field(
        default=None, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]*$"
    )
    limit: int | None = Field(default=None, gt=0)


class ImprovementExperimentCreate(BaseModel):
    """Request to record an improvement experiment proposal."""

    model_config = ConfigDict(extra="forbid")

    hypothesis: str
    changed_surface: str
    organization_id: str | None = None
    metrics: dict[str, Any] = Field(default_factory=dict)


class ImprovementExperimentUpdate(BaseModel):
    """Partial update to an experiment record.

    Consumed by the improvement plane (§14) — a factory or resident agent
    posts here to advance an experiment through ``running`` → ``kept`` /
    ``discarded`` / ``needs_human`` after evaluating candidate branches.
    """

    model_config = ConfigDict(extra="forbid")

    verdict: str | None = None
    branch_or_revision: str | None = None
    baseline_eval_record_id: str | None = None
    candidate_eval_record_id: str | None = None
    metrics: dict[str, Any] | None = None
    completed: bool = False


class ImprovementExperimentTrigger(BaseModel):
    """Request to enqueue an improvement experiment sandbox run.

    v0 records the trigger and marks the experiment ``running``; actual
    sandbox execution is Foundation-owned and out of scope for the runtime
    (spec §14). The runtime keeps a note so the Foundation can reconcile.
    """

    model_config = ConfigDict(extra="forbid")

    branch_or_revision: str | None = None
    note: str | None = None


class UsageSummary(BaseModel):
    """Simple usage aggregate over locally known runs."""

    model_config = ConfigDict(frozen=True)

    runs: int
    input_tokens: int
    output_tokens: int
    total_tokens: int
    estimated_cost_total: float
