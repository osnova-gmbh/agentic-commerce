"""Add artifacts, feedback, event uniqueness, and outbox idempotency.

Revision ID: 0004_artifacts_feedback
Revises: 0003_case_timeline
Create Date: 2026-07-13
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0004_artifacts_feedback"
down_revision: str | None = "0003_case_timeline"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "cogit_rt_artifacts",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("name", sa.String(length=512), nullable=True),
        sa.Column("mime_type", sa.String(length=128), nullable=True),
        sa.Column("size", sa.Integer(), nullable=True),
        sa.Column("uri", sa.Text(), nullable=True),
        sa.Column("case_id", sa.String(length=128), nullable=True),
        sa.Column("execution_id", sa.String(length=128), nullable=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=True),
        sa.Column("artifact_metadata", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_cogit_rt_artifacts_case_id", "cogit_rt_artifacts", ["case_id"])
    op.create_index(
        "ix_cogit_rt_artifacts_execution_id",
        "cogit_rt_artifacts",
        ["execution_id"],
    )
    op.create_index(
        "ix_cogit_rt_artifacts_tenant_id", "cogit_rt_artifacts", ["tenant_id"]
    )

    op.create_table(
        "cogit_rt_feedback",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("case_id", sa.String(length=128), nullable=True),
        sa.Column("execution_id", sa.String(length=128), nullable=True),
        sa.Column("rating", sa.String(length=32), nullable=True),
        sa.Column("score", sa.Float(), nullable=True),
        sa.Column("comment", sa.Text(), nullable=True),
        sa.Column("source", sa.String(length=128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("feedback_metadata", sa.JSON(), nullable=True),
    )
    op.create_index(
        "ix_cogit_rt_feedback_tenant_id", "cogit_rt_feedback", ["tenant_id"]
    )
    op.create_index("ix_cogit_rt_feedback_case_id", "cogit_rt_feedback", ["case_id"])
    op.create_index(
        "ix_cogit_rt_feedback_execution_id",
        "cogit_rt_feedback",
        ["execution_id"],
    )

    op.add_column(
        "cogit_rt_outbox",
        sa.Column("idempotency_key", sa.String(length=256), nullable=True),
    )
    op.create_index(
        "uq_outbox_idempotency_key",
        "cogit_rt_outbox",
        ["idempotency_key"],
        unique=True,
        postgresql_where=sa.text("idempotency_key IS NOT NULL"),
    )

    op.create_unique_constraint(
        "uq_run_event_execution_sequence",
        "cogit_rt_run_events",
        ["execution_id", "sequence"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_run_event_execution_sequence",
        "cogit_rt_run_events",
        type_="unique",
    )
    op.drop_index("uq_outbox_idempotency_key", table_name="cogit_rt_outbox")
    op.drop_column("cogit_rt_outbox", "idempotency_key")
    op.drop_index("ix_cogit_rt_feedback_execution_id", table_name="cogit_rt_feedback")
    op.drop_index("ix_cogit_rt_feedback_case_id", table_name="cogit_rt_feedback")
    op.drop_index("ix_cogit_rt_feedback_tenant_id", table_name="cogit_rt_feedback")
    op.drop_table("cogit_rt_feedback")
    op.drop_index("ix_cogit_rt_artifacts_tenant_id", table_name="cogit_rt_artifacts")
    op.drop_index("ix_cogit_rt_artifacts_execution_id", table_name="cogit_rt_artifacts")
    op.drop_index("ix_cogit_rt_artifacts_case_id", table_name="cogit_rt_artifacts")
    op.drop_table("cogit_rt_artifacts")
