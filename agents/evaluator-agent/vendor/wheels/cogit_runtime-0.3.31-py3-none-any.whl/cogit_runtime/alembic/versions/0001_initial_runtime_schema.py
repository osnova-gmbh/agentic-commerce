"""Initial runtime schema (``cogit_rt_*`` tables).

Revision ID: 0001_initial_runtime_schema
Revises:
Create Date: 2026-07-06

"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0001_initial_runtime_schema"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "cogit_rt_runs",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("organization_id", sa.String(length=128), nullable=True),
        sa.Column("agent_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("case_id", sa.String(length=128), nullable=True),
        sa.Column("session_id", sa.String(length=128), nullable=True),
        sa.Column("trigger", sa.String(length=32), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False, index=True),
        sa.Column("outcome_label", sa.String(length=128), nullable=True),
        sa.Column("input_summary", sa.Text(), nullable=True),
        sa.Column("output_summary", sa.Text(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("usage", sa.JSON(), nullable=True),
        sa.Column("error", sa.JSON(), nullable=True),
        sa.Column("run_metadata", sa.JSON(), nullable=True),
    )

    op.create_table(
        "cogit_rt_run_events",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column(
            "execution_id",
            sa.String(length=64),
            sa.ForeignKey("cogit_rt_runs.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        ),
        sa.Column("sequence", sa.Integer(), nullable=False),
        sa.Column("ts", sa.DateTime(timezone=True), nullable=False),
        sa.Column("type", sa.String(length=48), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
    )

    op.create_table(
        "cogit_rt_sessions",
        sa.Column("id", sa.String(length=128), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("agent_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("messages", sa.JSON(), nullable=False),
        sa.Column("state", sa.JSON(), nullable=True),
        sa.Column("session_metadata", sa.JSON(), nullable=True),
    )

    op.create_table(
        "cogit_rt_attention",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("kind", sa.String(length=48), nullable=False),
        sa.Column("execution_id", sa.String(length=64), nullable=True),
        sa.Column("case_id", sa.String(length=128), nullable=True),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("options", sa.JSON(), nullable=True),
        sa.Column("item_metadata", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("decision_action", sa.String(length=32), nullable=True),
        sa.Column("decision_rationale", sa.Text(), nullable=True),
        sa.Column("decided_by", sa.String(length=128), nullable=True),
        sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "cogit_rt_outbox",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("operation", sa.String(length=48), nullable=False, index=True),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("context", sa.JSON(), nullable=True),
        sa.Column(
            "enqueued_at",
            sa.DateTime(timezone=True),
            nullable=False,
            index=True,
        ),
        sa.Column("delivered", sa.Boolean(), nullable=False, index=True),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("retries", sa.Integer(), nullable=False),
    )

    op.create_table(
        "cogit_rt_learnings",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("agent_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=True),
        sa.Column("organization_id", sa.String(length=128), nullable=True),
        sa.Column("title", sa.Text(), nullable=False),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("tags", sa.JSON(), nullable=False),
        sa.Column("source", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "cogit_rt_experiments",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("agent_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("organization_id", sa.String(length=128), nullable=True),
        sa.Column("hypothesis", sa.Text(), nullable=False),
        sa.Column("changed_surface", sa.String(length=48), nullable=False),
        sa.Column("metrics", sa.JSON(), nullable=False),
        sa.Column("verdict", sa.String(length=32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "cogit_rt_evals",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=True),
        sa.Column("agent_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("agent_version", sa.String(length=64), nullable=False),
        sa.Column("suite_name", sa.String(length=128), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("eval_metadata", sa.JSON(), nullable=True),
    )


def downgrade() -> None:
    op.drop_table("cogit_rt_evals")
    op.drop_table("cogit_rt_experiments")
    op.drop_table("cogit_rt_learnings")
    op.drop_table("cogit_rt_outbox")
    op.drop_table("cogit_rt_attention")
    op.drop_table("cogit_rt_sessions")
    op.drop_table("cogit_rt_run_events")
    op.drop_table("cogit_rt_runs")
