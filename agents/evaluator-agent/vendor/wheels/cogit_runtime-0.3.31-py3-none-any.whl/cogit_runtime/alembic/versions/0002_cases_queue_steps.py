"""Add cases, queue items, and execution steps tables.

Revision ID: 0002_cases_queue_steps
Revises: 0001_initial_runtime_schema
Create Date: 2026-07-10

"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0002_cases_queue_steps"
down_revision: str | None = "0001_initial_runtime_schema"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "cogit_rt_cases",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("organization_id", sa.String(length=128), nullable=True),
        sa.Column("agent_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("source_type", sa.String(length=64), nullable=False),
        sa.Column("source_id", sa.String(length=256), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("retry_count", sa.Integer(), nullable=False),
        sa.Column("next_retry_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_attempt_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error", sa.JSON(), nullable=True),
        sa.Column("case_metadata", sa.JSON(), nullable=True),
        sa.UniqueConstraint(
            "tenant_id", "source_type", "source_id", name="uq_case_natural_key"
        ),
    )

    op.create_table(
        "cogit_rt_queue_items",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False, index=True),
        sa.Column("organization_id", sa.String(length=128), nullable=True),
        sa.Column("queue_name", sa.String(length=128), nullable=False, index=True),
        sa.Column("item_type", sa.String(length=64), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("addressed_to", sa.String(length=128), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False, index=True),
        sa.Column("case_id", sa.String(length=128), nullable=True),
        sa.Column("source_id", sa.String(length=256), nullable=True),
        sa.Column("idempotency_key", sa.String(length=256), nullable=True),
        sa.Column("dedupe_key", sa.String(length=256), nullable=True),
        sa.Column("retry_count", sa.Integer(), nullable=False),
        sa.Column("max_retries", sa.Integer(), nullable=False),
        sa.Column("lease_expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("heartbeat_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error", sa.Text(), nullable=True),
    )

    op.create_table(
        "cogit_rt_execution_steps",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "execution_id",
            sa.String(length=64),
            sa.ForeignKey("cogit_rt_runs.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        ),
        sa.Column("order_num", sa.Integer(), nullable=False),
        sa.Column("kind", sa.String(length=48), nullable=False),
        sa.Column("name", sa.String(length=256), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("summary", sa.Text(), nullable=True),
        sa.Column("data", sa.JSON(), nullable=True),
        sa.Column("error", sa.JSON(), nullable=True),
        sa.Column("usage", sa.JSON(), nullable=True),
        sa.UniqueConstraint(
            "execution_id", "order_num", name="uq_step_execution_order"
        ),
    )


def downgrade() -> None:
    op.drop_table("cogit_rt_execution_steps")
    op.drop_table("cogit_rt_queue_items")
    op.drop_table("cogit_rt_cases")
