"""Align the Alembic schema with the runtime outbox and checkpoint identity.

Revision ID: 0007_outbox_run_identity
Revises: 0006_database_ownership
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0007_outbox_run_identity"
down_revision: str | None = "0006_database_ownership"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_IDENTITIES = (
    ("cogit_rt_run_events", "execution_id"),
    ("cogit_rt_execution_steps", "execution_id"),
    ("cogit_rt_attention", "execution_id"),
    ("cogit_rt_runs", "id"),
)
_OUTBOX = "cogit_rt_outbox"
_INDEXES = {
    "ix_cogit_rt_outbox_available_at": "available_at",
    "ix_cogit_rt_outbox_dead_lettered": "dead_lettered",
}


def _known_layout() -> tuple[dict[tuple[str, str], int], bool, bool]:
    """Reject shapes outside the prior Alembic/create-all layouts before DDL."""

    inspector = sa.inspect(op.get_bind())
    tables = set(inspector.get_table_names())
    required = {table for table, _ in _IDENTITIES} | {_OUTBOX}
    if not required.issubset(tables):
        raise RuntimeError("Runtime schema is missing required migration tables")
    widths: dict[tuple[str, str], int] = {}
    for table, name in _IDENTITIES:
        columns = {column["name"]: column for column in inspector.get_columns(table)}
        column = columns.get(name)
        if column is None or not isinstance(column["type"], sa.String):
            raise RuntimeError("Runtime schema has an incompatible ID column")
        width = column["type"].length
        if width not in (64, 128):
            raise RuntimeError("Runtime schema has an incompatible ID column")
        widths[(table, name)] = width

    columns = {column["name"]: column for column in inspector.get_columns(_OUTBOX)}
    available = columns.get("available_at")
    dead = columns.get("dead_lettered")
    if available is not None and (
        not isinstance(available["type"], sa.DateTime) or not available["nullable"]
    ):
        raise RuntimeError("Runtime schema has an incompatible outbox column")
    if dead is not None and not isinstance(dead["type"], sa.Boolean):
        raise RuntimeError("Runtime schema has an incompatible outbox column")
    if dead is not None and dead["default"] not in (None, "0", "false", "FALSE"):
        raise RuntimeError("Runtime schema has an incompatible outbox default")

    indexes = {index["name"]: index for index in inspector.get_indexes(_OUTBOX)}
    for index_name, column_name in _INDEXES.items():
        index = indexes.get(index_name)
        if index is not None and (
            index["column_names"] != [column_name] or index["unique"]
        ):
            raise RuntimeError("Runtime schema has an incompatible outbox index")
    idempotency = indexes.get("uq_outbox_idempotency_key")
    if (
        idempotency is None
        or idempotency["column_names"] != ["idempotency_key"]
        or not idempotency["unique"]
    ):
        raise RuntimeError("Runtime schema is missing outbox idempotency")
    event_uniques = {
        item["name"]: item
        for item in inspector.get_unique_constraints("cogit_rt_run_events")
    }
    event_unique = event_uniques.get("uq_run_event_execution_sequence")
    if event_unique is None or event_unique["column_names"] != [
        "execution_id",
        "sequence",
    ]:
        raise RuntimeError("Runtime schema is missing event uniqueness")
    return widths, available is not None, dead is not None


def upgrade() -> None:
    widths, available_exists, dead_exists = _known_layout()
    if not available_exists:
        op.add_column(
            _OUTBOX,
            sa.Column("available_at", sa.DateTime(timezone=True), nullable=True),
        )
    if not dead_exists:
        op.add_column(
            _OUTBOX,
            sa.Column(
                "dead_lettered", sa.Boolean(), nullable=False, server_default=sa.false()
            ),
        )
    op.execute(
        sa.text(
            "UPDATE cogit_rt_outbox SET dead_lettered = false "
            "WHERE dead_lettered IS NULL"
        )
    )
    if dead_exists:
        op.alter_column(
            _OUTBOX,
            "dead_lettered",
            existing_type=sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        )

    indexes = {
        index["name"] for index in sa.inspect(op.get_bind()).get_indexes(_OUTBOX)
    }
    for name, column in _INDEXES.items():
        if name not in indexes:
            op.create_index(name, _OUTBOX, [column])

    for table, column in _IDENTITIES:
        if widths[(table, column)] == 128:
            continue
        op.alter_column(
            table,
            column,
            existing_type=sa.String(length=64),
            type_=sa.String(length=128),
        )


def downgrade() -> None:
    raise RuntimeError("Downgrade would truncate runtime run identities")
