"""Add fuller case contract fields to cogit_rt_cases.

Revision ID: 0005_case_fields
Revises: 0004_artifacts_feedback
Create Date: 2026-07-13
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0005_case_fields"
down_revision: str | None = "0004_artifacts_feedback"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "cogit_rt_cases",
        sa.Column("current_goal", sa.Text(), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("process_id", sa.String(length=128), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("process_version", sa.String(length=64), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("assigned_agent_ids", sa.JSON(), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("owner", sa.String(length=128), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "cogit_rt_cases",
        sa.Column("final_outcome", sa.Text(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("cogit_rt_cases", "final_outcome")
    op.drop_column("cogit_rt_cases", "completed_at")
    op.drop_column("cogit_rt_cases", "updated_at")
    op.drop_column("cogit_rt_cases", "created_at")
    op.drop_column("cogit_rt_cases", "owner")
    op.drop_column("cogit_rt_cases", "assigned_agent_ids")
    op.drop_column("cogit_rt_cases", "process_version")
    op.drop_column("cogit_rt_cases", "process_id")
    op.drop_column("cogit_rt_cases", "current_goal")
