"""Persist the tenant ownership of a production runtime SQL database."""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0006_database_ownership"
down_revision: str | None = "0005_case_fields"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "cogit_rt_database_ownership",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.CheckConstraint("id = 1", name="ck_runtime_single_owner"),
    )


def downgrade() -> None:
    op.drop_table("cogit_rt_database_ownership")
