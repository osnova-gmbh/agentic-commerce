"""Add explicit case linkage to events and execution steps.

Revision ID: 0003_case_timeline
Revises: 0002_cases_queue_steps
Create Date: 2026-07-11
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0003_case_timeline"
down_revision: str | None = "0002_cases_queue_steps"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "cogit_rt_run_events",
        sa.Column("case_id", sa.String(length=128), nullable=True),
    )
    op.create_index(
        "ix_cogit_rt_run_events_case_id",
        "cogit_rt_run_events",
        ["case_id"],
    )
    op.add_column(
        "cogit_rt_execution_steps",
        sa.Column("case_id", sa.String(length=128), nullable=True),
    )
    op.create_index(
        "ix_cogit_rt_execution_steps_case_id",
        "cogit_rt_execution_steps",
        ["case_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_cogit_rt_execution_steps_case_id",
        table_name="cogit_rt_execution_steps",
    )
    op.drop_column("cogit_rt_execution_steps", "case_id")
    op.drop_index(
        "ix_cogit_rt_run_events_case_id",
        table_name="cogit_rt_run_events",
    )
    op.drop_column("cogit_rt_run_events", "case_id")
