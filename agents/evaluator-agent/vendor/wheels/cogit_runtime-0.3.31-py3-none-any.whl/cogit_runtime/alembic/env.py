"""Alembic env for cogit-runtime migrations.

Usage::

    alembic -c src/cogit_runtime/alembic/alembic.ini upgrade head

Uses the runtime's :data:`cogit_runtime.persistence.Base.metadata` as the
authoritative schema.
"""

from __future__ import annotations

import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool
from sqlalchemy.engine import make_url

from cogit_runtime.migrations import require_legacy_postgres
from cogit_runtime.persistence import Base

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def _resolved_database_url() -> str:
    url = os.environ.get("DATABASE_URL") or config.get_main_option("sqlalchemy.url")
    if not url:
        msg = "DATABASE_URL or alembic.ini sqlalchemy.url must be configured"
        raise RuntimeError(msg)
    require_legacy_postgres(make_url(url).get_backend_name())
    return url


def run_migrations_offline() -> None:
    context.configure(
        url=_resolved_database_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    shared_connection = config.attributes.get("connection")
    if shared_connection is not None:
        require_legacy_postgres(shared_connection.dialect.name)
        context.configure(connection=shared_connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()
        return

    section = config.get_section(config.config_ini_section) or {}
    section["sqlalchemy.url"] = _resolved_database_url()
    connectable = engine_from_config(
        section,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    try:
        with connectable.connect() as connection:
            context.configure(connection=connection, target_metadata=target_metadata)
            with context.begin_transaction():
                context.run_migrations()
    finally:
        connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
