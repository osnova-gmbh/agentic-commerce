"""Queue coordinator boundary.

The coordinator is the abstraction workers use to claim, heartbeat, complete,
and fail platform work. In production this delegates to
``CogitClient.queue.*``; in tests we can wire a fake coordinator to exercise
worker behavior without a live platform.
"""

from __future__ import annotations

import asyncio
from typing import Any, Protocol

from cogit_agent_sdk.client import CogitClient
from cogit_agent_sdk.types import QueueItem


class Coordinator(Protocol):
    """Boundary that queue workers use to claim and complete work."""

    async def claim(
        self,
        queues: list[str],
        item_types: list[str],
        lease_seconds: int,
    ) -> QueueItem | None:
        """Claim one queue item or return ``None`` when no work is available."""

    async def heartbeat(self, item_id: str) -> None:
        """Extend the active lease."""

    async def complete(self, item_id: str, outcome: dict[str, object]) -> None:
        """Complete leased work."""

    async def park(self, item_id: str) -> None:
        """Release a lease while work waits for human approval."""

    async def fail(
        self,
        item_id: str,
        error: str,
        retryable: bool,
    ) -> None:
        """Mark leased work as failed."""


class PlatformQueuePassthrough:
    """Coordinator backed by the SDK ``CogitClient.queue`` verbs.

    The runtime uses this coordinator when a Cogit platform API URL is
    configured. Blocking client calls run on a thread pool so they don't stall
    the ``asyncio`` event loop that owns the worker.
    """

    def __init__(self, client: CogitClient | None) -> None:
        self._client = client

    async def claim(
        self,
        queues: list[str],
        item_types: list[str],
        lease_seconds: int,
    ) -> QueueItem | None:
        _ = (item_types, lease_seconds)
        if self._client is None:
            return None
        for queue_name in queues or ["default"]:
            item = await asyncio.to_thread(
                self._client.queue.claim,
                queue_name,
            )
            if item is not None:
                return item
        return None

    async def heartbeat(self, item_id: str) -> None:
        if self._client is None:
            return
        await asyncio.to_thread(self._client.queue.heartbeat, item_id)

    async def complete(self, item_id: str, outcome: dict[str, object]) -> None:
        _ = outcome
        if self._client is None:
            return
        await asyncio.to_thread(self._client.queue.complete, item_id)

    async def park(self, item_id: str) -> None:
        # The platform queue API has no parked state yet. Local SQL
        # coordination is used for approval continuations.
        _ = item_id

    async def fail(
        self,
        item_id: str,
        error: str,
        retryable: bool,
    ) -> None:
        if self._client is None:
            return
        await asyncio.to_thread(
            self._client.queue.fail,
            item_id,
            error,
            retryable=retryable,
        )


class DisabledCoordinator:
    """Coordinator used when no platform is configured — always empty."""

    async def claim(
        self,
        queues: list[str],
        item_types: list[str],
        lease_seconds: int,
    ) -> QueueItem | None:
        _ = (queues, item_types, lease_seconds)
        return None

    async def heartbeat(self, item_id: str) -> None:
        _ = item_id

    async def complete(self, item_id: str, outcome: dict[str, Any]) -> None:
        _ = (item_id, outcome)

    async def park(self, item_id: str) -> None:
        _ = item_id

    async def fail(self, item_id: str, error: str, retryable: bool) -> None:
        _ = (item_id, error, retryable)
