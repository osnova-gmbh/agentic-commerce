"""Translate platform queue items into runtime run requests."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal, cast
from uuid import uuid4

from cogit_agent_sdk.types import Context, QueueItem, RunRequest

Trigger = Literal[
    "manual",
    "chat",
    "scheduled",
    "email",
    "queue",
    "api",
    "eval",
    "improvement",
]


def queue_item_to_run_request(
    item: QueueItem,
    *,
    default_agent_id: str,
) -> tuple[RunRequest, Context]:
    """Build a run request and its context from a claimed platform queue item."""

    payload_any: dict[str, Any] = item.payload

    context_source = _extract_dict(payload_any, "context")
    tenant_id = _extract_str(context_source, "tenant_id") or item.tenant_id
    organization_id = (
        _extract_str(context_source, "organization_id") or item.organization_id
    )
    correlation_id = _extract_str(context_source, "correlation_id") or item.id
    agent_id = _extract_str(context_source, "agent_id") or default_agent_id
    session_id = _extract_str(context_source, "session_id")
    trigger_value = _extract_str(context_source, "trigger") or "queue"

    context = Context(
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        organization_id=organization_id,
        agent_id=agent_id,
        queue_item_id=item.id,
        case_id=item.case_id,
        session_id=session_id,
        trigger=_coerce_trigger(trigger_value),
        deadline=item.lease_expires_at,
    )

    instruction = (
        _extract_str(payload_any, "instruction")
        or _extract_str(payload_any, "task")
        or f"Process queue item {item.id}"
    )
    input_data = _extract_dict(payload_any, "input")
    pipeline_name = _extract_str(payload_any, "pipeline")
    pipeline_id = _extract_str(payload_any, "pipeline_id")
    metadata = {
        "queue_name": item.queue_name,
        "item_type": item.item_type,
        "queue_item_id": item.id,
        "retry_count": item.retry_count,
        "claimed_at": datetime.now(UTC).isoformat(),
        "trace_id": str(uuid4()),
    }
    if pipeline_id is not None:
        metadata["pipeline_id"] = pipeline_id

    run_request = RunRequest(
        instruction=instruction,
        input=input_data or None,
        context=context,
        mode="sync",
        pipeline=pipeline_name,
        metadata=metadata,
    )
    return run_request, context


def _extract_dict(source: dict[str, Any], key: str) -> dict[str, Any]:
    value: Any = source.get(key)
    if not isinstance(value, dict):
        return {}
    return cast(dict[str, Any], value)


def _extract_str(source: dict[str, Any], key: str) -> str | None:
    value = source.get(key)
    if isinstance(value, str) and value:
        return value
    return None


def _coerce_trigger(value: str) -> Trigger:
    allowed: set[Trigger] = {
        "manual",
        "chat",
        "scheduled",
        "email",
        "queue",
        "api",
        "eval",
        "improvement",
    }
    if value in allowed:
        return value  # type: ignore[return-value]
    return "queue"
