"""Resolve exact provider clients without a production echo fallback."""

from __future__ import annotations

import os
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import cast

from cogit_agent_sdk.providers import IdentifiedModelClient, ModelProviderError
from cogit_agent_sdk.types import (
    AssistantMessage,
    Cancellation,
    Message,
    ModelClient,
    ModelDescriptor,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
    TextContent,
    ToolResultMessage,
    Usage,
)

from cogit_runtime.config import ModelConfig, ModelFallbackConfig, RuntimeEnvironment
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.model_diagnostics import record_model_diagnostic
from cogit_runtime.readiness import ReadyModel, RuntimeModelProfile


class EchoModelClient:
    """Deterministic ``ModelClient`` that echoes the latest user text.

    Used when no production model is configured. Emits a single assistant
    message with no tool calls so the loop terminates on the first turn.
    """

    def __init__(self, model_name: str = "runtime-echo") -> None:
        self._model_name = model_name

    def generate(
        self,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> ModelResponse:
        cancellation.throw_if_cancelled()
        text = _latest_user_text(request.messages)
        assistant = AssistantMessage(
            content=[TextContent(text=f"Runtime scaffold echo: {text}")],
            model=self._model_name,
            provider="runtime",
            usage=Usage(input_tokens=0, output_tokens=0, provider="runtime"),
            stop_reason="end_turn",
        )
        return ModelResponse(
            message=assistant,
            usage=assistant.usage,
            stop_reason=assistant.stop_reason,
            provider_response_id=None,
        )

    def stream(
        self,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> Iterable[ModelStreamEvent]:
        response = self.generate(request, cancellation)
        yield ModelStreamEvent(
            type="message_completed",
            message=response.message,
            usage=response.usage,
            stop_reason=response.stop_reason,
        )


class UnavailableModelClient:
    """Injected into deterministic profiles; any accidental dispatch fails closed."""

    def generate(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> ModelResponse:
        _ = request, cancellation
        raise RuntimeConfigurationError("This agent profile has no model dispatch")

    def stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterable[ModelStreamEvent]:
        _ = request, cancellation
        raise RuntimeConfigurationError("This agent profile has no model dispatch")
        yield  # pragma: no cover - retain the ModelClient stream signature


class GuardedModelClient:
    """Route only to boot-verified adapter instances and exact model identities."""

    def __init__(
        self,
        routes: Mapping[tuple[str, str], tuple[ReadyModel, ModelClient]],
        selected: ReadyModel,
        *,
        canonical: bool = False,
    ) -> None:
        self._routes = dict(routes)
        self.selected = selected
        self.canonical = canonical

    def require_ready_route(self, provider: str, model: str) -> None:
        """Verify a declared route has a constructed SDK adapter at boot."""

        if (provider, model) not in self._routes:
            raise RuntimeConfigurationError(
                "Direct model dispatch is outside the verified "
                "provider/model allow-list"
            )

    def _route(
        self, request: ModelRequest, *, streaming: bool = False
    ) -> tuple[ModelClient, ModelRequest]:
        requested = request.model
        key = (
            (requested.provider.strip().lower(), requested.model.strip())
            if requested is not None
            else (self.selected.provider, self.selected.model)
        )
        entry = self._routes.get(key)
        if entry is None:
            raise RuntimeConfigurationError(
                "Model request differs from the verified provider client"
            )
        ready, delegate = entry
        if requested is not None:
            ready.require_model_api(requested)
            if (requested.supports_tools and not ready.supports_tools) or (
                requested.supports_streaming and not ready.supports_streaming
            ):
                raise RuntimeConfigurationError(
                    "Model request advertises unsupported provider capabilities"
                )
        if request.tools and not ready.supports_tools:
            raise RuntimeConfigurationError("Selected provider cannot dispatch tools")
        if streaming and not ready.supports_streaming:
            raise RuntimeConfigurationError("Selected provider cannot stream")
        return delegate, request.model_copy(update={"model": ready.descriptor()})

    def generate(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> ModelResponse:
        self._require_direct_dispatch()
        delegate, bound_request = self._route(request)
        if bound_request.model is None or bound_request.model.openai_api != "responses":
            return delegate.generate(bound_request, cancellation)
        try:
            response = delegate.generate(bound_request, cancellation)
        except ModelProviderError as exc:
            record_model_diagnostic("model.provider_error", exc.error_details)
            raise
        if response.provider_info is not None:
            data = response.provider_info.model_dump(
                include={"requested_effort", "effective_effort"}, exclude_none=True
            )
            data["provider"] = "openai"
            data["provider_api"] = response.provider_info.api
            reported = response.message.model
            configured = bound_request.model.model
            if reported is not None and (
                reported == configured
                or re.fullmatch(
                    re.escape(configured) + r"-[0-9]{4}-[0-9]{2}-[0-9]{2}", reported
                )
            ):
                data["reported_model"] = reported
            record_model_diagnostic("model.provider_response", data)
        return response

    def _require_direct_dispatch(self) -> None:
        if self.canonical:
            raise RuntimeConfigurationError(
                "Canonical model dispatch requires handle.model_client with "
                "an explicit durable slot"
            )

    def identified_route(
        self,
        request: ModelRequest,
        *,
        streaming: bool = False,
    ) -> tuple[ModelDescriptor, IdentifiedModelClient]:
        """Expose the boot-verified concrete route to the canonical spend wrapper."""
        delegate, bound = self._route(request, streaming=streaming)
        if bound.model is None or not callable(
            getattr(delegate, "dispatch_identity", None)
        ):
            raise RuntimeConfigurationError(
                "Canonical dispatch requires identified provider"
            )
        return bound.model, cast(IdentifiedModelClient, delegate)

    def stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterable[ModelStreamEvent]:
        self._require_direct_dispatch()
        delegate, bound_request = self._route(request, streaming=True)
        yield from delegate.stream(bound_request, cancellation)


@dataclass(frozen=True)
class ResolvedModel:
    client: ModelClient
    selected: ReadyModel | None
    ready_models: tuple[ReadyModel, ...]
    detail: str


def resolve_model_selection(
    profile: RuntimeModelProfile,
    environment: RuntimeEnvironment,
    *,
    provider_env: Mapping[str, str] | None = None,
) -> ResolvedModel:
    """Construct supported SDK adapters before any work can be claimed."""

    if profile.kind == "disabled":
        return ResolvedModel(UnavailableModelClient(), None, (), "model disabled")
    _validate_model_apis(profile, environment)
    source = os.environ if provider_env is None else provider_env
    declared_providers = {item.provider for item in profile.models}
    if not environment.dev_mode:
        for provider, key, canonical_url in (
            ("openai", "OPENAI_BASE_URL", "https://api.openai.com/v1"),
            ("openrouter", "OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
            ("anthropic", "ANTHROPIC_BASE_URL", "https://api.anthropic.com"),
        ):
            if provider not in declared_providers:
                continue
            configured_url = source.get(key, "").strip().rstrip("/")
            if configured_url and configured_url != canonical_url:
                raise RuntimeConfigurationError(
                    f"Production {key} requires a verified provider endpoint"
                )
    if profile.kind == "sdk" and profile.models[0].provider == "runtime":
        if not environment.dev_mode:
            raise RuntimeConfigurationError("Runtime echo requires explicit local mode")
        ready = profile.models[0]
        return ResolvedModel(
            GuardedModelClient(
                {(ready.provider, ready.model): (ready, EchoModelClient(ready.model))},
                ready,
            ),
            ready,
            (ready,),
            "explicit local echo",
        )

    routes: dict[tuple[str, str], tuple[ReadyModel, ModelClient]] = {}
    for candidate in profile.models:
        client = (
            _try_openai(candidate.model, source, responses=True)
            if candidate.openai_api == "responses"
            else _resolve_provider(candidate.provider, source, candidate.model)
        )
        if client is not None:
            routes[(candidate.provider, candidate.model)] = (candidate, client)
    if not routes:
        raise RuntimeConfigurationError(
            "No declared model provider is ready; check credentials and dependencies"
        )
    if profile.kind == "external" and len(routes) != len(profile.models):
        raise RuntimeConfigurationError(
            "Every external model provider must be ready before agent construction"
        )
    selected = next(
        candidate
        for candidate in profile.models
        if (candidate.provider, candidate.model) in routes
    )
    if profile.kind == "sdk":
        routes = {
            (selected.provider, selected.model): routes[
                (selected.provider, selected.model)
            ]
        }
    ready_models = tuple(
        item for item in profile.models if (item.provider, item.model) in routes
    )
    detail = f"{selected.provider} adapter active model={selected.model}"
    if selected.openai_api is not None:
        detail += f" api={selected.openai_api}"
    if selected is not profile.models[0]:
        detail += f" (fallback for {profile.models[0].provider})"
    return ResolvedModel(
        GuardedModelClient(routes, selected, canonical=profile.canonical),
        selected,
        ready_models,
        detail,
    )


def _validate_model_apis(
    profile: RuntimeModelProfile, environment: RuntimeEnvironment
) -> None:
    for model in profile.models:
        if model.openai_api is not None and model.provider != "openai":
            raise RuntimeConfigurationError("openai_api requires the OpenAI provider")
        if model.openai_api != "responses":
            continue
        if not environment.dev_mode or profile.canonical or profile.kind != "sdk":
            raise RuntimeConfigurationError(
                "OpenAI Responses requires an explicit local SDK model profile"
            )
        if (
            model.supports_tools
            or model.supports_streaming
            or model.descriptor().supports_images
            or len(profile.models) != 1
        ):
            raise RuntimeConfigurationError(
                "OpenAI Responses supports text decisions without images, tools, "
                "streaming, or model fallback"
            )


def resolve_model_client(
    config: ModelConfig,
    environment: RuntimeEnvironment,
    *,
    descriptor: ModelDescriptor | None = None,
    request_model: ModelDescriptor | None = None,
    provider_env: Mapping[str, str] | None = None,
) -> tuple[ModelClient, str]:
    """Compatibility facade for the profile-aware client resolver."""

    effective = resolve_model_descriptor(
        request_model=request_model,
        descriptor=descriptor,
        runtime=config,
    )
    source = os.environ if provider_env is None else provider_env
    candidates: list[ReadyModel] = []
    if effective is not None and effective.model != "runtime-default":
        candidates.append(ReadyModel.from_descriptor(effective))
    elif environment.dev_mode:
        candidates.append(ReadyModel("runtime", "echo", False, False))
    for fallback in config.fallbacks or ():
        fallback_descriptor = _fallback_descriptor(fallback, source)
        if fallback_descriptor is not None:
            candidates.append(ReadyModel.from_descriptor(fallback_descriptor))
    if not candidates:
        raise RuntimeConfigurationError("A concrete model is required in production")
    profile = RuntimeModelProfile(
        kind="sdk",
        models=tuple(candidates),
        canonical=False,
        dev_mode=environment.dev_mode,
    )
    selected = resolve_model_selection(profile, environment, provider_env=source)
    return selected.client, selected.detail


def resolve_model_descriptor(
    *,
    request_model: ModelDescriptor | None = None,
    descriptor: ModelDescriptor | None = None,
    runtime: ModelConfig | None = None,
) -> ModelDescriptor | None:
    """Resolve model identity: request → descriptor → runtime default."""

    if request_model is not None:
        return request_model
    if descriptor is not None:
        return descriptor
    if runtime is None:
        return None
    return None


def _fallback_descriptor(
    fallback: str | ModelFallbackConfig,
    source: Mapping[str, str],
) -> ModelDescriptor | None:
    if isinstance(fallback, ModelFallbackConfig):
        return ModelDescriptor(
            provider=fallback.adapter,
            model=fallback.model,
            supports_tools=fallback.supports_tools,
            supports_streaming=fallback.supports_streaming,
            context_window=fallback.context_window,
            max_output_tokens=fallback.max_output_tokens,
        )
    env_key = f"{fallback.upper().replace('-', '_')}_MODEL"
    model = source.get(env_key)
    if not model:
        return None
    return ModelDescriptor(provider=fallback, model=model)


def _try_anthropic(default_model: str, source: Mapping[str, str]) -> ModelClient | None:
    api_key = source.get("ANTHROPIC_API_KEY", "").strip()
    if not api_key:
        return None
    try:
        from cogit_agent_sdk.providers import AnthropicModelClient
    except ImportError:
        return None

    try:
        return AnthropicModelClient(api_key=api_key, default_model=default_model)
    except RuntimeError:
        return None


def _try_openai(
    default_model: str, source: Mapping[str, str], *, responses: bool = False
) -> ModelClient | None:
    api_key = source.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        return None
    try:
        from cogit_agent_sdk.providers import (
            OpenAIModelClient,
            OpenAIResponsesModelClient,
        )
    except ImportError:
        return None

    base_url = source.get("OPENAI_BASE_URL") or "https://api.openai.com/v1"
    try:
        if responses:
            return OpenAIResponsesModelClient(
                api_key=api_key, base_url=base_url, default_model=default_model
            )
        return OpenAIModelClient(
            api_key=api_key,
            base_url=base_url,
            default_model=default_model,
            provider="openai",
        )
    except RuntimeError:
        return None


def _try_openrouter(
    default_model: str, source: Mapping[str, str]
) -> ModelClient | None:
    api_key = source.get("OPENROUTER_API_KEY", "").strip()
    if not api_key:
        return None
    try:
        from cogit_agent_sdk.providers import OpenAIModelClient
    except ImportError:
        return None

    # OpenRouter is OpenAI-compatible but never lives at OpenAI's own endpoint,
    # so a non-default base_url is required even when OPENROUTER_BASE_URL is unset.
    base_url = source.get("OPENROUTER_BASE_URL") or "https://openrouter.ai/api/v1"
    try:
        return OpenAIModelClient(
            api_key=api_key,
            base_url=base_url,
            default_model=default_model,
            provider="openrouter",
        )
    except RuntimeError:
        return None


def _resolve_provider(
    name: str,
    source: Mapping[str, str],
    default_model: str,
) -> ModelClient | None:
    """Resolve a supported adapter from the supplied credential snapshot."""

    if name == "anthropic":
        return _try_anthropic(default_model, source)
    if name == "openai":
        return _try_openai(default_model, source)
    if name == "openrouter":
        return _try_openrouter(default_model, source)
    return None


def _latest_user_text(
    messages: list[Message | AssistantMessage | ToolResultMessage],
) -> str:
    for message in reversed(messages):
        if isinstance(message, Message) and message.role == "user":
            for block in message.content:
                if isinstance(block, TextContent):
                    return block.text
    return ""
