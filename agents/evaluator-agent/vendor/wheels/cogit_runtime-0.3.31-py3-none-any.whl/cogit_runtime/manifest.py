"""Manifest loading for resident agent repositories."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any, cast

import yaml
from cogit_agent_sdk.types import AgentDescriptor
from cogit_agent_sdk.types.tools import ToolDescriptor, ToolResult
from pydantic import ValidationError

from cogit_runtime.config import RuntimeConfig
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.operations.parity import (
    validate_manifest_action_entries,
    validate_manifest_tool_entries,
)

_RUNTIME_KEY = "runtime"
_sdk_rebuilt = False


class RuntimeManifest:
    """Parsed agent descriptor plus runtime-owned configuration."""

    def __init__(self, descriptor: AgentDescriptor, config: RuntimeConfig) -> None:
        self.descriptor = descriptor
        self.config = config


def load_manifest(path: str | Path) -> RuntimeManifest:
    """Load ``cogit.yaml`` into SDK and runtime-owned models."""

    manifest_path = Path(path)
    try:
        raw_text = manifest_path.read_text(encoding="utf-8")
    except OSError as exc:
        msg = f"Could not read manifest at {manifest_path}"
        raise RuntimeConfigurationError(msg) from exc

    try:
        raw_loaded = yaml.safe_load(raw_text)
    except yaml.YAMLError as exc:
        msg = f"Manifest at {manifest_path} is not valid YAML"
        raise RuntimeConfigurationError(msg) from exc

    if not isinstance(raw_loaded, Mapping):
        msg = "Manifest must be a YAML mapping"
        raise RuntimeConfigurationError(msg)

    raw = dict(cast(Mapping[str, Any], raw_loaded))
    return parse_manifest(raw)


def parse_manifest(raw: Mapping[str, Any]) -> RuntimeManifest:
    """Parse an already-loaded manifest mapping."""

    _rebuild_sdk_models()

    allowed = (
        set(AgentDescriptor.model_fields) | _agent_descriptor_aliases() | {_RUNTIME_KEY}
    )
    unknown = sorted(set(raw) - allowed)
    if unknown:
        joined = ", ".join(unknown)
        msg = f"Unknown manifest key(s): {joined}"
        raise RuntimeConfigurationError(msg)

    runtime_raw = raw.get(_RUNTIME_KEY, {})
    if runtime_raw is None:
        runtime_raw = {}
    if not isinstance(runtime_raw, Mapping):
        msg = "Manifest 'runtime' must be a mapping"
        raise RuntimeConfigurationError(msg)

    descriptor_raw = {key: value for key, value in raw.items() if key != _RUNTIME_KEY}

    raw_actions = descriptor_raw.get("actions")
    action_errors = validate_manifest_action_entries(
        raw_actions if isinstance(raw_actions, list) else [],
    )
    if action_errors:
        joined = "; ".join(action_errors)
        raise RuntimeConfigurationError(
            f"Manifest action validation failed: {joined}",
        )

    raw_tools = descriptor_raw.get("tools")
    tool_errors = validate_manifest_tool_entries(
        raw_tools if isinstance(raw_tools, list) else [],
    )
    if tool_errors:
        joined = "; ".join(tool_errors)
        raise RuntimeConfigurationError(
            f"Manifest tool validation failed: {joined}",
        )

    try:
        descriptor = AgentDescriptor.model_validate(descriptor_raw)
        config = RuntimeConfig.model_validate(runtime_raw)
    except ValidationError as exc:
        msg = f"Manifest validation failed: {_format_validation_error(exc)}"
        raise RuntimeConfigurationError(msg) from exc

    return RuntimeManifest(descriptor=descriptor, config=config)


def generate_manifest_schema() -> dict[str, Any]:
    """Export a JSON Schema for cogit.yaml (descriptor + runtime sections)."""
    _rebuild_sdk_models()
    descriptor_schema = AgentDescriptor.model_json_schema(by_alias=False)
    runtime_schema = RuntimeConfig.model_json_schema()
    definitions = {
        **descriptor_schema.get("$defs", {}),
        **runtime_schema.get("$defs", {}),
    }
    runtime_schema = {
        key: value for key, value in runtime_schema.items() if key != "$defs"
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "CogitAgentManifest",
        "type": "object",
        "$defs": definitions,
        "properties": {
            **descriptor_schema.get("properties", {}),
            "runtime": runtime_schema,
        },
        "required": descriptor_schema.get("required", []),
        "additionalProperties": False,
    }


def _agent_descriptor_aliases() -> set[str]:
    return {
        field.alias
        for field in AgentDescriptor.model_fields.values()
        if field.alias is not None
    }


def _format_validation_error(exc: ValidationError) -> str:
    """Format pydantic errors with dotted field paths."""
    parts: list[str] = []
    for error in exc.errors():
        loc = ".".join(str(segment) for segment in error["loc"])
        message = error.get("msg", "invalid value")
        if loc:
            parts.append(f"{loc}: {message}")
        else:
            parts.append(str(message))
    return "; ".join(parts) if parts else str(exc)


def _rebuild_sdk_models() -> None:
    """Resolve SDK forward refs needed by pydantic at runtime.

    The SDK owns the types; the runtime only ensures they are ready before using
    them as FastAPI response models or manifest validators.
    """

    global _sdk_rebuilt
    if _sdk_rebuilt:
        return

    namespace = {"JsonValue": Any, "JsonObject": dict[str, Any]}
    ToolDescriptor.model_rebuild(_types_namespace=namespace)
    ToolResult.model_rebuild(_types_namespace=namespace)
    AgentDescriptor.model_rebuild(_types_namespace=namespace)
    _sdk_rebuilt = True
