"""FastAPI application factory for resident Cogit agents."""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from collections.abc import Mapping
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from functools import partial
from pathlib import Path
from typing import Annotated, Any, Literal, cast

from cogit_agent_sdk import __version__ as sdk_version
from cogit_agent_sdk.types import (
    AgentDescriptor,
    AttentionItem,
    Case,
    Context,
    Decision,
    ErrorInfo,
    EvalRecord,
    ExecutionRecord,
    ExperimentRecord,
    LearningRecord,
    LearningSource,
    QueryRequest,
    QueryResult,
    QueueItem,
    RunEvent,
    RunRequest,
    RunResult,
    Session,
)
from fastapi import (
    Body,
    Depends,
    FastAPI,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)

from cogit_runtime._version import __version__ as runtime_version
from cogit_runtime.agentdb.client import build_client
from cogit_runtime.agentdb.coordinator import AgentDbCoordinator
from cogit_runtime.api_models import (
    AcceptedRun,
    CancelResult,
    EvalRunRequest,
    ImprovementExperimentCreate,
    ImprovementExperimentTrigger,
    ImprovementExperimentUpdate,
    RunStatusRecord,
    UsageSummary,
)
from cogit_runtime.approvals import ApprovalStore
from cogit_runtime.async_evals import AsyncEvalManager
from cogit_runtime.async_runs import AsyncRunManager
from cogit_runtime.auth import AgentAuthenticator
from cogit_runtime.cancellation import (
    CancellationRegistry,
    RuntimeWorkDeferred,
)
from cogit_runtime.cases import CaseService
from cogit_runtime.config import (
    RuntimeConfig,
    RuntimeEnvironment,
)
from cogit_runtime.context import ContextResolver
from cogit_runtime.coordinator import Coordinator
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.eval_launch import launch_eval
from cogit_runtime.health import HealthComponent, HealthReport, VersionInfo
from cogit_runtime.idempotency import IdempotencyStore
from cogit_runtime.lifecycle import AgentLifecycleManager
from cogit_runtime.loop_host import SdkLoopHost
from cogit_runtime.manifest import load_manifest
from cogit_runtime.middleware import (
    BodySizeLimitMiddleware,
    CorrelationIdMiddleware,
    RateLimitMiddleware,
)
from cogit_runtime.model import resolve_model_selection
from cogit_runtime.observability import configure_logging
from cogit_runtime.platform import PlatformReporter
from cogit_runtime.readiness import ModelInvocationPolicy, prepare_model_profile
from cogit_runtime.recovery import RecoveryReport
from cogit_runtime.reporter import RunReporter
from cogit_runtime.run_output import durable_run_output
from cogit_runtime.runner import LoopHost
from cogit_runtime.sql_coordinator import SqlCoordinator
from cogit_runtime.store import InMemoryRuntimeStore, RuntimeStore
from cogit_runtime.validation import build_validated_registries

_logger = logging.getLogger("cogit_runtime.app")


@dataclass(frozen=True)
class RuntimeState:
    """Immutable state shared by initial runtime endpoints."""

    descriptor: AgentDescriptor
    config: RuntimeConfig
    environment: RuntimeEnvironment
    agent_class: type[Any]
    agent: object
    manifest_path: Path
    store: Any  # RuntimeStore — typed as Any to accept both implementations
    reporter: RunReporter
    context_resolver: ContextResolver
    loop_host: LoopHost
    cancellations: CancellationRegistry
    idempotency: IdempotencyStore
    async_runs: AsyncRunManager
    async_evals: AsyncEvalManager
    model_detail: str
    model_policy: ModelInvocationPolicy
    store_kind: str
    coordinator: Coordinator | AgentDbCoordinator
    platform: PlatformReporter
    approvals: ApprovalStore
    case_service: CaseService
    lifecycle: AgentLifecycleManager | None = None
    recovery_report: RecoveryReport | None = None


@dataclass(frozen=True)
class CogitRuntimeApp:
    """Builds a FastAPI app around one resident Cogit agent."""

    state: RuntimeState

    @classmethod
    def from_manifest(
        cls,
        manifest_path: str | Path,
        *,
        agent_class: type[Any],
        env: Mapping[str, str] | None = None,
    ) -> CogitRuntimeApp:
        """Create an AgentDB-backed runtime app from a ``cogit.yaml`` file."""
        return cls._from_manifest(manifest_path, agent_class=agent_class, env=env)

    @classmethod
    def _from_manifest_for_testing(
        cls,
        manifest_path: str | Path,
        *,
        agent_class: type[Any],
        env: Mapping[str, str] | None = None,
        store: InMemoryRuntimeStore | None = None,
    ) -> CogitRuntimeApp:
        """Build an isolated in-memory fixture for protocol tests."""
        return cls._from_manifest(
            manifest_path,
            agent_class=agent_class,
            env=env if env is not None else {"COGIT_DEV_MODE": "1"},
            test_mode=True,
            test_store=store,
        )

    @classmethod
    def _from_manifest(
        cls,
        manifest_path: str | Path,
        *,
        agent_class: type[Any],
        env: Mapping[str, str] | None,
        test_mode: bool = False,
        test_store: RuntimeStore | None = None,
    ) -> CogitRuntimeApp:
        environment = RuntimeEnvironment.from_env(env)
        agentdb = None if test_mode else environment.require_agentdb_execution()
        if test_mode and (
            environment.database_url is not None or environment.agentdb is not None
        ):
            raise RuntimeConfigurationError(
                "In-memory Runtime tests cannot select AgentDB or DATABASE_URL."
            )

        parsed_manifest = load_manifest(manifest_path)
        profile = prepare_model_profile(
            parsed_manifest.descriptor,
            parsed_manifest.config,
            environment,
            agent_class,
        )
        resolved_model = resolve_model_selection(
            profile,
            environment,
            provider_env=os.environ if env is None else env,
        )
        model_policy = ModelInvocationPolicy(
            profile,
            resolved_model.client,
            resolved_model.ready_models,
            resolved_model.selected,
        )
        store: RuntimeStore
        coordinator: Coordinator | AgentDbCoordinator
        if agentdb is not None:
            from cogit_runtime.agentdb.cohort import load_cohort
            from cogit_runtime.agentdb.errors import AgentDbConfigError

            if agentdb.cohort_receipt is None:
                raise AgentDbConfigError(
                    "Canonical workers require COGIT_AGENTDB_COHORT_RECEIPT"
                )
            cohort = load_cohort(
                Path(agentdb.cohort_receipt),
                manifest_path=Path(manifest_path),
                agent_class=agent_class,
                config=agentdb,
            )
            worker_client = build_client(
                agentdb,
                parsed_manifest.descriptor.database_packages,
                cohort=cohort,
            )
            try:
                worker_client.modules.readiness()
            except Exception:
                worker_client.close()
                raise
            coordinator = AgentDbCoordinator(agentdb, worker_client)
            # AgentDB is authoritative. This store is a bounded diagnostic shadow.
            store = InMemoryRuntimeStore(
                diagnostic_limits=parsed_manifest.config.diagnostic_history
            )
            store_kind = "agentdb"
        else:
            store = test_store if test_store is not None else InMemoryRuntimeStore()
            store_kind = "memory"
            coordinator = SqlCoordinator(store)

        platform = PlatformReporter(environment, store=store)
        client = platform.resolve_client()
        lifecycle = AgentLifecycleManager(
            agent_class,
            parsed_manifest.descriptor,
            environment,
            client=client,
        )
        agent = lifecycle.construct()
        reporter = RunReporter(store, platform=platform)
        model_client = resolved_model.client
        model_detail = resolved_model.detail
        services = lifecycle.inject_services(
            agent,
            model_client=model_client,
            store=store,
        )
        lifecycle.configure(agent, services)
        action_registry, tool_registry = build_validated_registries(
            agent, parsed_manifest.descriptor
        )

        default_agent_id = (
            parsed_manifest.descriptor.id or parsed_manifest.descriptor.name
        )
        context_resolver = ContextResolver(
            environment=environment,
            default_agent_id=default_agent_id,
        )
        case_service = CaseService(store, default_agent_id=default_agent_id)
        cancellations = CancellationRegistry()
        idempotency = IdempotencyStore()
        approvals = ApprovalStore(store)
        loop_host = SdkLoopHost(
            agent=agent,
            descriptor=parsed_manifest.descriptor,
            config=parsed_manifest.config,
            reporter=reporter,
            model_client=model_client,
            model_policy=model_policy,
            cancellations=cancellations,
            store=store,
            approvals=approvals,
            dev_mode=environment.dev_mode,
            handle_factory=(
                partial(
                    coordinator.make_run_handle,
                    diagnostic_limits=parsed_manifest.config.diagnostic_history,
                )
                if isinstance(coordinator, AgentDbCoordinator)
                else None
            ),
            external_execution=isinstance(coordinator, AgentDbCoordinator),
            action_registry=action_registry,
            tool_registry=tool_registry,
            loop_integrity_key=(
                bytes.fromhex(environment.agentdb.loop_integrity_key.get_secret_value())
                if environment.agentdb is not None
                and environment.agentdb.loop_integrity_key is not None
                else None
            ),
        )

        async_runs = AsyncRunManager(
            executor=loop_host.run,
            reporter=reporter,
            cancellations=cancellations,
        )

        state = RuntimeState(
            descriptor=parsed_manifest.descriptor,
            config=parsed_manifest.config,
            environment=environment,
            agent_class=agent_class,
            agent=agent,
            manifest_path=Path(manifest_path),
            store=store,
            reporter=reporter,
            context_resolver=context_resolver,
            loop_host=loop_host,
            cancellations=cancellations,
            idempotency=idempotency,
            async_runs=async_runs,
            async_evals=AsyncEvalManager(),
            model_detail=model_detail,
            model_policy=model_policy,
            store_kind=store_kind,
            coordinator=coordinator,
            platform=platform,
            approvals=approvals,
            case_service=case_service,
            lifecycle=lifecycle,
        )
        return cls(state=state)

    def build(self) -> FastAPI:
        """Build a FastAPI application with the initial runtime endpoints."""

        self.state.environment.validate_boot(self.state.config)
        logger = configure_logging(
            self.state.config.observability,
            self.state.environment,
        )
        logger.info(
            "runtime.boot",
            extra={
                "agent": self.state.descriptor.name,
                "agent_version": self.state.descriptor.version,
                "runtime": runtime_version,
                "sdk": sdk_version,
                "dev_mode": self.state.environment.dev_mode,
                "model_detail": self.state.model_detail,
                "platform_enabled": self.state.platform.enabled,
            },
        )

        runtime_state = self.state

        @asynccontextmanager
        async def _lifespan(_app: FastAPI):
            stop_outbox = asyncio.Event()
            outbox_task: asyncio.Task[None] | None = None
            if runtime_state.lifecycle is not None:
                await runtime_state.lifecycle.startup(runtime_state.agent)
            if runtime_state.platform.enabled:
                await asyncio.to_thread(runtime_state.platform.flush)
                outbox_task = asyncio.create_task(
                    _run_outbox_flusher(
                        runtime_state.platform,
                        interval_seconds=(
                            runtime_state.config.reporter.outbox_flush_interval_seconds
                        ),
                        stop=stop_outbox,
                    )
                )
            try:
                yield
            finally:
                stop_outbox.set()
                if outbox_task is not None:
                    await outbox_task
                await runtime_state.async_evals.shutdown()
                await runtime_state.async_runs.shutdown()
                await runtime_state.loop_host.drain_deferred()
                if runtime_state.lifecycle is not None:
                    await runtime_state.lifecycle.shutdown(runtime_state.agent)
                if runtime_state.platform.enabled:
                    await asyncio.to_thread(runtime_state.platform.flush)
                runtime_state.platform.close()

        app = FastAPI(
            title=self.state.descriptor.name,
            version=self.state.descriptor.version,
            lifespan=_lifespan,
        )
        app.add_middleware(
            BodySizeLimitMiddleware,
            limit_bytes=self.state.config.server.body_limit_mb * 1024 * 1024,
        )
        rate_limit = self.state.config.server.rate_limit
        if rate_limit.requests_per_minute is not None:
            app.add_middleware(
                RateLimitMiddleware,
                requests_per_minute=rate_limit.requests_per_minute,
                burst=rate_limit.burst or 0,
            )
        app.add_middleware(CorrelationIdMiddleware)
        app.state.cogit_runtime = self.state

        authenticator = AgentAuthenticator(self.state.environment)
        require_agent_key = Depends(authenticator.require_agent_key)
        require_admin_key = Depends(authenticator.require_admin_key)
        app.add_api_route(
            "/health",
            self._health_report,
            methods=["GET"],
            response_model=HealthReport,
        )
        app.add_api_route(
            "/manifest",
            self._manifest,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=AgentDescriptor,
        )
        app.add_api_route(
            "/query",
            self._query,
            methods=["POST"],
            dependencies=[require_agent_key],
            response_model=QueryResult,
        )
        app.add_api_route(
            "/runs",
            self._create_run,
            methods=["POST"],
            dependencies=[require_agent_key],
            response_model=RunResult | AcceptedRun,
        )
        app.add_api_route(
            "/runs/{execution_id}",
            self._get_run,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=RunStatusRecord,
        )
        app.add_api_route(
            "/runs/{execution_id}/events",
            self._get_run_events,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=list[RunEvent],
        )
        app.add_api_route(
            "/runs/{execution_id}/cancel",
            self._cancel_run,
            methods=["POST"],
            dependencies=[require_agent_key],
            response_model=CancelResult,
        )
        app.add_api_route(
            "/actions/{action_name}",
            self._run_action,
            methods=["POST"],
            dependencies=[require_agent_key],
            response_model=dict[str, Any],
        )
        app.add_api_route(
            "/sessions/{session_id}",
            self._get_session,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=Session,
        )
        app.add_api_route(
            "/sessions/{session_id}",
            self._delete_session,
            methods=["DELETE"],
            dependencies=[require_agent_key],
            response_model=Session,
        )
        app.add_api_route(
            "/introspection/runs",
            self._introspection_runs,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=list[ExecutionRecord],
        )
        app.add_api_route(
            "/introspection/failures",
            self._introspection_failures,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=list[ExecutionRecord],
        )
        app.add_api_route(
            "/introspection/evals",
            self._introspection_evals,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=list[EvalRecord],
        )
        app.add_api_route(
            "/introspection/learnings",
            self._introspection_learnings,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=list[LearningRecord],
        )
        app.add_api_route(
            "/introspection/learnings",
            self._record_learning,
            methods=["POST"],
            dependencies=[require_agent_key],
            response_model=LearningRecord,
        )
        app.add_api_route(
            "/introspection/usage",
            self._usage_summary,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=UsageSummary,
        )
        app.add_api_route(
            "/evals/run",
            self._run_eval,
            methods=["POST"],
            dependencies=[require_admin_key],
            response_model=AcceptedRun,
        )
        app.add_api_route(
            "/evals/runs/{eval_id}",
            self._get_eval,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=EvalRecord,
        )
        app.add_api_route(
            "/improvement/experiments",
            self._create_experiment,
            methods=["POST"],
            dependencies=[require_admin_key],
            response_model=ExperimentRecord,
        )
        app.add_api_route(
            "/improvement/experiments",
            self._list_experiments,
            methods=["GET"],
            dependencies=[require_admin_key],
            response_model=list[ExperimentRecord],
        )
        app.add_api_route(
            "/improvement/experiments/{experiment_id}",
            self._get_experiment,
            methods=["GET"],
            dependencies=[require_admin_key],
            response_model=ExperimentRecord,
        )
        app.add_api_route(
            "/improvement/experiments/{experiment_id}",
            self._update_experiment,
            methods=["PATCH"],
            dependencies=[require_admin_key],
            response_model=ExperimentRecord,
        )
        app.add_api_route(
            "/improvement/experiments/{experiment_id}/run",
            self._trigger_experiment,
            methods=["POST"],
            dependencies=[require_admin_key],
            response_model=ExperimentRecord,
        )
        app.add_api_route(
            "/attention",
            self._list_attention,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=list[AttentionItem],
        )
        app.add_api_route(
            "/attention/{item_id}",
            self._get_attention,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=AttentionItem,
        )
        app.add_api_route(
            "/attention/{item_id}/decision",
            self._decide_attention,
            methods=["POST"],
            dependencies=[require_admin_key],
            response_model=Decision,
        )
        app.add_api_route(
            "/cases",
            self._list_cases,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=list[Case],
        )
        app.add_api_route(
            "/cases/{case_id}",
            self._get_case,
            methods=["GET"],
            dependencies=[require_agent_key],
            response_model=Case,
        )
        app.add_api_route(
            "/cases/{case_id}/retry",
            self._retry_case,
            methods=["POST"],
            dependencies=[require_admin_key],
            response_model=QueueItem,
        )
        app.add_api_route(
            "/dev/enqueue",
            self._dev_enqueue,
            methods=["POST"],
            response_model=QueueItem,
        )

        return app

    def _health_report(self) -> HealthReport:
        if self.state.environment.dev_mode:
            auth_detail = "disabled by COGIT_DEV_MODE"
        else:
            auth_detail = "enabled"
        model_status: Literal["ok", "degraded"] = (
            "degraded" if "echo" in self.state.model_detail else "ok"
        )
        agent_status, agent_detail = self._agent_health()
        components = {
            "runtime": HealthComponent(status="ok"),
            "manifest": HealthComponent(
                status="ok",
                detail=str(self.state.manifest_path),
            ),
            "auth": HealthComponent(status="ok", detail=auth_detail),
            "agent": HealthComponent(
                status=agent_status,
                detail=agent_detail,
            ),
            "store": HealthComponent(status="ok", detail=self.state.store_kind),
            "reporter": HealthComponent(status="ok", detail="local scaffold"),
            "queue_worker": HealthComponent(status="ok", detail="interface scaffold"),
            "model_client": HealthComponent(
                status=model_status,
                detail=self.state.model_detail,
            ),
            "platform_reporter": self._platform_health_component(),
            "recovery": self._recovery_health_component(),
        }
        overall: Literal["ok", "degraded", "error"] = "ok"
        for component in components.values():
            if component.status == "error":
                overall = "error"
                break
            if component.status == "degraded":
                overall = "degraded"
        return HealthReport(
            status=overall,
            version=VersionInfo(
                agent=self.state.descriptor.version,
                runtime=runtime_version,
                sdk=sdk_version,
            ),
            dev_mode=self.state.environment.dev_mode,
            components=components,
        )

    def _platform_health_component(self) -> HealthComponent:
        platform = self.state.platform
        depth = platform.outbox_depth
        if not platform.enabled:
            return HealthComponent(status="degraded", detail="platform mirror disabled")
        if platform.degraded_reason:
            return HealthComponent(
                status="degraded",
                detail=f"platform mirror unavailable (outbox={depth})",
            )
        return HealthComponent(status="ok", detail=f"outbox={depth}")

    def _recovery_health_component(self) -> HealthComponent:
        report = self.state.recovery_report
        if report is None:
            return HealthComponent(status="ok", detail="no durable store configured")
        if not report.schema_version_ok:
            return HealthComponent(status="error", detail="schema verification failed")
        parts = []
        if report.expired_leases_recovered:
            parts.append(f"leases_recovered={report.expired_leases_recovered}")
        if report.expired_leases_dead_lettered:
            parts.append(f"leases_dead_lettered={report.expired_leases_dead_lettered}")
        if report.interrupted_runs_handled:
            parts.append(f"interrupted_runs={report.interrupted_runs_handled}")
        if report.outbox_pending:
            parts.append(f"outbox_pending={report.outbox_pending}")
        if report.attention_items_unresolved:
            parts.append(f"attention_unresolved={report.attention_items_unresolved}")
        detail = ", ".join(parts) if parts else "clean startup"
        return HealthComponent(status="ok", detail=detail)

    def _agent_health(self) -> tuple[Literal["ok", "degraded", "error"], str]:
        lifecycle = self.state.lifecycle
        if lifecycle is not None:
            if lifecycle.startup_error is not None:
                return "error", "agent startup failed"
            if not lifecycle.ready:
                return "degraded", "agent lifecycle not ready"

        method = getattr(self.state.agent, "health", None)
        default_detail = self.state.agent_class.__name__
        if not callable(method):
            return "ok", default_detail
        try:
            report = method()
        except Exception:
            return "degraded", f"{default_detail}: health check failed"
        if isinstance(report, Mapping):
            report_mapping = cast(Mapping[str, Any], report)
            raw_status = report_mapping.get("status")
            raw_detail = report_mapping.get("detail")
            detail = str(raw_detail) if raw_detail else default_detail
            if raw_status == "unhealthy":
                return "error", detail
            if raw_status in {"ok", "degraded", "error"}:
                return cast(
                    Literal["ok", "degraded", "error"],
                    raw_status,
                ), detail
        return "ok", default_detail

    def _manifest(self) -> AgentDescriptor:
        return self.state.descriptor

    def _require_local_admission(self) -> None:
        """Keep deployed execution and state mutations in AgentDB."""
        if self.state.store_kind == "agentdb":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "agentdb_admission_required",
                    "message": (
                        "Use AgentDB for execution and state changes. Submit new "
                        "work through AgentDB POST /v1/queries."
                    ),
                },
            )

    async def _query(
        self,
        request: Request,
        raw_body: Annotated[dict[str, Any], Body(...)],
    ) -> QueryResult:
        import asyncio

        self._require_local_admission()
        context = self._resolve_context(request, raw_body)
        query_request = QueryRequest.model_validate({**raw_body, "context": context})
        try:
            self.state.loop_host.validate_query_request(query_request, context)
            execution = self.state.reporter.begin(
                context=context,
                trigger="query",
                input_summary=query_request.query,
                metadata={
                    "endpoint": "/query",
                    **self.state.loop_host.prompt_run_metadata(context),
                },
            )
        except RuntimeConfigurationError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=str(exc),
            ) from exc
        timeout_seconds = self.state.config.server.sync_run_timeout_seconds
        query_task = asyncio.create_task(
            self.state.loop_host.query(
                query_request,
                context,
                self.state.reporter,
                execution.id,
            )
        )
        try:
            done, _pending = await asyncio.wait(
                {query_task},
                timeout=timeout_seconds,
            )
        except asyncio.CancelledError:
            self.state.cancellations.cancel(execution.id)
            self.state.loop_host.track_deferred_task(query_task)
            raise
        if query_task not in done:
            self.state.cancellations.cancel(execution.id)
            try:
                done, _pending = await asyncio.wait({query_task}, timeout=1.0)
            except asyncio.CancelledError:
                self.state.loop_host.track_deferred_task(query_task)
                raise
            if query_task not in done:
                self.state.loop_host.track_deferred_task(query_task)
            else:
                query_task.exception()
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="Sync query exceeded configured timeout",
            )
        result = query_task.result()

        status_value: Literal["completed", "failed"] = (
            "failed" if result.error else "completed"
        )
        completed = self.state.reporter.complete(
            execution.id,
            status=status_value,
            output_summary=result.answer or result.interpretation,
            error=result.error,
            usage=result.usage,
        )
        if query_request.include_trace:
            result = result.model_copy(
                update={"trace": self.state.store.list_events(completed.id)}
            )
        return result

    async def _create_run(
        self,
        request: Request,
        raw_body: Annotated[dict[str, Any], Body(...)],
    ) -> RunResult | AcceptedRun:
        import asyncio

        self._require_local_admission()
        context = self._resolve_context(request, raw_body)
        run_request = RunRequest.model_validate({**raw_body, "context": context})
        try:
            self.state.loop_host.validate_run_request(run_request, context)
        except RuntimeConfigurationError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(exc),
            ) from exc

        idempotency_key = request.headers.get("idempotency-key")
        scoped_key = None
        if idempotency_key:
            scoped_key = self.state.idempotency.scoped_key(
                context.tenant_id,
                context.agent_id or self._default_agent_id(),
                idempotency_key,
            )
            existing = self.state.idempotency.get(scoped_key)
            if existing is not None:
                record = self.state.store.get_run(existing)
                if record is None:
                    return AcceptedRun(run_id=existing)
                if record.status == "running":
                    return AcceptedRun(run_id=existing)
                return RunResult(
                    execution_record=record,
                    output=durable_run_output(record, self.state.store),
                    status=record.status,
                    outcome_label=record.outcome_label,
                    usage=record.usage,
                    error=record.error,
                )

        try:
            execution = self.state.reporter.begin(
                context=context,
                trigger="run",
                input_summary=run_request.instruction,
                metadata={
                    "endpoint": "/runs",
                    "mode": run_request.mode,
                    **self.state.loop_host.prompt_run_metadata(context),
                },
            )
        except RuntimeConfigurationError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=str(exc),
            ) from exc
        if scoped_key is not None:
            self.state.idempotency.put(scoped_key, execution.id)

        if run_request.mode == "async":
            self.state.async_runs.schedule(
                execution_id=execution.id,
                request=run_request,
                context=context,
            )
            return AcceptedRun(run_id=execution.id)

        timeout_seconds = self.state.config.server.sync_run_timeout_seconds
        run_task = asyncio.create_task(
            self.state.loop_host.run(
                run_request,
                context,
                self.state.reporter,
                execution.id,
            )
        )
        try:
            done, _pending = await asyncio.wait(
                {run_task},
                timeout=timeout_seconds,
            )
        except asyncio.CancelledError:
            self.state.cancellations.cancel(execution.id)
            self.state.loop_host.track_deferred_task(run_task)
            raise
        if run_task in done:
            try:
                return run_task.result()
            except RuntimeWorkDeferred:
                raise HTTPException(
                    status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                    detail="Run cancellation is waiting for worker shutdown",
                ) from None

        self.state.cancellations.cancel(execution.id)
        # Give cooperative adapters and handlers a bounded chance to stop.
        # If they do not, the execution remains running until the owned task
        # actually exits; never publish a false terminal state.
        try:
            done, _pending = await asyncio.wait({run_task}, timeout=1.0)
        except asyncio.CancelledError:
            self.state.loop_host.track_deferred_task(run_task)
            raise
        if run_task not in done:
            self.state.loop_host.track_deferred_task(run_task)
        else:
            run_task.exception()
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="Sync run exceeded configured timeout",
        )

    def _get_run(self, execution_id: str) -> RunStatusRecord:
        record = self.state.store.get_run(execution_id)
        if record is None:
            raise _not_found("run")
        return RunStatusRecord.model_validate(
            {
                **record.model_dump(mode="python"),
                "output": durable_run_output(record, self.state.store),
            }
        )

    def _get_run_events(
        self,
        execution_id: str,
        response: Response,
        after_seq: int = Query(default=0, ge=0),
    ) -> list[RunEvent]:
        if self.state.store_kind == "agentdb" and isinstance(
            self.state.store, InMemoryRuntimeStore
        ):
            events, history = self.state.store.list_events_with_diagnostics(
                execution_id, after_seq=after_seq
            )
            if history is None:
                raise _not_found("run")
            response.headers["X-Cogit-Local-History-Dropped-Events"] = str(
                history["dropped_events"]
            )
            response.headers["X-Cogit-Local-History-First-Retained-Sequence"] = str(
                history["first_retained_sequence"]
            )
            response.headers["X-Cogit-Local-History-Next-Sequence"] = str(
                history["next_event_sequence"]
            )
            return events
        if self.state.store.get_run(execution_id) is None:
            raise _not_found("run")
        return self.state.store.list_events(execution_id, after_seq=after_seq)

    def _cancel_run(self, execution_id: str) -> CancelResult:
        self._require_local_admission()
        record = self.state.store.get_run(execution_id)
        if record is None:
            raise _not_found("run")
        if record.status != "running":
            return CancelResult(execution_id=execution_id, status=record.status)
        signalled = self.state.async_runs.cancel(execution_id)
        if not signalled:
            signalled = self.state.cancellations.cancel(execution_id)
        latest = self.state.store.get_run(execution_id)
        if latest is not None and latest.status != "running":
            return CancelResult(execution_id=execution_id, status=latest.status)
        return CancelResult(
            execution_id=execution_id,
            status="cancelling" if signalled else "running",
        )

    async def _run_action(
        self,
        action_name: str,
        request: Request,
        payload: Annotated[dict[str, Any], Body(default_factory=dict)],
    ) -> dict[str, Any]:
        self._require_local_admission()
        action = self._action_descriptor(action_name)
        if action is None:
            raise _not_found("action")

        context = self.state.context_resolver.resolve(request)

        try:
            self.state.model_policy.require_context(context)
        except RuntimeConfigurationError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(exc),
            ) from exc

        if action.idempotency == "keyed":
            idempotency_key = request.headers.get("idempotency-key")
            if idempotency_key is None or not idempotency_key.strip():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"Action '{action_name}' requires a non-empty "
                        "Idempotency-Key header."
                    ),
                )

        try:
            execution = self.state.reporter.begin(
                context=context,
                trigger="action",
                input_summary=f"action:{action_name}",
                metadata={"endpoint": f"/actions/{action_name}"},
            )
        except RuntimeConfigurationError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=str(exc),
            ) from exc

        approval_id = request.headers.get("x-cogit-approval-id")
        try:
            result = await self.state.loop_host.execute_bound_action(
                action_name,
                payload,
                context,
                execution.id,
                idempotency_key=request.headers.get("idempotency-key"),
                approval_id=approval_id,
                approval_source="action",
                reporter=self.state.reporter,
            )
        except RuntimeWorkDeferred:
            raise
        except asyncio.CancelledError:
            self.state.reporter.complete(
                execution.id,
                status="cancelled",
                output_summary="Action cancelled",
                outcome_label="cancelled",
                error=ErrorInfo(
                    code="CANCELLED",
                    message="Action was cancelled",
                    retryable=False,
                ),
            )
            raise

        if (
            result.attention_item_id is not None
            and result.error is not None
            and result.error.code == "APPROVAL_REQUIRED"
        ):
            if context.case_id:
                self.state.case_service.mark_waiting_for_approval(context.case_id)
            self.state.reporter.complete(
                execution.id,
                status="partial",
                output_summary=result.error.message,
                outcome_label="waiting_for_approval",
            )
            return {
                "status": "parked",
                "attention_item_id": result.attention_item_id,
                "message": result.error.message,
                "next_step": (
                    "POST /attention/{item_id}/decision to approve or reject"
                ),
            }

        if result.status != "succeeded":
            error = result.error or ErrorInfo(
                code="ACTION_ERROR",
                message="Action failed",
                retryable=False,
            )
            status_value: Literal["completed", "failed", "cancelled"] = (
                "cancelled" if result.status == "cancelled" else "failed"
            )
            outcome_label = (
                "cancelled" if result.status == "cancelled" else error.code.lower()
            )
            self.state.reporter.complete(
                execution.id,
                status=status_value,
                output_summary=error.message,
                outcome_label=outcome_label,
                error=error,
            )
            raise _operation_http_error(error)

        self.state.reporter.complete(
            execution.id,
            status="completed",
            output_summary=f"Action {action_name} completed",
            outcome_label="action_completed",
        )
        output = result.output
        if isinstance(output, dict):
            return cast(dict[str, Any], output)
        return {"result": output}

    def _list_attention(self) -> list[AttentionItem]:
        return self.state.approvals.list_pending()

    def _get_attention(self, item_id: str) -> AttentionItem:
        item = self.state.approvals.get(item_id)
        if item is None:
            raise _not_found("attention item")
        return item

    def _decide_attention(
        self,
        item_id: str,
        payload: Annotated[dict[str, Any], Body(...)],
    ) -> Decision:
        self._require_local_admission()
        item = self.state.approvals.get(item_id)
        if item is None:
            raise _not_found("attention item")
        action_value = str(payload.get("action") or "abort")
        rationale = payload.get("rationale")
        decided_by = str(payload.get("decided_by") or "admin")
        decision = self.state.approvals.decide(
            item_id=item_id,
            action=action_value,
            rationale=str(rationale) if rationale else None,
            decided_by=decided_by,
        )
        context = self.state.approvals.context_for(item_id)
        if decision.action in {"approve", "continue"}:
            self._enqueue_approval_continuation(item, decision, context)
        elif context is not None and context.queue_item_id:
            self.state.store.fail_queue_item(
                context.queue_item_id,
                f"Approval {decision.action}",
                retryable=False,
            )
        return decision

    def _enqueue_approval_continuation(
        self,
        item: AttentionItem,
        decision: Decision,
        context: Context | None,
    ) -> None:
        metadata = item.metadata or {}
        action_name = metadata.get("action")
        if not isinstance(action_name, str) or not action_name:
            return

        parked_payload = self.state.approvals.payload_for(item.id) or {}
        parked_key = None
        if item.metadata:
            raw_key = item.metadata.get("idempotency_key")
            if isinstance(raw_key, str) and raw_key.strip():
                parked_key = raw_key.strip()
        if metadata.get("source") == "loop":
            arguments = parked_payload.get("arguments")
            action_payload = arguments if isinstance(arguments, dict) else {}
        else:
            action_payload = parked_payload

        original_item = (
            self.state.store.get_queue_item(context.queue_item_id)
            if context is not None and context.queue_item_id
            else None
        )
        queue_name = (
            original_item.queue_name if original_item is not None else "default"
        )
        tenant_id = (
            context.tenant_id
            if context is not None
            else self.state.environment.tenant_id or "default"
        )
        continuation_id = f"approval-{item.id}"
        if self.state.store.get_queue_item(continuation_id) is not None:
            return
        continuation = QueueItem(
            id=continuation_id,
            tenant_id=tenant_id,
            organization_id=context.organization_id if context is not None else None,
            queue_name=queue_name,
            item_type="approval_continuation",
            payload={
                "instruction": f"Continue approved action {action_name}",
                "action": action_name,
                "action_payload": action_payload,
                "attention_item_id": item.id,
                "decision_id": decision.id,
                "idempotency_key": parked_key,
                "context": (
                    context.model_dump(
                        by_alias=True,
                        mode="json",
                        exclude_none=True,
                    )
                    if context is not None
                    else {}
                ),
            },
            addressed_to=context.agent_id if context is not None else None,
            status="pending",
            case_id=item.case_id,
            source_id=item.id,
            idempotency_key=f"approval-continuation:{item.id}",
        )
        self.state.store.put_queue_item(continuation)
        if original_item is not None:
            self.state.store.complete_queue_item(
                original_item.id,
                {"status": "continued", "continuation_id": continuation.id},
            )

    def _list_cases(self, request: Request) -> list[Case]:
        context = self.state.context_resolver.resolve(request)
        return self.state.store.list_cases(tenant_id=context.tenant_id)

    def _get_case(self, case_id: str) -> Case:
        case = self.state.store.get_case(case_id)
        if case is None:
            raise _not_found("case")
        return case

    def _retry_case(
        self,
        case_id: str,
        payload: Annotated[dict[str, Any], Body(default_factory=dict)],
    ) -> QueueItem:
        self._require_local_admission()
        try:
            return self.state.case_service.enqueue_retry(case_id, request=payload)
        except KeyError:
            raise _not_found("case") from None

    def _get_session(self, session_id: str, request: Request) -> Session:
        context = self.state.context_resolver.resolve(request)
        if self.state.store_kind == "agentdb":
            session = self.state.store.get_session(session_id)
            if session is None or session.tenant_id != context.tenant_id:
                raise _not_found("session")
            return session
        session = self.state.store.get_or_create_session(
            session_id=session_id,
            tenant_id=context.tenant_id,
            agent_id=context.agent_id or self._default_agent_id(),
        )
        return session

    def _delete_session(self, session_id: str) -> Session:
        self._require_local_admission()
        session = self.state.store.delete_session(session_id)
        if session is None:
            raise _not_found("session")
        return session

    def _introspection_runs(self) -> list[ExecutionRecord]:
        return self.state.store.list_runs()

    def _introspection_failures(self) -> list[ExecutionRecord]:
        return [
            record
            for record in self.state.store.list_runs()
            if record.status in {"failed", "partial", "cancelled"}
        ]

    def _introspection_evals(self) -> list[EvalRecord]:
        return self.state.store.list_evals()

    def _introspection_learnings(self) -> list[LearningRecord]:
        return self.state.store.list_learnings()

    def _record_learning(
        self,
        payload: Annotated[dict[str, Any], Body(...)],
        request: Request,
    ) -> LearningRecord:
        self._require_local_admission()
        context = self.state.context_resolver.resolve(
            request,
            {
                "tenant_id": payload.get("tenant_id", payload.get("tenantId")),
                "agent_id": payload.get("agent_id", payload.get("agentId")),
            },
        )
        learning = LearningRecord.model_validate(
            {
                "id": payload.get("id") or str(uuid.uuid4()),
                "agent_id": context.agent_id,
                "tenant_id": context.tenant_id,
                "organization_id": payload.get("organization_id"),
                "source": payload.get("source")
                or LearningSource(kind="manual", id="runtime").model_dump(),
                "title": payload["title"],
                "body": payload["body"],
                "tags": payload.get("tags", []),
                "status": payload.get("status", "active"),
                "created_at": payload.get("created_at") or datetime.now(UTC),
            }
        )
        stored = self.state.store.put_learning(learning)
        self.state.platform.record_learning(stored)
        return stored

    def _usage_summary(self) -> UsageSummary:
        runs = self.state.store.list_runs()
        input_tokens = sum(record.usage.input_tokens for record in runs if record.usage)
        output_tokens = sum(
            record.usage.output_tokens for record in runs if record.usage
        )
        estimated_cost_total = sum(
            record.usage.estimated_cost.total
            for record in runs
            if record.usage and record.usage.estimated_cost
        )
        return UsageSummary(
            runs=len(runs),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            estimated_cost_total=estimated_cost_total,
        )

    async def _run_eval(
        self,
        payload: Annotated[EvalRunRequest, Body(default_factory=EvalRunRequest)],
        request: Request,
    ) -> AcceptedRun:
        self._require_local_admission()
        try:
            eval_id = launch_eval(
                manifest=self.state.manifest_path,
                suite=payload.suite or "all",
                endpoint=str(request.base_url).rstrip("/"),
                app=request.app,
                store=self.state.store,
                platform=self.state.platform,
                manager=self.state.async_evals,
                api_key=(
                    None
                    if self.state.environment.dev_mode
                    else self.state.environment.agent_api_key
                ),
                limit=payload.limit,
            )
        except (FileNotFoundError, ValueError) as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(exc),
            ) from exc
        return AcceptedRun(run_id=eval_id)

    def _get_eval(self, eval_id: str) -> EvalRecord:
        record = self.state.store.get_eval(eval_id)
        if record is None:
            raise _not_found("eval")
        return record

    def _create_experiment(
        self,
        payload: ImprovementExperimentCreate,
    ) -> ExperimentRecord:
        self._require_local_admission()
        record = ExperimentRecord(
            id=str(uuid.uuid4()),
            agent_id=self._default_agent_id(),
            organization_id=payload.organization_id,
            hypothesis=payload.hypothesis,
            changed_surface=cast(Any, payload.changed_surface),
            metrics=payload.metrics,
            verdict="proposed",
            created_at=datetime.now(UTC),
        )
        stored = self.state.store.put_experiment(record)
        self.state.platform.record_experiment(stored)
        return stored

    def _list_experiments(self) -> list[ExperimentRecord]:
        return self.state.store.list_experiments()

    def _get_experiment(self, experiment_id: str) -> ExperimentRecord:
        record = self.state.store.get_experiment(experiment_id)
        if record is None:
            raise _not_found("experiment")
        return record

    def _update_experiment(
        self,
        experiment_id: str,
        payload: ImprovementExperimentUpdate,
    ) -> ExperimentRecord:
        self._require_local_admission()
        record = self.state.store.get_experiment(experiment_id)
        if record is None:
            raise _not_found("experiment")
        updates: dict[str, Any] = {}
        if payload.verdict is not None:
            allowed = {"proposed", "running", "kept", "discarded", "needs_human"}
            if payload.verdict not in allowed:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Unknown verdict: {payload.verdict}",
                )
            updates["verdict"] = payload.verdict
        if payload.branch_or_revision is not None:
            updates["branch_or_revision"] = payload.branch_or_revision
        if payload.baseline_eval_record_id is not None:
            updates["baseline_eval_record_id"] = payload.baseline_eval_record_id
        if payload.candidate_eval_record_id is not None:
            updates["candidate_eval_record_id"] = payload.candidate_eval_record_id
        if payload.metrics is not None:
            merged = dict(record.metrics)
            merged.update(payload.metrics)
            updates["metrics"] = merged
        if payload.completed and record.completed_at is None:
            updates["completed_at"] = datetime.now(UTC)
        updated = record.model_copy(update=updates)
        stored = self.state.store.put_experiment(updated)
        self.state.platform.record_experiment(stored)
        return stored

    def _trigger_experiment(
        self,
        experiment_id: str,
        payload: ImprovementExperimentTrigger,
    ) -> ExperimentRecord:
        self._require_local_admission()
        record = self.state.store.get_experiment(experiment_id)
        if record is None:
            raise _not_found("experiment")
        updates: dict[str, Any] = {"verdict": "running"}
        if payload.branch_or_revision is not None:
            updates["branch_or_revision"] = payload.branch_or_revision
        merged = dict(record.metrics)
        merged.setdefault("triggers", [])
        triggers = cast(list[Any], merged["triggers"])
        triggers.append(
            {
                "at": datetime.now(UTC).isoformat(),
                "note": payload.note,
                "branch_or_revision": payload.branch_or_revision,
            }
        )
        merged["triggers"] = triggers
        updates["metrics"] = merged
        updated = record.model_copy(update=updates)
        stored = self.state.store.put_experiment(updated)
        self.state.platform.record_experiment(stored)
        return stored

    def _dev_enqueue(
        self,
        payload: Annotated[dict[str, Any], Body(...)],
    ) -> QueueItem:
        if not self.state.environment.dev_mode:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Dev queue endpoint is available only in COGIT_DEV_MODE",
            )
        item = QueueItem.model_validate(
            {
                "id": payload.get("id") or str(uuid.uuid4()),
                "tenant_id": payload.get("tenant_id")
                or self.state.environment.tenant_id
                or "dev",
                "queue_name": payload.get("queue_name") or "dev",
                "item_type": payload.get("item_type") or "manual",
                "payload": payload.get("payload") or {},
                "status": payload.get("status") or "pending",
                **payload,
            }
        )
        return self.state.case_service.ensure_queue_item(item)

    def _resolve_context(self, request: Request, raw_body: dict[str, Any]) -> Context:
        body_context = raw_body.get("context")
        mapping: Mapping[str, Any] | Context | None
        if isinstance(body_context, Context):
            mapping = body_context
        elif isinstance(body_context, Mapping):
            mapping = cast(Mapping[str, Any], body_context)
        else:
            mapping = None
        return self.state.context_resolver.resolve(request, mapping)

    def _default_agent_id(self) -> str:
        return self.state.descriptor.id or self.state.descriptor.name

    def _action_descriptor(self, action_name: str) -> Any | None:
        actions = self.state.descriptor.actions
        if not actions:
            return None
        for action in actions:
            if action.name == action_name:
                return action
        return None


async def _run_outbox_flusher(
    platform: PlatformReporter,
    *,
    interval_seconds: int,
    stop: asyncio.Event,
) -> None:
    """Flush durable platform operations until runtime shutdown."""

    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval_seconds)
        except TimeoutError:
            try:
                await asyncio.to_thread(platform.flush)
            except Exception:
                _logger.exception("platform.outbox_flush_failed")


def _operation_http_error(error: ErrorInfo) -> HTTPException:
    if error.code == "INVALID_INPUT":
        status_code = status.HTTP_400_BAD_REQUEST
    elif error.code == "MISSING_IDEMPOTENCY_KEY":
        status_code = status.HTTP_400_BAD_REQUEST
    elif error.code == "CAPABILITY_DENIED":
        status_code = status.HTTP_403_FORBIDDEN
    elif error.code in {
        "APPROVAL_DENIED",
        "APPROVAL_PAYLOAD_MISMATCH",
        "APPROVAL_ALREADY_CONSUMED",
        "APPROVAL_PAYLOAD_UNAVAILABLE",
        "IDEMPOTENCY_KEY_MISMATCH",
    }:
        status_code = status.HTTP_409_CONFLICT
    elif error.code == "CONTRACT_BREACH":
        status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    else:
        status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    return HTTPException(status_code=status_code, detail=error.message)


def _instantiate_agent(agent_class: type[Any]) -> object:
    try:
        return agent_class()
    except TypeError as exc:
        msg = "agent_class must be instantiable without constructor arguments"
        raise RuntimeConfigurationError(msg) from exc


def _not_found(kind: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=f"{kind} not found",
    )
