"""Runtime-specific exceptions."""


class RuntimeConfigurationError(ValueError):
    """Raised when runtime configuration or manifest loading fails."""
