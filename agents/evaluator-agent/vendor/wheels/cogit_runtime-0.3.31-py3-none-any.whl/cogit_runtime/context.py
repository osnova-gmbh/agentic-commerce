"""Context and correlation-id extraction for inbound runtime requests."""

from __future__ import annotations

import json
import uuid
from collections.abc import Mapping
from typing import Any, cast

from cogit_agent_sdk.types import Context
from fastapi import HTTPException, Request, status
from pydantic import ValidationError

from cogit_runtime.config import RuntimeEnvironment

_CONTEXT_HEADER = "x-cogit-context"
_CORRELATION_HEADER = "x-cogit-correlation-id"


class ContextResolver:
    """Builds SDK contexts from headers and request bodies."""

    def __init__(
        self,
        *,
        environment: RuntimeEnvironment,
        default_agent_id: str,
    ) -> None:
        self._environment = environment
        self._default_agent_id = default_agent_id

    def resolve(
        self,
        request: Request,
        body_context: Mapping[str, Any] | Context | None = None,
    ) -> Context:
        """Resolve context from headers first, then body fields and env defaults."""

        raw_context: dict[str, Any] = {}
        raw_context.update(_context_from_body(body_context))
        raw_context.update(_context_from_header(request))
        raw_context.update(_context_from_individual_headers(request))

        correlation_id = _header_value(request, _CORRELATION_HEADER)
        state_correlation_id = getattr(request.state, "cogit_correlation_id", None)
        raw_context["correlation_id"] = (
            raw_context.get("correlation_id")
            or correlation_id
            or _str_or_none(state_correlation_id)
            or str(uuid.uuid4())
        )

        raw_context["tenant_id"] = raw_context.get("tenant_id") or (
            self._environment.tenant_id
        )
        if not raw_context.get("tenant_id"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cogit context requires tenant_id",
            )

        if (
            self._environment.tenant_id is not None
            and raw_context["tenant_id"] != self._environment.tenant_id
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Cogit context tenant_id does not match configured tenant",
            )

        incoming_agent_id = raw_context.get("agent_id")
        if (
            incoming_agent_id is not None
            and incoming_agent_id != self._default_agent_id
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Cogit context agent_id does not match this runtime",
            )
        raw_context["agent_id"] = incoming_agent_id or self._default_agent_id

        try:
            return Context.model_validate(raw_context)
        except ValidationError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid Cogit context",
            ) from exc


def _context_from_body(
    body_context: Mapping[str, Any] | Context | None,
) -> dict[str, Any]:
    if body_context is None:
        return {}
    if isinstance(body_context, Context):
        return body_context.model_dump(exclude_none=True)
    return dict(body_context)


def _context_from_header(request: Request) -> dict[str, Any]:
    value = _header_value(request, _CONTEXT_HEADER)
    if value is None:
        return {}
    try:
        loaded = json.loads(value)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Cogit-Context must be valid JSON",
        ) from exc
    if not isinstance(loaded, Mapping):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Cogit-Context must be a JSON object",
        )
    return dict(cast(Mapping[str, Any], loaded))


def _context_from_individual_headers(request: Request) -> dict[str, Any]:
    mapping = {
        "tenant_id": "x-cogit-tenant-id",
        "organization_id": "x-cogit-organization-id",
        "agent_id": "x-cogit-agent-id",
        "execution_id": "x-cogit-execution-id",
        "case_id": "x-cogit-case-id",
        "queue_item_id": "x-cogit-queue-item-id",
        "session_id": "x-cogit-session-id",
        "trigger": "x-cogit-trigger",
        "locale": "x-cogit-locale",
    }
    return {
        field: value
        for field, header in mapping.items()
        if (value := _header_value(request, header)) is not None
    }


def _header_value(request: Request, name: str) -> str | None:
    value = request.headers.get(name)
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def _str_or_none(value: object) -> str | None:
    if isinstance(value, str):
        stripped = value.strip()
        return stripped or None
    return None
