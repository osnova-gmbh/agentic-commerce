"""Attach bounded provider diagnostics to the current hosted execution."""

from __future__ import annotations

import logging
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any

from cogit_runtime.reporter import RunReporter

_execution: ContextVar[tuple[RunReporter, str] | None] = ContextVar(
    "cogit_model_diagnostic_execution", default=None
)
_logger = logging.getLogger(__name__)


@contextmanager
def capture_model_diagnostics(
    reporter: RunReporter, execution_id: str
) -> Iterator[None]:
    token = _execution.set((reporter, execution_id))
    try:
        yield
    finally:
        _execution.reset(token)


def record_model_diagnostic(message: str, data: dict[str, Any]) -> None:
    execution = _execution.get()
    if execution is None:
        return
    reporter, execution_id = execution
    try:
        reporter.emit(
            execution_id=execution_id,
            event_type="step_recorded",
            payload={"message": message, "data": data},
        )
    except Exception:
        # An optional event must preserve the provider outcome.
        _logger.debug("Unable to record a model provider diagnostic")
