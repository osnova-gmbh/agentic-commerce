"""Cost aggregation stubs for runtime executions.

Tracks per-run and per-tenant token usage so the platform reporter and any
future budget enforcement can share one source of truth. The
:class:`CostAggregator` is intentionally minimal — the runtime aggregates
what the loop returns, and passes an ``EstimatedCost`` forward. Full pricing
tables live at the platform layer.
"""

from __future__ import annotations

from threading import RLock

from cogit_agent_sdk.types import Usage


class CostAggregator:
    """Accumulate usage across runs, keyed by tenant and agent."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._by_tenant: dict[str, Usage] = {}
        self._by_agent: dict[str, Usage] = {}
        self._total = Usage()

    def add(self, *, tenant_id: str, agent_id: str, usage: Usage | None) -> None:
        if usage is None:
            return
        with self._lock:
            self._total = _add(self._total, usage)
            self._by_tenant[tenant_id] = _add(
                self._by_tenant.get(tenant_id, Usage()),
                usage,
            )
            self._by_agent[agent_id] = _add(
                self._by_agent.get(agent_id, Usage()),
                usage,
            )

    def total(self) -> Usage:
        with self._lock:
            return self._total

    def for_tenant(self, tenant_id: str) -> Usage:
        with self._lock:
            return self._by_tenant.get(tenant_id, Usage())

    def for_agent(self, agent_id: str) -> Usage:
        with self._lock:
            return self._by_agent.get(agent_id, Usage())


def _add(a: Usage, b: Usage) -> Usage:
    return Usage(
        input_tokens=a.input_tokens + b.input_tokens,
        output_tokens=a.output_tokens + b.output_tokens,
        cache_read_tokens=a.cache_read_tokens + b.cache_read_tokens,
        cache_write_tokens=a.cache_write_tokens + b.cache_write_tokens,
        model=b.model or a.model,
        provider=b.provider or a.provider,
    )


__all__ = ["CostAggregator"]
