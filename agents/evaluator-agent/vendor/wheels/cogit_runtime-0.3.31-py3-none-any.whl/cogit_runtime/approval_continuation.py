"""Bind local queued continuations to trusted, previously parked context claims."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from cogit_agent_sdk.types import Context, QueueItem
from cogit_agent_sdk.types.capabilities import CapabilityGrant, validate_capability_name

from cogit_runtime.approvals import ApprovalStore


class InvalidApprovalContinuationError(ValueError):
    """A queue envelope cannot be bound to its saved approval subject."""


@dataclass(frozen=True)
class ApprovedContinuation:
    attention_id: str
    action: str
    payload: dict[str, Any]
    context: Context


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _require(condition: bool) -> None:
    if not condition:
        raise InvalidApprovalContinuationError("Invalid approval continuation binding")


def resolve_continuation(
    approvals: ApprovalStore, item: QueueItem, default_agent_id: str
) -> ApprovedContinuation:
    """Restore local claims only from the trusted approval record, never queue JSON."""
    try:
        attention_id = item.payload.get("attention_item_id")
        if not isinstance(attention_id, str) or not attention_id:
            raise InvalidApprovalContinuationError("Missing attention identity")
        record = approvals.record_for(attention_id)
        _require(record is not None)
        if record is None:
            raise InvalidApprovalContinuationError("Missing approval record")
        saved = Context.model_validate(record.context.model_dump(), strict=True)
        for grant in saved.permissions or ():
            if type(grant) is str:
                validate_capability_name(grant)
            elif isinstance(grant, CapabilityGrant):
                CapabilityGrant.model_validate(grant.model_dump(), strict=True)
            else:
                raise InvalidApprovalContinuationError("Malformed saved claims")
        metadata, decision = record.item.metadata or {}, record.decision
        _require(not record.consumed)
        _require(record.item.id == attention_id and decision is not None)
        if decision is None:
            raise InvalidApprovalContinuationError("Missing approval decision")
        _require(decision.action in {"approve", "continue"})
        _require(decision.attention_item_id == attention_id)
        _require(item.payload.get("decision_id") == decision.id)
        _require(item.id == f"approval-{attention_id}")
        _require(item.source_id == attention_id)
        _require(item.idempotency_key == f"approval-continuation:{attention_id}")
        _require(item.tenant_id == saved.tenant_id)
        _require(item.organization_id == saved.organization_id)
        _require(bool(saved.agent_id) and saved.agent_id == default_agent_id)
        _require(item.addressed_to == saved.agent_id)
        _require(item.case_id == saved.case_id == record.item.case_id)
        action = metadata.get("action")
        if not isinstance(action, str) or not action:
            raise InvalidApprovalContinuationError("Missing approved action")
        _require(item.payload.get("action") == action)
        _require(metadata.get("source") in {"action", "pipeline", "tool", "loop"})
        payload = record.payload
        if metadata.get("source") == "loop":
            payload = payload.get("arguments")
        if not isinstance(payload, dict):
            raise InvalidApprovalContinuationError("Missing approved payload")
        _require(_canonical(item.payload.get("action_payload")) == _canonical(payload))
        raw_key = metadata.get("idempotency_key")
        _require(raw_key is None or isinstance(raw_key, str))
        key = raw_key.strip() if isinstance(raw_key, str) else None
        _require(item.payload.get("idempotency_key") == key)
        supplied = item.payload.get("context", {})
        _require(isinstance(supplied, dict))
        expected = saved.model_dump(mode="json")
        aliases = saved.model_dump(mode="json", by_alias=True)
        for field in (
            "tenant_id",
            "organization_id",
            "agent_id",
            "case_id",
            "principal",
        ):
            alias = Context.model_fields[field].alias or field
            for name, wanted in ((field, expected[field]), (alias, aliases[alias])):
                if name in supplied:
                    actual = supplied[name]
                    if field == "principal" and isinstance(wanted, dict):
                        _require(isinstance(actual, dict))
                        actual = {key: actual.get(key) for key in ("kind", "id")}
                        wanted = {key: wanted.get(key) for key in ("kind", "id")}
                    _require(_canonical(actual) == _canonical(wanted))
        restored = saved.model_copy(
            update={
                "execution_id": None,
                "queue_item_id": item.id,
                "deadline": item.lease_expires_at,
            }
        )
        return ApprovedContinuation(attention_id, action, payload, restored)
    except (ValueError, TypeError, AttributeError, RecursionError) as exc:
        raise InvalidApprovalContinuationError(
            "Invalid approval continuation binding"
        ) from exc
