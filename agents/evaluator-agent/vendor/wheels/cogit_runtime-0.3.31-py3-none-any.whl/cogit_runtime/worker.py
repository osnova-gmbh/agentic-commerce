"""Queue worker that translates platform items into runtime runs."""

from __future__ import annotations

import asyncio
import sys
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import (
    ActionDescriptor,
    Context,
    QueueItem,
    RunRequest,
    RunResult,
)

from cogit_runtime.approval_continuation import (
    ApprovedContinuation,
    InvalidApprovalContinuationError,
    resolve_continuation,
)
from cogit_runtime.approvals import ApprovalStore
from cogit_runtime.cancellation import await_runtime_completion
from cogit_runtime.cases import CaseService
from cogit_runtime.config import WorkerConfig
from cogit_runtime.coordinator import Coordinator
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.reporter import RunReporter
from cogit_runtime.translate import queue_item_to_run_request

RunExecutor = Callable[[RunRequest, Context, RunReporter, str], Awaitable[RunResult]]

ActionExecutor = Callable[
    [
        str,
        dict[str, Any],
        Context,
        RunReporter,
        str,
        str | None,
    ],
    Awaitable[OperationExecutionResult],
]


@dataclass(frozen=True)
class WorkerStats:
    """Result of one worker polling pass."""

    claimed: int = 0

    completed: int = 0

    failed: int = 0

    parked: int = 0


class QueueWorker:
    """Claim/heartbeat/execute/complete loop backed by the runtime loop host."""

    def __init__(
        self,
        *,
        coordinator: Coordinator,
        config: WorkerConfig,
        queues: list[str],
        item_types: list[str],
        executor: RunExecutor,
        reporter: RunReporter,
        default_agent_id: str,
        approvals: ApprovalStore | None = None,
        action_executor: ActionExecutor | None = None,
        case_service: CaseService | None = None,
        action_descriptor: Callable[[str], ActionDescriptor | None] | None = None,
    ) -> None:

        self._coordinator = coordinator

        self._config = config

        self._queues = queues or ["default"]

        self._item_types = item_types

        self._executor = executor

        self._reporter = reporter

        self._default_agent_id = default_agent_id

        self._approvals = approvals

        self._action_executor = action_executor

        self._case_service = case_service

        self._action_descriptor = action_descriptor

    async def poll_once(self) -> WorkerStats:
        """Claim one item, execute it through the loop host, and report."""

        item = await self._coordinator.claim(
            self._queues,
            self._item_types,
            self._config.lease_seconds,
        )

        if item is None:
            return WorkerStats()

        heartbeat_task = asyncio.create_task(self._heartbeat_loop(item.id))

        try:
            outcome = await self._execute(item)

        finally:
            await _quiet_cancel(heartbeat_task)

        if outcome.get("status") == "failed":
            await self._coordinator.fail(
                item.id,
                str(outcome.get("error") or "run failed"),
                retryable=bool(outcome.get("retryable", True)),
            )

            return WorkerStats(claimed=1, failed=1)

        if outcome.get("status") == "parked":
            await self._coordinator.park(item.id)

            return WorkerStats(claimed=1, parked=1)

        await self._coordinator.complete(item.id, outcome)

        return WorkerStats(claimed=1, completed=1)

    async def run_forever(self) -> None:
        """Poll and process work until cancelled."""

        while True:
            try:
                stats = await self.poll_once()

            except asyncio.CancelledError:
                raise

            except CoordinationFailure:
                raise

            except Exception:
                stats = WorkerStats(failed=1)

            if stats.claimed == 0:
                await asyncio.sleep(self._config.poll_interval_seconds)

    async def _execute(self, item: QueueItem) -> dict[str, Any]:

        continuation = None
        if item.item_type == "approval_continuation":
            try:
                if self._approvals is None or self._action_executor is None:
                    raise InvalidApprovalContinuationError(
                        "Approval continuation unavailable"
                    )
                continuation = resolve_continuation(
                    self._approvals, item, self._default_agent_id
                )
            except InvalidApprovalContinuationError:
                return {
                    "status": "failed",
                    "error": "Invalid approval continuation binding",
                    "retryable": False,
                }

        if self._case_service is not None:
            item = self._case_service.ensure_queue_item(item)

        try:
            run_request, context = queue_item_to_run_request(
                item,
                default_agent_id=self._default_agent_id,
            )
            if continuation is not None:
                context = continuation.context.model_copy(
                    update={"case_id": item.case_id}
                )
                run_request = run_request.model_copy(update={"context": context})

        except CoordinationFailure:
            raise
        except Exception as exc:
            return {
                "status": "failed",
                "error": f"translate error: {exc}",
                "retryable": False,
            }

        execution = self._reporter.begin(
            context=context,
            trigger="queue",
            input_summary=run_request.instruction,
            metadata={"queue_item_id": item.id, "queue_name": item.queue_name},
        )

        if self._case_service is not None:
            self._case_service.begin_attempt(context.case_id)

        if item.item_type == "approval_continuation":
            outcome = await self._execute_approval_continuation(
                item,
                context,
                execution.id,
                continuation,
            )

            self._finish_case(context.case_id, outcome)

            return outcome

        try:
            result = await self._executor(
                run_request,
                context,
                self._reporter,
                execution.id,
            )

        except CoordinationFailure:
            raise
        except Exception as exc:
            self._reporter.complete(
                execution.id,
                status="failed",
                output_summary=str(exc),
                outcome_label="worker_exception",
            )

            outcome = {"status": "failed", "error": str(exc), "retryable": True}

            self._finish_case(context.case_id, outcome)

            return outcome

        if self._approvals is not None and self._approvals.pending_for_execution(
            execution.id
        ):
            outcome = {
                "status": "parked",
                "execution_id": execution.id,
                "attention_item_ids": [
                    pending.id
                    for pending in self._approvals.pending_for_execution(execution.id)
                ],
            }

            self._finish_case(context.case_id, outcome)

            return outcome

        outcome = {
            "status": result.status,
            "outcome_label": result.outcome_label,
            "execution_id": execution.id,
        }

        if result.status == "waiting" or result.outcome_label == "waiting_for_approval":
            outcome = {
                "status": "parked",
                "execution_id": execution.id,
                "outcome_label": result.outcome_label,
            }

            self._finish_case(context.case_id, outcome)

            return outcome

        self._finish_case(context.case_id, outcome)

        return outcome

    def _finish_case(
        self,
        case_id: str | None,
        outcome: dict[str, Any],
    ) -> None:

        if self._case_service is None:
            return

        self._case_service.finish_attempt(
            case_id,
            execution_status=str(outcome.get("status") or "failed"),
            error=(str(outcome["error"]) if outcome.get("error") is not None else None),
        )

    async def _execute_approval_continuation(
        self,
        item: QueueItem,
        context: Context,
        execution_id: str,
        continuation: ApprovedContinuation | None,
    ) -> dict[str, Any]:

        attention_item_id = continuation.attention_id if continuation else None

        action_name = continuation.action if continuation else None

        if (
            self._approvals is None
            or self._action_executor is None
            or not isinstance(attention_item_id, str)
            or not isinstance(action_name, str)
        ):
            error = "Invalid approval continuation payload"

            self._reporter.complete(
                execution_id,
                status="failed",
                output_summary=error,
                outcome_label="approval_continuation_invalid",
            )

            return {"status": "failed", "error": error, "retryable": False}

        assert continuation is not None
        action_payload = continuation.payload

        continuation_context = context.model_copy(
            update={"execution_id": execution_id, "queue_item_id": item.id}
        )

        result = await self._action_executor(
            action_name,
            action_payload,
            continuation_context,
            self._reporter,
            execution_id,
            attention_item_id,
        )

        descriptor = (
            self._action_descriptor(action_name)
            if self._action_descriptor is not None
            else None
        )

        retryable = _continuation_retryable(result, descriptor)

        if result.status != "succeeded":
            error = (
                result.error.message
                if result.error is not None
                else "Approval continuation failed"
            )

            self._reporter.complete(
                execution_id,
                status="failed",
                output_summary=error,
                outcome_label="approval_continuation_failed",
                error=result.error,
            )

            return {"status": "failed", "error": error, "retryable": retryable}

        self._reporter.complete(
            execution_id,
            status="completed",
            output_summary=f"Approved action {action_name} completed",
            outcome_label="approval_continuation_completed",
        )

        return {
            "status": "completed",
            "execution_id": execution_id,
            "output": result.output,
        }

    async def _heartbeat_loop(self, item_id: str) -> None:

        interval = max(1, self._config.lease_seconds // 3)

        while True:
            await asyncio.sleep(interval)

            try:
                await self._coordinator.heartbeat(item_id)

            except CoordinationFailure:
                raise
            except Exception:
                return


def _continuation_retryable(
    result: OperationExecutionResult,
    descriptor: ActionDescriptor | None,
) -> bool:

    if result.error is not None and not result.error.retryable:
        return False

    if result.invocation_started and descriptor is not None:
        if descriptor.idempotency == "none":
            return False

    return True


async def _quiet_cancel(task: asyncio.Task[Any]) -> None:

    primary = sys.exception()
    task.cancel()

    try:
        await await_runtime_completion(task)

    except CoordinationFailure:
        if not isinstance(primary, CoordinationFailure):
            raise

    except asyncio.CancelledError:
        return

    except Exception:
        return
