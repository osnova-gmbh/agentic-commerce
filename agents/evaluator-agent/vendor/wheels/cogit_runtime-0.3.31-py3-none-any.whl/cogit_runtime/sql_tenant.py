"""Fail closed before recovery when a SQL database crosses tenant boundaries."""

from __future__ import annotations

from sqlalchemy import Engine, insert, select
from sqlalchemy.exc import IntegrityError

from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.migrations import require_legacy_postgres
from cogit_runtime.persistence import Base, RuntimeDatabaseOwnership


def bind_sql_tenant(engine: Engine, tenant_id: str) -> None:
    """Atomically bind clean/same-tenant history; reject conflicting ownership."""
    require_legacy_postgres(engine.dialect.name)
    if not tenant_id or len(tenant_id) > 128:
        raise RuntimeConfigurationError(
            "Production SQL requires a bounded COGIT_TENANT_ID"
        )
    ownership = RuntimeDatabaseOwnership.__table__
    for attempt in range(2):
        try:
            with engine.begin() as connection:
                owner = connection.scalar(
                    select(ownership.c.tenant_id)
                    .where(ownership.c.id == 1)
                    .with_for_update()
                )
                if owner is not None and owner != tenant_id:
                    raise RuntimeConfigurationError(
                        "Runtime SQL database is bound to another tenant"
                    )
                for table in Base.metadata.sorted_tables:
                    if table is ownership or "tenant_id" not in table.c:
                        continue
                    foreign = connection.scalar(
                        select(table.c.tenant_id)
                        .where(table.c.tenant_id != tenant_id)
                        .limit(1)
                    )
                    if foreign is not None:
                        raise RuntimeConfigurationError(
                            "Runtime SQL database contains another tenant's records"
                        )
                if owner is None:
                    connection.execute(
                        insert(RuntimeDatabaseOwnership).values(
                            id=1, tenant_id=tenant_id
                        )
                    )
            return
        except IntegrityError:
            # Concurrent PostgreSQL first bindings race on the singleton key.
            # The losing transaction is rolled back before checking the winner.
            if attempt:
                raise RuntimeConfigurationError(
                    "Runtime SQL tenant binding could not be confirmed"
                ) from None


def reject_bound_dev_database(engine: Engine) -> None:
    """Development's unrestricted tenant selection cannot open a bound database."""
    require_legacy_postgres(engine.dialect.name)
    with engine.connect() as connection:
        owner = connection.scalar(select(RuntimeDatabaseOwnership.tenant_id))
    if owner is not None:
        raise RuntimeConfigurationError(
            "Tenant-bound SQL storage requires production mode"
        )
