"""Runtime-owned loop hook implementations."""

from __future__ import annotations

from cogit_agent_sdk.types import (
    ActionDescriptor,
    AgentLoopConfig,
    AgentLoopState,
    ArtifactRef,
    ArtifactSlot,
    Context,
    ErrorInfo,
    ModelCallReservation,
    ModelCallUsage,
    ModelRequest,
    ModelResponse,
    RunEvent,
    ToolCall,
    ToolDescriptor,
    ToolResult,
)
from cogit_agent_sdk.types.loop import LoopMessage

from cogit_runtime.reporter import RunReporter


class RuntimeReporterHooks:
    """Mirror SDK events into the runtime run reporter."""

    def __init__(self, *, reporter: RunReporter, execution_id: str) -> None:
        self._reporter = reporter
        self._execution_id = execution_id

    def on_event(self, event: RunEvent) -> None:
        self._reporter.emit(
            execution_id=self._execution_id,
            event_type=event.type,
            payload=dict(event.payload) if event.payload else {},
        )

    def transform_messages(
        self,
        messages: list[LoopMessage],
        context: Context,
    ) -> list[LoopMessage]:
        _ = context
        return messages

    def convert_to_model(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelRequest:
        return ModelRequest(
            messages=state.messages,
            tools=config.tools or [],
            model=config.model_descriptor,
        )

    def transform_tools(
        self,
        tools: list[ToolDescriptor],
        context: Context,
    ) -> list[ToolDescriptor]:
        _ = context
        return tools

    def prepare_next_turn(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> AgentLoopState:
        _ = config
        return state

    def before_tool_call(
        self,
        tool_call: ToolCall,
        context: Context,
    ) -> bool:
        _ = (tool_call, context)
        return True

    def after_tool_call(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Context,
    ) -> ToolResult:
        _ = (tool_call, context)
        return result

    def on_model_error(
        self,
        error: ErrorInfo,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelResponse | None:
        _ = (error, state, config)
        return None

    def on_artifact_declared(self, slot: ArtifactSlot) -> None:
        _ = slot

    def on_artifact_finalized(self, ref: ArtifactRef) -> None:
        _ = ref

    def on_model_call_reserved(self, reservation: ModelCallReservation) -> None:
        _ = reservation

    def on_model_call_settled(
        self,
        reservation: ModelCallReservation,
        usage: ModelCallUsage,
    ) -> None:
        _ = (reservation, usage)


class CompositeLoopHooks:
    """Chain hook layers with well-defined composition semantics."""

    def __init__(
        self,
        layers: list[object],
        *,
        system_prompt: str | None = None,
    ) -> None:
        self._layers = layers
        self._system_prompt = system_prompt

    def transform_messages(
        self,
        messages: list[LoopMessage],
        context: Context,
    ) -> list[LoopMessage]:
        result = messages
        for layer in self._layers:
            method = getattr(layer, "transform_messages", None)
            if method is not None:
                result = method(result, context)
        return result

    def transform_tools(
        self,
        tools: list[ToolDescriptor],
        context: Context,
    ) -> list[ToolDescriptor]:
        result = tools
        for layer in self._layers:
            method = getattr(layer, "transform_tools", None)
            if method is not None:
                result = method(result, context)
        return result

    def prepare_next_turn(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> AgentLoopState:
        result = state
        for layer in self._layers:
            method = getattr(layer, "prepare_next_turn", None)
            if method is not None:
                result = method(result, config)
        return result

    def after_tool_call(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Context,
    ) -> ToolResult:
        current = result
        for layer in self._layers:
            method = getattr(layer, "after_tool_call", None)
            if method is not None:
                current = method(tool_call, current, context)
        return current

    def convert_to_model(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelRequest:
        if not self._layers:
            result = ModelRequest(
                messages=state.messages,
                tools=config.tools or [],
                model=config.model_descriptor,
            )
        else:
            convert = getattr(self._layers[0], "convert_to_model", None)
            if convert is not None:
                result = convert(state, config)
            else:
                result = ModelRequest(
                    messages=state.messages,
                    tools=config.tools or [],
                    model=config.model_descriptor,
                )

        if self._system_prompt:
            result = result.model_copy(update={"system": self._system_prompt})

        return result

    def before_tool_call(
        self,
        tool_call: ToolCall,
        context: Context,
    ) -> bool:
        for layer in self._layers:
            method = getattr(layer, "before_tool_call", None)
            if method is not None and not method(tool_call, context):
                return False
        return True

    def on_event(self, event: RunEvent) -> None:
        for layer in self._layers:
            method = getattr(layer, "on_event", None)
            if method is not None:
                method(event)

    def on_model_error(
        self,
        error: ErrorInfo,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelResponse | None:
        for layer in self._layers:
            method = getattr(layer, "on_model_error", None)
            if method is None:
                continue
            response = method(error, state, config)
            if response is not None:
                return response
        return None

    def on_artifact_declared(self, slot: ArtifactSlot) -> None:
        for layer in self._layers:
            method = getattr(layer, "on_artifact_declared", None)
            if method is not None:
                method(slot)

    def on_artifact_finalized(self, ref: ArtifactRef) -> None:
        for layer in self._layers:
            method = getattr(layer, "on_artifact_finalized", None)
            if method is not None:
                method(ref)

    def on_model_call_reserved(self, reservation: ModelCallReservation) -> None:
        for layer in self._layers:
            method = getattr(layer, "on_model_call_reserved", None)
            if method is not None:
                method(reservation)

    def on_model_call_settled(
        self,
        reservation: ModelCallReservation,
        usage: ModelCallUsage,
    ) -> None:
        for layer in self._layers:
            method = getattr(layer, "on_model_call_settled", None)
            if method is not None:
                method(reservation, usage)


class ReporterLoopHooks:
    """Backward-compatible facade combining reporting hooks."""

    def __init__(
        self,
        *,
        reporter: RunReporter,
        execution_id: str,
        actions_by_name: dict[str, ActionDescriptor] | None = None,
        tools_by_name: dict[str, ToolDescriptor] | None = None,
    ) -> None:
        _ = (actions_by_name, tools_by_name)
        self._composite = CompositeLoopHooks(
            [
                RuntimeReporterHooks(
                    reporter=reporter,
                    execution_id=execution_id,
                ),
            ],
        )

    def transform_messages(
        self,
        messages: list[LoopMessage],
        context: Context,
    ) -> list[LoopMessage]:
        return self._composite.transform_messages(messages, context)

    def convert_to_model(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelRequest:
        return self._composite.convert_to_model(state, config)

    def transform_tools(
        self,
        tools: list[ToolDescriptor],
        context: Context,
    ) -> list[ToolDescriptor]:
        return self._composite.transform_tools(tools, context)

    def prepare_next_turn(
        self,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> AgentLoopState:
        return self._composite.prepare_next_turn(state, config)

    def before_tool_call(
        self,
        tool_call: ToolCall,
        context: Context,
    ) -> bool:
        return self._composite.before_tool_call(tool_call, context)

    def after_tool_call(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Context,
    ) -> ToolResult:
        return self._composite.after_tool_call(tool_call, result, context)

    def on_event(self, event: RunEvent) -> None:
        self._composite.on_event(event)

    def on_model_error(
        self,
        error: ErrorInfo,
        state: AgentLoopState,
        config: AgentLoopConfig,
    ) -> ModelResponse | None:
        return self._composite.on_model_error(error, state, config)

    def on_artifact_declared(self, slot: ArtifactSlot) -> None:
        self._composite.on_artifact_declared(slot)

    def on_artifact_finalized(self, ref: ArtifactRef) -> None:
        self._composite.on_artifact_finalized(ref)

    def on_model_call_reserved(self, reservation: ModelCallReservation) -> None:
        self._composite.on_model_call_reserved(reservation)

    def on_model_call_settled(
        self,
        reservation: ModelCallReservation,
        usage: ModelCallUsage,
    ) -> None:
        self._composite.on_model_call_settled(reservation, usage)
