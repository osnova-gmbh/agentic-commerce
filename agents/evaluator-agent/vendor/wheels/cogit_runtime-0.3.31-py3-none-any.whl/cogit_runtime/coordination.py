"""Preserve portable coordination failures while releasing owned resources."""

from __future__ import annotations

import inspect
import sys
from collections.abc import Callable

from cogit_agent_sdk.coordination import CoordinationFailure


def finish_cleanup(*cleanups: Callable[[], object]) -> None:
    """Run every cleanup; a known coordination failure outranks cleanup errors."""
    primary = sys.exception()
    failure: BaseException | None = None
    for cleanup in cleanups:
        try:
            cleanup()
        except BaseException as exc:
            if isinstance(exc, CoordinationFailure):
                if not isinstance(failure, CoordinationFailure):
                    failure = exc
            elif failure is None:
                failure = exc
    if isinstance(primary, CoordinationFailure):
        return
    if failure is not None:
        raise failure


async def finish_cleanup_async(*cleanups: Callable[[], object]) -> None:
    """Await every owned cleanup while preserving the primary coordination fence."""
    primary = sys.exception()
    failure: BaseException | None = None
    for cleanup in cleanups:
        try:
            result = cleanup()
            if inspect.isawaitable(result):
                await result
        except BaseException as exc:
            if isinstance(exc, CoordinationFailure):
                if not isinstance(failure, CoordinationFailure):
                    failure = exc
            elif failure is None:
                failure = exc
    if isinstance(primary, CoordinationFailure):
        return
    if failure is not None:
        raise failure
