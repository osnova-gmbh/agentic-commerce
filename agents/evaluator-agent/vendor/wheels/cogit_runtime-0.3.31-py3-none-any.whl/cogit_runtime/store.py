"""Runtime store protocol and in-memory implementation."""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime, timedelta
from threading import RLock
from typing import Any, Protocol, runtime_checkable

from cogit_agent_sdk.types import (
    ArtifactRef,
    AssistantMessage,
    AttentionItem,
    Case,
    Context,
    Decision,
    EvalRecord,
    ExecutionRecord,
    ExecutionStepRecord,
    ExperimentRecord,
    Feedback,
    LearningRecord,
    Message,
    QueueItem,
    RunEvent,
    Session,
    ToolResultMessage,
)

from cogit_runtime.config import DiagnosticHistoryLimits
from cogit_runtime.errors import RuntimeConfigurationError

OUTBOX_MAX_RETRIES = 8
OUTBOX_BACKOFF_BASE_SECONDS = 1.0
OUTBOX_BACKOFF_CAP_SECONDS = 300.0


def outbox_backoff_seconds(retries: int) -> float:
    """Exponential backoff delay after ``retries`` failed delivery attempts."""

    delay = OUTBOX_BACKOFF_BASE_SECONDS * (2 ** max(retries - 1, 0))
    return float(min(OUTBOX_BACKOFF_CAP_SECONDS, delay))


@dataclass(frozen=True)
class OutboxRecord:
    """Durable platform-mirror operation stored before delivery."""

    operation: str
    payload: dict[str, Any]
    context: dict[str, Any] | None = None
    enqueued_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    available_at: datetime | None = None
    id: int | None = None
    delivered: bool = False
    dead_lettered: bool = False
    last_error: str | None = None
    retries: int = 0
    idempotency_key: str | None = None


@dataclass(frozen=True)
class ApprovalRecord:
    """Parked attention item plus the context needed for continuation."""

    item: AttentionItem
    context: Context
    payload: dict[str, Any]
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    decision: Decision | None = None
    # Whether this approval has already been used to execute an action.
    # A single approval authorizes exactly one execution; ``consume_approval``
    # is the atomic claim that prevents a second resubmit from running the
    # same financial action twice.
    consumed: bool = False


@runtime_checkable
class RuntimeStore(Protocol):
    """Abstract protocol for runtime state persistence.

    Both :class:`InMemoryRuntimeStore` and the forthcoming
    ``SqlRuntimeStore`` implement this interface so the rest of
    the runtime can be coded against a single contract.
    """

    # -- runs ----------------------------------------------------------

    def put_run(self, record: ExecutionRecord) -> ExecutionRecord: ...

    def create_run_if_absent(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord | None = None,
    ) -> bool: ...

    def get_run(self, execution_id: str) -> ExecutionRecord | None: ...

    def complete_run_if_running(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord | None = None,
    ) -> bool: ...

    def list_runs(self) -> list[ExecutionRecord]: ...

    # -- events --------------------------------------------------------

    def append_event(self, event: RunEvent) -> RunEvent: ...

    def list_events(
        self, execution_id: str, *, after_seq: int = 0
    ) -> list[RunEvent]: ...

    def next_event_sequence(self, execution_id: str) -> int: ...

    # -- sessions ------------------------------------------------------

    def put_session(self, session: Session) -> Session: ...

    def get_session(self, session_id: str) -> Session | None: ...

    def delete_session(self, session_id: str) -> Session | None: ...

    def get_or_create_session(
        self,
        *,
        session_id: str,
        tenant_id: str,
        agent_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> Session: ...

    def append_session_messages(
        self,
        session_id: str,
        messages: list[Message | AssistantMessage | ToolResultMessage],
        *,
        max_history: int,
    ) -> Session | None: ...

    # -- evals ---------------------------------------------------------

    def list_evals(self) -> list[EvalRecord]: ...

    def put_eval(self, record: EvalRecord) -> EvalRecord: ...

    def get_eval(self, eval_id: str) -> EvalRecord | None: ...

    # -- platform outbox -----------------------------------------------

    def enqueue_outbox(self, record: OutboxRecord) -> OutboxRecord: ...

    def list_pending_outbox(self, *, limit: int = 100) -> list[OutboxRecord]: ...

    def mark_outbox_delivered(self, outbox_id: int) -> None: ...

    def mark_outbox_failed(self, outbox_id: int, error: str) -> None: ...

    def count_pending_outbox(self) -> int: ...

    def put_run_and_enqueue_outbox(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord,
    ) -> tuple[ExecutionRecord, OutboxRecord]: ...

    def put_eval_and_enqueue_outbox(
        self,
        record: EvalRecord,
        outbox: OutboxRecord,
    ) -> tuple[EvalRecord, OutboxRecord]: ...

    # -- approvals -----------------------------------------------------

    def put_approval(self, record: ApprovalRecord) -> ApprovalRecord: ...

    def get_approval(self, item_id: str) -> ApprovalRecord | None: ...

    def list_pending_approvals(self) -> list[ApprovalRecord]: ...

    def consume_approval(self, item_id: str) -> bool: ...

    # -- learnings -----------------------------------------------------

    def list_learnings(self) -> list[LearningRecord]: ...

    def put_learning(self, record: LearningRecord) -> LearningRecord: ...

    # -- experiments ---------------------------------------------------

    def list_experiments(self) -> list[ExperimentRecord]: ...

    def put_experiment(self, record: ExperimentRecord) -> ExperimentRecord: ...

    def get_experiment(self, experiment_id: str) -> ExperimentRecord | None: ...

    # -- queue items ---------------------------------------------------

    def put_queue_item(self, item: QueueItem) -> QueueItem: ...

    def list_queue_items(self) -> list[QueueItem]: ...

    # -- cases ---------------------------------------------------------

    def put_case(self, case: Case) -> Case: ...

    def get_case(self, case_id: str) -> Case | None: ...

    def list_cases(self, *, tenant_id: str | None = None) -> list[Case]: ...

    def resolve_case(
        self,
        *,
        tenant_id: str,
        source_type: str,
        source_id: str,
    ) -> Case | None: ...

    # -- execution steps -----------------------------------------------

    def put_execution_step(self, step: ExecutionStepRecord) -> ExecutionStepRecord: ...

    def list_execution_steps(self, execution_id: str) -> list[ExecutionStepRecord]: ...

    # -- artifacts -----------------------------------------------------

    def put_artifact(self, artifact: ArtifactRef) -> ArtifactRef: ...

    def get_artifact(self, artifact_id: str) -> ArtifactRef | None: ...

    def list_artifacts(
        self,
        *,
        case_id: str | None = None,
        execution_id: str | None = None,
    ) -> list[ArtifactRef]: ...

    # -- feedback ------------------------------------------------------

    def put_feedback(self, feedback: Feedback) -> Feedback: ...

    def get_feedback(self, feedback_id: str) -> Feedback | None: ...

    def list_feedback(
        self,
        *,
        case_id: str | None = None,
        execution_id: str | None = None,
    ) -> list[Feedback]: ...

    # -- queue operations ----------------------------------------------

    def get_queue_item(self, item_id: str) -> QueueItem | None: ...

    def claim_queue_item(
        self,
        queues: list[str],
        item_types: list[str],
        lease_seconds: int,
    ) -> QueueItem | None: ...

    def complete_queue_item(
        self, item_id: str, outcome: dict[str, object]
    ) -> QueueItem | None: ...

    def fail_queue_item(
        self, item_id: str, error: str, retryable: bool
    ) -> QueueItem | None: ...

    def heartbeat_queue_item(
        self, item_id: str, lease_seconds: int = 900
    ) -> QueueItem | None: ...

    def park_queue_item(self, item_id: str) -> QueueItem | None: ...


class InMemoryRuntimeStore:
    """Local runtime state for runs, events, sessions, and scaffolding records."""

    def __init__(
        self, *, diagnostic_limits: DiagnosticHistoryLimits | None = None
    ) -> None:
        self._lock = RLock()
        # None preserves the exact standalone in-memory store contract. Only the
        # AgentDb profile enables bounded, disposable worker-local diagnostics.
        self._diagnostic_limits = diagnostic_limits
        self._runs: dict[str, ExecutionRecord] = {}
        self._events: dict[str, list[RunEvent]] = {}
        self._completed_order: OrderedDict[str, None] = OrderedDict()
        self._next_event_sequences: dict[str, int] = {}
        self._dropped_events: dict[str, int] = {}
        self._dropped_steps: dict[str, int] = {}
        self._event_order: OrderedDict[tuple[str, int], int] = OrderedDict()
        self._step_order: OrderedDict[tuple[str, str], int] = OrderedDict()
        self._event_bytes_by_run: dict[str, int] = {}
        self._step_bytes_by_run: dict[str, int] = {}
        self._event_bytes_total = 0
        self._step_bytes_total = 0
        self._sessions: dict[str, Session] = {}
        self._evals: dict[str, EvalRecord] = {}
        self._outbox: dict[int, OutboxRecord] = {}
        self._next_outbox_id = 1
        self._approvals: dict[str, ApprovalRecord] = {}
        self._learnings: dict[str, LearningRecord] = {}
        self._experiments: dict[str, ExperimentRecord] = {}
        self._queue: dict[str, QueueItem] = {}
        self._cases: dict[str, Case] = {}
        self._execution_steps: dict[str, list[ExecutionStepRecord]] = {}
        self._artifacts: dict[str, ArtifactRef] = {}
        self._feedback: dict[str, Feedback] = {}

    # -- runs ----------------------------------------------------------

    def put_run(self, record: ExecutionRecord) -> ExecutionRecord:
        with self._lock:
            if record.id not in self._runs or record.id in self._completed_order:
                self._check_active_capacity(record)
            self._runs[record.id] = self._copy_if_diagnostic(record)
            self._events.setdefault(record.id, [])
            self._update_completed(record)
            return record

    def create_run_if_absent(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord | None = None,
    ) -> bool:
        with self._lock:
            if record.id in self._runs:
                return False
            self._check_active_capacity(record)
            self._runs[record.id] = self._copy_if_diagnostic(record)
            self._events.setdefault(record.id, [])
            if outbox is not None:
                self.enqueue_outbox(outbox)
            self._update_completed(record)
            return True

    def get_run(self, execution_id: str) -> ExecutionRecord | None:
        with self._lock:
            record = self._runs.get(execution_id)
            return self._copy_if_diagnostic(record)

    def complete_run_if_running(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord | None = None,
    ) -> bool:
        with self._lock:
            existing = self._runs.get(record.id)
            if existing is None or existing.status != "running":
                return False
            self._runs[record.id] = self._copy_if_diagnostic(record)
            if outbox is not None:
                self.enqueue_outbox(outbox)
            self._update_completed(record)
            return True

    def list_runs(self) -> list[ExecutionRecord]:
        with self._lock:
            records = sorted(
                self._runs.values(),
                key=lambda record: record.started_at,
                reverse=True,
            )
            return [self._copy_if_diagnostic(record) for record in records]

    # -- events --------------------------------------------------------

    def append_event(self, event: RunEvent) -> RunEvent:
        with self._lock:
            limits = self._diagnostic_limits
            if limits is not None:
                if event.execution_id not in self._runs:
                    # A completion race must not resurrect an evicted record.
                    return event
                sequence = max(
                    event.sequence,
                    self._next_event_sequences.get(event.execution_id, 1),
                )
                self._next_event_sequences[event.execution_id] = sequence + 1
                try:
                    current = event.model_copy(deep=True, update={"sequence": sequence})
                except Exception:
                    self._dropped_events[event.execution_id] = (
                        self._dropped_events.get(event.execution_id, 0) + 1
                    )
                    return event
                size = _diagnostic_size(current)
                if (
                    size is None
                    or size > limits.event_bytes_per_run
                    or size > limits.event_bytes_total
                ):
                    self._dropped_events[event.execution_id] = (
                        self._dropped_events.get(event.execution_id, 0) + 1
                    )
                    return current
                self._events.setdefault(event.execution_id, []).append(current)
                self._event_order[(event.execution_id, sequence)] = size
                self._event_bytes_by_run[event.execution_id] = (
                    self._event_bytes_by_run.get(event.execution_id, 0) + size
                )
                self._event_bytes_total += size
                self._trim_events(event.execution_id)
                return current.model_copy(deep=True)
            events = self._events.setdefault(event.execution_id, [])
            sequences = {existing.sequence for existing in events}
            current = event
            while current.sequence in sequences:
                current = current.model_copy(
                    update={"sequence": max(sequences, default=0) + 1}
                )
            events.append(current)
            return current

    def list_events(self, execution_id: str, *, after_seq: int = 0) -> list[RunEvent]:
        with self._lock:
            events = [
                event
                for event in self._events.get(execution_id, [])
                if event.sequence > after_seq
            ]
            if self._diagnostic_limits is None:
                return events
            return [event.model_copy(deep=True) for event in events]

    def list_events_with_diagnostics(
        self, execution_id: str, *, after_seq: int = 0
    ) -> tuple[list[RunEvent], dict[str, int] | None]:
        """Read local events and gap counters from one consistent lock state."""

        with self._lock:
            if self._diagnostic_limits is None:
                raise RuntimeConfigurationError(
                    "Worker-local diagnostics are not enabled"
                )
            if execution_id not in self._runs:
                return [], None
            events = self.list_events(execution_id, after_seq=after_seq)
            return events, {
                "dropped_events": self._dropped_events.get(execution_id, 0),
                "first_retained_sequence": self._first_retained_sequence(execution_id),
                "next_event_sequence": self._next_event_sequences.get(execution_id, 1),
            }

    def next_event_sequence(self, execution_id: str) -> int:
        with self._lock:
            if self._diagnostic_limits is not None:
                return self._next_event_sequences.get(execution_id, 1)
            events = self._events.get(execution_id, [])
            if not events:
                return 1
            return max(event.sequence for event in events) + 1

    def release_local_run(self, execution_id: str) -> None:
        """Release uncertain or drained worker diagnostics without settling work."""

        with self._lock:
            if self._diagnostic_limits is not None and execution_id in self._runs:
                self._completed_order[execution_id] = None
                self._completed_order.move_to_end(execution_id)
                self._evict_completed()

    def diagnostic_snapshot(self, execution_id: str | None = None) -> dict[str, Any]:
        """Report retained local objects and drops; never a canonical audit view."""

        with self._lock:
            if self._diagnostic_limits is None:
                raise RuntimeConfigurationError(
                    "Worker-local diagnostics are not enabled"
                )
            snapshot: dict[str, Any] = {
                "runs": len(self._runs),
                "active_runs": len(self._runs) - len(self._completed_order),
                "completed_records": len(self._completed_order),
                "events_total": len(self._event_order),
                "event_bytes_total": self._event_bytes_total,
                "steps_total": len(self._step_order),
                "step_bytes_total": self._step_bytes_total,
            }
            if execution_id is not None:
                events = self._events.get(execution_id, [])
                steps = self._execution_steps.get(execution_id, [])
                snapshot["run"] = (
                    {
                        "dropped_events": self._dropped_events.get(execution_id, 0),
                        "first_retained_sequence": self._first_retained_sequence(
                            execution_id
                        ),
                        "next_event_sequence": self._next_event_sequences.get(
                            execution_id, 1
                        ),
                        "dropped_steps": self._dropped_steps.get(execution_id, 0),
                        "events": len(events),
                        "event_bytes": self._event_bytes_by_run.get(execution_id, 0),
                        "steps": len(steps),
                        "step_bytes": self._step_bytes_by_run.get(execution_id, 0),
                    }
                    if execution_id in self._runs
                    else None
                )
            return snapshot

    def _copy_if_diagnostic(self, record: Any) -> Any:
        if self._diagnostic_limits is not None and record is not None:
            return record.model_copy(deep=True)
        return record

    def _check_active_capacity(self, record: ExecutionRecord) -> None:
        limits = self._diagnostic_limits
        if limits is not None and record.status == "running":
            active = len(self._runs) - len(self._completed_order)
            if active >= limits.active_executions:
                raise RuntimeConfigurationError(
                    "Worker-local active execution capacity is exhausted"
                )

    def _update_completed(self, record: ExecutionRecord) -> None:
        if self._diagnostic_limits is None:
            return
        if record.status == "running":
            self._completed_order.pop(record.id, None)
        else:
            self._completed_order[record.id] = None
            self._completed_order.move_to_end(record.id)
            self._evict_completed()

    def _evict_completed(self) -> None:
        limits = self._diagnostic_limits
        if limits is None:
            return
        while len(self._completed_order) > limits.completed_records:
            execution_id, _ = self._completed_order.popitem(last=False)
            for event in list(self._events.pop(execution_id, [])):
                self._event_bytes_total -= self._event_order.pop(
                    (execution_id, event.sequence), 0
                )
            for step in list(self._execution_steps.pop(execution_id, [])):
                self._step_bytes_total -= self._step_order.pop(
                    (execution_id, step.id), 0
                )
            self._runs.pop(execution_id, None)
            self._next_event_sequences.pop(execution_id, None)
            self._dropped_events.pop(execution_id, None)
            self._dropped_steps.pop(execution_id, None)
            self._event_bytes_by_run.pop(execution_id, None)
            self._step_bytes_by_run.pop(execution_id, None)

    def _first_retained_sequence(self, execution_id: str) -> int:
        events = self._events.get(execution_id, [])
        if events:
            return events[0].sequence
        return self._next_event_sequences.get(execution_id, 1)

    def _drop_oldest_event(self, execution_id: str) -> None:
        events = self._events.get(execution_id, [])
        if not events:
            return
        removed = events.pop(0)
        size = self._event_order.pop((execution_id, removed.sequence))
        self._event_bytes_total -= size
        self._event_bytes_by_run[execution_id] -= size
        self._dropped_events[execution_id] = (
            self._dropped_events.get(execution_id, 0) + 1
        )

    def _trim_events(self, execution_id: str) -> None:
        limits = self._diagnostic_limits
        assert limits is not None
        while (
            len(self._events[execution_id]) > limits.events_per_run
            or self._event_bytes_by_run[execution_id] > limits.event_bytes_per_run
        ):
            self._drop_oldest_event(execution_id)
        while (
            len(self._event_order) > limits.events_total
            or self._event_bytes_total > limits.event_bytes_total
        ):
            oldest_run, _ = next(iter(self._event_order))
            self._drop_oldest_event(oldest_run)

    # -- sessions ------------------------------------------------------

    def put_session(self, session: Session) -> Session:
        with self._lock:
            self._sessions[session.id] = session
            return session

    def get_session(self, session_id: str) -> Session | None:
        with self._lock:
            return self._sessions.get(session_id)

    def delete_session(self, session_id: str) -> Session | None:
        with self._lock:
            return self._sessions.pop(session_id, None)

    def get_or_create_session(
        self,
        *,
        session_id: str,
        tenant_id: str,
        agent_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> Session:
        with self._lock:
            existing = self._sessions.get(session_id)
            if existing is not None:
                return existing
            now = datetime.now(UTC)
            session = Session(
                id=session_id,
                tenant_id=tenant_id,
                agent_id=agent_id,
                created_at=now,
                updated_at=now,
                metadata=metadata,
            )
            self._sessions[session.id] = session
            return session

    def append_session_messages(
        self,
        session_id: str,
        messages: list[Message | AssistantMessage | ToolResultMessage],
        *,
        max_history: int,
    ) -> Session | None:
        """Append messages onto a session and trim to ``max_history``.

        Only user/assistant/tool_result role messages that map to
        :class:`Message` are persisted. Tool-result and assistant messages are
        normalized into regular ``Message`` records so the session history has
        a single conversation transcript shape.
        """

        with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return None
            transcript = list(session.messages)
            for entry in messages:
                normalized = _normalize_session_message(entry)
                if normalized is not None:
                    transcript.append(normalized)
            if max_history > 0 and len(transcript) > max_history:
                transcript = transcript[-max_history:]
            updated = session.model_copy(
                update={
                    "messages": transcript,
                    "updated_at": datetime.now(UTC),
                }
            )
            self._sessions[session_id] = updated
            return updated

    # -- evals ---------------------------------------------------------

    def list_evals(self) -> list[EvalRecord]:
        with self._lock:
            return sorted(
                self._evals.values(),
                key=lambda record: record.started_at,
                reverse=True,
            )

    def put_eval(self, record: EvalRecord) -> EvalRecord:
        with self._lock:
            self._evals[record.id] = record
            return record

    def get_eval(self, eval_id: str) -> EvalRecord | None:
        with self._lock:
            return self._evals.get(eval_id)

    # -- platform outbox -----------------------------------------------

    def enqueue_outbox(self, record: OutboxRecord) -> OutboxRecord:
        with self._lock:
            if record.idempotency_key is not None:
                for existing in self._outbox.values():
                    if existing.idempotency_key == record.idempotency_key:
                        return existing
            outbox_id = self._next_outbox_id
            self._next_outbox_id += 1
            now = datetime.now(UTC)
            stored = OutboxRecord(
                id=outbox_id,
                operation=record.operation,
                payload=record.payload,
                context=record.context,
                enqueued_at=record.enqueued_at,
                available_at=record.available_at or now,
                delivered=False,
                dead_lettered=False,
                idempotency_key=record.idempotency_key,
            )
            self._outbox[outbox_id] = stored
            return stored

    def list_pending_outbox(self, *, limit: int = 100) -> list[OutboxRecord]:
        with self._lock:
            now = datetime.now(UTC)
            pending = [
                record
                for record in self._outbox.values()
                if not record.delivered
                and not record.dead_lettered
                and (record.available_at is None or record.available_at <= now)
            ]
            pending.sort(key=lambda record: (record.enqueued_at, record.id or 0))
            return pending[:limit]

    def mark_outbox_delivered(self, outbox_id: int) -> None:
        with self._lock:
            record = self._outbox.get(outbox_id)
            if record is None:
                return
            self._outbox[outbox_id] = OutboxRecord(
                id=record.id,
                operation=record.operation,
                payload=record.payload,
                context=record.context,
                enqueued_at=record.enqueued_at,
                available_at=record.available_at,
                delivered=True,
                dead_lettered=False,
                last_error=None,
                retries=record.retries,
                idempotency_key=record.idempotency_key,
            )

    def mark_outbox_failed(self, outbox_id: int, error: str) -> None:
        with self._lock:
            record = self._outbox.get(outbox_id)
            if record is None:
                return
            retries = record.retries + 1
            dead_lettered = retries >= OUTBOX_MAX_RETRIES
            available_at = datetime.now(UTC) + timedelta(
                seconds=outbox_backoff_seconds(retries)
            )
            self._outbox[outbox_id] = OutboxRecord(
                id=record.id,
                operation=record.operation,
                payload=record.payload,
                context=record.context,
                enqueued_at=record.enqueued_at,
                available_at=available_at,
                delivered=False,
                dead_lettered=dead_lettered,
                last_error=error,
                retries=retries,
                idempotency_key=record.idempotency_key,
            )

    def count_pending_outbox(self) -> int:
        with self._lock:
            return sum(
                1
                for record in self._outbox.values()
                if not record.delivered and not record.dead_lettered
            )

    def put_run_and_enqueue_outbox(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord,
    ) -> tuple[ExecutionRecord, OutboxRecord]:
        with self._lock:
            if record.id not in self._runs or record.id in self._completed_order:
                self._check_active_capacity(record)
            self._runs[record.id] = self._copy_if_diagnostic(record)
            stored_outbox = self.enqueue_outbox(outbox)
            self._update_completed(record)
            return record, stored_outbox

    def put_eval_and_enqueue_outbox(
        self,
        record: EvalRecord,
        outbox: OutboxRecord,
    ) -> tuple[EvalRecord, OutboxRecord]:
        with self._lock:
            self._evals[record.id] = record
            stored_outbox = self.enqueue_outbox(outbox)
            return record, stored_outbox

    # -- approvals -----------------------------------------------------

    def put_approval(self, record: ApprovalRecord) -> ApprovalRecord:
        with self._lock:
            existing = self._approvals.get(record.item.id)
            if existing is not None and (
                record.decision is None
                or existing.decision is not None
                or existing.consumed
            ):
                return existing
            if existing is not None:
                record = replace(existing, decision=record.decision)
            self._approvals[record.item.id] = record
            return record

    def get_approval(self, item_id: str) -> ApprovalRecord | None:
        with self._lock:
            return self._approvals.get(item_id)

    def consume_approval(self, item_id: str) -> bool:
        with self._lock:
            record = self._approvals.get(item_id)
            if record is None or record.consumed:
                return False
            self._approvals[item_id] = ApprovalRecord(
                item=record.item,
                context=record.context,
                payload=record.payload,
                created_at=record.created_at,
                decision=record.decision,
                consumed=True,
            )
            return True

    def list_pending_approvals(self) -> list[ApprovalRecord]:
        with self._lock:
            pending = [
                record for record in self._approvals.values() if record.decision is None
            ]
            pending.sort(key=lambda record: record.created_at)
            return pending

    # -- learnings -----------------------------------------------------

    def list_learnings(self) -> list[LearningRecord]:
        with self._lock:
            return sorted(
                self._learnings.values(),
                key=lambda record: record.created_at,
                reverse=True,
            )

    def put_learning(self, record: LearningRecord) -> LearningRecord:
        with self._lock:
            self._learnings[record.id] = record
            return record

    # -- experiments ---------------------------------------------------

    def list_experiments(self) -> list[ExperimentRecord]:
        with self._lock:
            return sorted(
                self._experiments.values(),
                key=lambda record: record.created_at,
                reverse=True,
            )

    def put_experiment(self, record: ExperimentRecord) -> ExperimentRecord:
        with self._lock:
            self._experiments[record.id] = record
            return record

    def get_experiment(self, experiment_id: str) -> ExperimentRecord | None:
        with self._lock:
            return self._experiments.get(experiment_id)

    # -- queue items ---------------------------------------------------

    def put_queue_item(self, item: QueueItem) -> QueueItem:
        with self._lock:
            self._queue[item.id] = item
            return item

    def get_queue_item(self, item_id: str) -> QueueItem | None:
        with self._lock:
            return self._queue.get(item_id)

    def claim_queue_item(
        self,
        queues: list[str],
        item_types: list[str],
        lease_seconds: int,
    ) -> QueueItem | None:
        """Atomically claim the first pending item matching filters."""

        with self._lock:
            now = datetime.now(UTC)
            for item in self._queue.values():
                if item.status != "pending":
                    continue
                if queues and item.queue_name not in queues:
                    continue
                if item_types and item.item_type not in item_types:
                    continue
                updated = item.model_copy(
                    update={
                        "status": "processing",
                        "lease_expires_at": now + timedelta(seconds=lease_seconds),
                        "heartbeat_at": now,
                    }
                )
                self._queue[item.id] = updated
                return updated
            return None

    def complete_queue_item(
        self,
        item_id: str,
        outcome: dict[str, object],
    ) -> QueueItem | None:
        """Mark a processing item as processed."""
        with self._lock:
            item = self._queue.get(item_id)
            if item is None:
                return None
            updated = item.model_copy(update={"status": "processed"})
            self._queue[item_id] = updated
            return updated

    def fail_queue_item(
        self,
        item_id: str,
        error: str,
        retryable: bool,
    ) -> QueueItem | None:
        """Mark a processing item as failed, or reset to pending if retryable."""
        with self._lock:
            item = self._queue.get(item_id)
            if item is None:
                return None
            if retryable and item.retry_count < item.max_retries:
                updated = item.model_copy(
                    update={
                        "status": "pending",
                        "error": error,
                        "retry_count": item.retry_count + 1,
                        "lease_expires_at": None,
                        "heartbeat_at": None,
                    }
                )
            else:
                updated = item.model_copy(
                    update={
                        "status": "failed",
                        "error": error,
                    }
                )
            self._queue[item_id] = updated
            return updated

    def heartbeat_queue_item(
        self,
        item_id: str,
        lease_seconds: int = 900,
    ) -> QueueItem | None:
        """Extend the lease on a processing item."""

        with self._lock:
            item = self._queue.get(item_id)
            if item is None:
                return None
            now = datetime.now(UTC)
            updated = item.model_copy(
                update={
                    "lease_expires_at": now + timedelta(seconds=lease_seconds),
                    "heartbeat_at": now,
                }
            )
            self._queue[item_id] = updated
            return updated

    def park_queue_item(self, item_id: str) -> QueueItem | None:
        """Release a queue lease while work waits for human approval."""
        with self._lock:
            item = self._queue.get(item_id)
            if item is None:
                return None
            updated = item.model_copy(
                update={
                    "status": "parked",
                    "lease_expires_at": None,
                    "heartbeat_at": None,
                }
            )
            self._queue[item_id] = updated
            return updated

    def list_queue_items(self) -> list[QueueItem]:
        with self._lock:
            return list(self._queue.values())

    # -- cases ---------------------------------------------------------

    def put_case(self, case: Case) -> Case:
        with self._lock:
            self._cases[case.id] = case
            return case

    def get_case(self, case_id: str) -> Case | None:
        with self._lock:
            return self._cases.get(case_id)

    def list_cases(self, *, tenant_id: str | None = None) -> list[Case]:
        with self._lock:
            cases = list(self._cases.values())
            if tenant_id is not None:
                cases = [c for c in cases if c.tenant_id == tenant_id]
            return cases

    def resolve_case(
        self,
        *,
        tenant_id: str,
        source_type: str,
        source_id: str,
    ) -> Case | None:
        """Find a case by its natural key (tenant + source_type + source_id)."""
        with self._lock:
            for case in self._cases.values():
                if (
                    case.tenant_id == tenant_id
                    and case.source_type == source_type
                    and case.source_id == source_id
                ):
                    return case
            return None

    # -- execution steps -----------------------------------------------

    def put_execution_step(self, step: ExecutionStepRecord) -> ExecutionStepRecord:
        with self._lock:
            limits = self._diagnostic_limits
            if limits is not None and step.execution_id not in self._runs:
                return step
            steps = self._execution_steps.setdefault(step.execution_id, [])
            if limits is not None:
                try:
                    stored = step.model_copy(deep=True)
                except Exception:
                    self._dropped_steps[step.execution_id] = (
                        self._dropped_steps.get(step.execution_id, 0) + 1
                    )
                    return step
                key = (step.execution_id, step.id)
                prior_size = self._step_order.pop(key, 0)
                if prior_size:
                    self._step_bytes_total -= prior_size
                    self._step_bytes_by_run[step.execution_id] -= prior_size
                steps[:] = [existing for existing in steps if existing.id != step.id]
                size = _diagnostic_size(stored)
                if (
                    size is None
                    or size > limits.step_bytes_per_run
                    or size > limits.step_bytes_total
                ):
                    self._dropped_steps[step.execution_id] = (
                        self._dropped_steps.get(step.execution_id, 0) + 1
                    )
                    return step
                steps.append(stored)
                self._step_order[key] = size
                self._step_bytes_total += size
                self._step_bytes_by_run[step.execution_id] = (
                    self._step_bytes_by_run.get(step.execution_id, 0) + size
                )
                self._trim_steps(step.execution_id)
                return step
            for index, existing in enumerate(steps):
                if existing.id == step.id:
                    steps[index] = step
                    break
            else:
                steps.append(step)
            return step

    def list_execution_steps(self, execution_id: str) -> list[ExecutionStepRecord]:
        """Return steps for an execution, sorted by order ascending."""
        with self._lock:
            steps = list(self._execution_steps.get(execution_id, []))
            steps.sort(key=lambda s: s.order)
            return [self._copy_if_diagnostic(step) for step in steps]

    def _drop_oldest_step(self, execution_id: str) -> None:
        steps = self._execution_steps.get(execution_id, [])
        if not steps:
            return
        removed = steps.pop(0)
        size = self._step_order.pop((execution_id, removed.id))
        self._step_bytes_total -= size
        self._step_bytes_by_run[execution_id] -= size
        self._dropped_steps[execution_id] = self._dropped_steps.get(execution_id, 0) + 1

    def _trim_steps(self, execution_id: str) -> None:
        limits = self._diagnostic_limits
        assert limits is not None
        while (
            len(self._execution_steps[execution_id]) > limits.steps_per_run
            or self._step_bytes_by_run[execution_id] > limits.step_bytes_per_run
        ):
            self._drop_oldest_step(execution_id)
        while (
            len(self._step_order) > limits.steps_total
            or self._step_bytes_total > limits.step_bytes_total
        ):
            oldest_run, _ = next(iter(self._step_order))
            self._drop_oldest_step(oldest_run)

    # -- artifacts -----------------------------------------------------

    def put_artifact(self, artifact: ArtifactRef) -> ArtifactRef:
        with self._lock:
            self._artifacts[artifact.id] = artifact
            return artifact

    def get_artifact(self, artifact_id: str) -> ArtifactRef | None:
        with self._lock:
            return self._artifacts.get(artifact_id)

    def list_artifacts(
        self,
        *,
        case_id: str | None = None,
        execution_id: str | None = None,
    ) -> list[ArtifactRef]:
        with self._lock:
            results: list[ArtifactRef] = []
            for artifact in self._artifacts.values():
                metadata = artifact.metadata or {}
                if case_id is not None and metadata.get("caseId") != case_id:
                    continue
                if (
                    execution_id is not None
                    and metadata.get("executionId") != execution_id
                ):
                    continue
                results.append(artifact)
            return results

    # -- feedback ------------------------------------------------------

    def put_feedback(self, feedback: Feedback) -> Feedback:
        with self._lock:
            self._feedback[feedback.id] = feedback
            return feedback

    def get_feedback(self, feedback_id: str) -> Feedback | None:
        with self._lock:
            return self._feedback.get(feedback_id)

    def list_feedback(
        self,
        *,
        case_id: str | None = None,
        execution_id: str | None = None,
    ) -> list[Feedback]:
        with self._lock:
            results: list[Feedback] = []
            for item in self._feedback.values():
                if case_id is not None and item.case_id != case_id:
                    continue
                if execution_id is not None and item.execution_id != execution_id:
                    continue
                results.append(item)
            return results


def _normalize_session_message(
    entry: Message | AssistantMessage | ToolResultMessage,
) -> Message | None:
    if isinstance(entry, Message):
        return entry
    if isinstance(entry, AssistantMessage):
        return Message(
            role="assistant",
            content=entry.content,
            timestamp=entry.timestamp,
            metadata=entry.metadata,
        )
    return Message(
        role="tool_result",
        content=entry.content,
        timestamp=entry.timestamp,
        metadata=entry.metadata,
    )


def _diagnostic_size(record: RunEvent | ExecutionStepRecord) -> int | None:
    """Account the full serialized object, including metadata, in UTF-8 bytes."""

    try:
        return len(record.model_dump_json().encode("utf-8"))
    except Exception:
        # Optional diagnostics cannot make a canonical effect fail. The
        # unrepresentable record is treated as oversized and never retained.
        return None
