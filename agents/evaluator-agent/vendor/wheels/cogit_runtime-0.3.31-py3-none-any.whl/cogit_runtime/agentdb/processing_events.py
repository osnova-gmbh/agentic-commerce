"""Bounded, content-free stage records shared by AgentDb workers."""

from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from cogit_runtime.agentdb.errors import AgentDbError

COUNT_FIELDS = frozenset(
    {
        "attachmentCount",
        "pageCount",
        "fieldCount",
        "candidateCount",
        "validationIssueCount",
        "artifactCount",
        "attempt",
        "promptChars",
        "responseChars",
        "ruleCount",
        "messageCount",
        "acceptedCount",
        "skippedCount",
        "reviewCount",
        "retryCount",
    }
)
CODE_FIELDS = frozenset({"outcome", "classification", "failureCode"})
IDENTITY_FIELDS = frozenset({"model", "provider"})
HASH_FIELDS = frozenset({"policyRevision", "inputSha256"})
IDENTIFIER = re.compile(r"^[a-z][a-z0-9._]{0,127}$")
STATUSES = frozenset({"started", "completed", "failed", "recorded"})


def safe_step_details(data: dict[str, Any] | None) -> dict[str, Any]:
    """Select declared metrics; never ship arbitrary SDK step text/data."""
    selected: dict[str, Any] = {}
    allowed = (
        COUNT_FIELDS
        | CODE_FIELDS
        | IDENTITY_FIELDS
        | HASH_FIELDS
        | {"contentHashPrefix", "margin", "elapsedSeconds"}
    )
    for key, value in (data or {}).items():
        pieces = key.split("_")
        canonical = pieces[0] + "".join(piece.title() for piece in pieces[1:])
        if canonical in allowed and value is not None:
            selected[canonical] = str(value) if isinstance(value, Decimal) else value
    validate_details(selected)
    return selected


def validate_details(details: dict[str, Any]) -> None:
    for key, value in details.items():
        if key in COUNT_FIELDS:
            valid = (
                isinstance(value, int)
                and not isinstance(value, bool)
                and 0 <= value <= 1000000
            )
        elif key in CODE_FIELDS:
            valid = isinstance(value, str) and IDENTIFIER.fullmatch(value) is not None
        elif key in IDENTITY_FIELDS:
            valid = (
                isinstance(value, str)
                and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}", value)
                is not None
            )
        elif key in HASH_FIELDS:
            valid = (
                isinstance(value, str)
                and re.fullmatch(r"[0-9a-f]{64}", value) is not None
            )
        elif key == "contentHashPrefix":
            valid = (
                isinstance(value, str)
                and re.fullmatch(r"[0-9a-f]{16}", value) is not None
            )
        elif key == "margin":
            valid = (
                isinstance(value, str)
                and re.fullmatch(r"-?[0-9](\.[0-9]{1,8})?", value) is not None
                and abs(Decimal(value)) <= 1
            )
        elif key == "elapsedSeconds":
            valid = (
                isinstance(value, (int, float))
                and not isinstance(value, bool)
                and 0 <= value <= 86400
            )
        else:
            valid = False
        if not valid:
            raise AgentDbError("Processing event contains unsupported detail")


def stage_request(
    *,
    stage_key: str,
    stage_order: int,
    status: str,
    reason_code: str | None = None,
    details: dict[str, Any] | None = None,
    evidence: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if (
        not IDENTIFIER.fullmatch(stage_key)
        or status not in STATUSES
        or isinstance(stage_order, bool)
        or not isinstance(stage_order, int)
        or not 1 <= stage_order <= 1000000
        or (reason_code is not None and not IDENTIFIER.fullmatch(reason_code))
    ):
        raise AgentDbError("Processing event identifiers are invalid")
    validate_details(details or {})
    if len(evidence or []) > 8:
        raise AgentDbError("Processing event evidence exceeds its bound")
    return {
        "stageKey": stage_key,
        "stageOrder": stage_order,
        "status": status,
        "details": details or {},
        "evidence": evidence or [],
        **({"reasonCode": reason_code} if reason_code else {}),
    }
