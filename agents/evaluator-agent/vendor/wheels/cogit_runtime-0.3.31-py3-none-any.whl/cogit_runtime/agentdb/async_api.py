"""Async wrappers around the attempt router and generated-client transport."""

from __future__ import annotations

import asyncio
import hashlib
import uuid
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import RunResult

from cogit_runtime.agentdb.errors import (
    AgentDbError,
    AgentDbReconciliationRequiredError,
    AgentDbTimeoutError,
)
from cogit_runtime.agentdb.results import (
    DeclaredArtifact,
    FinalizedArtifact,
    UploadLease,
)
from cogit_runtime.agentdb.router import AttemptRouter
from cogit_runtime.agentdb.session import AttemptSession
from cogit_runtime.agentdb.transport import AgentDbTransport


class AgentDbAsyncApi:
    """Shared async call helpers used by the coordinator."""

    _client: Any
    _session: AttemptSession
    _transport: AgentDbTransport
    _router: AttemptRouter

    async def start_execution(self) -> uuid.UUID:
        return await asyncio.to_thread(self._router.start_execution)

    async def store_result(self, result: RunResult) -> uuid.UUID:
        """Persist the returned result itself before terminal settlement."""
        body = result.model_dump_json().encode("utf-8")
        digest = hashlib.sha256(body).hexdigest()
        slot = await self.declare_artifact(
            "result",
            "application/json",
            "result.json",
            run_id=self._session.run_id,
            execution_id=self._session.require_execution_id(),
        )
        lease = await self.allocate_artifact_upload(
            slot.id, expected_bytes=len(body), expected_hash=digest
        )
        await asyncio.to_thread(self._router.upload_bytes, lease, body)
        result_ref = await self.finalize_artifact_upload(
            slot.id,
            lease.id,
            byte_count=len(body),
            content_hash=digest,
            expected_generation=lease.fencing_generation,
        )
        return result_ref.id

    async def declare_artifact(
        self,
        kind: str,
        media_type: str,
        filename: str | None,
        *,
        run_id: uuid.UUID | None,
        execution_id: uuid.UUID | None = None,
        max_size_bytes: int | None = None,
        renderer_hint: str | None = None,
    ) -> DeclaredArtifact:
        return await asyncio.to_thread(
            self._router.declare_artifact,
            kind,
            media_type,
            filename,
            run_id=run_id,
            execution_id=execution_id,
            max_size_bytes=max_size_bytes,
            renderer_hint=renderer_hint,
        )

    async def allocate_artifact_upload(
        self,
        artifact_id: uuid.UUID,
        *,
        expected_bytes: int | None = None,
        expected_hash: str | None = None,
    ) -> UploadLease:
        return await asyncio.to_thread(
            self._router.allocate_artifact_upload,
            artifact_id,
            expected_bytes=expected_bytes,
            expected_hash=expected_hash,
        )

    async def finalize_artifact_upload(
        self,
        artifact_id: uuid.UUID,
        lease_id: uuid.UUID,
        *,
        byte_count: int,
        content_hash: str,
        expected_generation: int,
    ) -> FinalizedArtifact:
        return await asyncio.to_thread(
            self._router.finalize_artifact_upload,
            artifact_id,
            lease_id,
            byte_count=byte_count,
            content_hash=content_hash,
            expected_generation=expected_generation,
        )

    async def _call(
        self,
        fn: Any,
        *args: Any,
        idempotent: bool = False,
        operation: str = "request",
        **kwargs: Any,
    ) -> Any:
        def _invoke() -> Any:
            return self._transport.invoke(
                lambda: fn(*args, **kwargs),
                idempotent=idempotent,
                operation=operation,
            )

        return await asyncio.to_thread(_invoke)

    async def _transition(
        self,
        operation: str,
        fn: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        try:
            return await self._call(fn, *args, operation=operation, **kwargs)
        except AgentDbError as exc:
            _raise_if_uncertain(operation, exc)
        finally:
            self._session.clear()


def _raise_if_uncertain(operation: str, exc: AgentDbError) -> None:
    if isinstance(exc, CoordinationFailure):
        raise exc
    if (
        isinstance(exc, AgentDbTimeoutError)
        or exc.retryable
        or (exc.http_status is not None and exc.http_status >= 500)
    ):
        raise AgentDbReconciliationRequiredError(
            f"AgentDb {operation} outcome is uncertain; reconcile before retrying",
            response_metadata=exc.response_metadata,
        ) from None
    raise exc
