"""SDK RunHandle adapter that routes AgentDb work through runtime ports."""

from __future__ import annotations

import hashlib
import uuid
from typing import Any
from uuid import UUID

from cogit_agent_sdk.types import (
    ActionIntent,
    ActionKey,
    ActionRef,
    ArtifactRef,
    ArtifactSlot,
    Context,
    ExecutionStepRecord,
    ModelCallReservation,
    ModelCallUsage,
    ModelClient,
    RunEvent,
)
from cogit_agent_sdk.types.policy import AuthorizationDecision, PolicyCheckpoint
from cogit_agent_sdk.types.universal_policy import UniversalPolicyDecision
from cogit_agent_sdk.universal_policy import UniversalPolicyAuthority

from cogit_runtime.agentdb.canonical_model import CanonicalModelClient
from cogit_runtime.agentdb.continuation import ContinuationJournal
from cogit_runtime.agentdb.errors import AgentDbAuthorityError
from cogit_runtime.agentdb.processing_events import IDENTIFIER, safe_step_details
from cogit_runtime.agentdb.router import AttemptRouter
from cogit_runtime.agentdb.runtime_audit import AuditKind, audit_key
from cogit_runtime.config import DiagnosticHistoryLimits
from cogit_runtime.model import GuardedModelClient
from cogit_runtime.runtime_handle import RuntimeRunHandle


class AgentDbRunHandle(RuntimeRunHandle):
    """Run handle that keeps generated AgentDb types off the agent surface."""

    def __init__(
        self,
        execution_id: str,
        context: Context,
        *,
        router: AttemptRouter,
        diagnostic_limits: DiagnosticHistoryLimits | None = None,
        protected_action_authority: UniversalPolicyAuthority | None = None,
    ) -> None:
        self._router = router
        self._protected_action_authority = protected_action_authority
        super().__init__(
            execution_id,
            context,
            step_recorder=self._record_durable_step,
            diagnostic_limits=diagnostic_limits,
        )

    @property
    def continuation(self) -> ContinuationJournal:
        self._router.require_execution(self.execution_id)
        return self._router.continuation

    def _record_durable_step(self, step: ExecutionStepRecord) -> None:
        stage = step.name or "execution.step"
        if not IDENTIFIER.fullmatch(stage):
            stage = "execution.step"
        self.record_processing_event(
            stage_key=stage,
            stage_order=step.order,
            status="started" if step.status == "running" else step.status,
            reason_code="step_error" if step.status == "failed" else None,
            details=safe_step_details(step.data),
        )

    def model_client(self, client: ModelClient, *, slot_key: str) -> ModelClient:
        """Bind the injected provider routes to one persisted workflow position."""
        self._router.require_execution(self.execution_id)
        if (
            self._model_policy is None
            or client is not self._model_policy.client
            or not isinstance(client, GuardedModelClient)
            or not client.canonical
        ):
            raise AgentDbAuthorityError(
                "Canonical model slot requires the Runtime-injected provider routes"
            )

        def store_response(slot: str, body: bytes) -> ArtifactRef:
            name = hashlib.sha256(slot.encode("utf-8")).hexdigest() + ".json"
            declared = self.declare_artifact("model_response", "application/json", name)
            return self.finalize_artifact(
                declared, body, hashlib.sha256(body).hexdigest()
            )

        def observe(slot: str, phase: str, details: dict[str, str | int]) -> None:
            self.record_runtime_audit(
                event_key=audit_key("model", slot, phase),
                kind="model",
                phase=phase,
                details=details,
            )

        dispatch = self._router.model_dispatch(
            execution_id=self.execution_id,
            store_response=store_response,
            observe=observe,
        )
        return CanonicalModelClient(
            routes=client,
            dispatch=dispatch,
            slot_key=slot_key,
            require_authority=lambda: self._router.require_execution(self.execution_id),
        )

    def require_human_decision(
        self,
        *,
        slot_key: str,
        exposure: str,
        payload: dict[str, Any],
        idempotency: str,
        invocation_key: str | None,
    ) -> None:
        self._router.require_human_decision(
            execution_id=self.execution_id,
            slot_key=slot_key,
            exposure=exposure,
            payload=payload,
            idempotency=idempotency,
            invocation_key=invocation_key,
        )

    def record_processing_event(
        self,
        *,
        stage_key: str,
        stage_order: int,
        status: str,
        reason_code: str | None = None,
        details: dict[str, Any] | None = None,
        evidence: list[dict[str, Any]] | None = None,
    ) -> None:
        self._router.record_processing_event(
            execution_id=self.execution_id,
            stage_key=stage_key,
            stage_order=stage_order,
            status=status,
            reason_code=reason_code,
            details=details,
            evidence=evidence,
        )

    def _perform_prepare_action(self, intent: ActionIntent) -> ActionRef:
        return self._router.prepare_action(intent, execution_id=self.execution_id)

    def record_runtime_audit(
        self,
        *,
        event_key: str,
        kind: AuditKind,
        phase: str,
        details: dict[str, str | int] | None = None,
        payload_artifact: ArtifactRef | None = None,
    ) -> None:
        """Confirm required history before effects or publishing successful results."""
        self._router.record_runtime_audit(
            execution_id=self.execution_id,
            event_key=event_key,
            kind=kind,
            phase=phase,
            details=details,
            payload_artifact=payload_artifact,
        )

    def get_governance_snapshot(self, snapshot_id: str) -> dict[str, Any]:
        return self._router.get_governance_snapshot(
            snapshot_id, execution_id=self.execution_id
        )

    def evaluate_policy(self, checkpoint: PolicyCheckpoint) -> AuthorizationDecision:
        from cogit_runtime.agentdb.runtime_policy import evaluate_checkpoint

        return evaluate_checkpoint(self, checkpoint)

    def evaluate_protected_action(self, action_id: UUID) -> UniversalPolicyDecision:
        from cogit_runtime.universal_policy import ProtectedActionAuthority

        if self._protected_action_authority is None:
            raise AgentDbAuthorityError("Protected action authority is unavailable")
        return ProtectedActionAuthority(
            self, self._protected_action_authority
        ).evaluate(action_id)

    def submit_database_command(
        self, name: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._router.submit_database_command(
            name, payload, execution_id=self.execution_id
        )

    def module_query(
        self,
        module_key: str,
        query_key: str,
        payload: dict[str, Any],
        *,
        contract_id: str,
    ) -> dict[str, Any]:
        return self._router.module_query(
            module_key,
            query_key,
            payload,
            contract_id=contract_id,
            execution_id=self.execution_id,
        )

    def module_command(
        self,
        module_key: str,
        command_key: str,
        payload: dict[str, Any],
        *,
        contract_id: str,
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._router.module_command(
            module_key,
            command_key,
            payload,
            contract_id=contract_id,
            idempotency_key=idempotency_key,
            execution_id=self.execution_id,
        )

    def _perform_lookup_action(self, key: ActionKey) -> ActionRef | None:
        return self._router.lookup_action(key, execution_id=self.execution_id)

    def _perform_get_action(self, action_id: str) -> ActionRef:
        return self._router.get_action(action_id, execution_id=self.execution_id)

    def _perform_read_artifact(self, ref: ArtifactRef, *, max_bytes: int) -> bytes:
        return self._router.read_artifact(
            ref, max_bytes=max_bytes, execution_id=self.execution_id
        )

    def _perform_declare_artifact(
        self, kind: str, media_type: str, filename: str
    ) -> ArtifactSlot:
        declared = self._router.declare_artifact(
            kind,
            media_type,
            filename,
            execution_id=_optional_uuid(self.execution_id),
        )
        return ArtifactSlot(
            id=str(declared.id),
            kind=kind,
            media_type=media_type,
            filename=filename,
        )

    def _perform_finalize_artifact(
        self,
        slot: ArtifactSlot,
        body: bytes,
        hash: str,  # noqa: A002 - SDK RunHandle.finalize_artifact contract
    ) -> ArtifactRef:
        self._router.require_execution(self.execution_id)
        artifact_id = uuid.UUID(slot.id)
        content_hash = hash
        lease = self._router.allocate_artifact_upload(
            artifact_id,
            expected_bytes=len(body),
            expected_hash=content_hash,
        )
        self._router.upload_bytes(lease, body)
        finalized = self._router.finalize_artifact_upload(
            artifact_id,
            lease.id,
            byte_count=len(body),
            content_hash=content_hash,
            expected_generation=lease.fencing_generation,
        )
        return ArtifactRef(
            id=str(finalized.id),
            name=slot.filename,
            mime_type=slot.media_type,
            size=len(body),
            metadata={"kind": slot.kind, "hash": content_hash},
        )

    def reserve_model_call(
        self,
        input_tokens: int,
        output_tokens: int,
        cost_budget: float,
    ) -> ModelCallReservation:
        self._router.require_execution(self.execution_id)
        reservation_id = self._router.reserve_model_call(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_budget=cost_budget,
        )
        return ModelCallReservation(
            id=reservation_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_budget=cost_budget,
        )

    def settle_model_call(
        self,
        reservation: ModelCallReservation,
        actual: ModelCallUsage,
    ) -> None:
        self._router.require_execution(self.execution_id)
        self._router.settle_model_call(
            reservation.id,
            input_tokens=actual.input_tokens,
            output_tokens=actual.output_tokens,
            cost=actual.cost,
        )

    def emit(self, event: RunEvent) -> None:
        self._router.require_execution(self.execution_id)
        if event.execution_id and event.execution_id != self.execution_id:
            raise AgentDbAuthorityError("Event is outside the current execution")
        # Streaming deltas are optional bounded diagnostics. Required history
        # uses record_runtime_audit with a durable logical event identity.
        super().emit(event)


def _optional_uuid(value: str | None) -> uuid.UUID | None:
    if not value:
        return None
    return uuid.UUID(value)
