"""Generated-client mappings for shared processing and discovery records."""

from __future__ import annotations

import hashlib
import uuid
from typing import Any

from agentdb_client import (
    AdmitProcessingIntakeRequest,
    ImportProcessingItemRequest,
    LookupCaseIntakeRequest,
    LookupDiscoveryCheckpointRequest,
    LookupProcessingItemRequest,
    PutDiscoveryCheckpointRequest,
    RequeueProcessingItemRequest,
)
from agentdb_client.api.client_api import ClientApi
from agentdb_client.api.tenant_admin_api import TenantAdminApi
from pydantic import TypeAdapter

from cogit_runtime.agentdb.errors import AgentDbNotFoundError

_JSON_OBJECT = TypeAdapter(dict[str, Any])


def _host_response(result: Any) -> dict[str, Any]:
    """Keep generated aliases and extensions while crossing the JSON host port."""
    return _JSON_OBJECT.dump_python(result.to_dict(), mode="json")


class HostProcessing:
    api: ClientApi
    admin: TenantAdminApi

    def _call(self, method: Any, *args: Any, read: bool = False) -> Any:
        raise NotImplementedError

    def _lookup(self, method: Any, request: Any) -> dict[str, Any] | None:
        try:
            result = self._call(method, str(uuid.uuid4()), request, read=True)
        except AgentDbNotFoundError:
            return None
        return _host_response(result)

    def lookup_receipt(
        self, source: str, external_event_id: str
    ) -> dict[str, Any] | None:
        return self._lookup(
            self.api.lookup_case_intake,
            LookupCaseIntakeRequest(source=source, externalEventId=external_event_id),
        )

    def lookup_processing(
        self, namespace: str, content_sha256: str
    ) -> dict[str, Any] | None:
        return self._lookup(
            self.api.lookup_processing_item,
            LookupProcessingItemRequest(
                namespace=namespace, contentSha256=content_sha256
            ),
        )

    def admit_processing(self, payload: dict[str, Any], key: str) -> dict[str, Any]:
        if payload.get("governanceSnapshotId") is not None:
            http = getattr(self, "database_http", None)
            if http is None:
                raise ValueError(
                    "Governed admission requires its shared database transport"
                )
            return http.request("/v1/processing-items/admit", payload, key=key)
        result = self._call(
            self.api.admit_processing_intake,
            key,
            AdmitProcessingIntakeRequest.model_validate(payload),
        )
        return _host_response(result)

    def import_processing(self, payload: dict[str, Any], key: str) -> dict[str, Any]:
        result = self._call(
            self.admin.import_processing_item,
            key,
            ImportProcessingItemRequest.model_validate(payload),
        )
        return _host_response(result)

    def get_processing(self, processing_id: str) -> dict[str, Any]:
        result = self._call(
            self.api.get_processing_item, uuid.UUID(processing_id), read=True
        )
        return _host_response(result)

    def requeue(
        self, processing_id: str, expected_version: int, reason: str
    ) -> dict[str, Any]:
        request = RequeueProcessingItemRequest(
            expectedVersion=expected_version, reasonCode=reason
        )
        key = hashlib.sha256(
            f"{processing_id}:{request.to_json()}".encode()
        ).hexdigest()
        result = self._call(
            self.api.requeue_processing_item,
            uuid.UUID(processing_id),
            f"cogit:requeue:{key}",
            request,
        )
        return _host_response(result)

    def get_checkpoint(self, namespace: str, key: str) -> dict[str, Any] | None:
        return self._lookup(
            self.api.lookup_discovery_checkpoint,
            LookupDiscoveryCheckpointRequest(namespace=namespace, key=key),
        )

    def save_checkpoint(
        self,
        namespace: str,
        key: str,
        expected_version: int,
        state: dict[str, Any],
    ) -> dict[str, Any]:
        request = PutDiscoveryCheckpointRequest(
            namespace=namespace,
            key=key,
            expectedVersion=expected_version,
            state=state,
        )
        identity = hashlib.sha256(request.to_json().encode()).hexdigest()
        result = self._call(
            self.api.put_discovery_checkpoint, f"cogit:checkpoint:{identity}", request
        )
        return _host_response(result)
