"""AgentDb worker adapter.

:class:`AgentDbCoordinator` consumes the P03 generated Python client to claim
fenced work, maintain its lease, and commit terminal state, without owning any
SQL tables, migrations, queues, or canonical run state.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from cogit_agent_sdk.types import CapabilityGrant, Context, WorkOutcome

from cogit_runtime.agentdb.async_api import AgentDbAsyncApi, _raise_if_uncertain
from cogit_runtime.agentdb.client import AgentDbClient
from cogit_runtime.agentdb.config import AgentDbConfig
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbError,
    AgentDbLeaseLostError,
)
from cogit_runtime.agentdb.handle import AgentDbRunHandle
from cogit_runtime.agentdb.port_values import (
    AttemptStatus,
    CancelWorkRequest,
    ClaimAccepted,
    ClaimEmpty,
    ClaimWorkRequest,
    FailAttemptRequest,
    HeartbeatAttemptRequest,
    ParkAttemptRequest,
    QueueDeliveryIdentity,
    SettleAttemptRequest,
    StructuredError,
)
from cogit_runtime.agentdb.router import AttemptRouter
from cogit_runtime.agentdb.session import AttemptSession
from cogit_runtime.agentdb.transport import AgentDbTransport
from cogit_runtime.agentdb.universal_policy import CurrentProtectedActionAuthority
from cogit_runtime.config import DiagnosticHistoryLimits
from cogit_runtime.readiness import reject_unreserved_claim_cap

_INACTIVE_ATTEMPT_STATUSES = {
    AttemptStatus.PARKED,
    AttemptStatus.SUCCEEDED,
    AttemptStatus.FAILED,
    AttemptStatus.EXPIRED,
}


@dataclass(frozen=True)
class ClaimedWork:
    """The outcome of a successful AgentDb pool claim."""

    attempt_id: uuid.UUID
    attempt_token: str
    work_item_id: uuid.UUID
    attempt_number: int
    lease_expires_at: datetime
    deadline_at: datetime | None
    derived: Any
    run_id: uuid.UUID | None
    input: Any
    input_sha256: str | None = None
    permissions: tuple[CapabilityGrant, ...] | None = None
    model_spend: dict[str, Any] | None = None
    processing_id: uuid.UUID | None = None
    processing_configuration_sha256: str | None = None
    processing_source_artifact_id: uuid.UUID | None = None
    delivery: QueueDeliveryIdentity | None = None

    def redacted(self) -> str:
        """Summary that never exposes the plaintext attempt token."""
        return (
            f"ClaimedWork(attempt_id={self.attempt_id}, "
            f"work_item_id={self.work_item_id}, run_id={self.run_id}, "
            f"attempt_token='<redacted>')"
        )

    __repr__ = redacted  # type: ignore[assignment]


class AgentDbCoordinator(AgentDbAsyncApi):
    """Coordinator backed by the generated AgentDb client."""

    def __init__(self, config: AgentDbConfig, client: AgentDbClient) -> None:
        self._config = config
        self._client = client
        self._session = AttemptSession()
        self._transport = AgentDbTransport()
        self._router = AttemptRouter(
            session=self._session,
            transport=self._transport,
            client=client,
        )

    @property
    def attempt_token(self) -> str | None:
        return self._session.attempt_token

    @property
    def attempt_id(self) -> uuid.UUID | None:
        return self._session.attempt_id

    @property
    def derived(self) -> Any:
        return self._session.derived

    @property
    def finalized_artifact_ids(self) -> list[uuid.UUID]:
        return list(self._session.finalized_artifact_ids)

    @property
    def router(self) -> AttemptRouter:
        return self._router

    def make_run_handle(
        self,
        execution_id: str,
        context: Context,
        *,
        diagnostic_limits: DiagnosticHistoryLimits | None = None,
    ) -> AgentDbRunHandle:
        return AgentDbRunHandle(
            execution_id,
            context,
            router=self._router,
            diagnostic_limits=diagnostic_limits,
            protected_action_authority=CurrentProtectedActionAuthority(
                self._router, execution_id
            ),
        )

    async def claim_work(
        self,
        lease_seconds: int = 900,
        idempotency_key: str | None = None,
    ) -> ClaimedWork | None:
        self._session.clear()
        try:
            result = await self._call(
                self._client.work.claim_pool_work,
                self._config.pool_id,
                idempotency_key=idempotency_key,
                claim_work_request=ClaimWorkRequest(lease_seconds=lease_seconds),
            )
        except AgentDbError as exc:
            _raise_if_uncertain("claim", exc)

        instance = getattr(result, "actual_instance", None)
        if instance is None or isinstance(instance, ClaimEmpty):
            return None
        if not isinstance(instance, ClaimAccepted):
            return None

        reject_unreserved_claim_cap(instance)
        self._session.bind_claim(
            attempt_id=instance.attempt_id,
            attempt_token=instance.attempt_token,
            work_item_id=instance.work_item_id,
            run_id=instance.derived.run_id,
            derived=instance.derived,
            delivery=instance.delivery,
            processing_id=instance.processing_id,
        )
        return ClaimedWork(
            attempt_id=instance.attempt_id,
            attempt_token=instance.attempt_token,
            work_item_id=instance.work_item_id,
            attempt_number=instance.attempt_number,
            lease_expires_at=instance.lease_expires_at,
            deadline_at=instance.deadline_at,
            derived=instance.derived,
            delivery=instance.delivery,
            run_id=instance.derived.run_id,
            input=instance.input,
            input_sha256=instance.input_sha256,
            permissions=instance.permissions,
            model_spend=instance.model_spend,
            processing_id=instance.processing_id,
            processing_configuration_sha256=instance.processing_configuration_sha256,
            processing_source_artifact_id=instance.processing_source_artifact_id,
        )

    async def heartbeat(self, progress: dict[str, Any] | None = None) -> None:
        attempt_id, token = self._session.require_ids()
        correlated = {
            **(progress or {}),
            "runId": str(self._session.run_id) if self._session.run_id else None,
            "attemptId": str(attempt_id),
            "executionId": (
                str(self._session.execution_id)
                if self._session.execution_id is not None
                else None
            ),
        }
        request = HeartbeatAttemptRequest(progress=correlated)
        try:
            await self._call(
                self._client.work.heartbeat_attempt,
                attempt_id,
                token,
                heartbeat_attempt_request=request,
            )
        except AgentDbLeaseLostError:
            self._session.clear()
            raise

    def decision_checkpoint(self, execution_id: str) -> uuid.UUID:
        """Choose the latest confirmed state after all supervised work drains."""
        self._router.require_execution(execution_id)
        checkpoint = self._router.continuation.checkpoint_id
        if checkpoint is None:
            raise AgentDbAuthorityError("Decision park has no confirmed checkpoint")
        return checkpoint

    async def park(
        self,
        checkpoint_id: uuid.UUID,
        wait_reason: str | None = None,
    ) -> None:
        attempt_id, token = self._session.require_ids()
        await self._transition(
            "park",
            self._client.work.park_attempt,
            attempt_id,
            token,
            self._session.idempotency_key("park"),
            ParkAttemptRequest(checkpoint_id=checkpoint_id, wait_reason=wait_reason),
        )

    async def settle(
        self,
        result_artifact_id: uuid.UUID | None = None,
        artifact_ids: list[uuid.UUID] | None = None,
    ) -> None:
        attempt_id, token = self._session.require_ids()
        settled_ids = (
            artifact_ids
            if artifact_ids is not None
            else list(self._session.finalized_artifact_ids)
        )
        result_id = result_artifact_id
        if result_id is None and settled_ids:
            result_id = settled_ids[-1]
        await self._transition(
            "settle",
            self._client.work.settle_attempt,
            attempt_id,
            token,
            self._session.idempotency_key("settle"),
            SettleAttemptRequest(
                result_artifact_id=result_id,
                artifact_ids=settled_ids or None,
            ),
        )

    async def settle_processing(
        self,
        *,
        result_artifact_id: uuid.UUID,
        outcome: WorkOutcome,
        execution_succeeded: bool,
    ) -> None:
        attempt_id, token = self._session.require_ids()
        if self._session.processing_id is None:
            raise AgentDbError("The active claim is not managed processing work")
        await self._transition(
            "processing-outcome",
            self._client.work.settle_processing_attempt,
            attempt_id,
            token,
            self._session.idempotency_key("processing-outcome"),
            result_artifact_id,
            outcome,
            execution_succeeded,
        )

    async def fail(
        self,
        error: str,
        *,
        retryable: bool = False,
        code: str = "runtime_failure",
    ) -> None:
        attempt_id, token = self._session.require_ids()
        await self._transition(
            "fail",
            self._client.work.fail_attempt,
            attempt_id,
            token,
            self._session.idempotency_key("fail"),
            FailAttemptRequest(
                error=StructuredError(code=code, message=error),
                retryable=retryable,
            ),
        )

    async def cancel(self, reason: str | None = None) -> None:
        work_item_id = self._session.require_work_item()
        token = self._session.require_token()
        await self._transition(
            "cancel",
            self._client.work.cancel_work,
            work_item_id,
            self._session.idempotency_key("cancel"),
            token,
            cancel_work_request=(CancelWorkRequest(reason=reason) if reason else None),
        )

    async def is_cancelled(self) -> bool:
        attempt_id, token = self._session.require_ids()
        try:
            attempt = await self._call(
                self._client.work.get_work_attempt,
                attempt_id,
                token,
                idempotent=True,
                operation="get-attempt",
            )
        except AgentDbLeaseLostError:
            self._session.clear()
            raise
        status = getattr(attempt, "status", None)
        if status == AttemptStatus.CANCELLED:
            self._session.clear()
            return True
        if status in _INACTIVE_ATTEMPT_STATUSES:
            self._session.clear()
            raise AgentDbLeaseLostError(
                "AgentDb attempt became inactive while execution was running"
            )
        return False

    async def close(self) -> None:
        try:
            await self._call(self._client.close, idempotent=True, operation="close")
        finally:
            self._session.clear()
