"""Canonical checkpoint publication and exact park reconciliation."""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING, Any
from uuid import UUID

from agentdb_client import (
    CreateCheckpointRequest,
    CreateCheckpointRequestPayload,
    CreateCheckpointRequestPayloadOneOf1,
    ParkAttemptRequest,
)

from cogit_runtime.agentdb.continuation_schema import bounded_json
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.agentdb.replay import replay_once

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


class CurrentCheckpoints:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client
        self.latest: tuple[UUID, UUID, int, UUID] | None = None

    def publish(self, token: str, execution_id: UUID, payload: dict[str, Any]) -> UUID:
        claim = self.client.active(token)
        if str(execution_id) != self.client.execution_id:
            raise AgentDbAuthorityError("Checkpoint execution identity mismatch")
        digest = hashlib.sha256(bounded_json(payload)).hexdigest()
        key = (
            "cogit:checkpoint:"
            + hashlib.sha256(
                f"{claim.attempt_id}:{execution_id}:{digest}".encode()
            ).hexdigest()
        )
        headers = self.client.headers(key)
        # The generated JSON oneOf decoder cannot distinguish the two formats;
        # explicitly select its validated v2 model instead of guessing a branch.
        wire_payload = CreateCheckpointRequestPayloadOneOf1.from_dict(payload)
        assert wire_payload is not None
        request = CreateCheckpointRequest(
            generation=claim.generation,
            payload=CreateCheckpointRequestPayload(actual_instance=wire_payload),
        )
        try:
            result = replay_once(
                lambda: self.client.attempt_api.create_checkpoint(
                    execution_id,
                    token,
                    request,
                    _headers=headers,
                    _request_timeout=self.client.timeout,
                )
            )
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Canonical checkpoint publication was not confirmed"
            ) from None
        if (
            getattr(result, "execution_id", None) != execution_id
            or getattr(result, "format", None) != "agentdb.checkpoint.v2"
            or not isinstance(getattr(result, "checkpoint_id", None), UUID)
        ):
            raise AgentDbReconciliationRequiredError(
                "Canonical checkpoint receipt identity mismatch"
            )
        self.client.runtime_audit.lifecycle(
            execution_id,
            token,
            "completed",
            "checkpoint",
            identity=str(result.checkpoint_id),
            details={"requestSha256": digest},
        )
        self.latest = (
            claim.attempt_id,
            execution_id,
            claim.generation,
            result.checkpoint_id,
        )
        return result.checkpoint_id

    def park(self, attempt_id: UUID, token: str, key: str, checkpoint_id: UUID) -> Any:
        claim = self.client.active(token)
        execution_id = (
            UUID(self.client.execution_id) if self.client.execution_id else None
        )
        if attempt_id != claim.attempt_id or self.latest != (
            attempt_id,
            execution_id,
            claim.generation,
            checkpoint_id,
        ):
            raise AgentDbAuthorityError("Park requires the latest current checkpoint")
        assert execution_id is not None
        self.client.runtime_audit.lifecycle(
            execution_id,
            token,
            "parked",
            "execution.park",
            identity=str(checkpoint_id),
        )
        request = ParkAttemptRequest(
            generation=claim.generation, checkpointId=checkpoint_id
        )
        headers = self.client.headers(key)
        try:
            result = replay_once(
                lambda: self.client.attempt_api.park_attempt(
                    attempt_id,
                    token,
                    request,
                    _headers=headers,
                    _request_timeout=self.client.timeout,
                )
            )
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Canonical park outcome was not confirmed"
            ) from None
        if (
            getattr(result, "attempt_id", None) != attempt_id
            or getattr(result, "checkpoint_id", None) != checkpoint_id
            or getattr(result, "prior_execution_id", None) != execution_id
            or getattr(result, "lifecycle", None) != "parked"
        ):
            raise AgentDbReconciliationRequiredError("Canonical park receipt mismatch")
        return result
