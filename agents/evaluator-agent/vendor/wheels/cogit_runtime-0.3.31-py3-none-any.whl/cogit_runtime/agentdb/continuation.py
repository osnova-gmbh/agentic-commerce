"""Synchronous canonical continuation journal, fenced before effects."""

from __future__ import annotations

import hashlib
import threading
from collections.abc import Callable
from typing import Any
from uuid import UUID

from pydantic import TypeAdapter, ValidationError

from cogit_runtime.agentdb.continuation_index import encode_index, index_checkpoint
from cogit_runtime.agentdb.continuation_schema import (
    ContinuationArtifact,
    LoopContinuation,
    LoopToolSlot,
    ModelSlot,
    PipelineContinuation,
    RuntimeContinuation,
    SlotKey,
    checkpoint_payload,
)
from cogit_runtime.agentdb.decision_schema import DecisionSlot
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbReconciliationRequiredError,
)


class ContinuationJournal:
    """Publish immutable state before allowing its caller to continue.

    The publisher must replay one identical idempotent request on an ambiguous
    response and validate the canonical receipt. Any unconfirmed publication
    permanently fences this instance; recovery requires another verified claim.
    """

    def __init__(
        self,
        state: RuntimeContinuation,
        *,
        execution_id: UUID,
        publish: Callable[[dict[str, Any]], UUID],
        store_index: Callable[[bytes], ContinuationArtifact] | None = None,
    ) -> None:
        self._state = state.model_copy(deep=True, update={"execution_id": execution_id})
        self._publish = publish
        self._store_index = store_index
        self._lock = threading.Lock()
        self._poisoned = False
        self._checkpoint_id: UUID | None = None

    @property
    def original_work_id(self) -> UUID:
        return self._state.original_work_id

    @property
    def checkpoint_id(self) -> UUID | None:
        with self._lock:
            self._require_live()
            return self._checkpoint_id

    def read_model_slot(self, slot_key: str) -> dict[str, Any] | None:
        with self._lock:
            self._require_live()
            value = self._state.model_slots.get(self._key(slot_key))
            return value.model_dump(mode="json", exclude_none=True) if value else None

    def write_model_slot(
        self,
        slot_key: str,
        value: dict[str, Any],
        *,
        expected_phase: str | None,
    ) -> None:
        with self._lock:
            self._require_live()
            key = self._key(slot_key)
            try:
                replacement = ModelSlot.model_validate(value)
            except ValidationError:
                raise AgentDbAuthorityError("Invalid model continuation slot") from None
            previous = self._state.model_slots.get(key)
            if (previous.phase if previous else None) != expected_phase:
                raise AgentDbAuthorityError("Model continuation phase conflict")
            allowed = {
                None: {"prepared"},
                "prepared": {"prepared", "dispatch_intent"},
                "dispatch_intent": {"completed"},
                "completed": set(),
            }
            if replacement.phase not in allowed.get(expected_phase, set()):
                raise AgentDbAuthorityError("Invalid model continuation transition")
            if previous and previous.commitment != replacement.commitment:
                raise AgentDbAuthorityError("Model continuation commitment changed")
            slots = {**self._state.model_slots, key: replacement}
            self._commit({"model_slots": slots})

    def checkpoint(self) -> UUID:
        with self._lock:
            self._require_live()
            self._commit({})
            assert self._checkpoint_id is not None
            return self._checkpoint_id

    def read_decision(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            self._require_live()
            value = self._state.decisions.get(self._decision_key(key))
            return value.model_dump(mode="json", exclude_none=True) if value else None

    def write_decision(
        self, key: str, value: dict[str, Any], *, expected_phase: str | None
    ) -> None:
        with self._lock:
            self._require_live()
            key = self._decision_key(key)
            try:
                replacement = DecisionSlot.model_validate(value)
            except ValidationError:
                raise AgentDbAuthorityError("Invalid decision continuation") from None
            previous = self._state.decisions.get(key)
            if (previous.phase if previous else None) != expected_phase:
                raise AgentDbAuthorityError("Decision continuation phase conflict")
            allowed = {
                None: {"prepared"},
                "prepared": {"requested"},
                "requested": {"requested"},
            }
            if replacement.phase not in allowed.get(expected_phase, set()):
                raise AgentDbAuthorityError("Invalid decision continuation transition")
            if previous and previous.intent != replacement.intent:
                raise AgentDbAuthorityError("Decision commitment changed")
            if previous and previous.receipt:
                assert replacement.receipt is not None
                excluded = {"state", "decision"}
                if previous.receipt.model_dump(
                    exclude=excluded
                ) != replacement.receipt.model_dump(exclude=excluded):
                    raise AgentDbAuthorityError("Decision receipt identity changed")
            self._commit({"decisions": {**self._state.decisions, key: replacement}})

    def read_pipeline(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            self._require_live()
            value = self._state.pipelines.get(self._key(key))
            return value.model_dump(mode="json", exclude_none=True) if value else None

    def write_pipeline(
        self, key: str, value: dict[str, Any], *, expected_revision: int | None
    ) -> None:
        with self._lock:
            self._require_live()
            key = self._key(key)
            try:
                replacement = PipelineContinuation.model_validate(value)
            except ValidationError:
                raise AgentDbAuthorityError("Invalid pipeline continuation") from None
            previous = self._state.pipelines.get(key)
            if (previous.revision if previous else None) != expected_revision:
                raise AgentDbAuthorityError("Pipeline continuation revision conflict")
            if replacement.revision != (previous.revision + 1 if previous else 0):
                raise AgentDbAuthorityError("Invalid pipeline continuation revision")
            if previous:
                if replacement.definition_sha256 != previous.definition_sha256:
                    raise AgentDbAuthorityError("Pipeline definition changed")
                for slot, old in previous.steps.items():
                    new = replacement.steps.get(slot)
                    if (
                        new is None
                        or old.idempotency != new.idempotency
                        or old.invocation_key != new.invocation_key
                    ):
                        raise AgentDbAuthorityError(
                            "Pipeline invocation identity changed"
                        )
                    if (
                        old.phase in {"completed", "skipped", "cancelled", "escalated"}
                        and old != new
                    ):
                        raise AgentDbAuthorityError(
                            "Completed pipeline evidence changed"
                        )
                    if new.attempts < old.attempts or new.attempts > old.attempts + 1:
                        raise AgentDbAuthorityError("Pipeline attempt count changed")
            self._commit({"pipelines": {**self._state.pipelines, key: replacement}})

    def read_loop(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            self._require_live()
            value = self._state.loops.get(self._key(key))
            return value.model_dump(mode="json") if value else None

    def write_loop(self, key: str, value: dict[str, Any]) -> None:
        with self._lock:
            self._require_live()
            key = self._key(key)
            replacement = LoopContinuation.model_validate(value)
            previous = self._state.loops.get(key)
            if previous and previous.model_dump(
                exclude={"snapshot", "snapshot_execution_id", "snapshot_queue_item_id"}
            ) != replacement.model_dump(
                exclude={"snapshot", "snapshot_execution_id", "snapshot_queue_item_id"}
            ):
                raise AgentDbAuthorityError("Loop recovery identity changed")
            self._commit({"loops": {**self._state.loops, key: replacement}})

    def read_loop_tool(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            self._require_live()
            value = self._state.loop_tools.get(self._key(key))
            return value.model_dump(mode="json") if value else None

    def write_loop_tool(
        self, key: str, value: dict[str, Any], *, expected_phase: str | None
    ) -> None:
        with self._lock:
            self._require_live()
            key = self._key(key)
            replacement = LoopToolSlot.model_validate(value)
            previous = self._state.loop_tools.get(key)
            if (previous.phase if previous else None) != expected_phase:
                raise AgentDbAuthorityError("Loop tool phase conflict")
            if replacement.phase != ("completed" if previous else "intent"):
                raise AgentDbAuthorityError("Invalid loop tool transition")
            if previous and previous.model_dump(
                exclude={"phase", "result"}
            ) != replacement.model_dump(exclude={"phase", "result"}):
                raise AgentDbAuthorityError("Loop tool identity changed")
            self._commit({"loop_tools": {**self._state.loop_tools, key: replacement}})

    def _commit(self, updates: dict[str, Any]) -> None:
        try:
            candidate = RuntimeContinuation.model_validate(
                {
                    **self._state.model_dump(),
                    **updates,
                    "revision": self._state.revision + 1,
                }
            )
        except ValidationError:
            raise AgentDbAuthorityError("Invalid Runtime continuation state") from None
        # A v1 checkpoint remains unchanged while it fits. Spill only through
        # a server-negotiated writer; rejected local bounds do not imply I/O.
        index_body: bytes | None = None
        try:
            payload = checkpoint_payload(candidate)
        except AgentDbAuthorityError:
            if self._store_index is None:
                raise
            index_body = encode_index(candidate)
        try:
            if index_body is not None:
                assert self._store_index is not None
                reference = self._store_index(index_body)
                if (
                    reference.size != len(index_body)
                    or reference.metadata.hash != hashlib.sha256(index_body).hexdigest()
                ):
                    raise AgentDbAuthorityError("Journal index publication differs")
                payload = index_checkpoint(candidate, reference)
            checkpoint_id = self._publish(payload)
            if not isinstance(checkpoint_id, UUID):
                raise AgentDbAuthorityError("Invalid canonical checkpoint receipt")
        except BaseException:
            self._poisoned = True
            raise AgentDbReconciliationRequiredError(
                "Runtime checkpoint publication was not confirmed"
            ) from None
        self._checkpoint_id = checkpoint_id
        self._state = candidate

    def _require_live(self) -> None:
        if self._poisoned:
            raise AgentDbReconciliationRequiredError(
                "Runtime continuation requires an authoritative replacement claim"
            )

    @staticmethod
    def _decision_key(value: str) -> str:
        if not isinstance(value, str) or not 1 <= len(value.encode("utf-8")) <= 4096:
            raise AgentDbAuthorityError("Invalid decision invocation identity")
        # Version strings are opaque SDK identities; do not constrain them to
        # the checkpoint map's narrower key grammar or store their raw text.
        return "decision:" + hashlib.sha256(value.encode("utf-8")).hexdigest()

    @staticmethod
    def _key(value: str) -> str:
        try:
            return TypeAdapter(SlotKey).validate_python(value)
        except ValidationError:
            raise AgentDbAuthorityError("Invalid continuation slot key") from None
