"""Verify interpreter caches against the already verified wheel source bytes."""

from __future__ import annotations

import io
import marshal
import re
import sys
from importlib.util import MAGIC_NUMBER, source_from_cache
from pathlib import Path
from types import CodeType

from cogit_runtime.agentdb.cohort_files import MAX_MEMBER_BYTES, read_bounded
from cogit_runtime.agentdb.errors import AgentDbError


def verify_cache(path: Path, approved: frozenset[Path]) -> None:
    """Parse a bounded cache without executing it and compare its complete code."""
    try:
        source = Path(source_from_cache(str(path))).resolve(strict=True)
        if source not in approved or source.suffix != ".py":
            raise ValueError("Cache source was not in the immutable wheel")
        tag = re.escape(str(sys.implementation.cache_tag))
        match = re.fullmatch(rf".+\.{tag}(?:\.opt-([012]))?\.pyc", path.name)
        if match is None:
            raise ValueError("Cache interpreter or optimization is unsupported")
        optimization = int(match.group(1) or "0")
        body = read_bounded(path, MAX_MEMBER_BYTES)
        if (
            len(body) < 16
            or body[:4] != MAGIC_NUMBER
            or int.from_bytes(body[4:8], "little") not in {0, 1, 3}
        ):
            raise ValueError("Cache header is invalid")
        stream = io.BytesIO(body[16:])
        code = marshal.load(stream)  # noqa: S302 - bounded code data, never executed
        if not isinstance(code, CodeType) or stream.read(1):
            raise ValueError("Cache must contain exactly one code object")
        expected = compile(
            read_bounded(source, MAX_MEMBER_BYTES),
            str(source),
            "exec",
            dont_inherit=True,
            optimize=optimization,
        )
        if marshal.dumps(_canonical_code(code, source)) != marshal.dumps(
            _canonical_code(expected, source)
        ):
            raise ValueError("Cache bytecode differs from immutable source")
    except AgentDbError:
        raise
    except (
        OSError,
        ValueError,
        TypeError,
        EOFError,
        SyntaxError,
        RecursionError,
    ) as exc:
        raise AgentDbError("Installed canonical worker bytecode is unverified") from exc


def _canonical_code(code: CodeType, source: Path) -> CodeType:
    # Importers can spell the same Windows path with another separator/case.
    # A cache pointing at any other filename is not an approved source cache.
    if Path(code.co_filename).resolve() != source:
        raise ValueError("Cache code filename differs from its verified source")
    constants = tuple(
        _canonical_code(value, source) if isinstance(value, CodeType) else value
        for value in code.co_consts
    )
    return code.replace(co_filename=str(source), co_consts=constants)
