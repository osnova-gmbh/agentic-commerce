"""Authorized host settings, policy activation and immutable snapshot port."""

from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from cogit_runtime.agentdb.database_http import DatabaseHttp, command_key


class HostGovernance:
    def __init__(self, http: DatabaseHttp) -> None:
        self.http = http

    def current_settings(self, installation_id: str, key: str) -> dict[str, Any]:
        return self.http.request(
            "/v1/agent-settings/lookup",
            {
                "installationId": str(UUID(installation_id)),
                "settingsKey": key,
            },
        )

    def update_settings(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.http.request(
            "/v1/agent-settings", payload, key=command_key("settings", payload)
        )

    def snapshot(self, installation_id: str, key: str) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "installationId": str(UUID(installation_id)),
            "settingsKey": key,
        }
        # A policy activation can change independently of the settings revision.
        revision = self.current_settings(installation_id, key)
        payload["expectedSettingsVersion"] = revision["version"]
        return self.http.request(
            "/v1/governance/snapshots",
            payload,
            key=command_key("snapshot", {**payload, "nonce": str(uuid4())}),
        )

    def create_policy(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.http.request(
            "/v1/policy-versions", payload, key=command_key("policy", payload)
        )

    def bind_policy(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.http.request(
            "/v1/policy-bindings", payload, key=command_key("binding", payload)
        )

    def specialization(self, installation_id: str) -> dict[str, Any]:
        return self.http.request(
            "/v1/agent-specializations/lookup",
            {"installationId": str(UUID(installation_id))},
        )

    def publish_specialization(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.http.request(
            "/v1/agent-specializations",
            payload,
            key=command_key("specialization", payload),
        )
