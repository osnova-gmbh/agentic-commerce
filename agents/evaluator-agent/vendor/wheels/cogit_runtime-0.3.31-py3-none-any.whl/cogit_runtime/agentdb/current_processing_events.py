"""Canonical stage event HTTP adapter; authority comes from the current claim."""

from __future__ import annotations

import json
import uuid
from typing import TYPE_CHECKING, Any

import httpx
from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.errors import (
    AgentDbAuthenticationError,
    AgentDbAuthorityError,
    AgentDbAuthorizationError,
    AgentDbConflictError,
    AgentDbError,
    AgentDbLeaseLostError,
    AgentDbNotFoundError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.agentdb.response_body import collected_response

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


class CurrentProcessingEvents:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client

    def record(
        self,
        execution_id: uuid.UUID,
        token: str,
        key: str,
        request: dict[str, Any],
    ) -> dict[str, Any]:
        claim = self.client.active(token)
        if self.client.execution_id != str(execution_id):
            raise AgentDbAuthorityError("Event is outside the current execution")
        payload = {**request, "generation": claim.generation}
        url = (
            self.client.config.url.rstrip("/")
            + f"/v1/worker/executions/{execution_id}/processing-events"
        )
        headers = {
            **self.client.headers(key),
            "authorization": "Bearer " + self.client.config.worker_token,
            "x-agentdb-attempt-token": token,
        }
        timeout = httpx.Timeout(self.client.timeout[1], connect=self.client.timeout[0])
        # Only replay transport loss with exactly the same event identity and body.
        for attempt in range(2):
            try:
                stream = httpx.stream(
                    "POST", url, json=payload, headers=headers, timeout=timeout
                )
                with collected_response(
                    stream, limit=8192, oversized=_oversized_response
                ) as (status, body):
                    return _classify_response(status, body, execution_id, request)
            except CoordinationFailure:
                raise
            except httpx.TransportError:
                if attempt == 0:
                    continue
                raise AgentDbReconciliationRequiredError(
                    "AgentDb stage receipt is unavailable"
                ) from None
            except AgentDbError:
                raise
            except Exception:
                raise AgentDbReconciliationRequiredError(
                    "AgentDb stage receipt is unavailable"
                ) from None
        raise AgentDbError("AgentDb stage event failed")


def _oversized_response(status: int) -> AgentDbError:
    if status == 201 or status >= 500:
        return AgentDbReconciliationRequiredError(
            "AgentDb stage receipt is unavailable"
        )
    return AgentDbError("AgentDb stage response exceeds its bound")


def _classify_response(
    status: int, body: bytes, execution_id: uuid.UUID, request: dict[str, Any]
) -> dict[str, Any]:
    try:
        result = json.loads(body)
    except (ValueError, UnicodeError, RecursionError):
        result = None
    if (
        status == 409
        and isinstance(result, dict)
        and result.get("code") == "stale_attempt"
    ):
        raise AgentDbLeaseLostError("AgentDb rejected stale attempt authority")
    error_type = {
        401: AgentDbAuthenticationError,
        403: AgentDbAuthorizationError,
        404: AgentDbNotFoundError,
        409: AgentDbConflictError,
    }.get(status)
    if error_type is not None:
        raise error_type("AgentDb rejected stage event")
    if status >= 500:
        raise AgentDbReconciliationRequiredError("AgentDb stage receipt is unavailable")
    if status != 201:
        raise AgentDbError("AgentDb stage receipt is invalid")
    try:
        if not isinstance(result, dict):
            raise ValueError("receipt")
        event_id = str(uuid.UUID(result["eventId"]))
        if (
            result["executionId"] != str(execution_id)
            or result["stageKey"] != request["stageKey"]
            or result["stageOrder"] != request["stageOrder"]
            or result["status"] != request["status"]
            or not isinstance(result["replayed"], bool)
        ):
            raise ValueError("receipt")
    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        raise AgentDbReconciliationRequiredError(
            "AgentDb stage receipt is invalid"
        ) from None
    return {**result, "eventId": event_id}
