"""Supervise one AgentDb attempt while its heartbeat remains active."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import Context, RunRequest, RunResult

from cogit_runtime.agentdb.coordinator import AgentDbCoordinator
from cogit_runtime.agentdb.errors import (
    AgentDbCancellationRejectedError,
)
from cogit_runtime.cancellation import RuntimeWorkDeferred, await_runtime_completion
from cogit_runtime.reporter import RunReporter

AgentDbRunExecutor = Callable[
    [RunRequest, Context, RunReporter, str],
    Coroutine[Any, Any, RunResult],
]
CancelExecution = Callable[[str], bool]


@dataclass(frozen=True)
class _CancellationSignal:
    accepted: bool


class ClaimSupervisor:
    """Run one claimed agent invocation under heartbeat and cancel polls."""

    def __init__(
        self,
        *,
        coordinator: AgentDbCoordinator,
        executor: AgentDbRunExecutor,
        reporter: RunReporter,
        cancel_execution: CancelExecution,
        heartbeat_interval: float,
        shutdown: asyncio.Event | None = None,
    ) -> None:
        self._coordinator = coordinator
        self._executor = executor
        self._reporter = reporter
        self._cancel_execution = cancel_execution
        self._heartbeat_interval = heartbeat_interval
        self._shutdown = shutdown or asyncio.Event()

    async def run(
        self,
        request: RunRequest,
        context: Context,
        execution_id: str,
    ) -> tuple[RunResult | None, bool]:
        stop_monitor = asyncio.Event()
        execution_task = asyncio.create_task(
            self._execute(request, context, execution_id)
        )
        monitor_task = asyncio.create_task(
            self._monitor(execution_id, execution_task, stop_monitor)
        )
        try:
            return await self._join(
                execution_id, execution_task, monitor_task, stop_monitor
            )
        except BaseException as primary:
            stop_monitor.set()
            cancel_error: CoordinationFailure | None = None
            if not execution_task.done():
                try:
                    self._request_cancel(execution_id)
                except CoordinationFailure as exc:
                    cancel_error = exc
                execution_task.cancel()
            if not monitor_task.done():
                monitor_task.cancel()
            execution_error = await await_runtime_completion(
                asyncio.create_task(_drain_execution(execution_task))
            )
            monitor_error = await await_runtime_completion(
                asyncio.create_task(_drain_monitor(monitor_task))
            )
            for failure in (primary, execution_error, monitor_error, cancel_error):
                if isinstance(failure, CoordinationFailure):
                    raise failure from None
            raise
        finally:
            stop_monitor.set()

    async def _execute(
        self, request: RunRequest, context: Context, execution_id: str
    ) -> RunResult:
        """Keep heartbeats and cancellation polls alive during deferred execution."""
        try:
            return await self._executor(request, context, self._reporter, execution_id)
        except RuntimeWorkDeferred as deferred:
            result = await await_runtime_completion(deferred.completion)
            if isinstance(result, RunResult):
                return result
            raise

    async def _join(
        self,
        execution_id: str,
        execution_task: asyncio.Task[RunResult],
        monitor_task: asyncio.Task[_CancellationSignal | None],
        stop_monitor: asyncio.Event,
    ) -> tuple[RunResult | None, bool]:
        done, _ = await asyncio.wait(
            {execution_task, monitor_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if execution_task in done and not monitor_task.done():
            stop_monitor.set()
        execution_failure = (
            execution_task.exception()
            if execution_task.done() and not execution_task.cancelled()
            else None
        )
        try:
            signal = await monitor_task
        except BaseException:
            if isinstance(execution_failure, CoordinationFailure):
                raise execution_failure from None
            raise
        if isinstance(execution_failure, CoordinationFailure):
            raise execution_failure
        if signal is None:
            return await self._execution_result(execution_task)
        if not execution_task.done():
            execution_task.cancel()
        failure = await await_runtime_completion(
            asyncio.create_task(_drain_execution(execution_task))
        )
        if isinstance(failure, CoordinationFailure):
            raise failure
        if not signal.accepted:
            raise AgentDbCancellationRejectedError(
                "AgentDb cancellation could not find the active execution"
            )
        return None, True

    async def _execution_result(
        self,
        task: asyncio.Task[RunResult],
    ) -> tuple[RunResult | None, bool]:
        try:
            return task.result(), False
        except RuntimeWorkDeferred as deferred:
            result = await await_runtime_completion(deferred.completion)
            if isinstance(result, RunResult):
                return result, False
            await self._coordinator.cancel(reason="Runtime execution was cancelled")
            return None, True

    async def _monitor(
        self,
        execution_id: str,
        execution_task: asyncio.Task[RunResult],
        stop: asyncio.Event,
    ) -> _CancellationSignal | None:
        # Host shutdown stops admission in AgentDbWorker. Continue supervising
        # already-owned work: cancelling its Runtime signal would persist a
        # business cancellation in the continuation instead of draining it.
        while not stop.is_set() and not execution_task.done():
            if await self._coordinator.is_cancelled():
                return _CancellationSignal(accepted=self._request_cancel(execution_id))
            try:
                await asyncio.wait_for(
                    stop.wait(),
                    timeout=self._heartbeat_interval,
                )
            except TimeoutError:
                if not execution_task.done():
                    await self._coordinator.heartbeat()
        return None

    def _request_cancel(self, execution_id: str) -> bool:
        try:
            return self._cancel_execution(execution_id)
        except CoordinationFailure:
            raise
        except Exception:
            return False


async def _drain_execution(
    task: asyncio.Task[RunResult],
) -> BaseException | None:
    try:
        await task
    except RuntimeWorkDeferred as deferred:
        try:
            await await_runtime_completion(deferred.completion)
        except BaseException as exc:
            return exc
    except BaseException as exc:
        return exc
    return None


async def _drain_monitor(task: asyncio.Task[Any]) -> BaseException | None:
    try:
        await task
    except BaseException as exc:
        return exc
    return None
