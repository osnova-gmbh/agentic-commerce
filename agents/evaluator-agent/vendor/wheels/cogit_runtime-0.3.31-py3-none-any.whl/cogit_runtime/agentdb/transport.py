"""Invoke the generated AgentDb client with contract-limited retries."""

from __future__ import annotations

from collections.abc import Callable
from typing import NoReturn, TypeVar

from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.errors import (
    AgentDbError,
    AgentDbReconciliationRequiredError,
    AgentDbTimeoutError,
    classify,
)

_T = TypeVar("_T")


class AgentDbTransport:
    """Synchronous generated-client boundary with redacted error mapping."""

    def invoke(
        self,
        fn: Callable[..., _T],
        *args: object,
        idempotent: bool = False,
        operation: str = "request",
    ) -> _T:
        try:
            return fn(*args)
        except CoordinationFailure:
            raise
        except AgentDbError as exc:
            self._raise_mapped(operation, exc, idempotent=idempotent)
        except Exception as exc:
            mapped = classify(exc)
            if idempotent and _is_retryable_read(mapped):
                return self._retry_read(fn, *args, operation=operation)
            self._raise_mapped(operation, mapped, idempotent=idempotent)

    def _retry_read(
        self,
        fn: Callable[..., _T],
        *args: object,
        operation: str,
    ) -> _T:
        try:
            return fn(*args)
        except CoordinationFailure:
            raise
        except AgentDbError as exc:
            self._raise_mapped(operation, exc, idempotent=True)
        except Exception as exc:
            self._raise_mapped(operation, classify(exc), idempotent=True)

    @staticmethod
    def _raise_mapped(
        operation: str,
        exc: AgentDbError,
        *,
        idempotent: bool,
    ) -> NoReturn:
        if not idempotent and (
            isinstance(exc, AgentDbTimeoutError)
            or exc.retryable
            or (exc.http_status is not None and exc.http_status >= 500)
        ):
            raise AgentDbReconciliationRequiredError(
                f"AgentDb {operation} outcome is uncertain; reconcile before retrying",
                response_metadata=exc.response_metadata,
            ) from None
        raise exc from None


def _is_retryable_read(exc: AgentDbError) -> bool:
    return isinstance(exc, AgentDbTimeoutError) or exc.retryable
