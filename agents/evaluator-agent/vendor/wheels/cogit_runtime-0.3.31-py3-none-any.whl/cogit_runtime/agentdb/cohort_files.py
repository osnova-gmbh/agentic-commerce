"""Bounded reads of local cohort artifacts; archives are never extracted."""

from __future__ import annotations

import hashlib
import re
import stat
from pathlib import Path
from typing import IO
from zipfile import ZipFile, ZipInfo

from cogit_runtime.agentdb.cohort_contract import require_relative_path
from cogit_runtime.agentdb.errors import AgentDbError

MAX_WHEEL_BYTES = 32 * 1024 * 1024
MAX_MEMBER_BYTES = 16 * 1024 * 1024
MAX_EXPANDED_BYTES = 128 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 4096


def plain_path(root: Path, relative: str) -> Path:
    """Reject traversal, symlinks and Windows reparse points before reading."""
    require_relative_path(relative)
    for directory in (root, *root.parents):
        _require_unlinked(directory)
    candidate = root
    for part in relative.split("/"):
        candidate /= part
        _require_unlinked(candidate)
    if not candidate.resolve(strict=True).is_relative_to(root.resolve(strict=True)):
        raise AgentDbError("Canonical worker artifact escaped its cohort directory")
    if not stat.S_ISREG(candidate.stat().st_mode):
        raise AgentDbError("Canonical worker artifact must be a regular file")
    return candidate


def _require_unlinked(path: Path) -> None:
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or (
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
    ):
        raise AgentDbError("Canonical worker artifacts cannot be linked")


def read_bounded(path: Path, maximum: int) -> bytes:
    if path.stat().st_size > maximum:
        raise AgentDbError("Canonical worker artifact exceeds its size limit")
    with path.open("rb") as stream:
        body = stream.read(maximum + 1)
    if len(body) > maximum:
        raise AgentDbError("Canonical worker artifact exceeds its size limit")
    return body


def stream_digest(stream: IO[bytes], maximum: int) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    while chunk := stream.read(65536):
        size += len(chunk)
        if size > maximum:
            raise AgentDbError("Canonical worker artifact exceeds its size limit")
        digest.update(chunk)
    return digest.hexdigest(), size


def archive_members(archive: ZipFile) -> tuple[ZipInfo, ...]:
    members = tuple(archive.infolist())
    if not 1 <= len(members) <= MAX_ARCHIVE_MEMBERS:
        raise AgentDbError("Canonical worker wheel has an invalid member count")
    names: set[str] = set()
    expanded = 0
    for member in members:
        name = member.filename.rstrip("/")
        if (
            re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_./+-]{0,239}", name) is None
            or name.casefold() in names
            or stat.S_ISLNK(member.external_attr >> 16)
            or any(part.endswith(".data") for part in name.split("/"))
            or ("/" not in name and name.endswith(".pth"))
        ):
            raise AgentDbError("Canonical worker wheel contains an unsafe member")
        try:
            require_relative_path(name)
        except ValueError as exc:
            raise AgentDbError(
                "Canonical worker wheel contains an unsafe path"
            ) from exc
        names.add(name.casefold())
        expanded += member.file_size
        if (
            not 0 <= member.file_size <= MAX_MEMBER_BYTES
            or expanded > MAX_EXPANDED_BYTES
        ):
            raise AgentDbError("Canonical worker wheel exceeds expanded size limits")
    return tuple(member for member in members if not member.is_dir())
