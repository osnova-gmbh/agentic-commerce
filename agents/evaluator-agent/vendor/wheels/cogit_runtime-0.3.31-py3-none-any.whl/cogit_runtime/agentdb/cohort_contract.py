"""Bounded deployment and immutable executable contracts for canonical workers."""

from __future__ import annotations

import json
from typing import Annotated, Any, Literal, Self
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from cogit_runtime.agentdb.errors import AgentDbError

Digest = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]
RelativePath = Annotated[
    str,
    Field(
        strict=True,
        min_length=1,
        max_length=200,
        pattern=r"^[A-Za-z0-9][A-Za-z0-9._/-]*$",
    ),
]
DistributionName = Annotated[
    str,
    Field(
        strict=True, min_length=1, max_length=100, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$"
    ),
]
Version = Annotated[
    str,
    Field(strict=True, min_length=1, max_length=80, pattern=r"^[0-9][A-Za-z0-9.+!-]*$"),
]
FRAMEWORK_DISTRIBUTIONS = frozenset(
    {"cogit-runtime", "cogit-agent-sdk", "agentdb-client"}
)


class CohortModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ImmutableRoute(CohortModel):
    """The published identities the loaded artifact must match exactly."""

    installation_id: UUID = Field(alias="installationId")
    definition_id: UUID = Field(alias="definitionId")
    version_id: UUID = Field(alias="versionId")
    deployment_id: UUID = Field(alias="deploymentId")
    pool_id: UUID = Field(alias="poolId")
    agent_principal_id: UUID = Field(alias="agentPrincipalId")
    executable_sha256: Digest = Field(alias="executableSha256")
    manifest_sha256: Digest = Field(alias="manifestSha256")


class CohortReceipt(CohortModel):
    """Deployment binding; paths are relative to this receipt's directory."""

    contract_version: Literal["cogit.worker-cohort.v1"] = Field(alias="contractVersion")
    tenant_id: UUID = Field(alias="tenantId")
    route: ImmutableRoute
    manifest: RelativePath
    executable: RelativePath

    @field_validator("manifest", "executable")
    @classmethod
    def _bounded_relative_path(cls, value: str) -> str:
        return require_relative_path(value)


class WheelArtifact(CohortModel):
    distribution: DistributionName
    version: Version
    path: RelativePath
    sha256: Digest

    @field_validator("path")
    @classmethod
    def _wheel_path(cls, value: str) -> str:
        require_relative_path(value)
        if not value.endswith(".whl"):
            raise ValueError("Executable closure requires wheel artifacts")
        return value


class WorkerExecutable(CohortModel):
    """These exact descriptor bytes are the published executable commitment."""

    contract_version: Literal["cogit.worker-executable.v1"] = Field(
        alias="contractVersion"
    )
    agent_distribution: DistributionName = Field(alias="agentDistribution")
    entrypoint: Annotated[
        str,
        Field(
            strict=True,
            max_length=200,
            pattern=r"^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*:[A-Za-z_][A-Za-z0-9_]*$",
        ),
    ]
    wheels: Annotated[tuple[WheelArtifact, ...], Field(min_length=4, max_length=64)]

    @model_validator(mode="after")
    def _exact_closure(self) -> Self:
        names = {wheel.distribution for wheel in self.wheels}
        if (
            self.agent_distribution in FRAMEWORK_DISTRIBUTIONS
            or not (FRAMEWORK_DISTRIBUTIONS | {self.agent_distribution}).issubset(names)
            or len(names) != len(self.wheels)
            or len({wheel.path for wheel in self.wheels}) != len(self.wheels)
        ):
            raise ValueError(
                "Executable needs unique selected wheels with agent and framework"
            )
        return self


def require_relative_path(value: str) -> str:
    parts = value.split("/")
    if len(parts) > 8 or any(part in {"", ".", ".."} for part in parts):
        raise ValueError("Artifact path must be bounded and relative")
    return value


def parse_cohort_json(body: bytes) -> dict[str, Any]:
    """Reject duplicate keys and ambiguous JSON before model validation."""

    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate executable contract key")
            result[key] = value
        return result

    def no_constant(_value: str) -> None:
        raise ValueError("Non-finite contract value")

    try:
        result = json.loads(body, object_pairs_hook=unique, parse_constant=no_constant)
        if not isinstance(result, dict):
            raise ValueError("Executable contract must be an object")
        return result
    except (ValueError, RecursionError, UnicodeError) as exc:
        raise AgentDbError("Invalid canonical worker artifact contract") from exc
