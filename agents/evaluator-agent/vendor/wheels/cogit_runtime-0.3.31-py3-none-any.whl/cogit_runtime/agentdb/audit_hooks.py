"""Required tool observations outside optional streaming telemetry."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import Context, ToolCall, ToolResult

from cogit_runtime.agentdb.runtime_audit import (
    RequiredAuditError,
    RuntimeAuditEvent,
    audit_key,
)


class RequiredAuditHooks:
    """Persist tool intent before dispatch and outcome before loop continuation."""

    def __init__(
        self,
        *,
        execution_id: str,
        record: Callable[[RuntimeAuditEvent], None],
        identity_for: Callable[[ToolCall, Context], str],
    ) -> None:
        self._execution_id = execution_id
        self._record = record
        self._identity_for = identity_for

    def before_tool_call(self, tool_call: ToolCall, context: Context) -> bool:
        self._require_context(context)
        self._persist(
            RuntimeAuditEvent.create(
                event_key=self._key(tool_call, context, "requested"),
                kind="tool",
                phase="requested",
                details={
                    "tool": tool_call.tool_name,
                    "requestSha256": _digest(
                        {"tool": tool_call.tool_name, "arguments": tool_call.arguments}
                    ),
                },
            )
        )
        return True

    def after_tool_call(
        self, tool_call: ToolCall, result: ToolResult, context: Context
    ) -> ToolResult:
        self._require_context(context)
        if (
            result.tool_call_id != tool_call.id
            or result.tool_name != tool_call.tool_name
        ):
            raise RequiredAuditError("Tool audit result identity does not match")
        phase = "failed" if result.is_error else "succeeded"
        self._persist(
            RuntimeAuditEvent.create(
                event_key=self._key(tool_call, context, phase),
                kind="tool",
                phase=phase,
                details={
                    "tool": tool_call.tool_name,
                    "resultSha256": _result_digest(result),
                },
            )
        )
        return result

    def _persist(self, event: RuntimeAuditEvent) -> None:
        try:
            self._record(event)
        except CoordinationFailure:
            raise
        except Exception:
            raise RequiredAuditError("Required tool audit is unconfirmed") from None

    def _key(self, call: ToolCall, context: Context, phase: str) -> str:
        try:
            identity = self._identity_for(call, context)
        except CoordinationFailure:
            raise
        except Exception:
            raise RequiredAuditError(
                "Durable tool audit identity is unavailable"
            ) from None
        return audit_key("tool", identity, phase)

    def _require_context(self, context: Context) -> None:
        if context.execution_id != self._execution_id:
            raise RequiredAuditError("Runtime audit context is outside its execution")


def _digest(value: object) -> str:
    try:
        encoded = json.dumps(
            value, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
    except (ValueError, TypeError, RecursionError):
        raise RequiredAuditError("Runtime audit commitment cannot be encoded") from None
    return hashlib.sha256(encoded).hexdigest()


def _result_digest(result: ToolResult) -> str:
    try:
        return _digest(result.model_dump(mode="json", exclude={"tool_call_id"}))
    except CoordinationFailure:
        raise
    except Exception:
        raise RequiredAuditError("Tool audit result cannot be encoded") from None
