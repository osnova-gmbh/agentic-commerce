"""Local worker readiness based on recent authenticated AgentDb contact."""

from __future__ import annotations

import json
import math
import os
import tempfile
import time
from pathlib import Path

from cogit_runtime.agentdb.errors import AgentDbError


def _process_alive(pid: int) -> bool:
    if os.name == "nt":
        # os.kill(pid, 0) terminates processes on Windows; query a handle instead.
        import ctypes
        from ctypes import wintypes

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(wintypes.DWORD),
        ]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return False
        try:
            status = wintypes.DWORD()
            return (
                bool(kernel.GetExitCodeProcess(handle, ctypes.byref(status)))
                and status.value == 259
            )
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def record_worker_contact() -> None:
    """Record successful claim/heartbeat contact without any credential data."""
    configured = os.environ.get("COGIT_WORKER_HEALTH_PATH")
    if not configured:
        return
    path = Path(configured)
    if not path.is_absolute():
        raise AgentDbError("COGIT_WORKER_HEALTH_PATH must be absolute")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as stream:
            temporary = Path(stream.name)
            json.dump(
                {"version": 1, "pid": os.getpid(), "contact_at": time.time()}, stream
            )
        temporary.replace(path)
    except OSError:
        raise AgentDbError("Could not record worker readiness") from None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def worker_is_ready(path: Path, *, max_age: float = 90.0) -> bool:
    """Require a live worker and a bounded, recent contact record."""
    try:
        if not math.isfinite(max_age) or not 0 < max_age <= 3600:
            return False
        if path.stat().st_size > 1024:
            return False
        record = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(record, dict) or record.get("version") != 1:
            return False
        pid = record.get("pid")
        contact = record.get("contact_at")
        if (
            type(pid) is not int
            or pid <= 0
            or isinstance(contact, bool)
            or not isinstance(contact, (int, float))
        ):
            return False
        age = time.time() - float(contact)
        if not math.isfinite(age) or not 0 <= age <= max_age:
            return False
        if not _process_alive(pid):
            return False
    except (OSError, ValueError, TypeError):
        return False
    return True


def main() -> int:
    configured = os.environ.get("COGIT_WORKER_HEALTH_PATH")
    if not configured:
        return 1
    try:
        max_age = float(os.environ.get("COGIT_WORKER_HEALTH_MAX_AGE", "90"))
    except ValueError:
        return 1
    return 0 if worker_is_ready(Path(configured), max_age=max_age) else 1


if __name__ == "__main__":
    raise SystemExit(main())
