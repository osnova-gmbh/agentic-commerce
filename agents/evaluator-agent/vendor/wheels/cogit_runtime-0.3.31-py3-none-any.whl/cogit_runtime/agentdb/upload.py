"""Upload artifact bytes to the lease URL AgentDb returned."""

from __future__ import annotations

import httpx

from cogit_runtime.agentdb.errors import AgentDbError


def put_artifact_bytes(upload_url: str | None, body: bytes) -> None:
    """PUT bytes to the lease URL, or fail closed when AgentDb omitted it."""

    if not upload_url:
        raise AgentDbError(
            "AgentDb omitted the artifact upload URL; refusing to finalize"
        )
    try:
        response = httpx.put(upload_url, content=body, timeout=30.0)
        response.raise_for_status()
    except httpx.TimeoutException:
        raise AgentDbError("Artifact upload timed out") from None
    except httpx.HTTPError:
        raise AgentDbError("Artifact upload failed") from None
