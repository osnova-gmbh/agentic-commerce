"""Preflight validation of canonical admission; dispatch still uses the live claim."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any
from uuid import UUID

from agentdb_client import ClaimModelSpend
from cogit_agent_sdk.types import Context, RunBudget

from cogit_runtime.agentdb.current_model_spend import money, money_cap_from_float
from cogit_runtime.errors import RuntimeConfigurationError

_FIELDS = frozenset(
    {
        "runId",
        "installationId",
        "settingsVersionId",
        "settingsSha256",
        "priceVersion",
        "currency",
        "cap",
        "spent",
        "outstanding",
        "available",
    }
)


def parse_spend(value: Any) -> ClaimModelSpend:
    """Validate all admission fields, including zero-budget deterministic work."""
    try:
        if isinstance(value, ClaimModelSpend):
            value = value.to_dict()
        if not isinstance(value, Mapping) or set(value) != _FIELDS:
            raise ValueError("Unsupported spend commitment")
        result = ClaimModelSpend.from_dict(dict(value))
        if result is None:
            raise ValueError("Missing spend commitment")
        cap = money(result.cap)
        if (
            sum(
                money(getattr(result, key))
                for key in ("spent", "outstanding", "available")
            )
            != cap
        ):
            raise ValueError("Inconsistent spend balance")
        policy = (
            result.settings_version_id,
            result.settings_sha256,
            result.price_version,
            result.currency,
        )
        if any(part is None for part in policy) and (
            cap != 0 or any(part is not None for part in policy)
        ):
            raise ValueError("Incomplete spend policy")
        return result
    except Exception:
        raise RuntimeConfigurationError(
            "Invalid canonical model spend admission"
        ) from None


def context_spend(context: Context) -> ClaimModelSpend:
    metadata = context.metadata or {}
    spend = parse_spend(metadata.get("model_spend"))
    try:
        matches = (
            UUID(str(metadata.get("installation_id"))) == spend.installation_id
            and UUID(str(metadata.get("run_id"))) == spend.run_id
        )
    except (ValueError, TypeError):
        matches = False
    if not matches:
        raise RuntimeConfigurationError("Model admission differs from current work")
    return spend


def require_admitted_budget(context: Context, budget: RunBudget | None) -> None:
    spend = context_spend(context)
    if money(spend.cap) <= 0:
        raise RuntimeConfigurationError("Model dispatch needs a positive admitted cap")
    if budget is not None and budget.max_cost is not None:
        if money(spend.cap) > money_cap_from_float(budget.max_cost):
            raise RuntimeConfigurationError(
                "Requested monetary cap must be applied during canonical admission"
            )
