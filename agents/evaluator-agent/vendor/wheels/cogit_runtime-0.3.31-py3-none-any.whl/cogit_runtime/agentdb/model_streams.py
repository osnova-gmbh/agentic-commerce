"""Explicit stream ownership across the portable SDK dispatch wrapper."""

from __future__ import annotations

from collections.abc import Iterator

from cogit_agent_sdk.providers import IdentifiedModelClient
from cogit_agent_sdk.types import (
    Cancellation,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
)


def close_stream(stream: object) -> None:
    close = getattr(stream, "close", None)
    if callable(close):
        close()


class OwnedModelStream:
    """Retain the real provider iterator so its close failures cannot disappear."""

    def __init__(self, client: IdentifiedModelClient) -> None:
        self.client = client
        self.iterator: Iterator[ModelStreamEvent] | None = None

    def dispatch_identity(self, request: ModelRequest) -> tuple[str, str]:
        return self.client.dispatch_identity(request)

    def generate(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> ModelResponse:
        return self.client.generate(request, cancellation)

    def stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterator[ModelStreamEvent]:
        self.iterator = iter(self.client.stream(request, cancellation))
        return self.iterator

    def close(self) -> None:
        close_stream(self.iterator)
