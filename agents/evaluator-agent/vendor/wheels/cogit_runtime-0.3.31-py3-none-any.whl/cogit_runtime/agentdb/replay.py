"""Resolve an uncertain HTTP mutation by replaying its exact idempotency key."""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.errors import AgentDbTimeoutError, classify

_T = TypeVar("_T")


def replay_once(call: Callable[[], _T]) -> _T:
    """Retry only an ambiguous response; callers must keep the same request key."""

    try:
        return call()
    except CoordinationFailure:
        raise
    except Exception as exc:
        mapped = classify(exc)
        if not isinstance(mapped, AgentDbTimeoutError) and not mapped.retryable:
            raise
    return call()
