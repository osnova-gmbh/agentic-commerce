"""AgentDb worker configuration.

Production worker startup must be able to prove it has a reachable AgentDb
URL, a compatible API version, a pool identity, and a scoped worker
credential before it claims any work. This module owns that configuration
surface and its validation, but not AgentDb authorization or retry policy.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator

from cogit_runtime.agentdb.errors import AgentDbConfigError, AgentDbVersionMismatch

# The AgentDb publication-profile contract versions this runtime can talk to.
SUPPORTED_API_VERSIONS = frozenset({"0.1.0", "0.1"})


class AgentDbConfig(BaseModel):
    """Immutable AgentDb worker configuration parsed once at boot."""

    model_config = ConfigDict(frozen=True)

    url: str = Field(min_length=1)
    pool_id: UUID
    installation_id: UUID | None = None
    worker_token: str = Field(min_length=1)
    api_version: str = Field(min_length=1)
    cohort_receipt: str | None = Field(default=None, min_length=1, max_length=4096)
    loop_integrity_key: SecretStr | None = Field(default=None, repr=False)
    connect_timeout_seconds: float = Field(default=10.0, gt=0)
    read_timeout_seconds: float = Field(default=30.0, gt=0)
    approval_decider_id: UUID | None = None
    approval_timeout_seconds: int = Field(default=86400, strict=True, ge=1, le=2592000)

    @field_validator("loop_integrity_key")
    @classmethod
    def _validate_loop_key(cls, value: SecretStr | None) -> SecretStr | None:
        import re

        if value is not None and not re.fullmatch(
            r"[0-9a-fA-F]{64}", value.get_secret_value()
        ):
            raise ValueError(
                "Loop integrity key must be exactly 32 bytes of hexadecimal"
            )
        return value

    @field_validator("url")
    @classmethod
    def _validate_url(cls, value: str) -> str:
        normalized = value.strip().rstrip("/")
        if not normalized.startswith(("http://", "https://")):
            raise ValueError("AgentDb URL must start with http:// or https://")
        return normalized

    @field_validator("api_version")
    @classmethod
    def _normalize_api_version(cls, value: str) -> str:
        normalized = value.strip()
        if normalized not in SUPPORTED_API_VERSIONS:
            raise AgentDbVersionMismatch(
                f"Unsupported AgentDb API version: {normalized!r}; "
                f"supported: {sorted(SUPPORTED_API_VERSIONS)}"
            )
        # Normalize the compact "0.1" form to the full "0.1.0" form.
        if normalized == "0.1":
            return "0.1.0"
        return normalized

    @property
    def is_configured(self) -> bool:
        """True when all required values are present and non-empty."""
        return bool(self.url and self.pool_id and self.worker_token)

    def redacted(self) -> str:
        """Human-readable summary that never exposes the worker token."""
        return (
            f"AgentDbConfig(url={self.url!r}, pool_id={self.pool_id}, "
            f"api_version={self.api_version!r}, worker_token='<redacted>')"
        )

    __repr__ = redacted  # type: ignore[assignment]
    __str__ = redacted  # type: ignore[assignment]

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> AgentDbConfig | None:
        """Parse AgentDb config from environment variables, or ``None``.

        Returns ``None`` when no AgentDb variable is present at all, so the
        caller can distinguish "not configured" from "configured but invalid"
        (the latter raises :class:`AgentDbConfigError`).
        """
        source = os.environ if env is None else env
        raw = {
            key: (source.get(key) or "").strip()
            for key in (
                "COGIT_AGENTDB_URL",
                "COGIT_AGENTDB_POOL_ID",
                "COGIT_AGENTDB_INSTALLATION_ID",
                "COGIT_AGENTDB_WORKER_TOKEN",
                "COGIT_AGENTDB_API_VERSION",
                "COGIT_AGENTDB_COHORT_RECEIPT",
                "COGIT_AGENTDB_LOOP_INTEGRITY_KEY",
                "COGIT_AGENTDB_CONNECT_TIMEOUT_SECONDS",
                "COGIT_AGENTDB_READ_TIMEOUT_SECONDS",
                "COGIT_AGENTDB_APPROVAL_DECIDER_ID",
                "COGIT_AGENTDB_APPROVAL_TIMEOUT_SECONDS",
            )
        }
        if not any(raw.values()):
            return None

        try:
            return cls(
                url=raw["COGIT_AGENTDB_URL"],
                pool_id=UUID(raw["COGIT_AGENTDB_POOL_ID"]),
                installation_id=(
                    UUID(raw["COGIT_AGENTDB_INSTALLATION_ID"])
                    if raw["COGIT_AGENTDB_INSTALLATION_ID"]
                    else None
                ),
                worker_token=raw["COGIT_AGENTDB_WORKER_TOKEN"],
                api_version=raw["COGIT_AGENTDB_API_VERSION"],
                cohort_receipt=raw["COGIT_AGENTDB_COHORT_RECEIPT"] or None,
                loop_integrity_key=SecretStr(raw["COGIT_AGENTDB_LOOP_INTEGRITY_KEY"])
                if raw["COGIT_AGENTDB_LOOP_INTEGRITY_KEY"]
                else None,
                connect_timeout_seconds=(
                    float(raw["COGIT_AGENTDB_CONNECT_TIMEOUT_SECONDS"])
                    if raw["COGIT_AGENTDB_CONNECT_TIMEOUT_SECONDS"]
                    else 10.0
                ),
                read_timeout_seconds=(
                    float(raw["COGIT_AGENTDB_READ_TIMEOUT_SECONDS"])
                    if raw["COGIT_AGENTDB_READ_TIMEOUT_SECONDS"]
                    else 30.0
                ),
                approval_decider_id=(
                    UUID(raw["COGIT_AGENTDB_APPROVAL_DECIDER_ID"])
                    if raw["COGIT_AGENTDB_APPROVAL_DECIDER_ID"]
                    else None
                ),
                approval_timeout_seconds=(
                    int(raw["COGIT_AGENTDB_APPROVAL_TIMEOUT_SECONDS"])
                    if raw["COGIT_AGENTDB_APPROVAL_TIMEOUT_SECONDS"]
                    else 86400
                ),
            )
        except AgentDbConfigError:
            raise
        except (ValueError, AssertionError) as exc:
            raise AgentDbConfigError("Invalid AgentDb configuration") from exc


def require_config(env: Mapping[str, str] | None = None) -> AgentDbConfig:
    """Return validated AgentDb config or raise when missing/invalid."""
    config = AgentDbConfig.from_env(env)
    if config is None:
        raise AgentDbConfigError(
            "AgentDb is not configured. Set COGIT_AGENTDB_URL, "
            "COGIT_AGENTDB_API_VERSION, COGIT_AGENTDB_POOL_ID, and "
            "COGIT_AGENTDB_WORKER_TOKEN."
        )
    return config
