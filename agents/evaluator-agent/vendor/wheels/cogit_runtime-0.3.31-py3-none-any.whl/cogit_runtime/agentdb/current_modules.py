"""Registered module transport under a server admitted attempt and exact pins."""

from __future__ import annotations

import hashlib
import json
from typing import TYPE_CHECKING, Any, Literal
from uuid import UUID

from cogit_agent_sdk.types import DatabasePackageRequirement

from cogit_runtime.agentdb.continuation_index import WIRE_FORMAT
from cogit_runtime.agentdb.database_http import DatabaseHttp, command_key
from cogit_runtime.agentdb.errors import AgentDbAuthorityError, AgentDbError
from cogit_runtime.agentdb.module_contracts import (
    bounded_input,
    parse_dependencies,
    resolve_export,
    validate_request_key,
)
from cogit_runtime.coordination import finish_cleanup

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


class CurrentModules:
    """Keep immutable accepted pins separate from installation readiness."""

    def __init__(
        self,
        client: CurrentClient,
        requirements: tuple[DatabasePackageRequirement, ...],
    ) -> None:
        self.client = client
        self.requirements = requirements
        self._dependencies: tuple[DatabasePackageRequirement, ...] | None = None
        self._authority: tuple[UUID, int, UUID | None] | None = None
        self.journal_indexes_supported = False

    def clear(self) -> None:
        self._dependencies = None
        self._authority = None

    def readiness(self) -> None:
        self.journal_indexes_supported = False
        cohort = self.client.require_cohort()
        installation = self.client.config.installation_id
        if installation is None:
            raise AgentDbError(
                "Canonical worker readiness requires COGIT_AGENTDB_INSTALLATION_ID"
            )
        cohort.require_config(self.client.config)
        cohort.require_artifacts()
        http = self._http()
        try:
            result = http.request(
                "/v1/worker/module-readiness",
                query={"installationId": str(installation)},
            )
        finally:
            finish_cleanup(http.close)
        cohort.require_readiness(result)
        parse_dependencies(result, self.requirements)
        formats = result.get("runtimeContinuationFormats", [])
        if (
            not isinstance(formats, list)
            or len(formats) > 16
            or any(not isinstance(value, str) or len(value) > 128 for value in formats)
            or len(set(formats)) != len(formats)
        ):
            raise AgentDbError("Invalid server continuation capability declaration")
        self.journal_indexes_supported = WIRE_FORMAT in formats

    def capture(self, token: str) -> None:
        self.clear()
        claim = self.client.active(token)
        self.client.require_cohort().require_claim(claim)
        if not self.requirements:
            self._dependencies = ()
            return
        if claim.run_id is None:
            raise AgentDbAuthorityError(
                "AgentDb module effects require an admitted run parent"
            )
        if claim.route.installation_id != self.client.config.installation_id:
            raise AgentDbAuthorityError(
                "Claim installation differs from worker readiness"
            )
        http = self._http()
        try:
            result = http.request(
                f"/v1/worker/attempts/{claim.attempt_id}/module-dependencies",
                attempt_token=token,
            )
        finally:
            finish_cleanup(http.close)
        identities = {
            "agentVersionId": claim.route.version_id,
            "runId": claim.run_id,
            "installationId": claim.route.installation_id,
        }
        if any(
            result.get(key) != str(identity) for key, identity in identities.items()
        ):
            raise AgentDbError(
                "Module dependency snapshot identity differs from admitted work"
            )
        self._dependencies = parse_dependencies(result, self.requirements)
        self._authority = (claim.attempt_id, claim.generation, claim.run_id)

    def query(
        self,
        token: str,
        module_key: str,
        key: str,
        payload: dict[str, Any],
        contract_id: str,
    ) -> dict[str, Any]:
        material = bounded_input(payload)
        return self._invoke(
            token,
            module_key,
            "query",
            key,
            material,
            contract_id,
            command_key("module-query", material),
        )

    def command(
        self,
        token: str,
        module_key: str,
        key: str,
        payload: dict[str, Any],
        contract_id: str,
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._invoke(
            token,
            module_key,
            "command",
            key,
            bounded_input(payload),
            contract_id,
            validate_request_key(idempotency_key),
        )

    def _invoke(
        self,
        token: str,
        module_key: str,
        kind: Literal["query", "command"],
        key: str,
        payload: dict[str, Any],
        contract_id: str,
        request_id: str,
    ) -> dict[str, Any]:
        claim = self.client.active(token)
        if self._authority != (claim.attempt_id, claim.generation, claim.run_id):
            raise AgentDbAuthorityError(
                "Module dependency pins belong to another attempt"
            )
        if self.client.execution_id is None:
            raise AgentDbAuthorityError("Module operation requires a current execution")
        package, export = resolve_export(
            self._dependencies, module_key, kind, key, contract_id
        )
        worker_request_id = hashlib.sha256(
            json.dumps([str(claim.run_id), module_key, kind, key, request_id]).encode()
        ).hexdigest()
        http_key = (
            "cogit:module:"
            + hashlib.sha256(
                f"{claim.attempt_id}:{worker_request_id}".encode()
            ).hexdigest()
        )
        body = {
            "generation": claim.generation,
            "executionId": self.client.execution_id,
            "moduleVersion": package.version,
            "artifactSha256": package.artifact_sha256,
            "exportVersion": export.export_version,
            "contractId": export.contract_id,
            "input": payload,
            "workerRequestId": worker_request_id,
        }
        route_kind = "queries" if kind == "query" else "commands"
        path = (
            f"/v1/worker/attempts/{claim.attempt_id}/modules/{module_key}"
            f"/{route_kind}/{key}"
        )
        http = self._http()
        try:
            return http.request(
                path,
                body,
                key=http_key,
                attempt_token=token,
                idempotent=kind == "query",
            )
        finally:
            finish_cleanup(http.close)

    def _http(self) -> DatabaseHttp:
        return DatabaseHttp(self.client.config.url, self.client.config.worker_token)
