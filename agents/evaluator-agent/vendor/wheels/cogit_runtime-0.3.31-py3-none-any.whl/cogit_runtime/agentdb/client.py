"""Runtime's internal worker ports, mapped to AgentDb's generated HTTP client.

The grouped ports let coordinator tests use fakes. CurrentClient translates
these internal values to the actual AgentDb wire contract; the port names
are not server endpoints.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, Protocol

from cogit_agent_sdk.types import DatabasePackageRequirement

from cogit_runtime.agentdb.config import AgentDbConfig

if TYPE_CHECKING:
    from cogit_runtime.agentdb.cohort import VerifiedCohort


class WorkApi(Protocol):
    """Attempt lifecycle operations used by the coordinator."""

    def claim_pool_work(self, *args: Any, **kwargs: Any) -> Any: ...

    def heartbeat_attempt(self, *args: Any, **kwargs: Any) -> Any: ...

    def park_attempt(self, *args: Any, **kwargs: Any) -> Any: ...

    def settle_attempt(self, *args: Any, **kwargs: Any) -> Any: ...

    def settle_processing_attempt(self, *args: Any, **kwargs: Any) -> Any: ...

    def fail_attempt(self, *args: Any, **kwargs: Any) -> Any: ...

    def cancel_work(self, *args: Any, **kwargs: Any) -> Any: ...

    def get_work_attempt(self, *args: Any, **kwargs: Any) -> Any: ...


class ArtifactsApi(Protocol):
    def read_artifact(self, *args: Any, **kwargs: Any) -> bytes: ...

    """Artifact operations used by the SDK service adapter."""

    def upload_bytes(self, *args: Any, **kwargs: Any) -> Any: ...

    def declare_artifact(self, *args: Any, **kwargs: Any) -> Any: ...

    def allocate_artifact_upload(self, *args: Any, **kwargs: Any) -> Any: ...

    def finalize_artifact_upload(self, *args: Any, **kwargs: Any) -> Any: ...


class ExecutionsApi(Protocol):
    """Execution and evidence operations used by the router."""

    def start_execution(self, *args: Any, **kwargs: Any) -> Any: ...

    def record_execution_step(self, *args: Any, **kwargs: Any) -> Any: ...

    def create_model_call_intent(self, *args: Any, **kwargs: Any) -> Any: ...


class UsageApi(Protocol):
    """Model budget operations, explicitly rejected until supported."""

    def reserve_model_call_budget(self, *args: Any, **kwargs: Any) -> Any: ...

    def settle_model_call_budget(self, *args: Any, **kwargs: Any) -> Any: ...


class ActionsApi(Protocol):
    def lookup_action(self, *args: Any, **kwargs: Any) -> Any: ...

    def prepare_action(self, *args: Any, **kwargs: Any) -> Any: ...

    def get_action(self, *args: Any, **kwargs: Any) -> Any: ...


class AgentDbClient(Protocol):
    """Internal client surface required by the coordinator."""

    work: WorkApi
    artifacts: ArtifactsApi
    executions: ExecutionsApi
    usage: UsageApi
    actions: ActionsApi

    def close(self) -> None:
        """Release transient attempt state and client resources."""


def build_client(
    config: AgentDbConfig,
    database_packages: Sequence[DatabasePackageRequirement] = (),
    *,
    cohort: VerifiedCohort | None = None,
) -> Any:
    """Construct ports mapped to the actual AgentDb-generated HTTP client."""
    from cogit_runtime.agentdb.current_client import CurrentClient

    return CurrentClient(config, database_packages, cohort=cohort)
