"""Translate execution-scoped action intents to canonical AgentDb contracts."""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any

from agentdb_client import (
    ActionResource,
    LookupWorkerActionRequest,
    WorkerPrepareActionRequest,
)
from agentdb_client.exceptions import ApiException
from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import ActionIntent, ActionKey, ActionRef, ArtifactRef

from cogit_runtime.agentdb.current_artifacts import MAX_ARTIFACT_BYTES
from cogit_runtime.agentdb.errors import (
    AgentDbAttemptContextError,
    AgentDbAuthorityError,
    AgentDbError,
)

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


def commitment(ref: ArtifactRef) -> dict[str, Any]:
    artifact_id = str(uuid.UUID(ref.id))
    digest = str((ref.metadata or {}).get("hash", "")).removeprefix("sha256:")
    if (
        ref.size is None
        or not 0 <= ref.size <= MAX_ARTIFACT_BYTES
        or not ref.mime_type
        or len(digest) != 64
        or any(c not in "0123456789abcdef" for c in digest)
    ):
        raise AgentDbError("Action artifacts require bounded finalized commitments")
    return {
        "artifactId": artifact_id,
        "sha256": digest,
        "byteLength": ref.size,
        "mediaType": ref.mime_type,
    }


class CurrentActions:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client
        self.prepared: set[uuid.UUID] = set()

    def clear(self) -> None:
        self.prepared.clear()

    def prepare_action(self, token: str, key: str, intent: ActionIntent) -> ActionRef:
        claim = self.client.active(token)
        if self.client.execution_id is None:
            raise AgentDbAuthorityError("Action preparation needs a current execution")
        manifest = commitment(intent.input_artifact)
        if (
            manifest["mediaType"] != "application/json"
            or manifest["byteLength"] > 65536
        ):
            raise AgentDbError("Action input must be a bounded JSON manifest")
        attachments = [commitment(ref) for ref in intent.input_attachments]
        if len({item["artifactId"] for item in attachments}) != len(attachments):
            raise AgentDbError("Action attachment references must be unique")
        metadata = intent.input_artifact.metadata or {}
        governed = metadata.get("governanceSnapshotId")
        if governed is not None:
            raw = self.client.governance.prepare_action(
                token,
                {
                    "generation": claim.generation,
                    "provider": intent.provider,
                    "credentialAccount": intent.credential_account,
                    "operation": intent.operation,
                    "idempotencyKey": intent.idempotency_key,
                    "inputSha256": manifest["sha256"],
                    "inputArtifactId": manifest["artifactId"],
                    "inputAttachments": attachments,
                    **{
                        name: metadata[name]
                        for name in (
                            "governanceSnapshotId",
                            "governanceFacts",
                            "evidenceArtifactId",
                            "evidenceSha256",
                        )
                    },
                },
                key,
            )
            result = ActionResource.model_validate(raw)
        else:
            result = self.client.attempt_api.worker_prepare_action(
                uuid.UUID(self.client.execution_id),
                token,
                WorkerPrepareActionRequest.model_validate(
                    {
                        "generation": claim.generation,
                        "provider": intent.provider,
                        "credentialAccount": intent.credential_account,
                        "operation": intent.operation,
                        "idempotencyKey": intent.idempotency_key,
                        "inputSha256": manifest["sha256"],
                        "inputArtifactId": manifest["artifactId"],
                        "inputAttachments": attachments,
                    }
                ),
                _headers=self.client.headers(key),
                _request_timeout=self.client.timeout,
            )
        if (
            result.provider != intent.provider
            or result.operation != intent.operation
            or result.credential_account != intent.credential_account
            or result.input_sha256 != manifest["sha256"]
            or result.idempotency_key != intent.idempotency_key
        ):
            raise AgentDbError(
                "Action receipt does not match its commitment", retryable=True
            )
        try:
            receipt = action_ref(result)
        except CoordinationFailure:
            raise
        except (AgentDbError, ValueError, TypeError):
            raise AgentDbError(
                "Invalid action receipt commitments", retryable=True
            ) from None
        if (
            receipt.input_artifact is None
            or commitment(receipt.input_artifact) != manifest
            or len(receipt.input_attachments) != len(attachments)
            or {
                tuple(sorted(commitment(ref).items()))
                for ref in receipt.input_attachments
            }
            != {tuple(sorted(item.items())) for item in attachments}
        ):
            raise AgentDbError(
                "Action receipt artifact commitments do not match", retryable=True
            )
        self.prepared.add(result.action_id)
        return receipt

    def lookup_action(self, token: str, key: ActionKey) -> ActionRef | None:
        claim = self.client.active(token)
        try:
            result = self.client.attempt_api.lookup_worker_action(
                claim.attempt_id,
                token,
                LookupWorkerActionRequest(
                    provider=key.provider,
                    credentialAccount=key.credential_account,
                    operation=key.operation,
                    idempotencyKey=key.idempotency_key,
                ),
                _headers=self.client.headers(),
                _request_timeout=self.client.timeout,
            )
        except ApiException as exc:
            if exc.status == 404:
                return None
            raise
        if (
            result.provider != key.provider
            or result.credential_account != key.credential_account
            or result.operation != key.operation
            or result.idempotency_key != key.idempotency_key
        ):
            raise AgentDbError("Action lookup identity mismatch")
        self.prepared.add(result.action_id)
        return action_ref(result)

    def get_action(self, token: str, action_id: str) -> ActionRef:
        claim = self.client.active(token)
        identity = uuid.UUID(action_id)
        if identity not in self.prepared:
            raise AgentDbAttemptContextError(
                "Prepare or reuse this action in the current execution first"
            )
        result = self.client.attempt_api.get_worker_action(
            claim.attempt_id,
            identity,
            token,
            _headers=self.client.headers(),
            _request_timeout=self.client.timeout,
        )
        if result.action_id != identity:
            raise AgentDbError("Action query identity mismatch")
        return action_ref(result)


def artifact_ref(item: Any) -> ArtifactRef:
    ref = ArtifactRef(
        id=str(item.artifact_id),
        mime_type=item.media_type,
        size=item.byte_length,
        metadata={"hash": item.sha256},
    )
    commitment(ref)
    return ref


def action_ref(result: Any) -> ActionRef:
    source = getattr(result, "input_artifact", None)
    return ActionRef(
        id=str(result.action_id),
        state=result.lifecycle,
        version=result.version,
        evidence=tuple(
            artifact_ref(item)
            for item in (getattr(result, "evidence_artifacts", None) or [])
        ),
        input_artifact=artifact_ref(source) if source is not None else None,
        input_attachments=tuple(
            artifact_ref(item)
            for item in (getattr(result, "input_attachments", None) or [])
        ),
    )
