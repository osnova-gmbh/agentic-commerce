"""Fenced, bounded required audit writes with exact-request replay."""

from __future__ import annotations

import json
import uuid
from typing import TYPE_CHECKING

from agentdb_client import RecordRuntimeAuditRequest, RuntimeAuditReceipt
from agentdb_client.exceptions import ApiException
from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.errors import AgentDbAuthorityError, classify
from cogit_runtime.agentdb.replay import replay_once
from cogit_runtime.agentdb.runtime_audit import (
    RequiredAuditError,
    RuntimeAuditEvent,
    audit_key,
)
from cogit_runtime.coordination import finish_cleanup

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


class CurrentRuntimeAudit:
    """Required writes must be confirmed before protected effects or success."""

    def __init__(self, client: CurrentClient) -> None:
        self.client = client

    def lifecycle(
        self,
        execution_id: uuid.UUID,
        token: str,
        phase: str,
        operation: str,
        *,
        identity: str | None = None,
        details: dict[str, str | int] | None = None,
    ) -> None:
        event = RuntimeAuditEvent.create(
            event_key=audit_key(
                "lifecycle", f"{execution_id}:{operation}:{identity or ''}", phase
            ),
            kind="lifecycle",
            phase=phase,
            details={**(details or {}), "operation": operation},
        )
        self.record(
            execution_id,
            token,
            f"cogit:runtime-audit:{execution_id}:{event.event_key}",
            event,
        )

    def record(
        self,
        execution_id: uuid.UUID,
        token: str,
        key: str,
        event: RuntimeAuditEvent,
    ) -> None:
        claim = self.client.active(token)
        if self.client.execution_id != str(execution_id):
            raise AgentDbAuthorityError("Audit is outside the current execution")
        try:
            request = RecordRuntimeAuditRequest.from_dict(
                event.request(claim.generation)
            )
            if request is None:
                raise RequiredAuditError("Runtime audit request is invalid")
            headers = self.client.headers(key)
            receipt = replay_once(
                lambda: self._append(execution_id, token, request, headers)
            )
            if (
                receipt.execution_id != execution_id
                or receipt.event_key != event.event_key
                or receipt.kind != event.kind
                or receipt.phase != event.phase
                or type(receipt.replayed) is not bool
            ):
                raise RequiredAuditError("AgentDb audit receipt does not match")
        except CoordinationFailure:
            raise
        except Exception as exc:
            mapped = classify(exc)
            if isinstance(mapped, CoordinationFailure):
                raise mapped from None
            raise RequiredAuditError(
                "Required AgentDb audit write is unconfirmed"
            ) from None

    def _append(
        self,
        execution_id: uuid.UUID,
        token: str,
        request: RecordRuntimeAuditRequest,
        headers: dict[str, str],
    ) -> RuntimeAuditReceipt:
        response = self.client.attempt_api.record_runtime_audit_without_preload_content(
            execution_id,
            token,
            request,
            _headers=headers,
            _request_timeout=self.client.timeout,
        )
        try:
            body = response.read(8193)
            if len(body) > 8192:
                raise RequiredAuditError("AgentDb audit receipt exceeds its bound")
            if response.status != 201:
                raise ApiException(status=response.status, body=body.decode("utf-8"))
            receipt = RuntimeAuditReceipt.from_dict(json.loads(body))
            if receipt is None:
                raise RequiredAuditError("AgentDb audit receipt is invalid")
            return receipt
        finally:
            finish_cleanup(response.close, response.release_conn)
