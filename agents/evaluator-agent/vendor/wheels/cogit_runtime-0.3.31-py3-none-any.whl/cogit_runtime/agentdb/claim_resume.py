"""Verify canonical parent and continuation commitments before execution."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from typing import Any
from uuid import UUID

from agentdb_client import ClaimResource
from pydantic import ValidationError

from cogit_runtime.agentdb.continuation_index import (
    WIRE_FORMAT,
    ContinuationRoot,
    hydrate_index,
    index_checkpoint,
    root_checkpoint,
)
from cogit_runtime.agentdb.continuation_schema import (
    MAX_CONTINUATION_BYTES,
    ContinuationArtifact,
    ContinuationIdentity,
    RuntimeContinuation,
    checkpoint_payload,
)
from cogit_runtime.agentdb.errors import AgentDbAuthorityError


def claim_identity(claim: ClaimResource) -> ContinuationIdentity:
    parents = claim.parents.to_dict()
    if (
        not isinstance(parents, dict)
        or parents.get("parentShape") != claim.parent_shape
        or parents.get("runId") != claim.run_id
    ):
        raise AgentDbAuthorityError("Canonical claim parent identity mismatch")
    processing = claim.processing
    try:
        return ContinuationIdentity(
            tenant_id=claim.tenant_id,
            principal_id=claim.principal_id,
            installation_id=claim.route.installation_id,
            deployment_id=claim.route.deployment_id,
            pool_id=claim.route.pool_id,
            agent_version_id=claim.route.version_id,
            parent_shape=claim.parent_shape,  # type: ignore[arg-type]
            run_id=claim.run_id,
            case_id=parents.get("caseId"),
            task_id=parents.get("taskId"),
            input_sha256=claim.input.sha256,
            processing_id=processing.processing_id if processing else None,
            processing_configuration_sha256=(
                processing.configuration_sha256 if processing else None
            ),
        )
    except ValidationError:
        raise AgentDbAuthorityError("Invalid canonical continuation identity") from None


def load_resume(
    claim: ClaimResource,
    identity: ContinuationIdentity,
    fetch: Callable[[UUID], str],
    *,
    fetch_index: Callable[[ContinuationArtifact], bytes] | None = None,
) -> RuntimeContinuation | None:
    resume = claim.resume
    if resume is None:
        return None
    if (
        resume.checkpoint_format != "agentdb.checkpoint.v2"
        or resume.media_type != "application/json"
        or resume.artifact_id != resume.checkpoint_id
        or not 0 < resume.byte_length <= MAX_CONTINUATION_BYTES
    ):
        raise AgentDbAuthorityError("Unsupported Runtime checkpoint commitment")
    delivery = resume.delivery.to_dict()
    content = (
        delivery["inlineUtf8"]
        if isinstance(delivery, dict) and "inlineUtf8" in delivery
        else fetch(resume.artifact_id)
    )
    if not isinstance(content, str) or len(content) > MAX_CONTINUATION_BYTES:
        raise AgentDbAuthorityError("Runtime checkpoint exceeds its byte bound")
    body = content.encode("utf-8")
    if (
        len(body) != resume.byte_length
        or hashlib.sha256(body).hexdigest() != resume.sha256
    ):
        raise AgentDbAuthorityError("Runtime checkpoint commitment mismatch")
    try:
        payload: Any = json.loads(body, object_pairs_hook=_unique_object)
        if not isinstance(payload, dict):
            raise ValueError
        runtime = payload.get("runtime")
        if isinstance(runtime, dict) and runtime.get("format") == WIRE_FORMAT:
            root = ContinuationRoot.model_validate(runtime)
            # Validate canonical claim authority before any index read.
            if (
                fetch_index is None
                or payload != root_checkpoint(root)
                or root.execution_id != resume.prior_execution_id
                or root.identity != identity
            ):
                raise ValueError
            state = hydrate_index(root, fetch_index)
            if payload != index_checkpoint(state, root.index):
                raise ValueError
        else:
            state = RuntimeContinuation.model_validate(runtime)
            if payload != checkpoint_payload(state):
                raise ValueError
    except (ValueError, TypeError, RecursionError, UnicodeError):
        raise AgentDbAuthorityError("Incompatible Runtime checkpoint state") from None
    if state.execution_id != resume.prior_execution_id or state.identity != identity:
        raise AgentDbAuthorityError("Runtime checkpoint belongs to different work")
    return state


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate checkpoint key")
        value[key] = item
    return value
