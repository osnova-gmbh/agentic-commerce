"""Translate fenced AgentDb claims into SDK execution inputs."""

from __future__ import annotations

import uuid
from collections.abc import Mapping
from typing import Any, cast

from cogit_agent_sdk.types import Context, Principal, RunRequest

from cogit_runtime.agentdb.coordinator import ClaimedWork
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.readiness import reject_unreserved_claim_cap


def claimed_work_to_run_request(
    claimed: ClaimedWork,
    *,
    default_agent_id: str,
    execution_id: str,
) -> tuple[RunRequest, Context]:
    """Translate server-derived claim context without exposing its token."""

    reject_unreserved_claim_cap(claimed)
    payload = _claim_input_payload(claimed.input)
    instruction = _instruction(payload, claimed.work_item_id)
    try:
        uuid.UUID(execution_id)
    except ValueError as exc:
        raise RuntimeConfigurationError(
            "AgentDb execution id must be the canonical server UUID"
        ) from exc
    context = Context(
        tenant_id=str(claimed.derived.tenant_id),
        correlation_id=str(claimed.run_id or claimed.work_item_id),
        agent_id=default_agent_id,
        principal=Principal(kind="agent", id=str(claimed.derived.principal_id)),
        permissions=claimed.permissions,
        execution_id=execution_id,
        queue_item_id=str(claimed.work_item_id),
        case_id=(
            str(claimed.derived.case_id)
            if getattr(claimed.derived, "case_id", None)
            else None
        ),
        trigger="queue",
        deadline=claimed.deadline_at,
        metadata=_claim_context_metadata(claimed),
    )
    request = RunRequest(
        instruction=instruction,
        input=payload or None,
        context=context,
        mode="sync",
        metadata=execution_metadata(claimed),
    )
    return request, context


def execution_metadata(claimed: ClaimedWork) -> dict[str, Any]:
    """Return safe execution metadata without the attempt token."""

    return {
        "source": "agentdb",
        "work_item_id": str(claimed.work_item_id),
        **_claim_context_metadata(claimed),
    }


def _claim_input_payload(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return dict(cast(Mapping[str, Any], value))
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        payload = to_dict()
        if isinstance(payload, dict):
            return cast(dict[str, Any], payload)
    raise RuntimeConfigurationError("AgentDb claim input has an unsupported shape")


def _instruction(payload: Mapping[str, Any], work_item_id: uuid.UUID) -> str:
    for key in ("processDescription", "process_description", "instruction", "task"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return f"Process AgentDb work item {work_item_id}"


def _claim_context_metadata(claimed: ClaimedWork) -> dict[str, object]:
    derived = claimed.derived
    return {
        **({"run_id": str(claimed.run_id)} if claimed.run_id else {}),
        **(
            {"case_id": str(derived.case_id)}
            if getattr(derived, "case_id", None)
            else {}
        ),
        **(
            {"task_id": str(derived.task_id)}
            if getattr(derived, "task_id", None)
            else {}
        ),
        "parent_shape": getattr(derived, "parent_shape", "run"),
        "attempt_id": str(claimed.attempt_id),
        "attempt_number": claimed.attempt_number,
        "principal_id": str(derived.principal_id),
        "installation_id": str(derived.installation_id),
        "deployment_id": str(derived.deployment_id),
        "pool_id": str(derived.pool_id),
        "agent_version_id": str(derived.agent_version_id),
        **(
            {"model_spend": claimed.model_spend}
            if claimed.model_spend is not None
            else {}
        ),
        **(
            {
                "processing_id": str(claimed.processing_id),
                "processing_configuration_sha256": (
                    claimed.processing_configuration_sha256
                ),
                "processing_source_artifact_id": str(
                    claimed.processing_source_artifact_id
                ),
            }
            if claimed.processing_id is not None
            else {}
        ),
    }
