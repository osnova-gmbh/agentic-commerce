"""AgentDb worker adapter (Sprint 014 / P06).

Production workers consume AgentDb work through the generated client without
owning SQL tables, migrations, queues, or canonical run state.
"""

from cogit_runtime.agentdb.config import AgentDbConfig, require_config
from cogit_runtime.agentdb.coordinator import AgentDbCoordinator, ClaimedWork
from cogit_runtime.agentdb.errors import (
    AgentDbAttemptContextError,
    AgentDbAuthenticationError,
    AgentDbAuthorityError,
    AgentDbAuthorizationError,
    AgentDbCancellationRejectedError,
    AgentDbCancelledError,
    AgentDbConfigError,
    AgentDbConflictError,
    AgentDbError,
    AgentDbLeaseLostError,
    AgentDbNotFoundError,
    AgentDbReconciliationRequiredError,
    AgentDbTimeoutError,
    AgentDbVersionMismatch,
)
from cogit_runtime.agentdb.translate import claimed_work_to_run_request
from cogit_runtime.agentdb.worker import AgentDbWorker

__all__ = [
    "AgentDbAttemptContextError",
    "AgentDbAuthenticationError",
    "AgentDbAuthorityError",
    "AgentDbAuthorizationError",
    "AgentDbCancellationRejectedError",
    "AgentDbCancelledError",
    "AgentDbConfig",
    "AgentDbConfigError",
    "AgentDbConflictError",
    "AgentDbCoordinator",
    "AgentDbError",
    "AgentDbLeaseLostError",
    "AgentDbNotFoundError",
    "AgentDbReconciliationRequiredError",
    "AgentDbTimeoutError",
    "AgentDbVersionMismatch",
    "AgentDbWorker",
    "ClaimedWork",
    "claimed_work_to_run_request",
    "require_config",
]
