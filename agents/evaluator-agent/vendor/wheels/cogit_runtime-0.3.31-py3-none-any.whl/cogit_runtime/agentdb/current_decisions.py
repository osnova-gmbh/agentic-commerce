"""Save, request and park decisions; only canonical successors permit effects."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any
from uuid import UUID

from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.decision_schema import DecisionIntent, DecisionSlot
from cogit_runtime.agentdb.decision_transport import DecisionTransport, verify_receipt
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.agentdb.loop_artifacts import digest as loop_payload_digest
from cogit_runtime.agentdb.runtime_audit import RuntimeAuditEvent, audit_key

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


class DecisionParkRequiredError(AgentDbError, CoordinationFailure):
    """Execution stopped safely; the owning worker must park this checkpoint."""

    def __init__(self, checkpoint_id: UUID, execution_id: UUID) -> None:
        super().__init__("Canonical operation is waiting for a human decision")
        self.checkpoint_id = checkpoint_id
        self.execution_id = execution_id


class CurrentDecisions:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client
        self.transport = DecisionTransport(client)

    def require(
        self,
        *,
        token: str,
        execution_id: str,
        slot_key: str,
        exposure: str,
        payload: dict[str, Any],
        idempotency: str,
        invocation_key: str | None,
    ) -> None:
        try:
            self._require(
                token=token,
                execution_id=execution_id,
                slot_key=slot_key,
                exposure=exposure,
                payload=payload,
                idempotency=idempotency,
                invocation_key=invocation_key,
            )
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Canonical decision could not be confirmed"
            ) from None

    def _require(
        self,
        *,
        token: str,
        execution_id: str,
        slot_key: str,
        exposure: str,
        payload: dict[str, Any],
        idempotency: str,
        invocation_key: str | None,
    ) -> None:
        claim = self.client.active(token)
        config = self.client.config
        if (
            self.client.execution_id != execution_id
            or config.approval_decider_id is None
            or idempotency not in {"inherent", "keyed"}
        ):
            raise AgentDbAuthorityError(
                "Canonical human decision authority is unavailable"
            )
        journal = self.client.continuation
        self._require_durable_slot(slot_key, idempotency, invocation_key, payload)
        if not isinstance(exposure, str) or not 1 <= len(exposure) <= 256:
            raise AgentDbAuthorityError("Invalid protected operation identity")
        material = json.dumps(
            {
                "operation": exposure,
                "slot": slot_key,
                "payload": payload,
                "idempotency": idempotency,
                "key": invocation_key,
            },
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode()
        if len(material) > 1024 * 1024:
            raise AgentDbAuthorityError("Protected operation input exceeds its bound")
        digest = hashlib.sha256(material).hexdigest()
        operation = (
            "runtime." + hashlib.sha256(f"{slot_key}:{exposure}".encode()).hexdigest()
        )
        previous = journal.read_decision(slot_key)
        if previous is None:
            intent = DecisionIntent(
                origin_work_id=claim.work_item_id,
                first_generation=claim.generation,
                operation_id=operation,
                payload_sha256=digest,
                authorized_decider_id=config.approval_decider_id,
                expires_at=(
                    datetime.now(UTC)
                    + timedelta(seconds=config.approval_timeout_seconds)
                ).isoformat(),
                idempotency="keyed" if idempotency == "keyed" else "inherent",
                invocation_key=invocation_key,
            )
            slot = DecisionSlot(phase="prepared", intent=intent)
            journal.write_decision(
                slot_key, slot.model_dump(mode="json"), expected_phase=None
            )
        else:
            slot = DecisionSlot.model_validate(previous)
            intent = slot.intent
            if (
                intent.operation_id != operation
                or intent.payload_sha256 != digest
                or intent.authorized_decider_id != config.approval_decider_id
                or intent.idempotency != idempotency
                or intent.invocation_key != invocation_key
            ):
                raise AgentDbAuthorityError(
                    "Protected operation differs from its decision commitment"
                )
        receipt = slot.receipt
        if receipt is not None:
            verify_receipt(receipt, intent, claim)
            if (
                claim.work_item_id == receipt.successor_work_item_id
                and claim.dispatch_id == receipt.successor_dispatch_id
            ):
                if receipt.state not in {"pending", "approved", "continued"}:
                    raise AgentDbAuthorityError(
                        "Closed human decision cannot grant execution"
                    )
                # D11 creates this exact work/dispatch only after immutable human
                # approval and pin checks. Confirm the current attempt fence now;
                # the old receipt alone is never permission to invoke an effect.
                self._audit(
                    token, execution_id, intent, "observed", str(receipt.request_id)
                )
                return
        if claim.work_item_id != intent.origin_work_id:
            raise AgentDbAuthorityError("Human decision lacks its authorized successor")
        if journal.checkpoint_id is None:
            journal.checkpoint()
        self._audit(token, execution_id, intent, "requested")
        receipt = self.transport.request(token, intent)
        updated = DecisionSlot(phase="requested", intent=intent, receipt=receipt)
        journal.write_decision(
            slot_key, updated.model_dump(mode="json"), expected_phase=slot.phase
        )
        checkpoint = journal.checkpoint_id
        assert checkpoint is not None
        raise DecisionParkRequiredError(checkpoint, UUID(execution_id))

    def _require_durable_slot(
        self,
        key: str,
        idempotency: str,
        invocation_key: str | None,
        payload: dict[str, Any],
    ) -> None:
        if re.fullmatch(r".+/model/(0|[1-9][0-9]*)/tool/(0|[1-9][0-9]*)", key):
            tool = self.client.continuation.read_loop_tool(key)
            if (
                tool is None
                or tool["phase"] != "intent"
                or tool["idempotency"] != idempotency
                or tool["invocation_key"] != invocation_key
                or tool["request"]["metadata"]["hash"] != loop_payload_digest(payload)
            ):
                raise AgentDbAuthorityError(
                    "Protected tool differs from its durable invocation"
                )
            return
        match = re.fullmatch(r"(pipeline:[0-9a-f]{64}):step:(0|[1-9][0-9]*):v(.+)", key)
        if match is None:
            raise AgentDbAuthorityError(
                "Protected operation needs a durable invocation slot"
            )
        pipeline = self.client.continuation.read_pipeline(match[1])
        step = (pipeline or {}).get("steps", {}).get(match[2])
        if (
            not step
            or step.get("phase") != "intent"
            or step.get("idempotency") != idempotency
            or step.get("invocation_key") != invocation_key
        ):
            raise AgentDbAuthorityError(
                "Protected operation differs from durable invocation"
            )

    def _audit(
        self,
        token: str,
        execution: str,
        intent: DecisionIntent,
        phase: str,
        decision_id: str | None = None,
    ) -> None:
        event = RuntimeAuditEvent.create(
            event_key=audit_key(
                "decision", f"{intent.origin_work_id}:{intent.operation_id}", phase
            ),
            kind="decision",
            phase=phase,
            details={
                "operation": intent.operation_id,
                "requestSha256": intent.payload_sha256,
                **({"decisionId": decision_id} if decision_id else {}),
            },
        )
        self.client.runtime_audit.record(
            UUID(execution),
            token,
            f"cogit:runtime-audit:{execution}:{event.event_key}",
            event,
        )
