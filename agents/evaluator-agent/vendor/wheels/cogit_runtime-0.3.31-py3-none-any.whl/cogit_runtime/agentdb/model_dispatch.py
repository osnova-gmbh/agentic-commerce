"""Durable model-call boundary using the SDK wrapper and canonical R07 slots."""

from __future__ import annotations

import hashlib
import json
import uuid
from collections.abc import Callable, Iterable
from dataclasses import asdict
from typing import Any, Protocol

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.providers import DispatchingModelClient, SelectedModelCall
from cogit_agent_sdk.providers.dispatch import IdentifiedModelClient
from cogit_agent_sdk.types import (
    ArtifactRef,
    Cancellation,
    ModelDescriptor,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
    Usage,
)

from cogit_runtime.agentdb.current_model_spend import (
    CurrentModelSpend,
    ReservedModelCall,
)
from cogit_runtime.agentdb.errors import AgentDbReconciliationRequiredError
from cogit_runtime.agentdb.model_commitments import (
    MAX_REQUEST_BYTES,
    prepare_model_request,
    usage_commitment,
)
from cogit_runtime.agentdb.model_streams import OwnedModelStream, close_stream
from cogit_runtime.coordination import finish_cleanup


class ModelSlotJournal(Protocol):
    """R07 supplies copied state and confirms each compare-and-write checkpoint."""

    def read_model_slot(self, slot_key: str) -> dict[str, Any] | None: ...

    def write_model_slot(
        self,
        slot_key: str,
        value: dict[str, Any],
        *,
        expected_phase: str | None,
    ) -> None: ...


class DurableModelDispatch:
    """One explicit logical slot per invocation; no retries or automatic fallback.

    The owning host supplies the loaded route, original admitted work identity,
    and slot from its continuation. No provider IDs, fresh UUIDs, request-body
    keys, local receipts, or request-supplied budget become dispatch authority.
    """

    def __init__(
        self,
        *,
        original_work_id: uuid.UUID,
        journal: ModelSlotJournal,
        spend: CurrentModelSpend,
        token: str,
        store_response: Callable[[str, bytes], ArtifactRef],
        read_response: Callable[[ArtifactRef], bytes],
        observe: Callable[[str, str, dict[str, str | int]], None],
    ) -> None:
        self._work_id = original_work_id
        self._journal = journal
        self._spend = spend
        self._token = token
        self._store_response = store_response
        self._read_response = read_response
        self._observe = observe

    def generate(
        self,
        slot_key: str,
        model: ModelDescriptor,
        client: IdentifiedModelClient,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> ModelResponse:
        events = self._invoke(
            slot_key, model, client, request, cancellation, stream=False
        )
        try:
            for event in events:
                if isinstance(event, ModelResponse):
                    return event
        finally:
            close_stream(events)
        raise AgentDbReconciliationRequiredError("Model response completion is missing")

    def stream(
        self,
        slot_key: str,
        model: ModelDescriptor,
        client: IdentifiedModelClient,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> Iterable[ModelStreamEvent]:
        events = self._invoke(
            slot_key, model, client, request, cancellation, stream=True
        )
        try:
            for item in events:
                if isinstance(item, ModelResponse):
                    yield ModelStreamEvent(
                        type="message_completed",
                        message=item.message,
                        usage=item.usage,
                        stop_reason=item.stop_reason,
                        diagnostics=item.diagnostics,
                        metadata=item.metadata,
                    )
                else:
                    yield item
        finally:
            close_stream(events)

    def _invoke(
        self,
        slot_key: str,
        model: ModelDescriptor,
        client: IdentifiedModelClient,
        request: ModelRequest,
        cancellation: Cancellation,
        *,
        stream: bool,
    ) -> Iterable[ModelStreamEvent | ModelResponse]:
        cancellation.throw_if_cancelled()
        commitment, bound = prepare_model_request(
            self._work_id, slot_key, model, request
        )
        identity = {**asdict(commitment), "call_id": str(commitment.call_id)}
        saved = self._prepare_slot(slot_key, identity)
        if saved is not None:
            if saved.get("commitment") != identity:
                raise AgentDbReconciliationRequiredError(
                    "Model slot commitment changed"
                )
            if saved.get("phase") == "completed":
                yield self._restore(saved)
                return
            if saved.get("phase") != "prepared":
                raise AgentDbReconciliationRequiredError(
                    "Reconcile unfinished model dispatch"
                )
        held: ReservedModelCall | None = None
        settled = False
        settled_cost: str | None = None
        settled_usage: Usage | None = None

        def reserve(route: SelectedModelCall, selected_request: ModelRequest) -> object:
            nonlocal held
            _ = route, selected_request
            held = self._spend.reserve(self._token, **asdict(commitment))
            # An intent persisted before I/O is uncertain after replacement even
            # if this process dies before it manages to reach the provider.
            self._journal.write_model_slot(
                slot_key,
                {"phase": "dispatch_intent", "commitment": identity},
                expected_phase="prepared",
            )
            self._observe(
                slot_key,
                "requested",
                {
                    "provider": model.provider,
                    "model": model.model,
                    "requestSha256": commitment.request_sha256,
                },
            )
            return held

        def settle(route: SelectedModelCall, reservation: object, usage: Usage) -> None:
            nonlocal settled, settled_cost, settled_usage
            if reservation is not held or held is None:
                raise AgentDbReconciliationRequiredError(
                    "Model reservation identity changed"
                )
            inputs, outputs, digest = usage_commitment(usage, route.model)
            cost = self._spend.settle(
                self._token,
                held,
                input_tokens=inputs,
                output_tokens=outputs,
                evidence_sha256=digest,
            )
            settled = True
            settled_cost = str(cost)
            settled_usage = usage.model_copy(deep=True)
            self._observe(
                slot_key,
                "succeeded",
                {
                    "provider": model.provider,
                    "model": model.model,
                    "inputTokens": inputs,
                    "outputTokens": outputs,
                    "resultSha256": digest,
                },
            )

        owned = OwnedModelStream(client)
        delegate = DispatchingModelClient(
            lambda _: SelectedModelCall(slot_key, model, owned),
            reserve,
            settle,
        )
        events: Iterable[ModelStreamEvent | ModelResponse] = ()
        try:
            events = (
                delegate.stream(bound, cancellation)
                if stream
                else (delegate.generate(bound, cancellation),)
            )
            for event in events:
                if (
                    isinstance(event, ModelStreamEvent)
                    and event.type == "message_completed"
                ):
                    if event.message is None:
                        raise AgentDbReconciliationRequiredError(
                            "Model completion lacks its response"
                        )
                    event = ModelResponse(
                        message=event.message,
                        usage=event.usage,
                        stop_reason=event.stop_reason,
                        diagnostics=event.diagnostics,
                        metadata=event.metadata,
                    )
                if isinstance(event, ModelResponse):
                    if settled_usage is None:
                        raise AgentDbReconciliationRequiredError(
                            "Model completion lacks settled usage"
                        )
                    event = event.model_copy(
                        update={
                            "usage": settled_usage,
                            "message": event.message.model_copy(
                                update={"usage": settled_usage}
                            ),
                        }
                    )
                    body = event.model_dump_json().encode("utf-8")
                    if len(body) > MAX_REQUEST_BYTES:
                        raise AgentDbReconciliationRequiredError(
                            "Model response exceeds storage bound"
                        )
                    artifact = self._store_response(slot_key, body)
                    digest = hashlib.sha256(body).hexdigest()
                    if (
                        artifact.mime_type != "application/json"
                        or artifact.size != len(body)
                        or str((artifact.metadata or {}).get("hash", "")).removeprefix(
                            "sha256:"
                        )
                        != digest
                    ):
                        raise AgentDbReconciliationRequiredError(
                            "Stored model response commitment differs"
                        )
                    self._journal.write_model_slot(
                        slot_key,
                        {
                            "phase": "completed",
                            "commitment": identity,
                            "response": {
                                "id": artifact.id,
                                "mime_type": "application/json",
                                "size": len(body),
                                "metadata": {"hash": digest},
                            },
                            "actual_cost": settled_cost,
                            "usage": event.usage.model_dump(exclude={"estimated_cost"})
                            if event.usage is not None
                            else None,
                        },
                        expected_phase="dispatch_intent",
                    )
                yield event
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Model dispatch completion is unconfirmed"
            ) from None
        finally:
            # Missing usage, partial stream, cancellation and unknown provider
            # response keep the reservation held, even if this marker also fails.
            finish_cleanup(
                lambda: (
                    self._mark_uncertain(slot_key, held)
                    if held is not None and not settled
                    else None
                ),
                owned.close,
                lambda: close_stream(events),
            )

    def _mark_uncertain(self, slot_key: str, held: ReservedModelCall) -> None:
        reason = hashlib.sha256(b"cogit.model-dispatch.unconfirmed.v1").hexdigest()
        try:
            self._spend.uncertain(self._token, held, reason_sha256=reason)
            self._observe(
                slot_key, "uncertain", {"reasonCode": "model_dispatch_unconfirmed"}
            )
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Model reservation remains held pending reconciliation"
            ) from None

    def _prepare_slot(
        self, slot_key: str, identity: dict[str, Any]
    ) -> dict[str, Any] | None:
        try:
            saved = self._journal.read_model_slot(slot_key)
            if saved is None:
                self._journal.write_model_slot(
                    slot_key,
                    {"phase": "prepared", "commitment": identity},
                    expected_phase=None,
                )
            return saved
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Model slot persistence is unconfirmed"
            ) from None

    def _restore(self, saved: dict[str, Any]) -> ModelResponse:
        try:
            artifact = ArtifactRef.model_validate(saved["response"])
            body = self._read_response(artifact)
            digest = str((artifact.metadata or {}).get("hash", "")).removeprefix(
                "sha256:"
            )
            if (
                artifact.mime_type != "application/json"
                or not 0 < len(body) <= MAX_REQUEST_BYTES
                or artifact.size != len(body)
                or hashlib.sha256(body).hexdigest() != digest
            ):
                raise ValueError("Mismatched response artifact")
            result = ModelResponse.model_validate(json.loads(body))
            if result.usage is None:
                raise ValueError("Incomplete saved model response")
            return result
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Invalid completed model response"
            ) from None
