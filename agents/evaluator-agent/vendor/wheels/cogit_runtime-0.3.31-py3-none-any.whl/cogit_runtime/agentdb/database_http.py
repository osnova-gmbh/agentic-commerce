"""Bounded shared transport for published AgentDb governance/domain operations."""

from __future__ import annotations

import hashlib
import json
from typing import Any, cast
from urllib.parse import urlsplit

import httpx
from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.error_metadata import response_metadata
from cogit_runtime.agentdb.errors import (
    AgentDbConflictError,
    AgentDbError,
    AgentDbLeaseLostError,
    AgentDbReconciliationRequiredError,
    AgentDbTimeoutError,
)
from cogit_runtime.agentdb.response_body import collected_response

MAX_RESPONSE_BYTES = 262144


def command_key(name: str, payload: dict[str, Any]) -> str:
    body = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return "cogit:" + name + ":" + hashlib.sha256(body.encode()).hexdigest()


class DatabaseHttp:
    """Never redirect credentials or surface server bodies in exception messages."""

    def __init__(
        self, url: str, token: str, *, transport: httpx.BaseTransport | None = None
    ) -> None:
        parsed = urlsplit(url)
        if (
            not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
            or parsed.path not in ("", "/")
            or (
                parsed.scheme != "https"
                and not (
                    parsed.scheme == "http"
                    and parsed.hostname in {"localhost", "127.0.0.1", "::1"}
                )
            )
        ):
            raise AgentDbError("Database endpoint requires HTTPS or local HTTP")
        if not token or any(
            ord(character) < 33 or ord(character) == 127 for character in token
        ):
            raise AgentDbError("Database credential is invalid")
        self._http = httpx.Client(
            base_url=url,
            headers={
                "Authorization": f"Bearer {token}",
                "x-agentdb-api-version": "0.1.0",
                "x-agentdb-sdk": "1/0.1.11",
            },
            follow_redirects=False,
            timeout=30,
            transport=transport,
        )

    def close(self) -> None:
        self._http.close()

    def request(
        self,
        path: str,
        payload: dict[str, Any] | None = None,
        *,
        key: str | None = None,
        attempt_token: str | None = None,
        query: dict[str, str] | None = None,
        idempotent: bool = False,
    ) -> dict[str, Any]:
        parsed = urlsplit(path)
        if (
            not path.startswith("/v1/")
            or path.startswith("//")
            or (
                parsed.scheme
                or parsed.netloc
                or parsed.query
                or parsed.fragment
                or any(segment in {".", ".."} for segment in parsed.path.split("/"))
                or "%" in path
                or "\\" in path
            )
        ):
            raise AgentDbError(
                "Database request requires a canonical relative API path"
            )
        headers = {"Idempotency-Key": key or command_key("read", payload or {})}
        if query is not None and (
            path != "/v1/worker/module-readiness" or set(query) != {"installationId"}
        ):
            raise AgentDbError("Database query parameters are not allowed here")
        if attempt_token is not None:
            headers["X-AgentDb-Attempt-Token"] = attempt_token
        read = payload is None or idempotent
        attempts = 2 if read else 1
        for retry in range(attempts):
            try:
                return self._request(path, payload, headers, query)
            except CoordinationFailure:
                raise
            except httpx.TransportError:
                if not read:
                    raise AgentDbReconciliationRequiredError(
                        "Database command outcome is uncertain; "
                        "reconcile before retrying"
                    ) from None
                if retry == attempts - 1:
                    raise AgentDbError(
                        "Database transport unavailable", retryable=True
                    ) from None
            except AgentDbError as exc:
                if not read and (
                    exc.retryable
                    or isinstance(exc, AgentDbTimeoutError)
                    or (exc.http_status is not None and exc.http_status >= 500)
                ):
                    raise AgentDbReconciliationRequiredError(
                        "Database command outcome is uncertain; "
                        "reconcile before retrying",
                        response_metadata=exc.response_metadata,
                    ) from None
                raise
            except Exception:
                if not read:
                    raise AgentDbReconciliationRequiredError(
                        "Database command outcome is uncertain; "
                        "reconcile before retrying"
                    ) from None
                raise
        raise AssertionError("Unreachable transport state")

    def _request(
        self,
        path: str,
        payload: dict[str, Any] | None,
        headers: dict[str, str],
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        stream = self._http.stream(
            "GET" if payload is None else "POST",
            path,
            json=payload,
            headers=headers,
            params=query,
        )
        with collected_response(
            stream,
            limit=MAX_RESPONSE_BYTES,
            oversized=lambda status: AgentDbError(
                "Database response exceeds its bound",
                retryable=status in (200, 201, 202) or status >= 500,
            ),
        ) as (status, body):
            return self._classify_response(status, body)

    @staticmethod
    def _classify_response(status: int, body: bytes) -> dict[str, Any]:
        successful = status in (200, 201, 202)
        try:
            value = json.loads(body)
        except (ValueError, UnicodeError, RecursionError):
            value = None
        metadata = response_metadata(status, value)
        if status == 409:
            if metadata.code == "stale_attempt":
                raise AgentDbLeaseLostError(
                    "Database rejected stale attempt authority",
                    response_metadata=metadata,
                )
            raise AgentDbConflictError(
                "Database revision or replay conflict", response_metadata=metadata
            )
        if status in (408, 504):
            raise AgentDbTimeoutError(
                "Database response deadline expired", response_metadata=metadata
            )
        if not successful:
            raise AgentDbError(
                "Database rejected the operation",
                retryable=metadata.retryable
                if status >= 500 and metadata.retryable is not None
                else status >= 500,
                response_metadata=metadata,
            )
        if not isinstance(value, dict):
            raise AgentDbError("Database response must be an object", retryable=True)
        return cast(dict[str, Any], value)
