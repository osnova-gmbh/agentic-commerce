"""Map Runtime's worker ports to AgentDb's published HTTP operations."""

from __future__ import annotations

import hashlib
import json
import uuid
from collections.abc import Sequence
from typing import Any, Literal

from agentdb_client import (
    ApiClient,
    ClaimResource,
    ClaimWorkRequest,
    CompleteAttemptRequest,
    Configuration,
    FinishExecutionRequest,
    StoreExecutionArtifactRequest,
    WorkerAttemptRequest,
)
from agentdb_client.api.attempt_api import AttemptApi
from agentdb_client.api.pool_worker_api import PoolWorkerApi
from agentdb_client.exceptions import ApiException
from cogit_agent_sdk.types import ArtifactRef, DatabasePackageRequirement

from cogit_runtime.agentdb.claim_permissions import claim_permissions
from cogit_runtime.agentdb.claim_resume import claim_identity, load_resume
from cogit_runtime.agentdb.cohort import VerifiedCohort
from cogit_runtime.agentdb.config import AgentDbConfig
from cogit_runtime.agentdb.continuation import ContinuationJournal
from cogit_runtime.agentdb.continuation_schema import (
    MAX_CONTINUATION_BYTES,
    RuntimeContinuation,
)
from cogit_runtime.agentdb.current_actions import CurrentActions
from cogit_runtime.agentdb.current_artifacts import CurrentArtifacts
from cogit_runtime.agentdb.current_checkpoints import CurrentCheckpoints
from cogit_runtime.agentdb.current_decisions import CurrentDecisions
from cogit_runtime.agentdb.current_governance import CurrentGovernance
from cogit_runtime.agentdb.current_journal_artifacts import CurrentJournalArtifacts
from cogit_runtime.agentdb.current_model_spend import CurrentModelSpend
from cogit_runtime.agentdb.current_modules import CurrentModules
from cogit_runtime.agentdb.current_processing_events import CurrentProcessingEvents
from cogit_runtime.agentdb.current_runtime_audit import CurrentRuntimeAudit
from cogit_runtime.agentdb.errors import (
    AgentDbAttemptContextError,
    AgentDbAuthorityError,
    AgentDbError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.agentdb.health import record_worker_contact
from cogit_runtime.agentdb.port_values import (
    AttemptStatus,
    ClaimAccepted,
    ClaimEmpty,
    ClaimResult,
    DerivedClaimContext,
    QueueDeliveryIdentity,
    WorkAttempt,
)
from cogit_runtime.agentdb.release_compatibility import verify_release
from cogit_runtime.agentdb.replay import replay_once
from cogit_runtime.agentdb.transport import AgentDbTransport
from cogit_runtime.readiness import reject_unreserved_claim_cap


class CurrentClient:
    """One worker's current claim; all durable state remains in AgentDb."""

    def __init__(
        self,
        config: AgentDbConfig,
        database_packages: Sequence[DatabasePackageRequirement] = (),
        *,
        cohort: VerifiedCohort | None = None,
    ) -> None:
        self.config = config
        self.cohort = cohort
        self.http = ApiClient(
            Configuration(host=config.url, access_token=config.worker_token, retries=0)
        )
        self.pool_api = PoolWorkerApi(self.http)
        self.attempt_api = AttemptApi(self.http)
        self.timeout = (config.connect_timeout_seconds, config.read_timeout_seconds)
        self.claim: ClaimResource | None = None
        self.execution_id: str | None = None
        self.digests: dict[uuid.UUID, str] = {}
        self.artifacts = CurrentArtifacts(self)
        self.journal_artifacts = CurrentJournalArtifacts(self)
        self.actions = CurrentActions(self)
        self.governance = CurrentGovernance(self)
        self.modules = CurrentModules(self, tuple(database_packages))
        self.processing_events = CurrentProcessingEvents(self)
        self.runtime_audit = CurrentRuntimeAudit(self)
        self.model_spend = CurrentModelSpend(self)
        self.checkpoints = CurrentCheckpoints(self)
        self.decisions = CurrentDecisions(self)
        self._resume: RuntimeContinuation | None = None
        self._continuation: ContinuationJournal | None = None
        self.work = self
        self.executions = self
        self.usage = self

    def headers(self, key: str | None = None) -> dict[str, str]:
        return {
            "idempotency-key": key or str(uuid.uuid4()),
            "x-agentdb-api-version": self.config.api_version,
            "x-agentdb-sdk": "1/0.1.11",
        }

    def active(self, token: str) -> ClaimResource:
        if self.claim is None or token != self.claim.token:
            raise AgentDbAuthorityError("No matching AgentDb attempt authority")
        return self.claim

    def require_cohort(self) -> VerifiedCohort:
        if self.cohort is None:
            raise AgentDbError(
                "Canonical workers require a verified immutable cohort receipt"
            )
        return self.cohort

    def claim_pool_work(
        self,
        pool_id: uuid.UUID,
        *,
        idempotency_key: str | None = None,
        claim_work_request: Any = None,
    ) -> ClaimResult:
        self._clear_claim()
        if pool_id != self.config.pool_id:
            raise AgentDbAuthorityError("Worker pool differs from its configuration")
        self.modules.readiness()
        verify_release(self.http, self.timeout)
        headers = self.headers(idempotency_key)
        request = ClaimWorkRequest(poolId=pool_id)
        try:
            claim = replay_once(
                lambda: self.pool_api.claim_work(
                    request,
                    _headers=headers,
                    _request_timeout=self.timeout,
                )
            )
        except ApiException as exc:
            if exc.status == 404 and getattr(exc.data, "code", None) == "not_found":
                record_worker_contact()
                return ClaimResult(ClaimEmpty(outcome="empty"))
            raise
        if claim is None:
            record_worker_contact()
            return ClaimResult(ClaimEmpty(outcome="empty"))
        reject_unreserved_claim_cap(claim)
        self.claim = claim
        if (
            claim.contract_version != "agentdb.claim-resource.v2"
            or claim.release.claim_payload_version != 2
            or claim.release.api_version != "0.1.0"
            or claim.route.pool_id != pool_id
        ):
            self._clear_claim()
            raise AgentDbError("AgentDb claim is incompatible with this worker")
        delivery = claim.delivery
        if (
            delivery is None
            or delivery.contract_version != "pgboss-1"
            or delivery.attempt_id != claim.attempt_id
            or delivery.token != claim.token
        ):
            self._clear_claim()
            raise AgentDbError("AgentDb claim lacks a matching queue delivery")
        record_worker_contact()
        try:
            self.require_cohort().require_claim(claim)
            permissions = claim_permissions(claim)
            identity = claim_identity(claim)
            self._resume = load_resume(
                claim,
                identity,
                self._resume_content,
                fetch_index=self.journal_artifacts.read
                if self.modules.journal_indexes_supported
                else None,
            )
            content = self.input_content(claim)
            self.modules.capture(claim.token)
        except Exception:
            self._clear_claim()
            raise
        if claim.input.media_type == "text/plain":
            payload = {"instruction": content}
        else:
            try:
                payload = json.loads(content)
            except ValueError:
                payload = {"instruction": content}
        if not isinstance(payload, dict):
            payload = {"value": payload}
        route = claim.route
        processing = getattr(claim, "processing", None)
        return ClaimResult(
            ClaimAccepted(
                outcome="accepted",
                work_item_id=claim.work_item_id,
                attempt_id=claim.attempt_id,
                attempt_number=claim.generation,
                attempt_token=claim.token,
                lease_expires_at=claim.lease_expires_at,
                derived=DerivedClaimContext(
                    tenant_id=claim.tenant_id,
                    principal_id=route.agent_principal_id,
                    installation_id=route.installation_id,
                    deployment_id=route.deployment_id,
                    pool_id=route.pool_id,
                    agent_version_id=route.version_id,
                    run_id=claim.run_id,
                    parent_shape=identity.parent_shape,
                    case_id=identity.case_id,
                    task_id=identity.task_id,
                ),
                delivery=QueueDeliveryIdentity(
                    contract_version=delivery.contract_version,
                    job_id=delivery.job_id,
                    delivery_generation=delivery.delivery_generation,
                    business_key=delivery.business_key,
                ),
                input=payload,
                input_sha256=claim.input.sha256,
                permissions=permissions,
                model_spend=claim.model_spend.model_dump(
                    mode="json", by_alias=True, exclude={"additional_properties"}
                )
                if claim.model_spend
                else None,
                processing_id=processing.processing_id
                if processing is not None
                else None,
                processing_configuration_sha256=processing.configuration_sha256
                if processing is not None
                else None,
                processing_source_artifact_id=processing.source_artifact_id
                if processing is not None
                else None,
            )
        )

    def input_content(self, claim: ClaimResource) -> str:
        if claim.input.media_type not in {"application/json", "text/plain"} or not (
            0 <= claim.input.byte_length <= 65536
        ):
            raise AgentDbError("This adapter requires bounded UTF-8 text or JSON input")
        delivery = claim.input.delivery.to_dict() or {}
        if not isinstance(delivery, dict):
            raise AgentDbError("Unsupported AgentDb input delivery")
        if "inlineUtf8" in delivery:
            content = delivery["inlineUtf8"]
        else:
            fetched = self.attempt_api.get_claim_artifact_content(
                claim.attempt_id,
                claim.input.artifact_id,
                claim.token,
                _headers=self.headers(),
                _request_timeout=self.timeout,
            )
            content = fetched.content
        body = content.encode("utf-8")
        if (
            len(body) != claim.input.byte_length
            or hashlib.sha256(body).hexdigest() != claim.input.sha256
        ):
            raise AgentDbError("AgentDb input commitment mismatch")
        return content

    def _resume_content(self, artifact_id: uuid.UUID) -> str:
        if self.claim is None or self.claim.resume is None:
            raise AgentDbAuthorityError("No active claim artifact authority")
        resume = self.claim.resume
        if artifact_id != resume.artifact_id:
            raise AgentDbAuthorityError("Checkpoint artifact identity mismatch")
        body = self.artifacts.read_artifact(
            ArtifactRef(
                id=str(artifact_id),
                size=resume.byte_length,
                mime_type=resume.media_type,
                metadata={"hash": resume.sha256},
            ),
            self.claim.token,
            MAX_CONTINUATION_BYTES,
        )
        try:
            return body.decode("utf-8")
        except UnicodeError:
            raise AgentDbAuthorityError("Checkpoint is not UTF-8") from None

    @property
    def continuation(self) -> ContinuationJournal:
        if (
            self.claim is None
            or self.execution_id is None
            or self._continuation is None
        ):
            raise AgentDbAuthorityError("No active Runtime continuation authority")
        return self._continuation

    def heartbeat_attempt(
        self, attempt_id: uuid.UUID, token: str, heartbeat_attempt_request: Any = None
    ) -> Any:
        claim = self.active(token)
        if attempt_id != claim.attempt_id:
            raise AgentDbAuthorityError("Attempt identity mismatch")
        result = self.attempt_api.heartbeat_attempt(
            claim.attempt_id,
            token,
            WorkerAttemptRequest(generation=claim.generation),
            _headers=self.headers(),
            _request_timeout=self.timeout,
        )
        record_worker_contact()
        return result

    def get_work_attempt(self, attempt_id: uuid.UUID, token: str) -> WorkAttempt:
        # Heartbeat checks current authority, including cancellation fencing.
        AgentDbTransport().invoke(
            self.heartbeat_attempt, attempt_id, token, operation="heartbeat"
        )
        claim = self.active(token)
        return WorkAttempt(
            id=attempt_id,
            work_item_id=claim.work_item_id,
            attempt_number=claim.generation,
            status=AttemptStatus.RUNNING,
            claimant_kind="worker",
            version=1,
        )

    def start_execution(self, token: str, key: str, request: Any) -> dict[str, str]:
        claim = self.active(token)
        if request.work_attempt_id != claim.attempt_id:
            raise AgentDbAuthorityError("Attempt identity mismatch")
        result = self.attempt_api.start_execution(
            claim.attempt_id,
            token,
            WorkerAttemptRequest(generation=claim.generation),
            _headers=self.headers(key),
            _request_timeout=self.timeout,
        )
        self.execution_id = str(result.execution_id)
        if self._continuation is None:
            state = self._resume or RuntimeContinuation(
                original_work_id=claim.work_item_id,
                identity=claim_identity(claim),
                execution_id=result.execution_id,
            )
            self._continuation = ContinuationJournal(
                state,
                execution_id=result.execution_id,
                publish=lambda payload: self.checkpoints.publish(
                    token, result.execution_id, payload
                ),
                store_index=self.journal_artifacts.save
                if self.modules.journal_indexes_supported
                else None,
            )
        self.runtime_audit.lifecycle(
            result.execution_id, token, "started", "execution.start"
        )
        return {"id": str(result.execution_id)}

    def store(
        self,
        token: str,
        key: str,
        content: str,
        media_type: Literal["application/json", "text/plain"],
    ) -> Any:
        claim = self.active(token)
        if self.execution_id is None:
            raise AgentDbAuthorityError("Start an execution before storing evidence")
        request = StoreExecutionArtifactRequest(
            generation=claim.generation, mediaType=media_type, content=content
        )
        headers = self.headers(key)
        result = replay_once(
            lambda: self.attempt_api.store_execution_artifact(
                uuid.UUID(self.execution_id),
                token,
                request,
                _headers=headers,
                _request_timeout=self.timeout,
            )
        )
        expected = hashlib.sha256(content.encode("utf-8")).hexdigest()
        if result.sha256 != expected or result.byte_length != len(
            content.encode("utf-8")
        ):
            raise AgentDbReconciliationRequiredError(
                "AgentDb result commitment mismatch"
            )
        self.digests[result.artifact_id] = result.sha256
        return result

    def record_execution_step(
        self, execution_id: uuid.UUID, token: str, request: Any, key: str
    ) -> Any:
        if str(execution_id) != self.execution_id:
            raise AgentDbAuthorityError("Execution identity mismatch")
        content = json.dumps(
            {
                "executionId": str(execution_id),
                "sequence": request.step_order,
                "kind": request.kind,
                "status": request.status,
            },
            sort_keys=True,
        )
        return self.store(token, key, content, "application/json")

    def finish(
        self,
        token: str,
        key: str,
        lifecycle: Literal["succeeded", "failed", "interrupted"],
    ) -> None:
        claim = self.active(token)
        if self.execution_id is None:
            raise AgentDbAuthorityError("No current execution")
        execution_id = uuid.UUID(self.execution_id)
        # This records the outcome being submitted. The following mutation must
        # still be confirmed before the coordinator treats execution as finished.
        self.runtime_audit.lifecycle(
            execution_id,
            token,
            "completed" if lifecycle == "succeeded" else "failed",
            "execution.finish",
            details={"reasonCode": lifecycle},
        )
        request = FinishExecutionRequest(
            generation=claim.generation, lifecycle=lifecycle
        )
        headers = self.headers(key)
        self.attempt_api.finish_execution(
            execution_id,
            token,
            request,
            _headers=headers,
            _request_timeout=self.timeout,
        )

    def settle_attempt(
        self, attempt_id: uuid.UUID, token: str, key: str, request: Any
    ) -> Any:
        claim = self.active(token)
        if attempt_id != claim.attempt_id:
            raise AgentDbAuthorityError("Attempt identity mismatch")
        if request.result_artifact_id not in self.digests:
            raise AgentDbAttemptContextError(
                "A finalized result from this execution is required"
            )
        self.finish(token, key + ":finish", "succeeded")
        payload = CompleteAttemptRequest(
            generation=claim.generation,
            resultSha256=self.digests[request.result_artifact_id],
        )
        headers = self.headers(key)
        return replay_once(
            lambda: self.attempt_api.complete_attempt(
                claim.attempt_id,
                token,
                payload,
                _headers=headers,
                _request_timeout=self.timeout,
            )
        )

    def fail_attempt(
        self, attempt_id: uuid.UUID, token: str, key: str, request: Any
    ) -> Any:
        claim = self.active(token)
        if attempt_id != claim.attempt_id:
            raise AgentDbAuthorityError("Attempt identity mismatch")
        if self.execution_id:
            evidence = self.store(
                token,
                key + ":evidence",
                json.dumps(
                    {"error": request.error.to_dict(), "retryable": request.retryable}
                ),
                "application/json",
            )
            if getattr(claim, "processing", None) is not None:
                from cogit_agent_sdk.types import WorkOutcome

                return self.settle_processing_attempt(
                    attempt_id,
                    token,
                    key,
                    evidence.artifact_id,
                    WorkOutcome(
                        outcome="retry" if request.retryable else "review_required",
                        reason_code="execution_failed",
                    ),
                    False,
                )
            self.finish(token, key + ":finish", "failed")
        payload = WorkerAttemptRequest(generation=claim.generation)
        headers = self.headers(key)
        return replay_once(
            lambda: self.attempt_api.fail_attempt(
                claim.attempt_id,
                token,
                payload,
                _headers=headers,
                _request_timeout=self.timeout,
            )
        )

    def settle_processing_attempt(
        self,
        attempt_id: uuid.UUID,
        token: str,
        key: str,
        result_artifact_id: uuid.UUID,
        outcome: Any,
        execution_succeeded: bool,
    ) -> Any:
        from agentdb_client import SettleProcessingAttemptRequest

        claim = self.active(token)
        if attempt_id != claim.attempt_id:
            raise AgentDbAuthorityError("Attempt identity mismatch")
        if (
            getattr(claim, "processing", None) is None
            or result_artifact_id not in self.digests
        ):
            raise AgentDbAttemptContextError(
                "Processing outcome requires current finalized evidence"
            )
        try:
            awaited_action = (
                uuid.UUID(outcome.awaited_action_id)
                if outcome.awaited_action_id is not None
                else None
            )
        except ValueError:
            raise AgentDbAttemptContextError(
                "Invalid awaited action identity"
            ) from None
        if awaited_action is not None and awaited_action not in self.actions.prepared:
            raise AgentDbAttemptContextError(
                "Observe the awaited action in this execution first"
            )
        if awaited_action is not None and outcome.outcome not in (
            "paused",
            "review_required",
        ):
            raise AgentDbAttemptContextError("Only waiting outcomes may name an action")
        if (
            outcome.reason_code in ("awaiting_action", "action_reconciliation_required")
            and awaited_action is None
        ):
            raise AgentDbAttemptContextError(
                "An action wait requires its exact action identity"
            )
        payload = SettleProcessingAttemptRequest(
            generation=claim.generation,
            outcome=outcome.outcome,
            reasonCode=outcome.reason_code,
            resultArtifactId=result_artifact_id,
            awaitedActionId=awaited_action,
        )
        self.finish(
            token, key + ":finish", "succeeded" if execution_succeeded else "failed"
        )
        headers = self.headers(key)
        return replay_once(
            lambda: self.attempt_api.settle_processing_attempt(
                attempt_id,
                token,
                payload,
                _headers=headers,
                _request_timeout=self.timeout,
            )
        )

    def park_attempt(
        self, attempt_id: uuid.UUID, token: str, key: str, request: Any
    ) -> Any:
        try:
            return self.checkpoints.park(attempt_id, token, key, request.checkpoint_id)
        finally:
            self._clear_claim()

    def cancel_work(self, *args: Any, **kwargs: Any) -> Any:
        raise AgentDbError("Worker-initiated cancellation is not supported by AgentDb")

    def create_model_call_intent(self, *args: Any, **kwargs: Any) -> Any:
        raise AgentDbError(
            "AgentDb model budget reservation is unavailable; model call rejected"
        )

    reserve_model_call_budget = create_model_call_intent
    settle_model_call_budget = create_model_call_intent

    def close(self) -> None:
        self._clear_claim()
        self.http.rest_client.pool_manager.clear()

    def _clear_claim(self) -> None:
        self.claim = None
        self.execution_id = None
        self._resume = None
        self._continuation = None
        self.checkpoints.latest = None
        self.digests.clear()
        self.artifacts.clear()
        self.actions.clear()
        self.modules.clear()
