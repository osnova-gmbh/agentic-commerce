"""Active-attempt governance and bounded specialization command transport."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any
from uuid import UUID

from cogit_runtime.agentdb.database_http import DatabaseHttp, command_key
from cogit_runtime.agentdb.errors import (
    AgentDbAttemptContextError,
    AgentDbAuthorityError,
)
from cogit_runtime.coordination import finish_cleanup

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


class CurrentGovernance:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client

    def snapshot(self, token: str, snapshot_id: str) -> dict[str, Any]:
        claim = self.client.active(token)
        result = self._request(
            token, f"/v1/worker/attempts/{claim.attempt_id}/governance-snapshot", None
        )
        if result.get("snapshotId") != str(UUID(snapshot_id)):
            raise AgentDbAuthorityError(
                "Configuration snapshot differs from admitted work"
            )
        return result

    def command(
        self, token: str, name: str, payload: dict[str, Any], key: str
    ) -> dict[str, Any]:
        claim = self.client.active(token)
        body = {**payload, "generation": claim.generation}
        base = f"/v1/worker/attempts/{claim.attempt_id}"
        execution = f"/v1/worker/executions/{self.client.execution_id}/governance"
        paths = {
            "governance.evaluate": execution + "/evaluations",
            "governance.coverage": execution + "/coverage",
        }
        if name.startswith("domain:"):
            path = specialization_command_path(base, name)
        elif name in paths:
            path = paths[name]
        else:
            raise AgentDbAttemptContextError("Unknown worker database command")
        return self._request(token, path, body, key)

    def prepare_action(
        self, token: str, payload: dict[str, Any], key: str
    ) -> dict[str, Any]:
        self.client.active(token)
        if self.client.execution_id is None:
            raise AgentDbAuthorityError("Governed action needs a current execution")
        return self._request(
            token,
            f"/v1/worker/executions/{self.client.execution_id}/actions",
            payload,
            key,
        )

    def _request(
        self, token: str, path: str, body: dict[str, Any] | None, key: str | None = None
    ) -> dict[str, Any]:
        self.client.active(token)
        http = DatabaseHttp(self.client.config.url, self.client.config.worker_token)
        try:
            return http.request(
                path,
                body,
                key=key or command_key("worker-read", body or {}),
                attempt_token=token,
            )
        finally:
            finish_cleanup(http.close)


def specialization_command_path(base: str, name: str) -> str:
    """Resolve a specialization route inside the authority-derived active attempt."""
    route = name.removeprefix("domain:")
    if not name.startswith("domain:") or not re.fullmatch(
        r"[a-z][a-z0-9-]{0,127}(?:/[a-z0-9-]{1,128}){0,3}", route
    ):
        raise AgentDbAttemptContextError("Invalid specialization command path")
    return base + "/" + route
