"""Active AgentDb attempt context that never logs the plaintext token."""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from typing import Any

from cogit_runtime.agentdb.errors import (
    AgentDbAttemptContextError,
    AgentDbAuthorityError,
)
from cogit_runtime.agentdb.port_values import QueueDeliveryIdentity


@dataclass(repr=False)
class AttemptSession:
    """Mutable fence for one claimed AgentDb attempt."""

    attempt_id: uuid.UUID | None = None
    attempt_token: str | None = None
    work_item_id: uuid.UUID | None = None
    run_id: uuid.UUID | None = None
    execution_id: uuid.UUID | None = None
    processing_id: uuid.UUID | None = None
    derived: Any = None
    delivery: QueueDeliveryIdentity | None = None
    finalized_artifact_ids: list[uuid.UUID] = field(default_factory=list)

    def bind_claim(
        self,
        *,
        attempt_id: uuid.UUID,
        attempt_token: str,
        work_item_id: uuid.UUID,
        run_id: uuid.UUID | None,
        derived: Any,
        delivery: QueueDeliveryIdentity | None = None,
        processing_id: uuid.UUID | None = None,
    ) -> None:
        self.clear()
        self.attempt_id = attempt_id
        self.attempt_token = attempt_token
        self.work_item_id = work_item_id
        self.run_id = run_id
        self.derived = derived
        self.delivery = delivery
        self.processing_id = processing_id

    def bind_execution(self, execution_id: uuid.UUID) -> None:
        self.require_token()
        self.execution_id = execution_id

    def record_finalized(self, artifact_id: uuid.UUID) -> None:
        if artifact_id not in self.finalized_artifact_ids:
            self.finalized_artifact_ids.append(artifact_id)

    def clear(self) -> None:
        self.attempt_id = None
        self.attempt_token = None
        self.work_item_id = None
        self.run_id = None
        self.execution_id = None
        self.processing_id = None
        self.derived = None
        self.delivery = None
        self.finalized_artifact_ids = []

    def require_token(self) -> str:
        if self.attempt_token is None or self.attempt_id is None:
            raise AgentDbAuthorityError(
                "No active AgentDb attempt context; claim work before mutating"
            )
        return self.attempt_token

    def require_ids(self) -> tuple[uuid.UUID, str]:
        token = self.require_token()
        assert self.attempt_id is not None
        return self.attempt_id, token

    def require_work_item(self) -> uuid.UUID:
        self.require_token()
        if self.work_item_id is None:
            raise AgentDbAuthorityError(
                "No active AgentDb work item; claim work before cancelling"
            )
        return self.work_item_id

    def require_run_id(self) -> uuid.UUID:
        self.require_token()
        if self.run_id is None:
            raise AgentDbAuthorityError(
                "No active AgentDb run; claim work before declaring artifacts"
            )
        return self.run_id

    def require_execution_id(self) -> uuid.UUID:
        self.require_token()
        if self.execution_id is None:
            raise AgentDbAuthorityError(
                "No active AgentDb execution; start execution before routing events"
            )
        return self.execution_id

    def idempotency_key(self, operation: str, *parts: object) -> str:
        attempt_id, _token = self.require_ids()
        extras = [str(part) for part in parts if part is not None]
        material = ":".join([operation, str(attempt_id), *extras])
        digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]
        key = f"cogit:{operation}:{digest}"
        if len(key) > 128:
            raise AgentDbAttemptContextError(
                "AgentDb idempotency key exceeded the 128-character contract limit"
            )
        return key

    def redacted(self) -> str:
        """Summary that never exposes the plaintext attempt token."""

        return (
            f"AttemptSession(attempt_id={self.attempt_id}, "
            f"run_id={self.run_id}, execution_id={self.execution_id}, "
            f"attempt_token='<redacted>')"
        )

    __repr__ = redacted  # type: ignore[assignment]
    __str__ = redacted  # type: ignore[assignment]
