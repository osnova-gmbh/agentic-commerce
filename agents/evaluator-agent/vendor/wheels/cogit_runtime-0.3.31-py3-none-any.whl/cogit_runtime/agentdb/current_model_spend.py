"""Fenced D12 transport; AgentDb owns prices, caps and reservation accounting.

A replayed reservation confirms accounting only. It never authorizes replaying
the provider call: the caller must reconcile its durable R07 dispatch slot.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from decimal import ROUND_FLOOR, Decimal
from typing import TYPE_CHECKING, Any

from agentdb_client import (
    MarkModelSpendUncertainRequest,
    ReserveModelSpendRequest,
    SettleModelSpendRequest,
)
from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.agentdb.replay import replay_once
from cogit_runtime.agentdb.transport import AgentDbTransport

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient

_MONEY = re.compile(r"(?:0|[1-9][0-9]{0,11})(?:\.[0-9]{1,12})?\Z")


def money(value: Any) -> Decimal:
    """Read bounded exact wire money without a float conversion."""
    if not isinstance(value, str) or _MONEY.fullmatch(value) is None:
        raise AgentDbAuthorityError("Invalid canonical model spend amount")
    return Decimal(value)


def money_cap_from_float(value: float) -> Decimal:
    """Compare the SDK cap's decimal spelling at AgentDb money precision."""
    if type(value) is not float:
        raise AgentDbAuthorityError("Invalid SDK model spend cap")
    amount = Decimal(str(value))
    if not amount.is_finite() or not 0 <= amount < Decimal("1000000000000"):
        raise AgentDbAuthorityError("Invalid SDK model spend cap")
    return amount.quantize(Decimal("0.000000000001"), rounding=ROUND_FLOOR)


@dataclass(frozen=True, slots=True)
class SpendAdmission:
    run_id: uuid.UUID
    installation_id: uuid.UUID
    settings_version_id: uuid.UUID
    settings_sha256: str
    price_version: str
    currency: str
    cap: Decimal

    @classmethod
    def from_claim(cls, claim: Any) -> SpendAdmission:
        value = claim.model_spend
        if value is None or (
            value.installation_id != claim.route.installation_id
            or (claim.run_id is not None and value.run_id != claim.run_id)
            or value.settings_version_id is None
            or value.settings_sha256 is None
            or value.price_version is None
            or value.currency is None
            or money(value.cap) <= 0
        ):
            raise AgentDbAuthorityError("Model dispatch needs an admitted spend policy")
        admission = cls(
            value.run_id,
            value.installation_id,
            value.settings_version_id,
            value.settings_sha256,
            value.price_version,
            value.currency,
            money(value.cap),
        )
        admission.verify_balance(value)
        return admission

    def verify_balance(self, value: Any) -> None:
        if (
            value.run_id != self.run_id
            or value.settings_version_id != self.settings_version_id
            or value.price_version != self.price_version
            or value.currency != self.currency
            or money(value.cap) != self.cap
        ):
            raise AgentDbReconciliationRequiredError(
                "Model spend receipt changed its admission commitment"
            )
        if (
            sum(
                money(getattr(value, name))
                for name in ("spent", "outstanding", "available")
            )
            != self.cap
        ):
            raise AgentDbReconciliationRequiredError(
                "Model spend receipt has an inconsistent balance"
            )


@dataclass(frozen=True, slots=True)
class ReservedModelCall:
    admission: SpendAdmission
    attempt_id: uuid.UUID
    execution_id: uuid.UUID
    generation: int
    call_id: uuid.UUID
    request_sha256: str
    max_input_tokens: int
    max_output_tokens: int
    reserved_cost: Decimal


class CurrentModelSpend:
    """Use only the active canonical claim, never request-supplied budget data."""

    def __init__(self, client: CurrentClient) -> None:
        self.client = client

    def reserve(
        self,
        token: str,
        *,
        call_id: uuid.UUID,
        request_id: str,
        request_sha256: str,
        model_key: str,
        max_input_tokens: int,
        max_output_tokens: int,
    ) -> ReservedModelCall:
        claim = self.client.active(token)
        admission = SpendAdmission.from_claim(claim)
        execution = self._execution()
        request = ReserveModelSpendRequest(
            generation=claim.generation,
            callId=call_id,
            requestId=request_id,
            requestSha256=request_sha256,
            modelKey=model_key,
            priceVersion=admission.price_version,
            currency=admission.currency,
            maxInputTokens=max_input_tokens,
            maxOutputTokens=max_output_tokens,
        )
        headers = self.client.headers(f"model-spend:{execution}:{call_id}:reserve")
        result = AgentDbTransport().invoke(
            lambda: replay_once(
                lambda: self.client.attempt_api.reserve_model_spend(
                    execution,
                    token,
                    request,
                    _headers=headers,
                    _request_timeout=self.client.timeout,
                )
            ),
            operation="model spend reservation",
        )
        try:
            admission.verify_balance(result.balance)
            cost = money(result.reserved_cost)
            if (
                result.call_id != call_id
                or result.currency != admission.currency
                or result.price_version != admission.price_version
                or cost > admission.cap
            ):
                raise ValueError("Mismatched commitment")
        except CoordinationFailure:
            raise
        except (AttributeError, TypeError, ValueError):
            raise AgentDbReconciliationRequiredError(
                "Unconfirmed model spend reservation receipt"
            ) from None
        return ReservedModelCall(
            admission,
            claim.attempt_id,
            execution,
            claim.generation,
            call_id,
            request_sha256,
            max_input_tokens,
            max_output_tokens,
            cost,
        )

    def settle(
        self,
        token: str,
        reservation: ReservedModelCall,
        *,
        input_tokens: int,
        output_tokens: int,
        evidence_sha256: str,
    ) -> Decimal:
        self._verify_reservation(token, reservation)
        if any(
            type(count) is not int or not 0 <= count <= bound
            for count, bound in (
                (input_tokens, reservation.max_input_tokens),
                (output_tokens, reservation.max_output_tokens),
            )
        ):
            raise AgentDbReconciliationRequiredError(
                "Known usage within the reserved bounds is required"
            )
        request = SettleModelSpendRequest(
            generation=reservation.generation,
            actualInputTokens=input_tokens,
            actualOutputTokens=output_tokens,
            evidenceSha256=evidence_sha256,
        )
        headers = self.client.headers(
            f"model-spend:{reservation.execution_id}:{reservation.call_id}:settle"
        )
        result = AgentDbTransport().invoke(
            lambda: replay_once(
                lambda: self.client.attempt_api.settle_model_spend(
                    reservation.execution_id,
                    reservation.call_id,
                    token,
                    request,
                    _headers=headers,
                    _request_timeout=self.client.timeout,
                )
            ),
            operation="model spend settlement",
        )
        try:
            reservation.admission.verify_balance(result.balance)
            cost = money(result.actual_cost)
            if (
                result.call_id != reservation.call_id
                or cost > reservation.reserved_cost
            ):
                raise ValueError("Mismatched commitment")
        except CoordinationFailure:
            raise
        except (AttributeError, TypeError, ValueError):
            raise AgentDbReconciliationRequiredError(
                "Unconfirmed model spend settlement receipt"
            ) from None
        return cost

    def uncertain(
        self,
        token: str,
        reservation: ReservedModelCall,
        *,
        reason_sha256: str,
    ) -> None:
        self._verify_reservation(token, reservation)
        request = MarkModelSpendUncertainRequest(
            generation=reservation.generation,
            reasonSha256=reason_sha256,
        )
        headers = self.client.headers(
            f"model-spend:{reservation.execution_id}:{reservation.call_id}:uncertain"
        )
        result = AgentDbTransport().invoke(
            lambda: replay_once(
                lambda: self.client.attempt_api.mark_model_spend_uncertain(
                    reservation.execution_id,
                    reservation.call_id,
                    token,
                    request,
                    _headers=headers,
                    _request_timeout=self.client.timeout,
                )
            ),
            operation="model spend uncertainty",
        )
        try:
            reservation.admission.verify_balance(result.balance)
            if result.call_id != reservation.call_id or result.state != "uncertain":
                raise ValueError("Mismatched commitment")
        except CoordinationFailure:
            raise
        except (AttributeError, TypeError, ValueError):
            raise AgentDbReconciliationRequiredError(
                "Unconfirmed model spend uncertainty receipt"
            ) from None

    def _execution(self) -> uuid.UUID:
        if self.client.execution_id is None:
            raise AgentDbAuthorityError("Model spend needs a current execution")
        return uuid.UUID(self.client.execution_id)

    def _verify_reservation(self, token: str, value: ReservedModelCall) -> None:
        claim = self.client.active(token)
        if (
            claim.attempt_id != value.attempt_id
            or claim.generation != value.generation
            or self._execution() != value.execution_id
            or SpendAdmission.from_claim(claim) != value.admission
        ):
            raise AgentDbAuthorityError("Model spend reservation fence mismatch")
