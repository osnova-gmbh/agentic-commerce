"""Bounded Runtime checkpoint state; no transport credentials or payload text."""

from __future__ import annotations

import json
from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

from cogit_runtime.agentdb.decision_schema import DecisionSlot
from cogit_runtime.agentdb.errors import AgentDbAuthorityError

MAX_CONTINUATION_BYTES = 64 * 1024
MAX_MODEL_SLOTS = 128
Digest = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]
SlotKey = Annotated[
    str, Field(strict=True, pattern=r"^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$")
]
Count = Annotated[int, Field(strict=True, ge=0, le=1_000_000_000)]


class ContinuationValue(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ContinuationIdentity(ContinuationValue):
    tenant_id: UUID
    principal_id: UUID
    installation_id: UUID
    deployment_id: UUID
    pool_id: UUID
    agent_version_id: UUID
    parent_shape: Literal["run", "run_plus_task", "task"]
    run_id: UUID | None
    case_id: UUID | None = None
    task_id: UUID | None = None
    input_sha256: Digest
    processing_id: UUID | None = None
    processing_configuration_sha256: Digest | None = None

    @model_validator(mode="after")
    def exact_parent(self) -> ContinuationIdentity:
        if self.parent_shape == "task":
            valid = self.run_id is None and self.case_id and self.task_id
        elif self.parent_shape == "run_plus_task":
            valid = self.run_id and self.case_id and self.task_id
        else:
            valid = self.run_id and self.case_id is None and self.task_id is None
        if not valid:
            raise ValueError("Continuation parent identity is invalid")
        return self


class ModelCommitment(ContinuationValue):
    call_id: UUID
    request_id: SlotKey
    request_sha256: Digest
    model_key: Annotated[str, Field(strict=True, min_length=1, max_length=128)]
    max_input_tokens: Annotated[int, Field(strict=True, gt=0, le=1_000_000_000)]
    max_output_tokens: Annotated[int, Field(strict=True, gt=0, le=1_000_000_000)]


class ArtifactHash(ContinuationValue):
    hash: Digest


class ContinuationArtifact(ContinuationValue):
    id: UUID
    mime_type: Literal["application/json"]
    size: Annotated[int, Field(strict=True, ge=0, le=1024 * 1024)]
    metadata: ArtifactHash


class ModelUsage(ContinuationValue):
    input_tokens: Count
    output_tokens: Count
    total_tokens: Count | None = None
    cache_read_tokens: Count | None = None
    cache_write_tokens: Count | None = None
    model: Annotated[str, Field(strict=True, min_length=1, max_length=256)] | None = (
        None
    )
    provider: (
        Annotated[str, Field(strict=True, min_length=1, max_length=128)] | None
    ) = None


class ModelSlot(ContinuationValue):
    phase: Literal["prepared", "dispatch_intent", "completed"]
    commitment: ModelCommitment
    response: ContinuationArtifact | None = None
    actual_cost: (
        Annotated[
            str,
            Field(strict=True, pattern=r"^(?:0|[1-9][0-9]{0,17})(?:\.[0-9]{1,12})?$"),
        ]
        | None
    ) = None
    usage: ModelUsage | None = None

    @model_validator(mode="after")
    def complete_result(self) -> ModelSlot:
        result = (self.response, self.actual_cost, self.usage)
        if self.phase == "completed":
            if any(value is None for value in result):
                raise ValueError("Completed model slot lacks committed evidence")
        elif any(value is not None for value in result):
            raise ValueError("Incomplete model slot contains a result")
        return self


class PipelineSlot(ContinuationValue):
    phase: Literal["intent", "completed", "failed", "skipped", "cancelled", "escalated"]
    attempts: Annotated[int, Field(strict=True, ge=1, le=100)]
    idempotency: Literal["none", "inherent", "keyed"]
    invocation_key: (
        Annotated[str, Field(strict=True, min_length=1, max_length=256)] | None
    ) = None
    result: ContinuationArtifact | None = None

    @model_validator(mode="after")
    def validate_evidence(self) -> PipelineSlot:
        if (self.phase == "intent") != (self.result is None):
            raise ValueError("Pipeline slot result does not match its phase")
        if self.idempotency == "keyed" and self.invocation_key is None:
            raise ValueError("Keyed pipeline slot lacks its durable invocation key")
        return self


class PipelineContinuation(ContinuationValue):
    definition_sha256: Digest
    revision: Annotated[int, Field(strict=True, ge=0, le=10000)] = 0
    steps: Annotated[dict[SlotKey, PipelineSlot], Field(max_length=128)] = Field(
        default_factory=dict
    )


class LoopContinuation(ContinuationValue):
    definition_sha256: Digest
    initial: ContinuationArtifact
    snapshot: ContinuationArtifact
    snapshot_execution_id: Annotated[str, Field(min_length=1, max_length=128)]
    snapshot_queue_item_id: Annotated[str, Field(min_length=1, max_length=128)] | None
    original_execution_id: Annotated[str, Field(min_length=1, max_length=128)]
    original_queue_item_id: Annotated[str, Field(min_length=1, max_length=128)] | None
    started_ms: Annotated[int, Field(strict=True, ge=0, le=99999999999999)]
    deadline_ms: Annotated[int, Field(strict=True, ge=0, le=99999999999999)] | None


class LoopToolSlot(ContinuationValue):
    phase: Literal["intent", "completed"]
    commitment_sha256: Digest
    request: ContinuationArtifact
    idempotency: Literal["none", "inherent", "keyed"]
    invocation_key: Annotated[str, Field(min_length=1, max_length=256)] | None
    result: ContinuationArtifact | None = None

    @model_validator(mode="after")
    def evidence(self) -> LoopToolSlot:
        if (self.phase == "completed") != (self.result is not None):
            raise ValueError("Loop tool phase and result disagree")
        if self.idempotency == "keyed" and self.invocation_key is None:
            raise ValueError("Keyed loop tool lacks its resolved invocation key")
        return self


class RuntimeContinuation(ContinuationValue):
    format: Literal["cogit.runtime.continuation.v1"] = "cogit.runtime.continuation.v1"
    original_work_id: UUID
    identity: ContinuationIdentity
    execution_id: UUID
    revision: Annotated[int, Field(strict=True, ge=0, le=1_000_000_000)] = 0
    loops: Annotated[dict[SlotKey, LoopContinuation], Field(max_length=8)] = Field(
        default_factory=dict
    )
    loop_tools: Annotated[dict[SlotKey, LoopToolSlot], Field(max_length=128)] = Field(
        default_factory=dict
    )
    model_slots: Annotated[
        dict[SlotKey, ModelSlot], Field(max_length=MAX_MODEL_SLOTS)
    ] = Field(default_factory=dict)
    pipelines: Annotated[dict[SlotKey, PipelineContinuation], Field(max_length=8)] = (
        Field(default_factory=dict)
    )
    decisions: Annotated[dict[SlotKey, DecisionSlot], Field(max_length=128)] = Field(
        default_factory=dict
    )


def checkpoint_payload(state: RuntimeContinuation) -> dict[str, Any]:
    payload = {
        "format": "agentdb.checkpoint.v2",
        "resumeFormat": "agentdb.checkpoint.v2",
        "cursor": {"kind": state.format, "value": str(state.revision)},
        "completedActions": [],
        "pendingWaits": [],
        "pendingActions": [],
        "runtime": state.model_dump(mode="json"),
    }
    bounded_json(payload)
    return payload


def bounded_json(value: Any) -> bytes:
    # AgentDb materializes checkpoint jsonb::text inline on the replacement
    # claim, with a hard 64 KiB cap. Match its comma/colon spacing rather than
    # admitting compact JSON that expands beyond the producer's claim limit.
    # Strict continuation fields contain integers, strings and booleans only;
    # arbitrary business values and floating point numbers live in artifacts.
    try:
        body = json.dumps(
            value,
            sort_keys=True,
            separators=(", ", ": "),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, RecursionError):
        raise AgentDbAuthorityError(
            "Runtime continuation is not bounded JSON"
        ) from None
    if len(body) > MAX_CONTINUATION_BYTES:
        raise AgentDbAuthorityError("Runtime continuation exceeds its byte bound")
    return body
