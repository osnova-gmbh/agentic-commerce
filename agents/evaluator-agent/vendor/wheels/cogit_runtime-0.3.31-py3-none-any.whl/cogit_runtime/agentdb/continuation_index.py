"""Bounded artifact-backed journal encoding; the inline claim stays at 64 KiB."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from typing import Annotated, Any, Literal
from uuid import UUID

from cogit_agent_sdk.coordination import CoordinationFailure
from pydantic import Field, model_validator

from cogit_runtime.agentdb.continuation_schema import (
    ContinuationArtifact,
    ContinuationIdentity,
    ContinuationValue,
    Count,
    Digest,
    RuntimeContinuation,
    bounded_json,
)
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbReconciliationRequiredError,
)

MAX_INDEX_BYTES = 1024 * 1024
MAX_INDEX_ARTIFACTS = 400
INDEX_FORMAT = "cogit.runtime.journal.v1"
WIRE_FORMAT = "cogit.runtime.continuation.v2"
ArtifactSize = Annotated[int, Field(strict=True, ge=0, le=MAX_INDEX_BYTES)]
CompactArtifact = tuple[UUID, Digest, ArtifactSize]


class JournalIndex(ContinuationValue):
    format: Literal["cogit.runtime.journal.v1"] = INDEX_FORMAT
    state: RuntimeContinuation


class ContinuationRoot(ContinuationValue):
    format: Literal["cogit.runtime.continuation.v2"] = WIRE_FORMAT
    original_work_id: UUID
    identity: ContinuationIdentity
    execution_id: UUID
    revision: Count
    index: ContinuationArtifact
    artifacts: Annotated[list[CompactArtifact], Field(max_length=MAX_INDEX_ARTIFACTS)]

    @model_validator(mode="after")
    def exact_grants(self) -> ContinuationRoot:
        identities = [str(item[0]) for item in self.artifacts]
        if identities != sorted(set(identities)) or str(self.index.id) in identities:
            raise ValueError("Journal artifact grants must be unique and sorted")
        if self.index.size == 0:
            raise ValueError("Journal index must not be empty")
        return self


def artifact_grants(state: RuntimeContinuation) -> list[CompactArtifact]:
    """Enumerate only the existing six evidence positions, never arbitrary JSON."""
    references: dict[UUID, CompactArtifact] = {}

    def include(ref: ContinuationArtifact | None) -> None:
        if ref is None:
            return
        value = (ref.id, ref.metadata.hash, ref.size)
        if ref.id in references and references[ref.id] != value:
            raise AgentDbAuthorityError("Journal has conflicting artifact commitments")
        references[ref.id] = value
        if len(references) > MAX_INDEX_ARTIFACTS:
            raise AgentDbAuthorityError(
                "Journal artifact grant count exceeds its bound"
            )

    for model in state.model_slots.values():
        include(model.response)
    for pipeline in state.pipelines.values():
        for step in pipeline.steps.values():
            include(step.result)
    for loop in state.loops.values():
        include(loop.initial)
        include(loop.snapshot)
    for tool in state.loop_tools.values():
        include(tool.request)
        include(tool.result)
    return [references[key] for key in sorted(references, key=str)]


def encode_index(state: RuntimeContinuation) -> bytes:
    # Validate the complete explicit grant closure before making an artifact write.
    artifact_grants(state)
    body = JournalIndex(state=state).model_dump_json().encode("utf-8")
    if len(body) > MAX_INDEX_BYTES:
        raise AgentDbAuthorityError("Runtime journal index exceeds its byte bound")
    return body


def index_checkpoint(
    state: RuntimeContinuation, reference: ContinuationArtifact
) -> dict[str, Any]:
    root = ContinuationRoot(
        original_work_id=state.original_work_id,
        identity=state.identity,
        execution_id=state.execution_id,
        revision=state.revision,
        index=reference,
        artifacts=artifact_grants(state),
    )
    return root_checkpoint(root)


def root_checkpoint(root: ContinuationRoot) -> dict[str, Any]:
    payload = {
        "format": "agentdb.checkpoint.v2",
        "resumeFormat": "agentdb.checkpoint.v2",
        "cursor": {"kind": WIRE_FORMAT, "value": str(root.revision)},
        "completedActions": [],
        "pendingWaits": [],
        "pendingActions": [],
        "runtime": root.model_dump(mode="json"),
    }
    bounded_json(payload)
    return payload


def unique_json(body: bytes) -> Any:
    """Reject duplicate keys, non-JSON numbers and excessive structure."""

    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate journal JSON key")
            result[key] = value
        return result

    def invalid_number(value: str) -> None:
        raise ValueError("Non-JSON number")

    value = json.loads(
        body.decode("utf-8"), object_pairs_hook=unique, parse_constant=invalid_number
    )
    pending = [(value, 0)]
    count = 0
    while pending:
        item, depth = pending.pop()
        count += 1
        if depth > 32 or count > 100000:
            raise ValueError("Journal JSON structure exceeds its bound")
        if isinstance(item, dict):
            pending.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, list):
            pending.extend((child, depth + 1) for child in item)
    return value


def hydrate_index(
    root: ContinuationRoot, fetch: Callable[[ContinuationArtifact], bytes]
) -> RuntimeContinuation:
    """Read one authorized exact artifact, then verify all duplicated commitments."""
    try:
        body = fetch(root.index)
    except CoordinationFailure:
        raise
    except Exception:
        raise AgentDbReconciliationRequiredError(
            "Runtime journal index could not be verified"
        ) from None
    if (
        not isinstance(body, bytes)
        or len(body) > MAX_INDEX_BYTES
        or len(body) != root.index.size
        or hashlib.sha256(body).hexdigest() != root.index.metadata.hash
    ):
        raise AgentDbAuthorityError("Runtime journal index commitment mismatch")
    try:
        index = JournalIndex.model_validate(unique_json(body))
        state = index.state
        if (
            state.identity != root.identity
            or state.execution_id != root.execution_id
            or state.original_work_id != root.original_work_id
            or state.revision != root.revision
            or artifact_grants(state) != root.artifacts
        ):
            raise ValueError("Journal index does not match its root")
    except (ValueError, TypeError, RecursionError, UnicodeError):
        raise AgentDbAuthorityError("Incompatible Runtime journal index") from None
    return state
