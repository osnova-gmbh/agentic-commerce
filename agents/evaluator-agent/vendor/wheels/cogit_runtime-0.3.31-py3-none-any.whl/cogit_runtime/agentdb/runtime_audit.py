"""Bounded required observations for AgentDb's canonical runtime event ledger."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Literal
from uuid import UUID

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import ArtifactRef

from cogit_runtime.agentdb.errors import AgentDbError

AuditKind = Literal["lifecycle", "model", "tool", "decision"]
AuditDetail = str | int
_PHASES: dict[str, frozenset[str]] = {
    "lifecycle": frozenset({"started", "completed", "failed", "parked"}),
    "model": frozenset({"requested", "succeeded", "failed", "uncertain"}),
    "tool": frozenset({"requested", "succeeded", "failed", "uncertain"}),
    "decision": frozenset({"requested", "observed", "expired"}),
}
_CODE = re.compile(r"[a-z][a-z0-9._-]{0,127}")
_IDENTITY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}")
_HASH = re.compile(r"[0-9a-f]{64}")


class RequiredAuditError(AgentDbError, CoordinationFailure):
    """Required history is unconfirmed; protected work must stop."""


def audit_key(kind: AuditKind, identity: str, phase: str) -> str:
    """Derive identity from a durable logical call/decision, never its result."""
    if (
        type(identity) is not str
        or not identity
        or len(identity.encode("utf-8")) > 4096
    ):
        raise RequiredAuditError("Runtime audit identity is invalid")
    if phase not in _PHASES.get(kind, ()):
        raise RequiredAuditError("Runtime audit transition is unsupported")
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()
    return f"{kind}.{digest}.{phase}"


@dataclass(frozen=True)
class RuntimeAuditEvent:
    """Immutable exact body reused after an ambiguous response."""

    event_key: str
    kind: AuditKind
    phase: str
    _body: str

    @classmethod
    def create(
        cls,
        *,
        event_key: str,
        kind: AuditKind,
        phase: str,
        details: Mapping[str, AuditDetail] | None = None,
        payload_artifact: ArtifactRef | None = None,
    ) -> RuntimeAuditEvent:
        if (
            type(event_key) is not str
            or type(kind) is not str
            or type(phase) is not str
            or not _CODE.fullmatch(event_key)
            or phase not in _PHASES.get(kind, ())
        ):
            raise RequiredAuditError("Runtime audit transition is unsupported")
        if details is not None and not isinstance(details, Mapping):
            raise RequiredAuditError("Runtime audit details must be a bounded mapping")
        selected = dict(details or {})
        _validate_details(selected)
        body: dict[str, object] = {
            "eventKey": event_key,
            "kind": kind,
            "phase": phase,
            "details": selected,
        }
        if payload_artifact is not None:
            body["payloadArtifact"] = _artifact_commitment(payload_artifact)
        encoded = json.dumps(body, sort_keys=True, separators=(",", ":"))
        if len(encoded.encode("utf-8")) > 8192:
            raise RequiredAuditError("Runtime audit body exceeds its bound")
        return cls(event_key, kind, phase, encoded)

    def request(self, generation: int) -> dict[str, object]:
        if type(generation) is not int or not 1 <= generation <= 2147483647:
            raise RequiredAuditError("Runtime audit generation is invalid")
        return {**json.loads(self._body), "generation": generation}


def _validate_details(details: Mapping[str, AuditDetail]) -> None:
    for key, value in details.items():
        if key in {"operation", "tool", "reasonCode"}:
            valid = type(value) is str and _CODE.fullmatch(value) is not None
        elif key in {"model", "provider"}:
            valid = type(value) is str and _IDENTITY.fullmatch(value) is not None
        elif key in {"requestSha256", "resultSha256"}:
            valid = type(value) is str and _HASH.fullmatch(value) is not None
        elif key == "decisionId":
            valid = type(value) is str and _canonical_uuid(value)
        elif key in {"inputTokens", "outputTokens", "elapsedMs"}:
            limit = 86400000 if key == "elapsedMs" else 1000000000
            valid = type(value) is int and 0 <= value <= limit
        else:
            valid = False
        if not valid:
            raise RequiredAuditError("Runtime audit contains unsupported detail")


def _canonical_uuid(value: str) -> bool:
    try:
        return str(UUID(value)) == value
    except ValueError:
        return False


def _artifact_commitment(ref: ArtifactRef) -> dict[str, object]:
    if not isinstance(ref, ArtifactRef):
        raise RequiredAuditError("Runtime audit artifact commitment is invalid")
    digest = (ref.metadata or {}).get("hash")
    if type(digest) is str:
        digest = digest.removeprefix("sha256:")
    media_type = ref.mime_type
    if (
        not _canonical_uuid(ref.id)
        or type(digest) is not str
        or not _HASH.fullmatch(digest)
        or type(ref.size) is not int
        or not 1 <= ref.size <= 5000000
        or type(media_type) is not str
        or len(media_type) > 128
        or not re.fullmatch(r"[a-zA-Z0-9!#$&^_.+-]+/[a-zA-Z0-9!#$&^_.+-]+", media_type)
    ):
        raise RequiredAuditError("Runtime audit artifact commitment is invalid")
    return {
        "artifactId": ref.id,
        "sha256": digest,
        "byteLength": ref.size,
        "mediaType": media_type,
    }
