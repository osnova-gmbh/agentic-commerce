"""Typed, redacted errors for AgentDb worker coordination.

The worker adapter never copies AgentDb authorization or retry policy into
runtime business logic. What it *does* own is a faithful translation of
AgentDb responses into typed local errors so the runtime can decide how to
react, plus a retryability classification that is safe to surface.

Every error is redaction-safe: ``str(error)`` and ``repr(error)`` never
include the plaintext attempt token, worker credential, or authorization
header values.
"""

from __future__ import annotations

from http.client import HTTPException
from typing import Any
from urllib.error import URLError

from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.error_metadata import (
    ErrorMetadata,
    diagnostic_summary,
    exception_metadata,
)


class AgentDbError(Exception):
    """Base class for redacted AgentDb authority and domain errors."""

    retryable: bool = False

    def __init__(
        self,
        message: str,
        *,
        retryable: bool | None = None,
        response_metadata: ErrorMetadata | None = None,
    ) -> None:
        self.response_metadata = response_metadata or ErrorMetadata()
        summary = diagnostic_summary(self.response_metadata)
        super().__init__(f"{message} ({summary})" if summary else message)
        self.code = self.response_metadata.code
        self.correlation_id = self.response_metadata.correlation_id
        self.http_status = self.response_metadata.http_status
        if retryable is not None:
            self.retryable = retryable


class AgentDbConfigError(AgentDbError):
    """AgentDb is not configured or its configuration is invalid."""


class AgentDbVersionMismatch(AgentDbError):  # noqa: N818
    """The connected AgentDb API version is not compatible with the runtime."""


class AgentDbAuthenticationError(AgentDbError):
    """Pool-worker credential was rejected (401)."""


class AgentDbAuthorizationError(AgentDbError):
    """Pool-worker credential was accepted but lacked permission (403)."""


class AgentDbConflictError(AgentDbError):
    """A revision, transition or replay conflict (409), ordinary by default.

    Only the explicit lease-loss subtype implements CoordinationFailure.
    """


class AgentDbLeaseLostError(AgentDbConflictError, CoordinationFailure):
    """The active attempt fence is no longer owned by this worker."""


class AgentDbNotFoundError(AgentDbError):
    """The requested attempt, run, execution, or artifact does not exist."""


class AgentDbTimeoutError(AgentDbError):
    """A request to AgentDb timed out. Retryable only for idempotent reads.

    The coordinator never retries mutating commands blindly; a timeout on a
    mutation requires canonical reconciliation before any further dispatch.
    """

    def __init__(
        self,
        message: str,
        *,
        retryable: bool = False,
        response_metadata: ErrorMetadata | None = None,
    ) -> None:
        super().__init__(
            message, retryable=retryable, response_metadata=response_metadata
        )


class AgentDbCancelledError(AgentDbError):
    """AgentDb signalled cooperative cancellation for the attempt."""


class AgentDbCancellationRejectedError(AgentDbCancelledError, CoordinationFailure):
    """The runtime no longer owned the execution AgentDb asked it to cancel."""


class AgentDbReconciliationRequiredError(AgentDbError, CoordinationFailure):
    """A mutating request had an uncertain outcome and must be reconciled."""


class AgentDbAttemptContextError(AgentDbError):
    """An attempt-scoped request has invalid context or domain input."""


class AgentDbAuthorityError(AgentDbAttemptContextError, CoordinationFailure):
    """The current attempt or execution authority is missing or mismatched."""


def _classify_status(status: int | None) -> str:
    if status == 401:
        return "authentication"
    if status == 403:
        return "authorization"
    if status == 404:
        return "not_found"
    if status == 409:
        return "conflict"
    if status == 408 or status == 504:
        return "timeout"
    if status is not None and status >= 500:
        return "transient"
    return "unknown"


def classify(exception: BaseException) -> AgentDbError:
    """Translate a generated-client exception into a typed local error.

    The generated client exposes HTTP status on its AgentDbError. We map
    those statuses to local errors and attach a conservative
    retryability hint. Only idempotent/read operations are retryable; the
    coordinator applies further policy on top of this hint.
    """

    if isinstance(exception, AgentDbError):
        return exception
    # Avoid a hard import of the generated client at module load: this module
    # must stay importable when the client is not installed (unit tests use a
    # fake client). We inspect by class name, which is stable for generated
    # output.
    class_name = type(exception).__name__
    status = getattr(exception, "status", None)
    body = getattr(exception, "body", None)

    kind = _classify_status(status if isinstance(status, int) else None)
    if class_name in {"AgentDbProtocolError", "ValidationError", "JSONDecodeError"}:
        kind = "transient"
    if type(exception).__module__.startswith("urllib3."):
        kind = "transient"
    if isinstance(exception, (ConnectionError, HTTPException)):
        kind = "transient"
    if isinstance(exception, URLError):
        kind = "timeout" if isinstance(exception.reason, TimeoutError) else "transient"
    if kind == "unknown" and "timeout" in class_name.lower():
        kind = "timeout"

    detail = _redacted_detail(exception, body)
    metadata = exception_metadata(exception)
    if kind == "authentication":
        return AgentDbAuthenticationError(detail, response_metadata=metadata)
    if kind == "authorization":
        return AgentDbAuthorizationError(detail, response_metadata=metadata)
    if kind == "not_found":
        return AgentDbNotFoundError(detail, response_metadata=metadata)
    if kind == "conflict":
        if error_code(exception) == "stale_attempt":
            return AgentDbLeaseLostError(detail, response_metadata=metadata)
        return AgentDbConflictError(detail, response_metadata=metadata)
    if kind == "timeout":
        return AgentDbTimeoutError(detail, response_metadata=metadata)
    if kind == "transient":
        message = detail or f"AgentDb service error ({class_name})"
        # Transient 5xx on a read is retryable; the caller narrows further.
        return AgentDbError(
            message,
            retryable=metadata.retryable if metadata.retryable is not None else True,
            response_metadata=metadata,
        )
    message = detail or f"AgentDb error ({class_name})"
    return AgentDbError(message, response_metadata=metadata)


def error_code(exception: BaseException) -> str | None:
    """Extract a flat canonical code without retaining untrusted response text."""
    return exception_metadata(exception).code


def _redacted_detail(exception: BaseException, body: Any) -> str:
    # Generated-client messages and bodies can include request/response details.
    # Report only structural information that cannot contain credentials.
    _ = body
    class_name = type(exception).__name__
    status = getattr(exception, "status", None)
    if isinstance(status, int):
        return f"AgentDb request failed with HTTP {status} ({class_name})"
    return f"AgentDb request failed ({class_name})"
