"""Collect bounded HTTPX bodies before response cleanup selects an outcome."""

from __future__ import annotations

import sys
from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager, contextmanager

import httpx
from cogit_agent_sdk.coordination import CoordinationFailure

from cogit_runtime.agentdb.errors import AgentDbError
from cogit_runtime.coordination import finish_cleanup


class _ResponseStream(httpx.SyncByteStream):
    def __init__(self, source: httpx.SyncByteStream) -> None:
        self.source = source
        self.close_error: BaseException | None = None

    def __iter__(self) -> Iterator[bytes]:
        yield from self.source

    def close(self) -> None:
        # HTTPX closes at raw iterator exhaustion, before decoder/chunker flush.
        # Retain only that cleanup failure so the complete body can be classified.
        try:
            self.source.close()
        except BaseException as exc:
            self.close_error = exc

    def raise_close_error(self) -> None:
        if self.close_error is not None:
            raise self.close_error


@contextmanager
def collected_response(
    stream: AbstractContextManager[httpx.Response],
    *,
    limit: int,
    oversized: Callable[[int], BaseException],
) -> Iterator[tuple[int, bytes]]:
    """Preserve complete classified errors; incomplete reads remain transport loss."""
    response = stream.__enter__()
    if not isinstance(response.stream, httpx.SyncByteStream):
        raise TypeError("Database response requires a synchronous byte stream")
    owned = _ResponseStream(response.stream)
    response.stream = owned
    complete = False
    try:
        body = bytearray()
        for chunk in response.iter_bytes(chunk_size=4096):
            body.extend(chunk)
            if len(body) > limit:
                raise oversized(response.status_code)
        complete = True
        yield response.status_code, bytes(body)
    finally:
        primary = sys.exception()
        try:
            finish_cleanup(
                lambda: stream.__exit__(*sys.exc_info()), owned.raise_close_error
            )
        except CoordinationFailure:
            raise
        except BaseException:
            if not (
                isinstance(primary, httpx.TransportError)
                or (complete and isinstance(primary, AgentDbError))
            ):
                raise
