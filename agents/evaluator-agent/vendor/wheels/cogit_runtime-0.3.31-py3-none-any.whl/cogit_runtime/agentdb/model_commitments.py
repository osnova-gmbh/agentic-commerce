"""Bounded commitments for the actual selected provider, independent of attempts."""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from dataclasses import dataclass

from cogit_agent_sdk.types import ModelDescriptor, ModelRequest, Usage

from cogit_runtime.agentdb.errors import AgentDbAuthorityError

_CALL_NAMESPACE = uuid.UUID("5a687383-6d91-599f-95bd-df236642a344")
_SLOT = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}\Z")
_MODEL_KEY = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,127}\Z")
MAX_REQUEST_BYTES = 1024 * 1024


@dataclass(frozen=True, slots=True)
class ModelCommitment:
    call_id: uuid.UUID
    request_id: str
    request_sha256: str
    model_key: str
    max_input_tokens: int
    max_output_tokens: int


def prepare_model_request(
    original_work_id: uuid.UUID,
    slot_key: str,
    selected: ModelDescriptor,
    request: ModelRequest,
) -> tuple[ModelCommitment, ModelRequest]:
    """Reserve a full context bound and enforce the chosen output bound on wire.

    The configured descriptor is trusted deployment input, not request metadata.
    The reviewed D12 rate key is exactly ``provider:model``; there is no alias
    supplied by a caller which could select a cheaper price for another model.
    """
    if (
        not isinstance(original_work_id, uuid.UUID)
        or _SLOT.fullmatch(slot_key) is None
        or re.fullmatch(r"[a-z][a-z0-9-]*", selected.provider) is None
    ):
        raise AgentDbAuthorityError("Model dispatch requires a stable admitted slot")
    model_key = f"{selected.provider}:{selected.model}"
    if _MODEL_KEY.fullmatch(model_key) is None:
        raise AgentDbAuthorityError("Model price identity is not representable")
    if request.model is not None and (
        request.model.provider != selected.provider
        or request.model.model != selected.model
    ):
        raise AgentDbAuthorityError("Requested and selected model identities differ")
    input_bound = selected.context_window
    output_bound = selected.max_output_tokens
    if any(
        type(bound) is not int or not 0 < bound <= 1_000_000_000
        for bound in (
            input_bound,
            output_bound,
        )
    ):
        raise AgentDbAuthorityError("Selected model requires known token bounds")
    assert input_bound is not None and output_bound is not None
    if request.max_output_tokens is not None:
        if type(request.max_output_tokens) is not int or not (
            0 < request.max_output_tokens <= output_bound
        ):
            raise AgentDbAuthorityError("Requested output exceeds selected model bound")
        output_bound = request.max_output_tokens
    reasoning_cap = request.reasoning_max_tokens
    if reasoning_cap is not None and (
        selected.provider != "openrouter"
        or type(reasoning_cap) is not int
        or not 0 < reasoning_cap < output_bound
    ):
        raise AgentDbAuthorityError(
            "Reasoning budget requires OpenRouter and a larger total output bound"
        )
    # JSON round-trip isolates provider input without deepcopying the SDK's
    # immutable tool schemas (FrozenDict intentionally rejects that mutation).
    # Bind the same selected descriptor/output limit used for pricing.
    try:
        body = json.dumps(
            {
                **request.model_dump(mode="json"),
                "model": selected.model_dump(mode="json"),
                "max_output_tokens": output_bound,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (ValueError, TypeError):
        raise AgentDbAuthorityError(
            "Model request cannot form an exact commitment"
        ) from None
    if len(body) > MAX_REQUEST_BYTES:
        raise AgentDbAuthorityError("Model request exceeds its bounded commitment size")
    bound = ModelRequest.model_validate_json(body)
    call_id = uuid.uuid5(_CALL_NAMESPACE, f"v1:{original_work_id}:{slot_key}")
    return ModelCommitment(
        call_id=call_id,
        request_id=f"runtime-model:{call_id}",
        request_sha256=hashlib.sha256(body).hexdigest(),
        model_key=model_key,
        max_input_tokens=input_bound,
        max_output_tokens=output_bound,
    ), bound


def usage_commitment(usage: Usage, model: ModelDescriptor) -> tuple[int, int, str]:
    """Charge normalized input categories at the reviewed conservative input rate.

    SDK Anthropic usage separates cache tokens; OpenAI usage includes its prompt
    total in input_tokens and leaves the separate cache counters zero. D12 has
    one reviewed input rate and does not use floating-point SDK cost estimates.
    """
    counts = (
        usage.input_tokens,
        usage.output_tokens,
        usage.cache_read_tokens,
        usage.cache_write_tokens,
    )
    if any(
        type(count) is not int or not 0 <= count <= 1_000_000_000 for count in counts
    ):
        raise AgentDbAuthorityError("Model usage must contain known token counts")
    if usage.provider not in (None, model.provider) or usage.model not in (
        None,
        model.model,
    ):
        raise AgentDbAuthorityError("Model usage identity differs from its reservation")
    evidence = json.dumps(
        {
            "format": "cogit.model-usage.v1",
            "provider": model.provider,
            "model": model.model,
            "inputTokens": counts[0],
            "outputTokens": counts[1],
            "cacheReadTokens": counts[2],
            "cacheWriteTokens": counts[3],
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return (
        counts[0] + counts[2] + counts[3],
        counts[1],
        hashlib.sha256(evidence).hexdigest(),
    )
