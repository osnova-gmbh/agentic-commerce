"""Tenant-authorized host operations; worker credentials never enter this adapter."""

from __future__ import annotations

import hashlib
import uuid
from typing import Any

from agentdb_client import (
    AllocateArtifactUploadRequest,
    ApiClient,
    Configuration,
    FinalizeArtifactUploadRequest,
)
from agentdb_client.api.client_api import ClientApi
from agentdb_client.api.tenant_admin_api import TenantAdminApi
from agentdb_client.exceptions import ApiException
from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import ArtifactRef
from pydantic import BaseModel, ConfigDict, Field, SecretStr

from cogit_runtime.agentdb.current_artifacts import MAX_ARTIFACT_BYTES, MEDIA_TYPES
from cogit_runtime.agentdb.database_http import DatabaseHttp
from cogit_runtime.agentdb.errors import (
    AgentDbConflictError,
    AgentDbError,
    AgentDbNotFoundError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.agentdb.host_governance import HostGovernance
from cogit_runtime.agentdb.host_processing import HostProcessing
from cogit_runtime.agentdb.transport import AgentDbTransport
from cogit_runtime.coordination import finish_cleanup


class AgentDbHostConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    url: str = Field(pattern=r"^https?://", min_length=8)
    tenant_id: uuid.UUID
    token: SecretStr
    connect_timeout: float = Field(default=10.0, gt=0, le=300)
    read_timeout: float = Field(default=30.0, gt=0, le=300)


class AgentDbHost(HostProcessing):
    """Host-only durable admission and artifact port, using a tenant OIDC token."""

    def __init__(self, config: AgentDbHostConfig) -> None:
        self.config = config
        self.http = ApiClient(
            Configuration(
                host=config.url.rstrip("/"),
                access_token=config.token.get_secret_value(),
                retries=0,
            )
        )
        self.api = ClientApi(self.http)
        self.admin = TenantAdminApi(self.http)
        self.transport = AgentDbTransport()
        self.timeout = (config.connect_timeout, config.read_timeout)
        self.database_http = DatabaseHttp(config.url, config.token.get_secret_value())
        self.governance = HostGovernance(self.database_http)

    def close(self) -> None:
        self.database_http.close()
        self.http.rest_client.pool_manager.clear()

    def _call(self, method: Any, *args: Any, read: bool = False) -> Any:
        return self.transport.invoke(
            lambda: method(
                *args,
                _request_timeout=self.timeout,
                _headers={
                    "x-agentdb-api-version": "0.1.0",
                    "x-agentdb-sdk": "1/0.1.11",
                },
            ),
            idempotent=read,
            operation="host-request",
        )

    def put_artifact(self, body: bytes, media_type: str, key: str) -> ArtifactRef:
        if (
            type(body) is not bytes
            or len(body) > MAX_ARTIFACT_BYTES
            or media_type not in MEDIA_TYPES
        ):
            raise AgentDbError("Invalid bounded host artifact")
        digest = hashlib.sha256(body).hexdigest()
        identity = hashlib.sha256(f"{key}:{media_type}:{digest}".encode()).hexdigest()
        allocation = self._call(
            self.api.allocate_artifact_upload,
            f"cogit:upload:{identity}",
            AllocateArtifactUploadRequest(
                mediaType=media_type,
                classification="restricted",
                sha256=digest,
                byteLength=len(body),
            ),
        )
        try:
            receipt = self._call(
                self.api.put_artifact_upload_content, allocation.upload_id, body
            )
        except CoordinationFailure:
            raise
        except (AgentDbConflictError, AgentDbNotFoundError):
            # A replay may find an already finalized upload whose temporary
            # object was collected (404) or is no longer writable (409).
            # Only server-validated finalization can resolve it; the
            # immutable commitment below stays identical.
            pass
        else:
            if (
                receipt.upload_id != allocation.upload_id
                or receipt.sha256 != digest
                or receipt.size != len(body)
            ):
                raise AgentDbReconciliationRequiredError(
                    "Host upload commitment mismatch"
                )
        result = self._call(
            self.api.finalize_artifact_upload,
            allocation.upload_id,
            f"cogit:finalize:{identity}",
            FinalizeArtifactUploadRequest(sha256=digest, byteLength=len(body)),
        )
        if (
            result.sha256 != digest
            or result.byte_length != len(body)
            or result.media_type != media_type
        ):
            raise AgentDbReconciliationRequiredError(
                "Host artifact commitment mismatch"
            )
        return ArtifactRef(
            id=str(result.artifact_id),
            name=key,
            mime_type=media_type,
            size=len(body),
            metadata={"hash": digest, "classification": result.classification},
        )

    def read_artifact(self, ref: ArtifactRef, max_bytes: int) -> bytes:
        if type(max_bytes) is not int or not 0 < max_bytes <= MAX_ARTIFACT_BYTES:
            raise AgentDbError("Invalid host artifact read bound")
        artifact_id = uuid.UUID(ref.id)
        metadata = self._call(self.api.get_artifact, artifact_id, read=True)
        digest = str((ref.metadata or {}).get("hash", "")).removeprefix("sha256:")
        if (
            metadata.artifact_id != artifact_id
            or metadata.media_type not in MEDIA_TYPES
            or metadata.byte_length > max_bytes
            or (ref.size is not None and ref.size != metadata.byte_length)
            or (ref.mime_type is not None and ref.mime_type != metadata.media_type)
            or (digest and digest != metadata.sha256)
        ):
            raise AgentDbError("Host artifact reference commitment mismatch")

        def fetch() -> bytes:
            response = self.api.get_artifact_bytes_without_preload_content(
                artifact_id,
                _request_timeout=self.timeout,
                _headers={
                    "x-agentdb-api-version": "0.1.0",
                    "x-agentdb-sdk": "1/0.1.11",
                },
            )
            try:
                if response.status != 200:
                    raise ApiException(
                        status=response.status,
                        body=response.read(amt=8193).decode("utf-8", errors="replace"),
                    )
                body = response.read(amt=max_bytes + 1)
            finally:
                finish_cleanup(response.close, response.release_conn)
            if (
                len(body) != metadata.byte_length
                or hashlib.sha256(body).hexdigest() != metadata.sha256
            ):
                raise AgentDbError("Host artifact bytes do not match the commitment")
            return body

        return self.transport.invoke(
            fetch, idempotent=True, operation="host-artifact-read"
        )
