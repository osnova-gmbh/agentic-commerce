"""Bounded structural diagnostics without retaining server messages or bodies."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from uuid import UUID

_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}", re.ASCII)
_DISPLAY_CODES = frozenset(
    {
        "authentication_required",
        "permission_denied",
        "tenant_scope_violation",
        "not_found",
        "version_conflict",
        "idempotency_conflict",
        "stale_attempt",
        "invalid_transition",
        "policy_denied",
        "approval_required",
        "validation_failed",
        "database_timeout",
        "database_response_timeout",
        "route_not_found",
        "ambiguous_route",
        "completion_requirements_unmet",
        "action_reconciliation_required",
        "capability_not_installed",
    }
)


@dataclass(frozen=True)
class ErrorMetadata:
    code: str | None = None
    correlation_id: str | None = None
    http_status: int | None = None
    retryable: bool | None = None


def diagnostic_summary(metadata: ErrorMetadata) -> str:
    """Safe for ordinary exception output, including worker startup failures."""
    parts = []
    if isinstance(metadata.code, str) and metadata.code in _DISPLAY_CODES:
        parts.append(f"code={metadata.code}")
    safe = response_metadata(
        metadata.http_status,
        {
            "correlationId": metadata.correlation_id,
        },
    )
    if safe.correlation_id is not None:
        parts.append(f"correlation_id={safe.correlation_id}")
    if safe.http_status is not None:
        parts.append(f"http_status={safe.http_status}")
    return ", ".join(parts)


def response_metadata(status: int | None, value: object) -> ErrorMetadata:
    """Accept only flat protocol fields; never inspect free-form messages."""
    code = (
        value.get("code") if isinstance(value, dict) else getattr(value, "code", None)
    )
    correlation = (
        value.get("correlationId")
        if isinstance(value, dict)
        else getattr(value, "correlation_id", None)
    )
    retryable = (
        value.get("retryable")
        if isinstance(value, dict)
        else getattr(value, "retryable", None)
    )
    safe_code = code if isinstance(code, str) and _CODE.fullmatch(code) else None
    safe_id = None
    if isinstance(correlation, UUID):
        safe_id = str(correlation)
    elif isinstance(correlation, str) and len(correlation) == 36:
        try:
            safe_id = str(UUID(correlation))
        except ValueError:
            pass
    return ErrorMetadata(
        code=safe_code,
        correlation_id=safe_id,
        http_status=status if type(status) is int and 100 <= status <= 599 else None,
        retryable=retryable if type(retryable) is bool else None,
    )


def exception_metadata(exception: BaseException) -> ErrorMetadata:
    existing = getattr(exception, "response_metadata", None)
    if isinstance(existing, ErrorMetadata):
        return existing
    status = getattr(exception, "status", None)
    data = getattr(exception, "data", None)
    if data is not None:
        return response_metadata(status, data)
    body = getattr(exception, "body", None)
    value: object = None
    if isinstance(body, (str, bytes)) and len(body) <= 262144:
        try:
            if not isinstance(body, str) or len(body.encode("utf-8")) <= 262144:
                value = json.loads(body)
        except (ValueError, UnicodeError, RecursionError):
            pass
    return response_metadata(status, value)
