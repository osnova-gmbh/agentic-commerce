"""Persist resolved logical tool identity before the existing broker dispatch."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.loop.tool_execution import invalid_arguments_result
from cogit_agent_sdk.operations.contract import OperationError
from cogit_agent_sdk.types import Context, ToolCall, ToolResult, WorkOutcome
from pydantic import ValidationError

from cogit_runtime.agentdb import loop_artifacts
from cogit_runtime.agentdb.continuation_schema import LoopToolSlot
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.agentdb.loop_recovery import CanonicalLoopRecovery
from cogit_runtime.agentdb.runtime_audit import audit_key
from cogit_runtime.operations.executor_support import (
    missing_capabilities,
    resolve_idempotency_key,
)
from cogit_runtime.policy import RuntimePolicyGate


class CanonicalLoopTools:
    def __init__(
        self,
        recovery: CanonicalLoopRecovery,
        broker: Any,
        policy: RuntimePolicyGate | None = None,
    ) -> None:
        self.recovery, self.broker = recovery, broker
        self.policy = policy

    def prepare(
        self, call: ToolCall, context: Context, allowed: set[str]
    ) -> tuple[str, LoopToolSlot, dict[str, Any]] | ToolResult | None:
        self.recovery.cancellation.throw_if_cancelled()
        binding = self.broker.registry.get(call.tool_name)
        if binding is None or call.tool_name not in allowed:
            return None
        error = missing_capabilities(
            binding.descriptor.requirements, call.tool_name, context
        )
        if error is not None:
            raise OperationError(error)
        slot = self.recovery.tool_slot(call)
        commitment = loop_artifacts.digest(
            {
                "name": call.tool_name,
                "arguments": call.arguments,
                "descriptor": binding.descriptor.model_dump(mode="json"),
            }
        )
        previous = self.recovery.journal.read_loop_tool(slot)
        if previous is None:
            try:
                prepared = self.broker._prepare_arguments(
                    binding, dict(call.arguments), context
                )
                validated = binding.operation.input_model.model_validate(prepared)
            except CoordinationFailure:
                raise
            except ValidationError as exc:
                # No durable intent or tool effect exists yet. Let the model
                # correct this call inside the same admitted execution.
                return invalid_arguments_result(
                    tool_call_id=call.id,
                    tool_name=call.tool_name,
                    error=exc,
                    input_model=binding.operation.input_model,
                )
            key, error = resolve_idempotency_key(
                key_for=binding.key_for,
                request=validated,
                context=context,
                supplied_key="cogit:tool:v1:"
                + hashlib.sha256(
                    f"{self.recovery.journal.original_work_id}:{slot}".encode()
                ).hexdigest()
                if binding.descriptor.idempotency == "keyed"
                else None,
                key_source="generated",
                idempotency=binding.descriptor.idempotency,
                exposure_name=call.tool_name,
            )
            if error is not None:
                raise OperationError(error)
            payload = validated.model_dump(mode="json", by_alias=True)
            request = loop_artifacts.save(
                self.recovery.handle,
                loop_artifacts.encoded(payload),
                slot_key=f"{slot}/request",
            )
            record = LoopToolSlot(
                phase="intent",
                commitment_sha256=commitment,
                request=request,
                idempotency=binding.descriptor.idempotency,
                invocation_key=key,
            )
            self.recovery.journal.write_loop_tool(
                slot, record.model_dump(mode="json"), expected_phase=None
            )
        else:
            try:
                record = LoopToolSlot.model_validate(previous)
            except CoordinationFailure:
                raise
            except ValidationError:
                raise AgentDbAuthorityError(
                    "Persisted tool record does not match its committed contract"
                ) from None
            if record.commitment_sha256 != commitment:
                raise AgentDbAuthorityError(
                    "Canonical loop tool contract or arguments changed"
                )
            if record.phase == "intent" and record.idempotency == "none":
                raise AgentDbReconciliationRequiredError(
                    "Interrupted unkeyed loop tool cannot be replayed"
                )
            try:
                payload = json.loads(
                    loop_artifacts.read(self.recovery.handle, record.request)
                )
                binding.operation.input_model.model_validate(payload)
            except CoordinationFailure:
                raise
            except (ValueError, UnicodeError, RecursionError):
                raise AgentDbAuthorityError(
                    "Persisted tool request does not match its committed contract"
                ) from None
        self.recovery.cancellation.throw_if_cancelled()
        # This required write also checks the fresh canonical attempt before
        # either a new effect or cached result is handed to the SDK.
        self.observe(slot, "requested", record)
        return slot, record, payload

    def cached(
        self, call: ToolCall, prepared: tuple[str, LoopToolSlot, dict[str, Any]]
    ) -> ToolResult | None:
        slot, record, _ = prepared
        if record.phase != "completed":
            return None
        assert record.result is not None
        try:
            payload = json.loads(
                loop_artifacts.read(self.recovery.handle, record.result)
            )
            if not isinstance(payload, dict) or set(payload) != {
                "result",
                "work_outcome",
            }:
                raise ValueError
            result = ToolResult.model_validate(payload["result"])
            outcome = (
                WorkOutcome.model_validate(payload["work_outcome"])
                if payload["work_outcome"] is not None
                else None
            )
            if result.tool_call_id != call.id or result.tool_name != call.tool_name:
                raise ValueError
        except (ValueError, TypeError):
            raise AgentDbAuthorityError(
                "Cached tool result does not match its logical slot"
            ) from None
        if self.policy is not None:
            binding = self.broker.registry.get(call.tool_name)
            if binding is None:
                raise AgentDbAuthorityError("Cached tool has no current descriptor")
            self.policy.require(
                self.recovery.handle,
                self.policy.checkpoint(
                    phase="checkpoint",
                    operation=self.policy.operation(
                        call.tool_name, binding.descriptor.requirements, "tool"
                    ),
                    payload=prepared[2],
                    slot=slot,
                    result=result.model_dump(mode="json"),
                    state="completed",
                ),
            )
        self.observe(slot, "failed" if result.is_error else "succeeded", record)
        if outcome is not None:
            self.recovery.handle.set_work_outcome(outcome)
        return result

    def complete(
        self, prepared: tuple[str, LoopToolSlot, dict[str, Any]], result: ToolResult
    ) -> None:
        slot, record, _ = prepared
        self.recovery.cancellation.throw_if_cancelled()
        outcome = getattr(self.recovery.handle, "work_outcome", None)
        artifact = loop_artifacts.save(
            self.recovery.handle,
            loop_artifacts.encoded(
                {
                    "result": result.model_dump(mode="json"),
                    "work_outcome": outcome.model_dump(mode="json")
                    if outcome
                    else None,
                }
            ),
            slot_key=f"{slot}/result",
        )
        candidate = record.model_copy(update={"phase": "completed", "result": artifact})
        self.observe(slot, "failed" if result.is_error else "succeeded", candidate)
        self.recovery.journal.write_loop_tool(
            slot, candidate.model_dump(mode="json"), expected_phase="intent"
        )

    def observe(self, slot: str, phase: str, record: LoopToolSlot) -> None:
        self.recovery.handle.record_runtime_audit(
            event_key=audit_key("tool", slot, phase),
            kind="tool",
            phase=phase,
            details={
                "requestSha256": record.commitment_sha256,
                **(
                    {"resultSha256": record.result.metadata.hash}
                    if record.result and phase != "requested"
                    else {}
                ),
            },
        )
