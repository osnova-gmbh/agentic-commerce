"""Production worker loop for fenced AgentDb attempts."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine
from datetime import UTC, datetime
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import Context, RunRequest, RunResult, WorkOutcome

from cogit_runtime.agentdb.coordinator import AgentDbCoordinator, ClaimedWork
from cogit_runtime.agentdb.current_decisions import DecisionParkRequiredError
from cogit_runtime.agentdb.errors import AgentDbAuthorityError, AgentDbError
from cogit_runtime.agentdb.supervision import ClaimSupervisor
from cogit_runtime.agentdb.translate import (
    claimed_work_to_run_request,
    execution_metadata,
)
from cogit_runtime.cancellation import await_runtime_completion
from cogit_runtime.config import WorkerConfig
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.readiness import reject_unreserved_claim_cap
from cogit_runtime.reporter import RunReporter
from cogit_runtime.worker import WorkerStats

AgentDbRunExecutor = Callable[
    [RunRequest, Context, RunReporter, str],
    Coroutine[Any, Any, RunResult],
]
CancelExecution = Callable[[str], bool]
ValidateRunRequest = Callable[[RunRequest, Context], None]


def claim_heartbeat_interval(expires_at: datetime, configured: float) -> float:
    """Keep the AgentDb delivery alive inside its 60-second queue heartbeat window."""
    remaining = (expires_at - datetime.now(UTC)).total_seconds()
    return min(configured, max(0.1, remaining / 3), 20.0)


class AgentDbWorker:
    """Claim and execute one fenced AgentDb attempt at a time."""

    def __init__(
        self,
        *,
        coordinator: AgentDbCoordinator,
        config: WorkerConfig,
        executor: AgentDbRunExecutor,
        reporter: RunReporter,
        default_agent_id: str,
        cancel_execution: CancelExecution,
        validate_run_request: ValidateRunRequest,
        heartbeat_interval_seconds: float | None = None,
    ) -> None:
        if config.concurrency != 1:
            raise RuntimeConfigurationError(
                "Production AgentDb workers require worker.concurrency=1"
            )
        self._coordinator = coordinator
        self._config = config
        self._executor = executor
        self._reporter = reporter
        self._default_agent_id = default_agent_id
        self._cancel_execution = cancel_execution
        self._validate_run_request = validate_run_request
        self._heartbeat_interval = heartbeat_interval_seconds or max(
            1.0, config.lease_seconds / 3
        )
        self._stop = asyncio.Event()
        self._poll_lock = asyncio.Lock()
        self._current_execution_id: str | None = None
        self._close_task: asyncio.Task[None] | None = None

    async def poll_once(self) -> WorkerStats:
        """Claim at most one attempt and execute its configured agent once."""

        # Production uses one fenced coordinator/session. Never claim a second
        # item while the first still owns a worker task or deferred drain.
        if self._stop.is_set() or self._poll_lock.locked():
            return WorkerStats()
        async with self._poll_lock:
            if self._stop.is_set():
                return WorkerStats()
            claimed = await self._coordinator.claim_work(
                lease_seconds=self._config.lease_seconds
            )
            if claimed is None:
                return WorkerStats()
            if self._stop.is_set():
                # A claim response may race shutdown. Do not start business work;
                # its unstarted attempt remains recoverable through lease expiry.
                return WorkerStats(claimed=1)
            return await self._run_claimed(claimed)

    async def run_forever(self) -> None:
        """Process claims, propagating typed coordination failures to the host."""

        while not self._stop.is_set():
            stats = await self.poll_once()
            if stats.claimed == 0:
                await self._back_off()

    def request_stop(self) -> None:
        """Stop claiming new attempts after the active poll completes."""

        self._stop.set()

    async def close(self) -> None:
        """Drain owned work before releasing its client and attempt authority."""

        self.request_stop()
        if self._close_task is None:
            self._close_task = asyncio.create_task(self._close_after_poll())
        try:
            await asyncio.shield(self._close_task)
        except asyncio.CancelledError:
            await await_runtime_completion(self._close_task)
            raise

    async def _close_after_poll(self) -> None:
        async with self._poll_lock:
            await self._coordinator.close()

    async def _run_claimed(self, claimed: ClaimedWork) -> WorkerStats:
        self._current_execution_id = None
        try:
            return await self._run_claimed_body(claimed)
        finally:
            if self._current_execution_id is not None:
                self._reporter.release_local_run(self._current_execution_id)
                self._current_execution_id = None

    async def _run_claimed_body(self, claimed: ClaimedWork) -> WorkerStats:
        try:
            reject_unreserved_claim_cap(claimed)
            # Validate claim-derived policy and pipeline selection before a
            # heartbeat or canonical execution is created. The temporary UUID
            # is replaced with the server's execution UUID after admission.
            preflight_request, preflight_context = claimed_work_to_run_request(
                claimed,
                default_agent_id=self._default_agent_id,
                execution_id=str(claimed.run_id or claimed.work_item_id),
            )
            self._validate_run_request(preflight_request, preflight_context)
            await self._coordinator.heartbeat()
            execution_id = str(await self._coordinator.start_execution())
            self._current_execution_id = execution_id
            request, context = claimed_work_to_run_request(
                claimed,
                default_agent_id=self._default_agent_id,
                execution_id=execution_id,
            )
            self._validate_run_request(request, context)
            self._reporter.begin(
                context=context,
                trigger="queue",
                input_summary=request.instruction,
                metadata=execution_metadata(claimed),
            )
        except CoordinationFailure:
            raise
        except Exception as exc:
            if isinstance(exc, AgentDbError):
                raise
            await self._fail_exception(exc)
            return WorkerStats(claimed=1, failed=1)

        try:
            result, cancellation_seen = await ClaimSupervisor(
                coordinator=self._coordinator,
                executor=self._executor,
                reporter=self._reporter,
                cancel_execution=self._cancel_execution,
                heartbeat_interval=claim_heartbeat_interval(
                    claimed.lease_expires_at, self._heartbeat_interval
                ),
                shutdown=self._stop,
            ).run(request, context, execution_id)
        except DecisionParkRequiredError as pending:
            if str(pending.execution_id) != execution_id:
                raise AgentDbAuthorityError(
                    "Decision park is outside its current execution"
                ) from None
            checkpoint = self._coordinator.decision_checkpoint(execution_id)
            await self._coordinator.park(checkpoint)
            return WorkerStats(claimed=1)
        except (CoordinationFailure, AgentDbError):
            raise
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self._fail_exception(exc)
            return WorkerStats(claimed=1, failed=1)

        if result is None or cancellation_seen:
            return WorkerStats(claimed=1)
        # Execution may win the supervisor join while cancellation wins in the
        # database. Observe the current fence before publishing a result; each
        # canonical mutation still rechecks authority for the remaining race.
        if await self._coordinator.is_cancelled():
            return WorkerStats(claimed=1)
        return await self._settle_result(
            result, processing=claimed.processing_id is not None
        )

    async def _settle_result(
        self, result: RunResult, *, processing: bool = False
    ) -> WorkerStats:
        if processing:
            outcome = result.work_outcome
            if outcome is None:
                retryable = result.error is not None and result.error.retryable
                outcome = WorkOutcome(
                    outcome="retry" if retryable else "review_required",
                    reason_code="execution_failed"
                    if result.status == "failed"
                    else "missing_work_outcome",
                )
            if outcome.outcome == "completed" and result.status != "completed":
                outcome = WorkOutcome(
                    outcome="review_required", reason_code="inconsistent_work_outcome"
                )
            result_id = await self._coordinator.store_result(result)
            await self._coordinator.settle_processing(
                result_artifact_id=result_id,
                outcome=outcome,
                execution_succeeded=result.status == "completed",
            )
            return WorkerStats(
                claimed=1,
                completed=int(outcome.outcome == "completed"),
                failed=int(outcome.outcome != "completed"),
            )
        if result.status == "cancelled":
            await self._coordinator.cancel(reason="Agent cancelled execution")
            return WorkerStats(claimed=1)
        if result.status == "completed":
            result_id = await self._coordinator.store_result(result)
            finalized = self._coordinator.finalized_artifact_ids
            await self._coordinator.settle(
                result_artifact_id=result_id,
                artifact_ids=finalized or None,
            )
            return WorkerStats(claimed=1, completed=1)

        message = (
            result.error.message
            if result.error is not None
            else f"Agent returned {result.status}"
        )
        retryable = bool(result.error.retryable) if result.error is not None else False
        code = result.error.code if result.error is not None else "agent_status"
        await self._coordinator.fail(message, retryable=retryable, code=code)
        return WorkerStats(claimed=1, failed=1)

    async def _fail_exception(self, exc: BaseException) -> None:
        safe_message = f"Agent execution failed ({type(exc).__name__})"
        await self._coordinator.fail(safe_message, retryable=False)

    async def _back_off(self) -> None:
        try:
            await asyncio.wait_for(
                self._stop.wait(),
                timeout=self._config.poll_interval_seconds,
            )
        except TimeoutError:
            return
