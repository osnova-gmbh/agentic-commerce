"""Protected-action observations through the current admitted module authority."""

from __future__ import annotations

from uuid import UUID, uuid4

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types.universal_policy import UniversalPolicyDecision
from cogit_agent_sdk.universal_policy import PolicyAuthorityUnavailable

from cogit_runtime.agentdb.router import AttemptRouter


class CurrentProtectedActionAuthority:
    """Use exact admitted pins and the worker's existing attempt credential."""

    def __init__(self, router: AttemptRouter, execution_id: str) -> None:
        self._router = router
        self._execution_id = execution_id

    def evaluate(self, action_id: UUID) -> UniversalPolicyDecision:
        try:
            raw = self._router.module_command(
                "cogit.universal-policy",
                "action.evaluate",
                {"contractVersion": "universal-policy.v1", "actionId": str(action_id)},
                contract_id="universal-policy.v1",
                # A fresh request must not replay an earlier module-command allow.
                idempotency_key=str(uuid4()),
                execution_id=self._execution_id,
            )
            return UniversalPolicyDecision.model_validate(raw)
        except CoordinationFailure:
            raise
        except Exception:
            raise PolicyAuthorityUnavailable(
                "Protected action module authority is unavailable"
            ) from None
