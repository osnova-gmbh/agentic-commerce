"""Verify approved wheel payloads against the actual noneditable installation."""

from __future__ import annotations

import base64
import csv
import io
import json
import os
import re
import sys
from email.parser import BytesParser
from importlib import metadata
from pathlib import Path
from zipfile import ZipFile

from cogit_runtime.agentdb.cohort_bytecode import verify_cache
from cogit_runtime.agentdb.cohort_contract import WheelArtifact
from cogit_runtime.agentdb.cohort_files import (
    MAX_MEMBER_BYTES,
    MAX_WHEEL_BYTES,
    _require_unlinked,
    archive_members,
    plain_path,
    read_bounded,
    stream_digest,
)
from cogit_runtime.agentdb.errors import AgentDbError


def normalized_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def verify_wheel(root: Path, artifact: WheelArtifact) -> frozenset[Path]:
    """Hash every payload from the committed wheel, not just installed RECORD."""
    path = plain_path(root, artifact.path)
    if path.stat().st_size > MAX_WHEEL_BYTES:
        raise AgentDbError("Canonical worker wheel exceeds its size limit")
    with path.open("rb") as stream:
        digest, _ = stream_digest(stream, MAX_WHEEL_BYTES)
        if digest != artifact.sha256:
            raise AgentDbError("Canonical worker wheel commitment mismatch")
        stream.seek(0)
        with ZipFile(stream) as archive:
            return _verify_installed(archive, artifact)


def _verify_installed(archive: ZipFile, artifact: WheelArtifact) -> frozenset[Path]:
    members = archive_members(archive)
    names = {member.filename for member in members}
    metadata_paths = [name for name in names if name.endswith(".dist-info/METADATA")]
    if len(metadata_paths) != 1:
        raise AgentDbError("Canonical worker wheel requires one distribution")
    dist_info = metadata_paths[0].rsplit("/", 1)[0]
    package = BytesParser().parsebytes(archive.read(metadata_paths[0]))
    if (
        normalized_name(str(package.get("Name", ""))) != artifact.distribution
        or package.get("Version") != artifact.version
    ):
        raise AgentDbError("Canonical worker wheel distribution identity mismatch")
    wheel_metadata = BytesParser().parsebytes(archive.read(f"{dist_info}/WHEEL"))
    if wheel_metadata.get("Root-Is-Purelib") != "true":
        raise AgentDbError("Canonical worker closure requires pure Python wheels")
    record_path = f"{dist_info}/RECORD"
    record_body = archive.read(record_path)
    if len(record_body) > 1024 * 1024:
        raise AgentDbError("Canonical worker wheel RECORD exceeds its size limit")
    records: dict[str, tuple[str, str]] = {}
    for row in csv.reader(io.StringIO(record_body.decode("utf-8"))):
        if len(row) != 3 or row[0] in records:
            raise AgentDbError("Canonical worker wheel has an invalid RECORD")
        records[row[0]] = (row[1], row[2])
    if set(records) != names:
        raise AgentDbError("Canonical worker wheel RECORD omits payloads")
    distribution = metadata.distribution(artifact.distribution)
    if distribution.version != artifact.version:
        raise AgentDbError("Installed canonical worker distribution version mismatch")
    install_root = Path(str(distribution.locate_file(""))).absolute()
    if not install_root.resolve(strict=True).is_relative_to(
        Path(sys.prefix).resolve()
    ) or not {
        "site-packages",
        "dist-packages",
    }.intersection(install_root.parts):
        raise AgentDbError("Canonical worker distributions must be installed")
    _require_site_startup_baseline(install_root)
    inventory = {str(item).replace("\\", "/") for item in distribution.files or ()}
    if not names.issubset(inventory):
        raise AgentDbError("Installed canonical worker inventory omits wheel payloads")
    caches = _require_package_inventory(install_root, names, dist_info)
    direct_path = install_root / dist_info / "direct_url.json"
    if direct_path.exists():
        direct = json.loads(
            read_bounded(
                plain_path(install_root, f"{dist_info}/direct_url.json"), 16384
            )
        )
        if direct.get("dir_info", {}).get("editable", False):
            raise AgentDbError("Canonical workers cannot use editable distributions")
    approved: set[Path] = set()
    for member in members:
        if member.filename == record_path:
            continue  # Installers rewrite RECORD; every immutable payload is compared.
        with archive.open(member) as stream:
            digest, size = stream_digest(stream, MAX_MEMBER_BYTES)
        encoded = base64.urlsafe_b64encode(bytes.fromhex(digest)).rstrip(b"=").decode()
        if records[member.filename] != (f"sha256={encoded}", str(size)):
            raise AgentDbError("Canonical worker wheel RECORD commitment mismatch")
        installed = plain_path(install_root, member.filename)
        with installed.open("rb") as stream:
            actual, actual_size = stream_digest(stream, MAX_MEMBER_BYTES)
        if actual != digest or actual_size != size:
            raise AgentDbError(
                "Installed canonical worker payload differs from its wheel"
            )
        approved.add(installed.resolve(strict=True))
    verified = frozenset(approved)
    for cache in caches:
        verify_cache(cache, verified)
    return verified


def _require_site_startup_baseline(root: Path) -> None:
    """Reject unexpected site hooks before admitting work (after Python startup)."""
    for count, path in enumerate(root.iterdir(), start=1):
        if count > 8192:
            raise AgentDbError("Canonical worker site inventory exceeds its bound")
        name = path.name.casefold()
        if name in {"sitecustomize", "usercustomize"} or name.startswith(
            ("sitecustomize.", "usercustomize.")
        ):
            raise AgentDbError("Canonical worker has an unexpected Python startup hook")
        if path.suffix.casefold() != ".pth":
            continue
        _require_unlinked(path)
        if name == "_virtualenv.pth" and read_bounded(path, 64).strip() == (
            b"import _virtualenv"
        ):
            continue
        raise AgentDbError("Canonical worker has an unexpected Python startup hook")


def _require_package_inventory(
    root: Path, expected: set[str], dist_info: str
) -> tuple[Path, ...]:
    """Reject extra package payloads that a later lazy import could execute."""
    generated = {
        f"{dist_info}/{name}"
        for name in ("INSTALLER", "REQUESTED", "direct_url.json", "uv_cache.json")
    }
    visited = 0
    caches: list[Path] = []
    flat_module_names = {
        Path(name).stem for name in expected if "/" not in name and name.endswith(".py")
    }
    flat_modules = {module.casefold() for module in flat_module_names}
    for module in flat_module_names:
        if (root / f"{module}.pyc").exists():
            raise AgentDbError(
                "Installed canonical worker contains an unapproved payload"
            )
    root_cache = root / "__pycache__"
    if flat_modules and root_cache.exists():
        _require_unlinked(root_cache)
        for count, path in enumerate(root_cache.iterdir(), start=1):
            if count > 8192:
                raise AgentDbError(
                    "Installed canonical worker inventory exceeds its bound"
                )
            if path.suffix.casefold() != ".pyc":
                continue
            if path.name.split(".", 1)[0].casefold() in flat_modules:
                _require_unlinked(path)
                caches.append(path)
    for top in {name.split("/", 1)[0] for name in expected if "/" in name}:
        directory = root / top
        _require_unlinked(directory)
        for parent, directories, files in os.walk(directory, followlinks=False):
            for name in directories:
                _require_unlinked(Path(parent) / name)
            visited += len(directories) + len(files)
            if visited > 8192:
                raise AgentDbError(
                    "Installed canonical worker inventory exceeds its bound"
                )
            for name in files:
                path = Path(parent) / name
                _require_unlinked(path)
                relative = path.relative_to(root).as_posix()
                if path.parent.name == "__pycache__" and path.suffix == ".pyc":
                    caches.append(path)
                    continue
                if relative not in expected and relative not in generated:
                    raise AgentDbError(
                        "Installed canonical worker contains an unapproved payload"
                    )
    return tuple(caches)
