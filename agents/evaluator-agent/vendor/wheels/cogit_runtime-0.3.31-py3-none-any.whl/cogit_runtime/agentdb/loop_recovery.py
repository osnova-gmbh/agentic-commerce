"""Recover the existing SDK algorithm from canonical transcript/result evidence."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from time import monotonic
from typing import Any

from cogit_agent_sdk.loop.state import dump_loop_state, load_loop_state
from cogit_agent_sdk.types import (
    AgentLoopConfig,
    AgentLoopState,
    Context,
    ModelResponse,
    ToolCall,
)

from cogit_runtime.agentdb import loop_artifacts
from cogit_runtime.agentdb.continuation_schema import LoopContinuation
from cogit_runtime.agentdb.errors import AgentDbAuthorityError
from cogit_runtime.cancellation import RuntimeCancellation


class CanonicalLoopRecovery:
    """Replay completed receipts through the SDK; never repeat completed effects.

    The SDK rebuilds its transcript and token/tool/turn counters from exact
    normalized results. Its configured limits therefore do not reset. The
    original wall deadline independently bounds replay and new effects.
    """

    def __init__(
        self,
        *,
        handle: Any,
        prefix: str,
        integrity_key: bytes,
        config: AgentLoopConfig,
        initial: AgentLoopState,
        definition: dict[str, Any],
        cancellation: RuntimeCancellation,
    ) -> None:
        if not isinstance(integrity_key, bytes) or len(integrity_key) != 32:
            raise AgentDbAuthorityError(
                "Canonical SDK recovery requires its deployment integrity key"
            )
        self.handle, self.prefix, self.key = handle, prefix, integrity_key
        self.journal = handle.continuation
        self.context = initial.context
        self._turn = -1
        self._tool_ordinals: dict[str, tuple[int, ToolCall]] = {}
        commitment = loop_artifacts.digest(
            {"config": config.model_dump(mode="json"), **definition}
        )
        saved = self.journal.read_loop(prefix)
        if saved is None:
            body = dump_loop_state(initial, integrity_key=self.key)
            artifact = loop_artifacts.save(handle, body, slot_key=f"{prefix}/initial")
            started = _now_ms()
            durations = [
                v
                for v in (
                    config.wall_clock_timeout_seconds,
                    config.budget.max_duration_seconds if config.budget else None,
                )
                if v is not None
            ]
            if not initial.context.execution_id:
                raise AgentDbAuthorityError("Canonical loop lacks its actual execution")
            self.record = LoopContinuation(
                definition_sha256=commitment,
                initial=artifact,
                snapshot=artifact,
                snapshot_execution_id=initial.context.execution_id,
                snapshot_queue_item_id=initial.context.queue_item_id,
                original_execution_id=initial.context.execution_id,
                original_queue_item_id=initial.context.queue_item_id,
                started_ms=started,
                deadline_ms=started + min(durations) * 1000 if durations else None,
            )
            self.journal.write_loop(prefix, self.record.model_dump(mode="json"))
        else:
            self.record = LoopContinuation.model_validate(saved)
            if self.record.definition_sha256 != commitment:
                raise AgentDbAuthorityError(
                    "Canonical loop definition changed during recovery"
                )
        # Verify with the real original identity, then use only the fresh
        # attempt Context for permission checks, audits and effects.
        original = self.context.model_copy(
            update={
                "execution_id": self.record.original_execution_id,
                "queue_item_id": self.record.original_queue_item_id,
            }
        )
        restored = load_loop_state(
            loop_artifacts.read(handle, self.record.initial),
            context=original,
            integrity_key=self.key,
        )
        if restored.pending_model_call_id or restored.pending_tool_slots:
            raise AgentDbAuthorityError(
                "Initial SDK transcript contains unresolved calls"
            )
        load_loop_state(
            loop_artifacts.read(handle, self.record.snapshot),
            context=self.context.model_copy(
                update={
                    "execution_id": self.record.snapshot_execution_id,
                    "queue_item_id": self.record.snapshot_queue_item_id,
                }
            ),
            integrity_key=self.key,
        )
        self.state = restored.state.model_copy(update={"context": self.context})
        deadline = self.record.deadline_ms
        self.cancellation = RuntimeCancellation(
            parent=cancellation,
            deadline=monotonic() + max(0, (deadline - _now_ms()) / 1000)
            if deadline is not None
            else None,
        )
        self.cancellation.throw_if_cancelled()

    def prepare(self, state: AgentLoopState) -> None:
        self.cancellation.throw_if_cancelled()
        self._turn = state.current_turn
        self._tool_ordinals = {}
        # Persist normalized history before dispatch. Reject unsupported opaque
        # or thinking content through the SDK's bounded serialization contract.
        body = dump_loop_state(state, integrity_key=self.key)
        previous = self.record.snapshot
        artifact = (
            previous
            if previous.size == len(body)
            and previous.metadata.hash == hashlib.sha256(body).hexdigest()
            else loop_artifacts.save(
                self.handle,
                body,
                slot_key=f"{self.prefix}/turn/{state.current_turn}/snapshot",
            )
        )
        self.record = self.record.model_copy(
            update={
                "snapshot": artifact,
                "snapshot_execution_id": state.context.execution_id,
                "snapshot_queue_item_id": state.context.queue_item_id,
            }
        )
        self.journal.write_loop(self.prefix, self.record.model_dump(mode="json"))

    def received(self, response: ModelResponse) -> None:
        calls = response.message.tool_calls or []
        if len(calls) > 128 or len({c.id for c in calls}) != len(calls):
            raise AgentDbAuthorityError("Canonical model returned invalid tool slots")
        self._tool_ordinals = {
            call.id: (ordinal, call.model_copy(deep=True))
            for ordinal, call in enumerate(calls)
        }

    def tool_slot(self, call: ToolCall) -> str:
        matched = self._tool_ordinals.get(call.id)
        if matched is None or matched[1] != call:
            raise AgentDbAuthorityError(
                "Tool call does not match its persisted model result"
            )
        return f"{self.prefix}/model/{self._turn}/tool/{matched[0]}"

    def tool_context(self, slot: str, context: Context) -> Context:
        return context.model_copy(
            update={
                "metadata": {
                    **(context.metadata or {}),
                    "runtime_pipeline_slot": slot,
                }
            }
        )


def _now_ms() -> int:
    return int(datetime.now(UTC).timestamp() * 1000)
