"""Generated D11 transport with bounded receipts and exact-request replay."""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING
from uuid import UUID

from agentdb_client import ClaimResource, RequestHumanDecisionRequest
from agentdb_client.exceptions import ApiException
from cogit_agent_sdk.coordination import CoordinationFailure
from pydantic import ValidationError

from cogit_runtime.agentdb.decision_schema import DecisionIntent, DecisionReceipt
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbReconciliationRequiredError,
    classify,
)
from cogit_runtime.agentdb.replay import replay_once
from cogit_runtime.coordination import finish_cleanup

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


def verify_receipt(
    receipt: DecisionReceipt, intent: DecisionIntent, claim: ClaimResource
) -> None:
    parents = claim.parents.to_dict()
    if not isinstance(parents, dict):
        raise AgentDbAuthorityError("Human decision claim parents are invalid")
    if (
        receipt.work_item_id != intent.origin_work_id
        or receipt.operation_id != intent.operation_id
        or receipt.payload_sha256 != intent.payload_sha256
        or receipt.authorized_decider_id != intent.authorized_decider_id
        or receipt.expires_at != intent.expires_at
        or receipt.agent_version_id != claim.route.version_id
        or receipt.agent_manifest_sha256 != claim.route.manifest_sha256
        or receipt.run_id != claim.run_id
        or receipt.case_id != parents.get("caseId")
        or receipt.task_id != parents.get("taskId")
        or not intent.first_generation <= receipt.generation <= claim.generation
    ):
        raise AgentDbAuthorityError("Human decision receipt binding mismatch")


class DecisionTransport:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client

    def request(self, token: str, intent: DecisionIntent) -> DecisionReceipt:
        claim = self.client.active(token)
        if claim.work_item_id != intent.origin_work_id:
            raise AgentDbAuthorityError("Human decision is outside its admitted work")
        body = RequestHumanDecisionRequest.from_dict(
            {
                "generation": claim.generation,
                "operationId": intent.operation_id,
                "payloadSha256": intent.payload_sha256,
                "authorizedDeciderId": str(intent.authorized_decider_id),
                "expiresAt": intent.expires_at,
            }
        )
        if body is None:
            raise AgentDbAuthorityError("Invalid human decision request")
        key = (
            "cogit:decision:"
            + hashlib.sha256(
                f"{claim.attempt_id}:{intent.origin_work_id}:{intent.operation_id}".encode()
            ).hexdigest()
        )
        headers = self.client.headers(key)
        try:
            receipt = replay_once(
                lambda: self._post(claim.attempt_id, token, body, headers)
            )
            verify_receipt(receipt, intent, claim)
            # A replacement reassertion returns the original receipt's attempt.
            if (receipt.generation == claim.generation) != (
                receipt.attempt_id == claim.attempt_id
            ):
                raise AgentDbAuthorityError("Human decision origin attempt mismatch")
            return receipt
        except CoordinationFailure:
            raise
        except Exception as exc:
            mapped = classify(exc)
            if isinstance(mapped, CoordinationFailure):
                raise mapped from None
            raise AgentDbReconciliationRequiredError(
                "Human decision request was not confirmed"
            ) from None

    def _post(
        self,
        attempt: UUID,
        token: str,
        body: RequestHumanDecisionRequest,
        headers: dict[str, str],
    ) -> DecisionReceipt:
        response = (
            self.client.attempt_api.request_human_decision_without_preload_content(
                attempt,
                token,
                body,
                _headers=headers,
                _request_timeout=self.client.timeout,
            )
        )
        try:
            raw = response.read(65537)
            if len(raw) > 65536:
                raise AgentDbAuthorityError("Human decision receipt exceeds its bound")
            if response.status != 201:
                raise ApiException(status=response.status, body=raw.decode("utf-8"))
            try:
                return DecisionReceipt.model_validate_json(raw)
            except ValidationError:
                raise AgentDbAuthorityError(
                    "Human decision receipt is invalid"
                ) from None
        finally:
            finish_cleanup(response.close, response.release_conn)
