"""Bounded immutable admitted dependency references, with no SQL authority."""

from __future__ import annotations

import json
from typing import Annotated, Any, Literal
from uuid import UUID

from cogit_agent_sdk.types import (
    DatabaseExportRequirement,
    DatabasePackageRequirement,
)
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictBool,
    StrictInt,
    ValidationError,
)

from cogit_runtime.agentdb.errors import AgentDbAttemptContextError, AgentDbError

MAX_MODULE_INPUT_BYTES = 65536
_Revision = Annotated[StrictInt, Field(ge=0, le=2147483647)]


class _SettingsSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")

    values: dict[str, Any]
    tenant_revision: _Revision = Field(alias="tenantRevision")
    installation_revision: _Revision = Field(alias="installationRevision")
    legacy_settings_revision: _Revision = Field(
        default=0, alias="legacySettingsRevision"
    )


class _PolicyPin(BaseModel):
    model_config = ConfigDict(extra="forbid")

    policy_version_id: UUID = Field(alias="policyVersionId")
    binding_id: UUID = Field(alias="bindingId")
    binding_version: Annotated[StrictInt, Field(ge=1, le=2147483647)] = Field(
        alias="bindingVersion"
    )
    required: StrictBool
    active: StrictBool


def _resolved_package(item: Any) -> DatabasePackageRequirement:
    pins = {"moduleKey", "version", "artifactSha256", "exports"}
    metadata = {"settings", "policies"}
    if (
        not isinstance(item, dict)
        or not pins <= item.keys()
        or item.keys() - pins - metadata
    ):
        raise AgentDbError("AgentDb module dependency envelope is invalid")
    bounded_input({key: item[key] for key in metadata if key in item})
    if "settings" in item:
        _SettingsSnapshot.model_validate(item["settings"])
    if "policies" in item:
        if not isinstance(item["policies"], list) or len(item["policies"]) > 128:
            raise AgentDbError("AgentDb module policy snapshot is invalid")
        for policy in item["policies"]:
            _PolicyPin.model_validate(policy)
    return DatabasePackageRequirement.model_validate({key: item[key] for key in pins})


def parse_dependencies(
    value: dict[str, Any], expected: tuple[DatabasePackageRequirement, ...]
) -> tuple[DatabasePackageRequirement, ...]:
    """Parse only server resolved pins; never resolve from a current tenant version."""
    raw = value.get("databasePackages")
    if not isinstance(raw, list) or len(raw) > 32:
        raise AgentDbError("AgentDb module dependencies are missing or invalid")
    try:
        resolved = tuple(_resolved_package(item) for item in raw)
    except ValidationError:
        raise AgentDbError("AgentDb module dependency contracts are invalid") from None
    by_key = {entry.module_key: entry for entry in resolved}
    if len(by_key) != len(resolved) or set(by_key) != {p.module_key for p in expected}:
        raise AgentDbError("AgentDb dependency set differs from the worker declaration")
    for required in expected:
        actual = by_key[required.module_key]
        if (
            actual.version != required.version
            or actual.artifact_sha256 != required.artifact_sha256
            or set(actual.exports) != set(required.exports)
        ):
            raise AgentDbError(
                f"Database package {required.module_key} has incompatible admitted pins"
            )
    return resolved


def resolve_export(
    packages: tuple[DatabasePackageRequirement, ...] | None,
    module_key: str,
    kind: Literal["query", "command"],
    key: str,
    contract_id: str,
) -> tuple[DatabasePackageRequirement, DatabaseExportRequirement]:
    if packages is None:
        raise AgentDbAttemptContextError("No immutable admitted module dependency set")
    for package in packages:
        if package.module_key != module_key:
            continue
        for export in package.exports:
            if (
                export.kind == kind
                and export.key == key
                and export.contract_id == contract_id
            ):
                return package, export
    raise AgentDbAttemptContextError("Module export is outside the admitted contract")


def bounded_input(payload: dict[str, Any]) -> dict[str, Any]:
    """Take a bounded JSON copy so an agent cannot mutate input during retries."""
    if not isinstance(payload, dict):
        raise AgentDbAttemptContextError("Module input must be a JSON object")
    _validate_json(payload, depth=0, seen=set(), remaining=[4096])
    try:
        encoded = json.dumps(
            payload, allow_nan=False, separators=(",", ":"), sort_keys=True
        )
    except (ValueError, TypeError, RecursionError):
        raise AgentDbAttemptContextError("Module input must be bounded JSON") from None
    if len(encoded.encode("utf-8")) > MAX_MODULE_INPUT_BYTES:
        raise AgentDbAttemptContextError("Module input exceeds the 65536 byte bound")
    return json.loads(encoded)


def _validate_json(
    value: Any, *, depth: int, seen: set[int], remaining: list[int]
) -> None:
    remaining[0] -= 1
    if remaining[0] < 0:
        raise AgentDbAttemptContextError("Module input exceeds the node bound")
    if depth > 16:
        raise AgentDbAttemptContextError("Module input exceeds the nesting bound")
    if isinstance(value, (dict, list)):
        if id(value) in seen or len(value) > 4096:
            raise AgentDbAttemptContextError("Module input is recursive or oversized")
        seen.add(id(value))
        if isinstance(value, dict):
            if any(not isinstance(key, str) or len(key) > 128 for key in value):
                raise AgentDbAttemptContextError("Module input field names are invalid")
            children = value.values()
        else:
            children = value
        for child in children:
            _validate_json(child, depth=depth + 1, seen=seen, remaining=remaining)
        seen.remove(id(value))
    elif value is not None and type(value) not in (str, int, float, bool):
        raise AgentDbAttemptContextError("Module input must contain JSON values")
    elif isinstance(value, str) and len(value) > MAX_MODULE_INPUT_BYTES:
        raise AgentDbAttemptContextError("Module input exceeds the string bound")


def validate_request_key(key: str) -> str:
    if (
        not isinstance(key, str)
        or not 1 <= len(key) <= 128
        or any(ord(character) < 33 or ord(character) > 126 for character in key)
    ):
        raise AgentDbAttemptContextError(
            "Module idempotency key must be 1..128 visible ASCII bytes"
        )
    return key
