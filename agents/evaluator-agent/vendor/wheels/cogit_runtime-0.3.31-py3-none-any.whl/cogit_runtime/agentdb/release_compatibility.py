"""Check the published release contract before acquiring a queue delivery."""

from __future__ import annotations

from agentdb_client import ApiClient
from agentdb_client.api.public_api import PublicApi
from agentdb_client.models.version_response import VersionResponse
from cogit_agent_sdk.coordination import CoordinationFailure
from pydantic import ValidationError

from cogit_runtime.agentdb.errors import AgentDbError, AgentDbVersionMismatch


def verify_release(http: ApiClient, timeout: tuple[float, float]) -> None:
    """Read-only check; a mismatch must never be treated as an uncertain claim."""
    try:
        version = PublicApi(http).get_version(_request_timeout=timeout)
        VersionResponse.model_validate(version)
    except ValidationError:
        raise AgentDbVersionMismatch(
            "AgentDb release is incompatible with the installed client; "
            "compare /version with the release wheel provenance"
        ) from None
    except CoordinationFailure:
        raise
    except Exception:
        raise AgentDbError(
            "AgentDb release preflight unavailable; no work was claimed"
        ) from None
