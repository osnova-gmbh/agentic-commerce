"""Bind SDK loop turns to explicit canonical model slots without another loop."""

from __future__ import annotations

from collections.abc import Iterable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cogit_runtime.agentdb.loop_recovery import CanonicalLoopRecovery

from cogit_agent_sdk.types import (
    AgentLoopConfig,
    AgentLoopState,
    Cancellation,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
)

from cogit_runtime.agentdb.errors import AgentDbAuthorityError
from cogit_runtime.agentdb.handle import AgentDbRunHandle
from cogit_runtime.agentdb.model_streams import close_stream
from cogit_runtime.model import GuardedModelClient


class CanonicalLoopModel:
    """A model client plus a final prepare-next-turn hook for the SDK host."""

    def __init__(
        self,
        handle: AgentDbRunHandle,
        routes: GuardedModelClient,
        *,
        prefix: str,
        recovery: CanonicalLoopRecovery | None = None,
    ) -> None:
        self._handle = handle
        self._routes = routes
        self._prefix = prefix
        self._slot: str | None = None
        self._recovery = recovery

    def prepare_next_turn(
        self, state: AgentLoopState, config: AgentLoopConfig
    ) -> AgentLoopState:
        _ = config
        if type(state.current_turn) is not int or not 0 <= state.current_turn < 10000:
            raise AgentDbAuthorityError("SDK model call lacks a bounded logical turn")
        self._slot = f"{self._prefix}/model/{state.current_turn}"
        if self._recovery is not None:
            self._recovery.prepare(state)
        return state

    def _current(self):
        if self._slot is None:
            raise AgentDbAuthorityError("SDK model call has no prepared logical slot")
        return self._handle.model_client(self._routes, slot_key=self._slot)

    def generate(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> ModelResponse:
        response = self._current().generate(request, cancellation)
        if self._recovery is not None:
            self._recovery.received(response)
        return response

    def stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterable[ModelStreamEvent]:
        events = self._current().stream(request, cancellation)
        try:
            yield from events
        finally:
            close_stream(events)
