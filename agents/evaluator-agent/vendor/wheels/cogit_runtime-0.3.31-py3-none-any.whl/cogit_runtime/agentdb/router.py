"""Attempt-scoped AgentDb mutations that never expose generated types."""

from __future__ import annotations

import hashlib
import json
import uuid
from collections.abc import Callable
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import ActionIntent, ActionKey, ActionRef, ArtifactRef
from cogit_agent_sdk.types.policy import PolicySubject

from cogit_runtime.agentdb.client import AgentDbClient
from cogit_runtime.agentdb.continuation import ContinuationJournal
from cogit_runtime.agentdb.current_model_spend import CurrentModelSpend
from cogit_runtime.agentdb.errors import (
    AgentDbAttemptContextError,
    AgentDbAuthorityError,
)
from cogit_runtime.agentdb.model_dispatch import DurableModelDispatch
from cogit_runtime.agentdb.port_values import (
    AllocateArtifactUploadRequest,
    CreateModelCallIntentRequest,
    DeclareArtifactRequest,
    ExecutionMode,
    FinalizeArtifactUploadRequest,
    HeartbeatAttemptRequest,
    ReserveModelCallBudgetRequest,
    SettleModelCallBudgetRequest,
    StartExecutionRequest,
)
from cogit_runtime.agentdb.processing_events import stage_request
from cogit_runtime.agentdb.results import (
    DeclaredArtifact,
    FinalizedArtifact,
    UploadLease,
    entity_id,
    optional_str,
    required_int,
)
from cogit_runtime.agentdb.runtime_audit import (
    AuditKind,
    RequiredAuditError,
    RuntimeAuditEvent,
)
from cogit_runtime.agentdb.session import AttemptSession
from cogit_runtime.agentdb.transport import AgentDbTransport


class AttemptRouter:
    """Route events, artifacts, and model calls through the active token."""

    def __init__(
        self,
        *,
        session: AttemptSession,
        transport: AgentDbTransport,
        client: AgentDbClient,
    ) -> None:
        self._session = session
        self._transport = transport
        self._client = client

    def __repr__(self) -> str:
        return f"AttemptRouter(session={self._session.redacted()})"

    def require_policy_subject(
        self, subject: PolicySubject, *, execution_id: str
    ) -> None:
        from cogit_runtime.agentdb.current_client import CurrentClient

        self.require_execution(execution_id)
        if not isinstance(self._client, CurrentClient):
            raise AgentDbAuthorityError("Runtime policy needs the canonical client")
        claim = self._client.active(self._session.require_token())
        if (
            subject.attempt_id != str(claim.attempt_id)
            or subject.generation != claim.generation
            or subject.run_id != str(claim.run_id)
            or subject.installation_id != str(claim.route.installation_id)
        ):
            raise AgentDbAuthorityError("Runtime policy receipt has a stale subject")

    def start_execution(self) -> uuid.UUID:
        attempt_id, token = self._session.require_ids()
        execution = self._mutate(
            "start-execution",
            self._client.executions.start_execution,
            token,
            self._session.idempotency_key("start-execution"),
            StartExecutionRequest(
                work_attempt_id=attempt_id,
                mode=ExecutionMode.EXECUTION,
            ),
        )
        execution_id = entity_id(execution, "id")
        self._session.bind_execution(execution_id)
        return execution_id

    def require_execution(self, execution_id: str) -> None:
        if str(self._session.require_execution_id()) != execution_id:
            raise AgentDbAuthorityError("Request is outside the current execution")

    def model_dispatch(
        self,
        *,
        execution_id: str,
        store_response: Callable[[str, bytes], ArtifactRef],
        observe: Callable[[str, str, dict[str, str | int]], None],
    ) -> DurableModelDispatch:
        self.require_execution(execution_id)
        spend = getattr(self._client, "model_spend", None)
        if not isinstance(spend, CurrentModelSpend):
            raise AgentDbAuthorityError("Canonical model spend port is unavailable")
        journal = self.continuation
        return DurableModelDispatch(
            original_work_id=journal.original_work_id,
            journal=journal,
            spend=spend,
            token=self._session.require_token(),
            store_response=store_response,
            read_response=lambda ref: self.read_artifact(
                ref, max_bytes=1024 * 1024, execution_id=execution_id
            ),
            observe=observe,
        )

    @property
    def continuation(self) -> ContinuationJournal:
        self._session.require_execution_id()
        journal = getattr(self._client, "continuation", None)
        if not isinstance(journal, ContinuationJournal):
            raise AgentDbAuthorityError("Canonical continuation port is unavailable")
        return journal

    def require_human_decision(
        self,
        *,
        execution_id: str,
        slot_key: str,
        exposure: str,
        payload: dict[str, Any],
        idempotency: str,
        invocation_key: str | None,
    ) -> None:
        self.require_execution(execution_id)
        port = getattr(self._client, "decisions", None)
        if port is None:
            raise AgentDbAuthorityError("Canonical decision transport is unavailable")
        try:
            port.require(
                token=self._session.require_token(),
                execution_id=execution_id,
                slot_key=slot_key,
                exposure=exposure,
                payload=payload,
                idempotency=idempotency,
                invocation_key=invocation_key,
            )
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbAuthorityError(
                "Canonical human decision is unconfirmed"
            ) from None

    def prepare_action(self, intent: ActionIntent, *, execution_id: str) -> ActionRef:
        self.require_execution(execution_id)
        return self._mutate(
            "prepare-action",
            self._client.actions.prepare_action,
            self._session.require_token(),
            self._session.idempotency_key(
                "prepare-action",
                intent.provider,
                intent.credential_account,
                intent.operation,
                intent.idempotency_key,
            ),
            intent,
        )

    def lookup_action(self, key: ActionKey, *, execution_id: str) -> ActionRef | None:
        self.require_execution(execution_id)
        return self._transport.invoke(
            self._client.actions.lookup_action,
            self._session.require_token(),
            key,
            idempotent=True,
            operation="lookup-action",
        )

    def get_action(self, action_id: str, *, execution_id: str) -> ActionRef:
        self.require_execution(execution_id)
        return self._transport.invoke(
            self._client.actions.get_action,
            self._session.require_token(),
            action_id,
            idempotent=True,
            operation="get-action",
        )

    def record_progress(self, progress: dict[str, Any]) -> None:
        attempt_id, token = self._session.require_ids()
        correlated = {
            **progress,
            "runId": str(self._session.run_id) if self._session.run_id else None,
            "attemptId": str(attempt_id),
            "executionId": (
                str(self._session.execution_id)
                if self._session.execution_id is not None
                else None
            ),
        }
        self._mutate(
            "heartbeat",
            self._client.work.heartbeat_attempt,
            attempt_id,
            token,
            HeartbeatAttemptRequest(progress=correlated),
        )

    def record_event(
        self,
        *,
        kind: str,
        sequence: int,
        execution_id: str | None = None,
    ) -> None:
        resolved = (
            uuid.UUID(execution_id)
            if execution_id
            else self._session.require_execution_id()
        )
        self.record_processing_event(
            execution_id=str(resolved),
            stage_key="sdk." + kind,
            stage_order=sequence + 1,
            status="recorded",
        )

    def get_governance_snapshot(
        self, snapshot_id: str, *, execution_id: str
    ) -> dict[str, Any]:
        self.require_execution(execution_id)
        port = getattr(self._client, "governance", None)
        if port is None:
            raise AgentDbAttemptContextError("Database governance port is unavailable")
        return self._transport.invoke(
            port.snapshot,
            self._session.require_token(),
            snapshot_id,
            idempotent=True,
            operation="governance-snapshot",
        )

    def submit_database_command(
        self, name: str, payload: dict[str, Any], *, execution_id: str
    ) -> dict[str, Any]:
        self.require_execution(execution_id)
        port = getattr(self._client, "governance", None)
        if port is None:
            raise AgentDbAttemptContextError("Database governance port is unavailable")
        digest = hashlib.sha256(
            json.dumps(
                payload, sort_keys=True, separators=(",", ":"), allow_nan=False
            ).encode()
        ).hexdigest()
        return self._transport.invoke(
            port.command,
            self._session.require_token(),
            name,
            payload,
            self._session.idempotency_key(name, execution_id, digest),
            idempotent=True,
            operation="database-command",
        )

    def module_query(
        self,
        module_key: str,
        query_key: str,
        payload: dict[str, Any],
        *,
        contract_id: str,
        execution_id: str,
    ) -> dict[str, Any]:
        self.require_execution(execution_id)
        port = getattr(self._client, "modules", None)
        if port is None:
            raise AgentDbAttemptContextError("Database module port is unavailable")
        return self._transport.invoke(
            port.query,
            self._session.require_token(),
            module_key,
            query_key,
            payload,
            contract_id,
            idempotent=True,
            operation="module-query",
        )

    def module_command(
        self,
        module_key: str,
        command_key: str,
        payload: dict[str, Any],
        *,
        contract_id: str,
        idempotency_key: str,
        execution_id: str,
    ) -> dict[str, Any]:
        self.require_execution(execution_id)
        port = getattr(self._client, "modules", None)
        if port is None:
            raise AgentDbAttemptContextError("Database module port is unavailable")
        return self._transport.invoke(
            port.command,
            self._session.require_token(),
            module_key,
            command_key,
            payload,
            contract_id,
            idempotency_key,
            idempotent=True,
            operation="module-command",
        )

    def record_processing_event(
        self,
        *,
        execution_id: str,
        stage_key: str,
        stage_order: int,
        status: str,
        reason_code: str | None = None,
        details: dict[str, Any] | None = None,
        evidence: list[dict[str, Any]] | None = None,
    ) -> None:
        self.require_execution(execution_id)
        request = stage_request(
            stage_key=stage_key,
            stage_order=stage_order,
            status=status,
            reason_code=reason_code,
            details=details,
            evidence=evidence,
        )
        port = getattr(self._client, "processing_events", None)
        if port is None:
            raise AgentDbAttemptContextError(
                "AgentDb processing event transport is unavailable"
            )
        self._transport.invoke(
            port.record,
            uuid.UUID(execution_id),
            self._session.require_token(),
            self._session.idempotency_key(
                "processing-event", execution_id, stage_key, stage_order, status
            ),
            request,
            idempotent=True,
            operation="processing-event",
        )

    def record_runtime_audit(
        self,
        *,
        execution_id: str,
        event_key: str,
        kind: AuditKind,
        phase: str,
        details: dict[str, str | int] | None = None,
        payload_artifact: ArtifactRef | None = None,
    ) -> None:
        self.require_execution(execution_id)
        event = RuntimeAuditEvent.create(
            event_key=event_key,
            kind=kind,
            phase=phase,
            details=details,
            payload_artifact=payload_artifact,
        )
        port = getattr(self._client, "runtime_audit", None)
        if port is None:
            raise RequiredAuditError("Required AgentDb audit transport is unavailable")
        try:
            port.record(
                uuid.UUID(execution_id),
                self._session.require_token(),
                self._session.idempotency_key("runtime-audit", execution_id, event_key),
                event,
            )
        except CoordinationFailure:
            raise
        except Exception:
            raise RequiredAuditError(
                "Required AgentDb audit write is unconfirmed"
            ) from None

    def declare_artifact(
        self,
        kind: str,
        media_type: str,
        filename: str | None,
        *,
        run_id: uuid.UUID | None = None,
        execution_id: uuid.UUID | None = None,
        max_size_bytes: int | None = None,
        renderer_hint: str | None = None,
    ) -> DeclaredArtifact:
        token = self._session.require_token()
        resolved_run = run_id if run_id is not None else self._session.run_id
        resolved_execution = execution_id or self._session.execution_id
        declared = self._mutate(
            "declare-artifact",
            self._client.artifacts.declare_artifact,
            token,
            self._session.idempotency_key(
                "declare-artifact",
                kind,
                filename,
                resolved_execution,
            ),
            DeclareArtifactRequest(
                run_id=resolved_run,
                execution_id=resolved_execution,
                kind=kind,
                media_type=media_type,
                filename=filename,
                max_size_bytes=max_size_bytes,
                renderer_hint=renderer_hint,
            ),
        )
        return DeclaredArtifact(id=entity_id(declared, "id", "artifactId"))

    def allocate_artifact_upload(
        self,
        artifact_id: uuid.UUID,
        *,
        expected_bytes: int | None = None,
        expected_hash: str | None = None,
    ) -> UploadLease:
        token = self._session.require_token()
        lease = self._mutate(
            "allocate-upload",
            self._client.artifacts.allocate_artifact_upload,
            artifact_id,
            token,
            self._session.idempotency_key("allocate-upload", artifact_id),
            AllocateArtifactUploadRequest(
                expected_bytes=expected_bytes,
                expected_hash=expected_hash,
            ),
        )
        return UploadLease(
            id=entity_id(lease, "id", "leaseId"),
            fencing_generation=required_int(
                lease, "fencing_generation", "fencingGeneration"
            ),
            upload_url=optional_str(lease, "upload_url", "uploadUrl"),
        )

    def upload_bytes(self, lease: UploadLease, body: bytes) -> None:
        self._session.require_token()
        self._mutate(
            "upload-bytes", self._client.artifacts.upload_bytes, lease.id, body
        )

    def read_artifact(
        self, ref: ArtifactRef, *, max_bytes: int, execution_id: str
    ) -> bytes:
        if str(self._session.require_execution_id()) != execution_id:
            raise AgentDbAuthorityError(
                "Artifact read is outside the current execution"
            )
        token = self._session.require_token()
        return self._transport.invoke(
            self._client.artifacts.read_artifact,
            ref,
            token,
            max_bytes,
            idempotent=True,
            operation="read-artifact",
        )

    def finalize_artifact_upload(
        self,
        artifact_id: uuid.UUID,
        lease_id: uuid.UUID,
        *,
        byte_count: int,
        content_hash: str,
        expected_generation: int,
    ) -> FinalizedArtifact:
        token = self._session.require_token()
        finalized = self._mutate(
            "finalize-upload",
            self._client.artifacts.finalize_artifact_upload,
            artifact_id,
            lease_id,
            token,
            self._session.idempotency_key("finalize-upload", artifact_id, lease_id),
            FinalizeArtifactUploadRequest(
                expected_generation=expected_generation,
                byte_count=byte_count,
                content_hash=content_hash,
            ),
        )
        finalized_id = entity_id(finalized, "id", "artifactId")
        self._session.record_finalized(finalized_id)
        return FinalizedArtifact(id=finalized_id)

    def reserve_model_call(
        self,
        *,
        input_tokens: int,
        output_tokens: int,
        cost_budget: float,
        provider: str = "runtime",
        model: str = "unspecified",
    ) -> str:
        token = self._session.require_token()
        execution_id = self._session.require_execution_id()
        intent = self._mutate(
            "model-intent",
            self._client.executions.create_model_call_intent,
            execution_id,
            token,
            self._session.idempotency_key("model-intent", input_tokens, output_tokens),
            CreateModelCallIntentRequest(
                provider=provider,
                model=model,
                purpose="runtime-model-call",
            ),
        )
        intent_id = entity_id(intent, "id")
        reservation = self._mutate(
            "model-reserve",
            self._client.usage.reserve_model_call_budget,
            token,
            self._session.idempotency_key("model-reserve", intent_id),
            ReserveModelCallBudgetRequest(
                execution_id=execution_id,
                intent_id=intent_id,
                provider=provider,
                model=model,
                max_input_tokens=input_tokens,
                max_output_tokens=output_tokens,
                max_cost_amount=f"{cost_budget:.6f}",
                currency="USD",
            ),
        )
        return str(entity_id(reservation, "id"))

    def settle_model_call(
        self,
        reservation_id: str,
        *,
        input_tokens: int,
        output_tokens: int,
        cost: float,
    ) -> None:
        token = self._session.require_token()
        self._mutate(
            "model-settle",
            self._client.usage.settle_model_call_budget,
            uuid.UUID(reservation_id),
            token,
            self._session.idempotency_key("model-settle", reservation_id),
            SettleModelCallBudgetRequest(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_amount=f"{cost:.6f}",
                currency="USD",
            ),
        )

    def _mutate(self, operation: str, fn: Any, *args: Any) -> Any:
        return self._transport.invoke(
            fn,
            *args,
            idempotent=False,
            operation=operation,
        )
