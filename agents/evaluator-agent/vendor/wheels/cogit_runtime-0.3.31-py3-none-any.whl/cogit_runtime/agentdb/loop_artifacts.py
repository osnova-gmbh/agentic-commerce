"""Verified bounded artifacts used by canonical SDK loop recovery."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import ArtifactRef

from cogit_runtime.agentdb.continuation_schema import ContinuationArtifact
from cogit_runtime.agentdb.errors import AgentDbReconciliationRequiredError

LIMIT = 1024 * 1024


def encoded(value: Any) -> bytes:
    data = json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()
    if len(data) > LIMIT:
        raise AgentDbReconciliationRequiredError("Loop evidence exceeds its byte bound")
    return data


def digest(value: Any) -> str:
    return hashlib.sha256(encoded(value)).hexdigest()


def save(handle: Any, body: bytes, *, slot_key: str) -> ContinuationArtifact:
    try:
        if len(body) > LIMIT or not isinstance(slot_key, str) or not slot_key:
            raise ValueError
        sha = hashlib.sha256(body).hexdigest()
        slot_hash = hashlib.sha256(slot_key.encode("utf-8")).hexdigest()
        declared = handle.declare_artifact(
            "loop-evidence", "application/json", f"{slot_hash}-{sha}.json"
        )
        ref = handle.finalize_artifact(declared, body, sha)
        if ref.size != len(body) or (ref.metadata or {}).get("hash") != sha:
            raise ValueError
        return ContinuationArtifact.model_validate(
            {
                "id": ref.id,
                "mime_type": "application/json",
                "size": len(body),
                "metadata": {"hash": sha},
            }
        )
    except CoordinationFailure:
        raise
    except Exception:
        raise AgentDbReconciliationRequiredError(
            "Loop evidence publication is unconfirmed"
        ) from None


def read(handle: Any, ref: ContinuationArtifact) -> bytes:
    try:
        body = handle.read_artifact(
            ArtifactRef.model_validate(ref.model_dump(mode="json")), max_bytes=LIMIT
        )
        if (
            len(body) != ref.size
            or hashlib.sha256(body).hexdigest() != ref.metadata.hash
        ):
            raise ValueError
        return body
    except CoordinationFailure:
        raise
    except Exception:
        raise AgentDbReconciliationRequiredError(
            "Loop evidence could not be verified"
        ) from None
