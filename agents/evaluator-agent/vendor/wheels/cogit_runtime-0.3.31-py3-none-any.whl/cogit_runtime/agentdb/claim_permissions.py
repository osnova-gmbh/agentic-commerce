"""Translate AgentDb's authoritative claim-v2 capability snapshot without flattening."""

from __future__ import annotations

import json

from agentdb_client import ClaimResource
from cogit_agent_sdk.types import CapabilityGrant
from cogit_agent_sdk.types.capabilities import (
    validate_capability_name,
    validate_module_scope,
)
from pydantic import ValidationError

from cogit_runtime.agentdb.errors import AgentDbAuthorityError


def claim_permissions(claim: ClaimResource) -> tuple[CapabilityGrant, ...]:
    """Capture only exact core/module grants, bound to the routed principal."""
    if claim.principal_id != claim.route.agent_principal_id:
        raise AgentDbAuthorityError("AgentDb claim principal does not match its route")
    entries = [grant.to_dict() for grant in claim.effective_capabilities]
    if (
        len(entries) > 128
        or len(
            json.dumps(entries, separators=(",", ":"), ensure_ascii=False).encode(
                "utf-8"
            )
        )
        > 32768
    ):
        raise AgentDbAuthorityError("AgentDb claim capability snapshot is too large")
    grants: list[CapabilityGrant] = []
    for entry in entries:
        if set(entry) != {"name", "scope"} or not isinstance(entry["scope"], dict):
            raise AgentDbAuthorityError("AgentDb claim capability scope is invalid")
        scope = entry["scope"]
        if scope and (
            set(scope) != {"moduleKey"} or type(scope["moduleKey"]) is not str
        ):
            raise AgentDbAuthorityError("AgentDb claim capability scope is invalid")
        try:
            validate_module_scope(scope.get("moduleKey"))
        except ValueError:
            raise AgentDbAuthorityError(
                "AgentDb claim capability scope is invalid"
            ) from None
        try:
            validate_capability_name(entry["name"])
        except ValueError:
            # AgentDb also supports names outside the SDK requirement grammar.
            # Such grants cannot satisfy an SDK requirement; retain no authority.
            continue
        try:
            grants.append(
                CapabilityGrant(name=entry["name"], module_scope=scope.get("moduleKey"))
            )
        except ValidationError:
            raise AgentDbAuthorityError(
                "AgentDb claim capability is unsupported"
            ) from None
    return tuple(grants)
