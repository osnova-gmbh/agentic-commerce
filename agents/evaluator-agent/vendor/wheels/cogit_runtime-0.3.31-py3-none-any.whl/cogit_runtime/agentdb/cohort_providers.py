"""Bind selected tool entrypoints and their neutral dependencies to the cohort."""

from __future__ import annotations

import re
from importlib import metadata
from importlib.machinery import PathFinder
from pathlib import Path

import yaml

from cogit_runtime.agentdb.cohort_contract import WorkerExecutable
from cogit_runtime.agentdb.cohort_wheels import normalized_name
from cogit_runtime.agentdb.errors import AgentDbError


def require_provider_target(module: str, approved: frozenset[Path]) -> None:
    """Resolve every parent without importing or executing selected provider code."""
    locations: list[str] | None = None
    parts = module.split(".")
    for index in range(len(parts)):
        spec = PathFinder.find_spec(".".join(parts[: index + 1]), locations)
        if (
            spec is None
            or not isinstance(spec.origin, str)
            or Path(spec.origin).resolve() not in approved
        ):
            raise AgentDbError("Selected provider entrypoint targets unapproved code")
        if index + 1 < len(parts):
            if spec.submodule_search_locations is None:
                raise AgentDbError(
                    "Selected provider entrypoint parent is not a package"
                )
            locations = list(spec.submodule_search_locations)


def require_selected_providers(
    body: bytes, executable: WorkerExecutable, inventory: dict[str, frozenset[Path]]
) -> None:
    manifest = yaml.safe_load(body)
    if not isinstance(manifest, dict):
        raise AgentDbError("Canonical manifest is not an object")
    meta = manifest.get("metadata") or {}
    selections = (meta.get("cogit_tools") or {}).get("providers") or []
    if not isinstance(selections, list) or len(selections) > 128:
        raise AgentDbError("Canonical provider selection is invalid")
    entries = metadata.entry_points(group="cogit.tool_providers.v1")
    required = {executable.agent_distribution}
    for selection in selections:
        if not isinstance(selection, dict) or not isinstance(
            selection.get("provider"), str
        ):
            raise AgentDbError("Canonical provider selection is invalid")
        matches = [entry for entry in entries if entry.name == selection["provider"]]
        if len(matches) != 1 or matches[0].dist is None:
            raise AgentDbError("Selected provider entrypoint is absent or ambiguous")
        owner = normalized_name(matches[0].dist.name)
        if owner not in inventory:
            raise AgentDbError(
                "Selected provider wheel is missing from executable closure"
            )
        require_provider_target(matches[0].module, inventory[owner])
        # Checking installed inventory occurs before EntryPoint.load or agent import.
        required.add(owner)
    seen: set[str] = set()
    while required - seen:
        name = next(iter(required - seen))
        if name not in inventory:
            raise AgentDbError(
                "Selected neutral dependency is missing from executable closure"
            )
        seen.add(name)
        for raw in metadata.requires(name) or ():
            # Agent extras describe optional selections; chosen provider dependencies
            # themselves are all pinned, including any optional neutral helpers.
            if name == executable.agent_distribution and re.search(
                r";.*\bextra\b", raw
            ):
                continue
            match = re.match(r"\s*([A-Za-z0-9_.-]+)", raw)
            if match is None:
                raise AgentDbError("Selected dependency metadata is invalid")
            dependency = normalized_name(match[1])
            if dependency.startswith("cogit-") or dependency == "agentdb-client":
                required.add(dependency)
