"""Attempt-authorized binary transfer; canonical IDs come from AgentDb."""

from __future__ import annotations

import hashlib
import re
import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from agentdb_client import (
    AllocateExecutionArtifactUploadRequest,
    FinalizeExecutionArtifactUploadRequest,
)
from agentdb_client.exceptions import ApiException
from cogit_agent_sdk.types import ArtifactRef

from cogit_runtime.agentdb.errors import (
    AgentDbAttemptContextError,
    AgentDbAuthorityError,
    AgentDbError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.coordination import finish_cleanup

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient

MAX_ARTIFACT_BYTES = 5_000_000
# Host input uploads retain their separately bounded supported-format contract.
MEDIA_TYPES = frozenset({"application/json", "text/plain", "application/pdf"})
_MEDIA_TYPE_PATTERN = re.compile(r"[a-zA-Z0-9!#$&^_.+-]+/[a-zA-Z0-9!#$&^_.+-]+")
_MAX_MEDIA_TYPE_LENGTH = 128


@dataclass
class PendingUpload:
    slot_id: uuid.UUID
    execution_id: uuid.UUID
    generation: int
    size: int
    digest: str
    uploaded: bool = False


class CurrentArtifacts:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client
        self.slots: dict[uuid.UUID, Any] = {}
        self.uploads: dict[uuid.UUID, PendingUpload] = {}

    def clear(self) -> None:
        self.slots.clear()
        self.uploads.clear()

    def declare_artifact(
        self, token: str, key: str, request: Any
    ) -> dict[str, uuid.UUID]:
        claim = self.client.active(token)
        if (
            request.run_id != claim.run_id
            or str(request.execution_id) != self.client.execution_id
        ):
            raise AgentDbAuthorityError("Artifact is outside the current execution")
        if (
            not isinstance(request.media_type, str)
            or len(request.media_type) > _MAX_MEDIA_TYPE_LENGTH
            or _MEDIA_TYPE_PATTERN.fullmatch(request.media_type) is None
        ):
            raise AgentDbError("Unsupported artifact media type")
        slot = uuid.uuid5(uuid.NAMESPACE_URL, key)
        if slot in self.slots and self.slots[slot] != request:
            raise AgentDbError("Artifact declaration commitment changed")
        self.slots[slot] = request
        return {"id": slot}

    def allocate_artifact_upload(
        self, artifact_id: uuid.UUID, token: str, key: str, request: Any
    ) -> dict[str, Any]:
        claim = self.client.active(token)
        slot = self.slots.get(artifact_id)
        if self.client.execution_id is None:
            raise AgentDbAuthorityError("No current artifact execution")
        if slot is None:
            raise AgentDbAttemptContextError("Unknown artifact slot")
        size = request.expected_bytes
        digest = str(request.expected_hash or "").removeprefix("sha256:")
        if type(size) is not int or not 0 <= size <= MAX_ARTIFACT_BYTES:
            raise AgentDbError("Artifact exceeds the bounded binary contract")
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise AgentDbError("Artifact requires a SHA-256 commitment")
        execution = uuid.UUID(self.client.execution_id)
        allocation = self.client.attempt_api.allocate_execution_artifact_upload(
            execution,
            token,
            AllocateExecutionArtifactUploadRequest(
                generation=claim.generation,
                mediaType=slot.media_type,
                sha256=digest,
                byteLength=size,
            ),
            _headers=self.client.headers(key),
            _request_timeout=self.client.timeout,
        )
        self.uploads[allocation.upload_id] = PendingUpload(
            artifact_id,
            execution,
            claim.generation,
            size,
            digest,
        )
        # AgentDb's upload generation belongs to its storage lifecycle; the
        # execution-scoped lease is fenced by the active attempt generation.
        return {"id": allocation.upload_id, "fencingGeneration": claim.generation}

    def upload_bytes(self, lease_id: uuid.UUID, body: bytes) -> None:
        upload = self._upload(lease_id)
        claim = self.client.claim
        if claim is None:
            raise AgentDbAuthorityError("No active artifact attempt")
        self.client.active(claim.token)
        if (
            len(body) != upload.size
            or hashlib.sha256(body).hexdigest() != upload.digest
        ):
            raise AgentDbError("Artifact upload commitment mismatch")
        result = self.client.attempt_api.put_execution_artifact_upload_content(
            upload.execution_id,
            lease_id,
            claim.token,
            body=body,
            _headers=self.client.headers(f"upload:{lease_id}"),
            _request_timeout=self.client.timeout,
        )
        if (
            result.upload_id != lease_id
            or result.sha256 != upload.digest
            or result.size != upload.size
        ):
            raise AgentDbReconciliationRequiredError("Artifact upload receipt mismatch")
        upload.uploaded = True

    def finalize_artifact_upload(
        self,
        artifact_id: uuid.UUID,
        lease_id: uuid.UUID,
        token: str,
        key: str,
        request: Any,
    ) -> dict[str, str]:
        claim = self.client.active(token)
        upload = self._upload(lease_id)
        if not upload.uploaded or upload.slot_id != artifact_id:
            raise AgentDbAttemptContextError("Upload bytes before finalizing")
        if (
            request.expected_generation != claim.generation
            or upload.generation != claim.generation
            or request.byte_count != upload.size
            or request.content_hash.removeprefix("sha256:") != upload.digest
        ):
            raise AgentDbError("Artifact finalization commitment mismatch")
        result = self.client.attempt_api.finalize_execution_artifact_upload(
            upload.execution_id,
            lease_id,
            token,
            FinalizeExecutionArtifactUploadRequest(
                generation=claim.generation,
                sha256=upload.digest,
                byteLength=upload.size,
            ),
            _headers=self.client.headers(key),
            _request_timeout=self.client.timeout,
        )
        if (
            result.sha256 != upload.digest
            or result.byte_length != upload.size
            or result.media_type != self.slots[artifact_id].media_type
        ):
            raise AgentDbReconciliationRequiredError(
                "Artifact finalization receipt mismatch"
            )
        self.client.digests[result.artifact_id] = result.sha256
        return {"id": str(result.artifact_id)}

    def _upload(self, lease_id: uuid.UUID) -> PendingUpload:
        upload = self.uploads.get(lease_id)
        if upload is None:
            raise AgentDbAttemptContextError("Unknown artifact upload")
        if str(upload.execution_id) != self.client.execution_id:
            raise AgentDbAuthorityError("Artifact upload belongs to another execution")
        return upload

    def read_artifact(self, ref: ArtifactRef, token: str, max_bytes: int) -> bytes:
        claim = self.client.active(token)
        if type(max_bytes) is not int or not 0 < max_bytes <= MAX_ARTIFACT_BYTES:
            raise AgentDbError("Invalid artifact read bound")
        artifact_id = uuid.UUID(ref.id)
        metadata = self.client.attempt_api.get_claim_artifact(
            claim.attempt_id,
            artifact_id,
            token,
            _headers=self.client.headers(),
            _request_timeout=self.client.timeout,
        )
        expected_hash = str((ref.metadata or {}).get("hash", "")).removeprefix(
            "sha256:"
        )
        if (
            metadata.artifact_id != artifact_id
            or metadata.byte_length > max_bytes
            or (ref.size is not None and ref.size != metadata.byte_length)
            or (ref.mime_type is not None and ref.mime_type != metadata.media_type)
            or (expected_hash and expected_hash != metadata.sha256)
        ):
            raise AgentDbError("Artifact reference commitment mismatch")
        response = (
            self.client.attempt_api.get_claim_artifact_bytes_without_preload_content(
                claim.attempt_id,
                artifact_id,
                token,
                _headers=self.client.headers(),
                _request_timeout=self.client.timeout,
            )
        )
        try:
            if response.status != 200:
                raise ApiException(
                    status=response.status,
                    body=response.read(amt=8193).decode("utf-8", errors="replace"),
                )
            body = response.read(amt=max_bytes + 1)
        finally:
            finish_cleanup(response.close, response.release_conn)
        if (
            len(body) != metadata.byte_length
            or hashlib.sha256(body).hexdigest() != metadata.sha256
        ):
            raise AgentDbError("Artifact content commitment mismatch")
        return body
