"""Artifact-backed identity for current and retained canonical worker cohorts."""

from __future__ import annotations

import hashlib
import inspect
import sys
from dataclasses import dataclass
from importlib.machinery import PathFinder
from importlib.util import source_from_cache
from pathlib import Path
from typing import Any
from zipfile import BadZipFile

from cogit_runtime.agentdb.cohort_contract import (
    CohortReceipt,
    WorkerExecutable,
    parse_cohort_json,
)
from cogit_runtime.agentdb.cohort_files import plain_path, read_bounded
from cogit_runtime.agentdb.cohort_providers import require_selected_providers
from cogit_runtime.agentdb.cohort_wheels import verify_wheel
from cogit_runtime.agentdb.config import AgentDbConfig
from cogit_runtime.agentdb.errors import AgentDbAuthorityError, AgentDbError

_FRAMEWORK_MODULES = {
    "cogit-runtime": "cogit_runtime",
    "cogit-agent-sdk": "cogit_agent_sdk",
    "agentdb-client": "agentdb_client",
}


@dataclass(frozen=True)
class VerifiedCohort:
    """A verified immutable deployment binding, rechecked before every claim."""

    path: Path
    receipt_sha256: str
    receipt: CohortReceipt
    manifest_path: Path
    agent_class: type[Any]

    def require_artifacts(self) -> None:
        try:
            executable, inventory = _verify_artifacts(
                self.path, self.receipt_sha256, self.receipt, self.manifest_path
            )
            _require_loaded_origins(executable, inventory, self.agent_class)
        except AgentDbError:
            raise
        except (OSError, ValueError, KeyError, TypeError, BadZipFile) as exc:
            raise AgentDbError("Canonical worker artifact verification failed") from exc

    def require_config(self, config: AgentDbConfig) -> None:
        if (
            config.installation_id != self.receipt.route.installation_id
            or config.pool_id != self.receipt.route.pool_id
        ):
            raise AgentDbAuthorityError(
                "Worker configuration differs from its artifact cohort"
            )

    def require_readiness(self, result: dict[str, Any]) -> None:
        expected = {
            "installationId": self.receipt.route.installation_id,
            "agentVersionId": self.receipt.route.version_id,
            "deploymentId": self.receipt.route.deployment_id,
            "poolId": self.receipt.route.pool_id,
        }
        if (
            result.get("ready") is not True
            or result.get("cohortStatus") not in {"active", "retained"}
            or any(result.get(key) != str(value) for key, value in expected.items())
        ):
            raise AgentDbAuthorityError(
                "Canonical worker readiness failed for loaded artifact cohort"
            )

    def require_claim(self, claim: Any) -> None:
        expected = self.receipt.route
        fields = tuple(type(expected).model_fields)
        if claim.tenant_id != self.receipt.tenant_id or any(
            getattr(claim.route, name, None) != getattr(expected, name)
            for name in fields
        ):
            raise AgentDbAuthorityError(
                "Claim immutable route differs from loaded worker artifacts"
            )


def load_cohort(
    receipt_path: Path,
    *,
    manifest_path: Path,
    agent_class: type[Any],
    config: AgentDbConfig,
) -> VerifiedCohort:
    """Load the mandatory binding without accepting identity env overrides."""
    try:
        absolute = receipt_path.absolute()
        body = read_bounded(plain_path(absolute.parent, absolute.name), 16384)
        receipt = CohortReceipt.model_validate(parse_cohort_json(body))
        cohort = VerifiedCohort(
            absolute,
            hashlib.sha256(body).hexdigest(),
            receipt,
            manifest_path.absolute(),
            agent_class,
        )
        cohort.require_config(config)
        cohort.require_artifacts()
        return cohort
    except AgentDbError:
        raise
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise AgentDbError("Invalid canonical worker deployment receipt") from exc


def preflight_cohort(
    receipt_path: Path,
    *,
    manifest_path: Path,
    agent_entrypoint: str,
    config: AgentDbConfig,
) -> None:
    """Verify installed bytes and entrypoint before importing the agent."""
    try:
        absolute = receipt_path.absolute()
        body = read_bounded(plain_path(absolute.parent, absolute.name), 16384)
        receipt = CohortReceipt.model_validate(parse_cohort_json(body))
        if (
            config.installation_id != receipt.route.installation_id
            or config.pool_id != receipt.route.pool_id
        ):
            raise AgentDbAuthorityError(
                "Worker configuration differs from its artifact cohort"
            )
        executable, inventory = _verify_artifacts(
            absolute,
            hashlib.sha256(body).hexdigest(),
            receipt,
            manifest_path.absolute(),
        )
        if executable.entrypoint != agent_entrypoint:
            raise AgentDbError(
                "Requested agent differs from immutable executable entrypoint"
            )
        agent_package = executable.entrypoint.split(":", 1)[0].split(".", 1)[0]
        if any(
            name == agent_package or name.startswith(agent_package + ".")
            for name in sys.modules
        ):
            raise AgentDbError("Canonical worker agent was imported before preflight")
        _require_agent_import_origin(
            executable.entrypoint, inventory[executable.agent_distribution]
        )
    except AgentDbError:
        raise
    except (OSError, ValueError, KeyError, TypeError, BadZipFile) as exc:
        raise AgentDbError("Canonical worker artifact preflight failed") from exc


def _verify_artifacts(
    path: Path,
    receipt_sha256: str,
    receipt: CohortReceipt,
    manifest_path: Path,
) -> tuple[WorkerExecutable, dict[str, frozenset[Path]]]:
    receipt_path = plain_path(path.parent, path.name)
    body = read_bounded(receipt_path, 16384)
    if hashlib.sha256(body).hexdigest() != receipt_sha256:
        raise AgentDbError("Canonical worker deployment receipt changed")
    root = path.parent
    manifest = plain_path(root, receipt.manifest)
    if manifest.resolve() != manifest_path.resolve():
        raise AgentDbError("Canonical worker loaded a different manifest")
    manifest_body = read_bounded(manifest, 1024 * 1024)
    if hashlib.sha256(manifest_body).hexdigest() != receipt.route.manifest_sha256:
        raise AgentDbError("Canonical worker manifest commitment mismatch")
    descriptor = read_bounded(plain_path(root, receipt.executable), 65536)
    if hashlib.sha256(descriptor).hexdigest() != receipt.route.executable_sha256:
        raise AgentDbError("Canonical worker executable commitment mismatch")
    executable = WorkerExecutable.model_validate(parse_cohort_json(descriptor))
    inventory = {
        wheel.distribution: verify_wheel(root, wheel) for wheel in executable.wheels
    }
    _require_selected_import_origins(inventory)
    require_selected_providers(manifest_body, executable, inventory)
    return executable, inventory


def _require_selected_import_origins(inventory: dict[str, frozenset[Path]]) -> None:
    """Selected provider wheels cannot shadow another wheel or an import origin."""
    owners: dict[str, str] = {}
    for distribution, files in inventory.items():
        prefixes: set[str] = set()
        for path in files:
            if path.suffix != ".py":
                continue
            parts = path.parts
            sites = [
                i
                for i, part in enumerate(parts)
                if part in {"site-packages", "dist-packages"}
            ]
            if not sites:
                raise AgentDbError("Selected wheel has no installed package root")
            top = parts[sites[-1] + 1]
            prefixes.add(top[:-3] if top.endswith(".py") else top)
        for prefix in prefixes:
            if prefix in owners and owners[prefix] != distribution:
                raise AgentDbError("Selected wheels overlap an import namespace")
            owners[prefix] = distribution
            spec = PathFinder.find_spec(prefix)
            if (
                spec is None
                or not isinstance(spec.origin, str)
                or Path(spec.origin).resolve() not in files
            ):
                raise AgentDbError("Selected provider import would use unverified code")
            for name, loaded in tuple(sys.modules.items()):
                if name != prefix and not name.startswith(prefix + "."):
                    continue
                origin = getattr(loaded, "__file__", None)
                if isinstance(origin, str) and origin.endswith(".pyc"):
                    origin = source_from_cache(origin)
                if not isinstance(origin, str) or Path(origin).resolve() not in files:
                    raise AgentDbError(
                        "Loaded provider module origin is outside its selected wheel"
                    )


def _require_agent_import_origin(entrypoint: str, approved: frozenset[Path]) -> None:
    """Resolve package files without importing parents or executing agent code."""
    parts = entrypoint.split(":", 1)[0].split(".")
    locations: list[str] | None = None
    for index in range(len(parts)):
        name = ".".join(parts[: index + 1])
        spec = PathFinder.find_spec(name, locations)
        if spec is None or not isinstance(spec.origin, str):
            raise AgentDbError("Canonical worker agent import has no verified origin")
        if Path(spec.origin).resolve(strict=True) not in approved:
            raise AgentDbError(
                "Canonical worker agent import would use unverified code"
            )
        if index + 1 < len(parts):
            if spec.submodule_search_locations is None:
                raise AgentDbError("Canonical worker agent import is not a package")
            locations = list(spec.submodule_search_locations)


def _require_loaded_origins(
    executable: WorkerExecutable,
    inventory: dict[str, frozenset[Path]],
    agent_class: type[Any],
) -> None:
    module_name, class_name = executable.entrypoint.split(":")
    module = sys.modules.get(module_name)
    if (
        agent_class.__module__ != module_name
        or agent_class.__name__ != class_name
        or module is None
        or getattr(module, class_name, None) is not agent_class
    ):
        raise AgentDbError(
            "Loaded agent class differs from immutable executable entrypoint"
        )
    agent_files = inventory[executable.agent_distribution]
    if Path(inspect.getfile(agent_class)).resolve() not in agent_files:
        raise AgentDbError("Loaded agent origin differs from its installed wheel")
    modules = {
        **_FRAMEWORK_MODULES,
        executable.agent_distribution: module_name.split(".")[0],
    }
    for distribution, prefix in modules.items():
        if prefix not in sys.modules:
            raise AgentDbError("Expected canonical worker package is not loaded")
        for name, loaded in tuple(sys.modules.items()):
            if name != prefix and not name.startswith(prefix + "."):
                continue
            origin = getattr(loaded, "__file__", None)
            if not isinstance(origin, str):
                raise AgentDbError(
                    "Canonical worker module has no verified file origin"
                )
            if origin.endswith(".pyc"):
                origin = source_from_cache(origin)
            if Path(origin).resolve() not in inventory[distribution]:
                raise AgentDbError(
                    "Loaded canonical worker module is outside its wheel"
                )
