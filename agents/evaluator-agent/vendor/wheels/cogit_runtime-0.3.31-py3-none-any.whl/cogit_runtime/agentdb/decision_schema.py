"""Bounded immutable commitments for canonical human decisions."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from pydantic.alias_generators import to_camel

Digest = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]
DecisionKey = Annotated[
    str, Field(strict=True, pattern=r"^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$")
]
OperationId = Annotated[str, Field(strict=True, pattern=r"^[a-z][a-z0-9._-]{1,127}$")]


def utc_deadline(value: str) -> str:
    if not isinstance(value, str) or not 20 <= len(value) <= 40:
        raise ValueError("Invalid decision deadline")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Decision deadline needs a timezone")
    return parsed.astimezone(UTC).isoformat().replace("+00:00", "Z")


class DecisionValue(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)


class DecisionIntent(DecisionValue):
    origin_work_id: UUID
    first_generation: Annotated[int, Field(strict=True, ge=1)]
    operation_id: OperationId
    payload_sha256: Digest
    authorized_decider_id: UUID
    expires_at: str
    idempotency: Literal["inherent", "keyed"]
    invocation_key: (
        Annotated[str, Field(strict=True, min_length=1, max_length=256)] | None
    ) = None

    _deadline = field_validator("expires_at")(utc_deadline)

    @model_validator(mode="after")
    def keyed(self) -> DecisionIntent:
        if self.idempotency == "keyed" and self.invocation_key is None:
            raise ValueError("Protected keyed operation requires its actual key")
        return self


class PackagePin(DecisionValue):
    model_config = ConfigDict(
        extra="forbid", frozen=True, populate_by_name=True, alias_generator=to_camel
    )
    module_key: Annotated[str, Field(strict=True, min_length=1, max_length=96)]
    version: Annotated[str, Field(strict=True, min_length=1, max_length=128)]
    artifact_sha256: Digest


class DecisionReceipt(DecisionValue):
    model_config = ConfigDict(
        extra="forbid", frozen=True, populate_by_name=True, alias_generator=to_camel
    )
    request_id: UUID
    work_item_id: UUID
    attempt_id: UUID
    generation: Annotated[int, Field(strict=True, ge=1)]
    run_id: UUID | None = None
    case_id: UUID | None = None
    task_id: UUID | None = None
    operation_id: OperationId
    payload_sha256: Digest
    authorized_decider_id: UUID
    expires_at: str
    agent_version_id: UUID
    agent_manifest_sha256: Digest
    package_pins: Annotated[tuple[PackagePin, ...], Field(max_length=256)]
    package_pins_sha256: Digest
    wait_id: UUID
    attention_id: UUID
    state: Literal[
        "pending", "approved", "rejected", "expired", "cancelled", "continued"
    ]
    successor_work_item_id: UUID
    successor_dispatch_id: UUID
    decision: Literal["approve", "reject"] | None = None

    _deadline = field_validator("expires_at")(utc_deadline)

    @model_validator(mode="after")
    def pin_commitment(self) -> DecisionReceipt:
        # D11 hashes PostgreSQL jsonb::text. Its three fixed object keys have
        # the following length/byte order; preserve the producer's array order.
        pins = [
            {
                "version": p.version,
                "moduleKey": p.module_key,
                "artifactSha256": p.artifact_sha256,
            }
            for p in self.package_pins
        ]
        material = json.dumps(
            pins, ensure_ascii=False, separators=(", ", ": ")
        ).encode()
        if hashlib.sha256(material).hexdigest() != self.package_pins_sha256:
            raise ValueError("Decision package pin commitment differs")
        if len({p.module_key for p in self.package_pins}) != len(self.package_pins):
            raise ValueError("Decision package pins contain duplicates")
        if self.work_item_id == self.successor_work_item_id:
            raise ValueError("Decision successor must be distinct")
        return self


class DecisionSlot(DecisionValue):
    phase: Literal["prepared", "requested"]
    intent: DecisionIntent
    receipt: DecisionReceipt | None = None

    @model_validator(mode="after")
    def receipt_phase(self) -> DecisionSlot:
        if (self.phase == "requested") != (self.receipt is not None):
            raise ValueError("Decision phase lacks its matching evidence")
        return self
