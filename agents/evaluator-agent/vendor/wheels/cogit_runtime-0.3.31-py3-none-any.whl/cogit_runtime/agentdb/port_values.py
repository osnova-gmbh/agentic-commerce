"""Internal worker port values, independent of AgentDb's HTTP wire models.

These preserve Runtime's coordinator interface; current_client maps each supported
operation to the generated AgentDb contract. Unsupported capabilities raise.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Any, Literal
from uuid import UUID

from cogit_agent_sdk.types import CapabilityGrant
from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel


class PortValue(BaseModel):
    model_config = ConfigDict(populate_by_name=True, alias_generator=to_camel)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json", by_alias=True, exclude_none=True)


class AttemptStatus(StrEnum):
    CLAIMED = "claimed"
    RUNNING = "running"
    PARKED = "parked"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


class ExecutionMode(StrEnum):
    EXECUTION = "execution"
    SCHEMA_PLANNING = "schema_planning"


class StructuredError(PortValue):
    code: str
    message: str
    retryable: bool | None = None


class DerivedClaimContext(PortValue):
    tenant_id: UUID
    principal_id: UUID
    installation_id: UUID
    deployment_id: UUID
    pool_id: UUID
    agent_version_id: UUID
    run_id: UUID | None
    parent_shape: Literal["run", "run_plus_task", "task"] = "run"
    case_id: UUID | None = None
    task_id: UUID | None = None


class QueueDeliveryIdentity(PortValue):
    """Server-issued queue delivery, never exposed to agent code."""

    contract_version: Literal["pgboss-1"]
    job_id: UUID
    delivery_generation: Annotated[int, Field(strict=True, ge=0)]
    business_key: Annotated[str, Field(min_length=1, max_length=512)]


class ClaimAccepted(PortValue):
    outcome: str
    work_item_id: UUID
    attempt_id: UUID
    attempt_number: int
    attempt_token: str = Field(repr=False)
    lease_expires_at: datetime
    deadline_at: datetime | None = None
    derived: DerivedClaimContext
    input: dict[str, Any] | None = None
    input_sha256: str | None = None
    permissions: tuple[CapabilityGrant, ...] | None = None
    model_spend: dict[str, Any] | None = None
    context_refs: list[dict[str, Any]] | None = None
    processing_id: UUID | None = None
    processing_configuration_sha256: str | None = None
    processing_source_artifact_id: UUID | None = None
    delivery: QueueDeliveryIdentity | None = None


class ClaimEmpty(PortValue):
    outcome: str


class ClaimAlreadyParked(PortValue):
    outcome: str
    work_item_id: UUID


@dataclass
class ClaimResult:
    actual_instance: Any = None


class CancelWorkRequest(PortValue):
    reason: str | None = None


class ClaimWorkRequest(PortValue):
    lease_seconds: Annotated[int, Field(le=3600, strict=True, ge=10)] | None = None


class FailAttemptRequest(PortValue):
    error: StructuredError
    retryable: bool | None = False


class HeartbeatAttemptRequest(PortValue):
    progress: dict[str, Any] | None = None


class ParkAttemptRequest(PortValue):
    checkpoint_id: UUID
    continuation_idempotency_key: (
        Annotated[str, Field(min_length=8, strict=True, max_length=128)] | None
    ) = None
    wait_reason: str | None = None


class SettleAttemptRequest(PortValue):
    result_artifact_id: UUID | None = None
    artifact_ids: list[UUID] | None = None


class AllocateArtifactUploadRequest(PortValue):
    expected_bytes: Annotated[int, Field(strict=True, ge=1)] | None = None
    expected_hash: Annotated[str, Field(strict=True)] | None = None


class CreateModelCallIntentRequest(PortValue):
    provider: str
    model: str
    purpose: str | None = None
    intent_key: str | None = None


class DeclareArtifactRequest(PortValue):
    run_id: UUID | None
    execution_id: UUID | None = None
    kind: str
    media_type: str
    filename: str | None = None
    max_size_bytes: Annotated[int, Field(strict=True, ge=1)] | None = None
    renderer_hint: str | None = None


class FinalizeArtifactUploadRequest(PortValue):
    expected_generation: int
    byte_count: int
    content_hash: str


class RecordExecutionStepRequest(PortValue):
    step_order: int
    kind: str
    status: str
    input_artifact_id: UUID | None = None
    output_artifact_id: UUID | None = None


class ReserveModelCallBudgetRequest(PortValue):
    execution_id: UUID
    intent_id: UUID
    provider: str
    model: str
    max_input_tokens: int
    max_output_tokens: int
    max_cost_amount: str
    currency: str


class SettleModelCallBudgetRequest(PortValue):
    input_tokens: int
    output_tokens: int
    cost_amount: str
    currency: str | None = None


class StartExecutionRequest(PortValue):
    work_attempt_id: UUID
    mode: ExecutionMode | None = None
    context_manifest_id: UUID | None = None


class WorkAttempt(PortValue):
    id: UUID
    work_item_id: UUID
    attempt_number: int
    status: AttemptStatus
    claimant_kind: str
    lease_expires_at: datetime | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    error: StructuredError | None = None
    version: int
