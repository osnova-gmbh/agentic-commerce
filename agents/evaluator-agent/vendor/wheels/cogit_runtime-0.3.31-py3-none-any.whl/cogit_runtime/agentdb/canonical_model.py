"""One explicit logical model slot, with current authority checked on every call."""

from __future__ import annotations

from collections.abc import Callable, Iterable

from cogit_agent_sdk.types import (
    Cancellation,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
)

from cogit_runtime.agentdb.model_dispatch import DurableModelDispatch
from cogit_runtime.agentdb.model_streams import close_stream
from cogit_runtime.model import GuardedModelClient


class CanonicalModelClient:
    """Reuse a completed slot or dispatch exactly once through the D12 boundary.

    The host or resident supplies a semantic slot from its persisted workflow.
    A provider response ID, request hash, or fresh attempt counter is not a slot.
    Holding this object does not extend the lifetime of its execution authority.
    """

    def __init__(
        self,
        *,
        routes: GuardedModelClient,
        dispatch: DurableModelDispatch,
        slot_key: str,
        require_authority: Callable[[], None],
    ) -> None:
        self._routes = routes
        self._dispatch = dispatch
        self._slot_key = slot_key
        self._require_authority = require_authority

    def generate(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> ModelResponse:
        self._require_authority()
        model, provider = self._routes.identified_route(request)
        return self._dispatch.generate(
            self._slot_key, model, provider, request, cancellation
        )

    def stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterable[ModelStreamEvent]:
        self._require_authority()
        model, provider = self._routes.identified_route(request, streaming=True)
        events = self._dispatch.stream(
            self._slot_key, model, provider, request, cancellation
        )
        try:
            yield from events
        finally:
            close_stream(events)
