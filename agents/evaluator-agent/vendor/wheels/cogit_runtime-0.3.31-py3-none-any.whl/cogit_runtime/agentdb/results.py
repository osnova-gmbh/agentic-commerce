"""Runtime-owned AgentDb results that hide generated client types."""

from __future__ import annotations

import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from cogit_runtime.agentdb.errors import AgentDbError


@dataclass(frozen=True)
class DeclaredArtifact:
    """Canonical artifact identity returned by AgentDb."""

    id: uuid.UUID


@dataclass(frozen=True)
class UploadLease:
    """Fenced upload allocation used for finalization."""

    id: uuid.UUID
    fencing_generation: int
    upload_url: str | None = None


@dataclass(frozen=True)
class FinalizedArtifact:
    """Artifact that completed upload finalization."""

    id: uuid.UUID


def entity_id(value: Any, *names: str) -> uuid.UUID:
    """Read a server-issued UUID or fail closed without fabricating one."""

    for name in names:
        raw = getattr(value, name, None)
        if raw is None and isinstance(value, Mapping):
            raw = value.get(name)
        if raw is not None:
            return uuid.UUID(str(raw))
    raise AgentDbError("AgentDb response omitted a canonical identifier")


def optional_str(value: Any, *names: str) -> str | None:
    for name in names:
        raw = getattr(value, name, None)
        if raw is None and isinstance(value, Mapping):
            raw = value.get(name)
        if isinstance(raw, str) and raw:
            return raw
    return None


def required_int(value: Any, *names: str) -> int:
    for name in names:
        raw = getattr(value, name, None)
        if raw is None and isinstance(value, Mapping):
            raw = value.get(name)
        if raw is not None:
            return int(raw)
    raise AgentDbError("AgentDb response omitted a fencing generation")
