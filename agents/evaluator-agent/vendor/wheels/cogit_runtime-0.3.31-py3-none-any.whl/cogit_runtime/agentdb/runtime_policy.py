"""Typed bridge to the installed AgentDB runtime-policy module."""

from __future__ import annotations

import hashlib
import json
from typing import TYPE_CHECKING
from uuid import uuid4

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types.policy import AuthorizationDecision, PolicyCheckpoint
from pydantic import ValidationError

from cogit_runtime.agentdb.errors import AgentDbAuthorityError

if TYPE_CHECKING:
    from cogit_runtime.agentdb.handle import AgentDbRunHandle


def evaluate_checkpoint(
    handle: AgentDbRunHandle,
    checkpoint: PolicyCheckpoint,
) -> AuthorizationDecision:
    material = checkpoint.model_dump(mode="json", by_alias=True)
    commitment = hashlib.sha256(
        json.dumps(
            material,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode()
    ).hexdigest()
    # Never reuse a stale allow receipt. The nonce forces evaluation on every
    # boundary, including replays, checkpoints and approval continuation.
    request_id = str(uuid4())
    try:
        raw = handle.module_command(
            "cogit.runtime-policy",
            "checkpoint.evaluate",
            {"requestId": request_id, "checkpoint": material},
            contract_id="runtime.checkpoint.v1",
            idempotency_key=request_id,
        )
    except CoordinationFailure:
        raise
    except Exception:
        # A policy service failure cannot become an ordinary recoverable tool
        # error: mandatory authority must stop the enclosing execution.
        raise AgentDbAuthorityError(
            "Required policy authority could not decide"
        ) from None
    try:
        decision = AuthorizationDecision.model_validate(raw)
    except ValidationError:
        raise AgentDbAuthorityError(
            "Runtime policy receipt is absent or malformed"
        ) from None
    context = handle.context
    subject = decision.subject
    if (
        decision.decision_id != request_id
        or decision.checkpoint_sha256 != commitment
        or subject.tenant_id != context.tenant_id
        or subject.execution_id != handle.execution_id
        or context.principal is None
        or subject.principal_id != context.principal.id
    ):
        raise AgentDbAuthorityError("Runtime policy receipt binding does not match")
    handle._router.require_policy_subject(subject, execution_id=handle.execution_id)
    return decision
