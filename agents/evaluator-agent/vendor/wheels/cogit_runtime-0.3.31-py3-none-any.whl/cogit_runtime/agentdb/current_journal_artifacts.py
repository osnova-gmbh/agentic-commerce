"""Use the existing fenced binary artifact transport for Runtime journal indexes."""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING
from uuid import UUID

from cogit_agent_sdk.types import ArtifactRef

from cogit_runtime.agentdb.continuation_index import MAX_INDEX_BYTES
from cogit_runtime.agentdb.continuation_schema import ContinuationArtifact
from cogit_runtime.agentdb.errors import AgentDbAuthorityError
from cogit_runtime.agentdb.port_values import (
    AllocateArtifactUploadRequest,
    DeclareArtifactRequest,
    FinalizeArtifactUploadRequest,
)

if TYPE_CHECKING:
    from cogit_runtime.agentdb.current_client import CurrentClient


class CurrentJournalArtifacts:
    def __init__(self, client: CurrentClient) -> None:
        self.client = client

    def save(self, body: bytes) -> ContinuationArtifact:
        client = self.client
        claim = client.claim
        if claim is None or client.execution_id is None:
            raise AgentDbAuthorityError("Journal publication needs an active execution")
        if not isinstance(body, bytes) or not 0 < len(body) <= MAX_INDEX_BYTES:
            raise AgentDbAuthorityError("Journal index exceeds its publication bound")
        sha = hashlib.sha256(body).hexdigest()
        key = f"runtime-journal:{client.execution_id}:{sha}"
        declared = client.artifacts.declare_artifact(
            claim.token,
            key,
            DeclareArtifactRequest(
                run_id=claim.run_id,
                execution_id=UUID(client.execution_id),
                kind="runtime-journal",
                media_type="application/json",
                filename=f"{sha}.json",
                max_size_bytes=MAX_INDEX_BYTES,
            ),
        )
        slot = declared["id"]
        allocation = client.artifacts.allocate_artifact_upload(
            slot,
            claim.token,
            key + ":allocate",
            AllocateArtifactUploadRequest(expected_bytes=len(body), expected_hash=sha),
        )
        client.artifacts.upload_bytes(allocation["id"], body)
        finalized = client.artifacts.finalize_artifact_upload(
            slot,
            allocation["id"],
            claim.token,
            key + ":finalize",
            FinalizeArtifactUploadRequest(
                expected_generation=claim.generation,
                byte_count=len(body),
                content_hash=sha,
            ),
        )
        return ContinuationArtifact.model_validate(
            {
                "id": finalized["id"],
                "mime_type": "application/json",
                "size": len(body),
                "metadata": {"hash": sha},
            }
        )

    def read(self, ref: ContinuationArtifact) -> bytes:
        claim = self.client.claim
        if claim is None:
            raise AgentDbAuthorityError("Journal read needs an active claim")
        return self.client.artifacts.read_artifact(
            ArtifactRef.model_validate(ref.model_dump(mode="json")),
            claim.token,
            MAX_INDEX_BYTES,
        )
