"""Deterministic pipeline recovery through verified canonical checkpoints."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict
from typing import Any

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import ArtifactRef, Context, WorkOutcome

from cogit_runtime.agentdb.continuation_schema import PipelineContinuation, PipelineSlot
from cogit_runtime.agentdb.errors import (
    AgentDbAuthorityError,
    AgentDbReconciliationRequiredError,
)
from cogit_runtime.cancellation import RuntimeCancelledError, RuntimeWorkDeferred
from cogit_runtime.operations.errors import OperationExecutionError
from cogit_runtime.pipeline import (
    OnFailure,
    PipelineResult,
    PipelineRunner,
    StepResult,
    StepType,
)

_RESULT_LIMIT = 1024 * 1024


class _BoundKeyHost:
    def __init__(self, host: Any, key: str | None) -> None:
        self.host, self.key = host, key

    def __getattr__(self, name: str) -> Any:
        return getattr(self.host, name)

    async def execute_bound_action(self, *args: Any, **kwargs: Any) -> Any:
        return await self.host.execute_bound_action(
            *args, **{**kwargs, "idempotency_key": self.key, "key_source": "caller"}
        )


class CanonicalPipelineRunner(PipelineRunner):
    """One bounded deterministic graph; business outputs live in artifacts."""

    def __init__(self, *, handle: Any, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        if not self._explicit_pipeline_id or not 0 < len(self._steps) <= 128:
            raise AgentDbAuthorityError(
                "Canonical pipeline needs a bounded stable identity"
            )
        if len({step.name for step in self._steps}) != len(self._steps):
            raise AgentDbAuthorityError("Canonical pipeline step names must be unique")
        if any(step.on_failure == OnFailure.ESCALATE for step in self._steps):
            raise AgentDbAuthorityError(
                "Canonical escalation requires a decision continuation"
            )
        if any(not 1 <= step.max_retries <= 100 for step in self._steps):
            raise AgentDbAuthorityError(
                "Canonical pipeline retry policy exceeds its bound"
            )
        self._handle = handle
        self._journal = handle.continuation
        self._slot = (
            "pipeline:" + hashlib.sha256(self._pipeline_id.encode()).hexdigest()
        )
        definition = {
            "pipeline": self._pipeline_id,
            "agent_version": self._agent_version,
            "steps": [
                {
                    **asdict(step),
                    "step_type": step.step_type.value,
                    "on_failure": step.on_failure.value,
                }
                for step in self._steps
            ],
        }
        digest = hashlib.sha256(_json_bytes(definition)).hexdigest()
        previous = self._journal.read_pipeline(self._slot)
        if previous is None:
            self._state = PipelineContinuation(definition_sha256=digest)
            self._journal.write_pipeline(
                self._slot, self._state.model_dump(mode="json"), expected_revision=None
            )
        else:
            self._state = PipelineContinuation.model_validate(previous)
            if self._state.definition_sha256 != digest:
                raise AgentDbAuthorityError(
                    "Canonical pipeline definition changed on resume"
                )

    async def execute(
        self,
        loop_host: Any,
        context: Context,
        reporter: Any,
        execution_id: str,
        *,
        cancellation: Any = None,
    ) -> PipelineResult:
        results: list[StepResult] = []
        metadata = context.metadata or {}
        attempt_number = metadata.get("attempt_number", 1)
        if type(attempt_number) is not int or attempt_number < 1:
            raise AgentDbAuthorityError("Invalid admitted attempt number")
        for index, step in enumerate(self._steps):
            if cancellation is not None:
                cancellation.throw_if_cancelled()
            key = str(index)
            slot = self._state.steps.get(key)
            maximum = step.max_retries if step.on_failure == OnFailure.RETRY else 1
            while True:
                if slot is not None and slot.phase != "intent":
                    result, outcome = self._read_result(slot)
                    policy = getattr(loop_host, "_policy", None)
                    if policy is not None:
                        action = step.action_name or step.name
                        descriptor = loop_host.action_descriptor(action)
                        if descriptor is None and step.step_type not in {
                            StepType.TERMINAL,
                            StepType.AGENTIC,
                        }:
                            raise AgentDbAuthorityError(
                                "Cached pipeline action has no current descriptor"
                            )
                        if descriptor is not None:
                            policy.require(
                                self._handle,
                                policy.checkpoint(
                                    phase="checkpoint",
                                    operation=policy.operation(
                                        action, descriptor.requirements
                                    ),
                                    payload=step.payload or {},
                                    slot=f"{self._slot}:step:{index}:v{step.key_version}",
                                    result=asdict(result),
                                    state="completed",
                                ),
                            )
                    if outcome is not None:
                        self._checkpoint.work_outcome = outcome
                    if (
                        slot.phase != "failed"
                        or slot.idempotency == "none"
                        or step.on_failure != OnFailure.RETRY
                        or slot.attempts >= maximum
                    ):
                        break
                action = step.action_name or step.name
                terminal = (
                    step.step_type == StepType.TERMINAL and step.action_name is None
                )
                agentic = step.step_type == StepType.AGENTIC
                descriptor = (
                    None if terminal or agentic else loop_host.action_descriptor(action)
                )
                idempotency = (
                    "inherent"
                    if terminal or agentic
                    else descriptor.idempotency
                    if descriptor
                    else "none"
                )
                if slot is not None and slot.idempotency != idempotency:
                    raise AgentDbAuthorityError("Pipeline operation contract changed")
                if slot is not None and slot.phase == "intent":
                    if slot.idempotency == "none":
                        raise AgentDbReconciliationRequiredError(
                            "Interrupted pipeline operation has no safe replay contract"
                        )
                    invocation_key, attempt = slot.invocation_key, slot.attempts
                else:
                    if slot is None and attempt_number > 1 and idempotency == "none":
                        raise AgentDbReconciliationRequiredError(
                            "Replacement claim cannot prove an unkeyed operation "
                            "is unstarted"
                        )
                    generated = self._stable_key(context, step.name, step.key_version)
                    invocation_key = (
                        slot.invocation_key
                        if slot is not None
                        else None
                        if terminal or agentic
                        else loop_host.resolve_pipeline_key(
                            action, step.payload or {}, context, generated
                        )
                    )
                    attempt = slot.attempts + 1 if slot else 1
                    slot = PipelineSlot(
                        phase="intent",
                        attempts=attempt,
                        idempotency=idempotency,
                        invocation_key=invocation_key,
                    )
                    self._write_slot(key, slot)
                step_context = context.model_copy(
                    update={
                        "metadata": {
                            **metadata,
                            "runtime_pipeline_slot": (
                                f"{self._slot}:step:{index}:v{step.key_version}"
                            ),
                        }
                    }
                )
                try:
                    if agentic:
                        output = await loop_host.run_canonical_step(
                            instruction=step.instruction
                            or f"Execute step: {step.name}",
                            context=step_context,
                            execution_id=execution_id,
                            cancellation=cancellation,
                            timeout_seconds=step.timeout_seconds,
                        )
                        self._checkpoint.work_outcome = self._handle.work_outcome
                    else:
                        output = await self._dispatch_step(
                            step=step,
                            loop_host=_BoundKeyHost(loop_host, invocation_key),
                            context=step_context,
                            reporter=reporter,
                            execution_id=execution_id,
                            cancellation=cancellation,
                            attempt=attempt,
                        )
                    result = StepResult(step.name, "completed", output=output)
                except (CoordinationFailure, RuntimeWorkDeferred):
                    raise
                except RuntimeCancelledError:
                    result = StepResult(
                        step.name, "cancelled", error="Pipeline cancelled"
                    )
                except OperationExecutionError as exc:
                    result = StepResult(
                        step.name,
                        "failed",
                        error=(
                            exc.result.error.message
                            if exc.result.error
                            else "Operation failed"
                        ),
                    )
                    if (
                        exc.result.error
                        and exc.result.error.code == "APPROVAL_REQUIRED"
                    ):
                        result.status = "escalated"
                        result.attention_item_id = exc.result.attention_item_id
                    elif exc.result.invocation_started and idempotency == "none":
                        maximum = attempt
                except Exception as exc:
                    if idempotency == "none":
                        raise AgentDbReconciliationRequiredError(
                            "Unkeyed pipeline operation outcome is uncertain"
                        ) from None
                    result = StepResult(
                        step.name,
                        "failed",
                        error=f"Operation failed ({type(exc).__name__})",
                    )
                if result.status == "failed" and step.on_failure == OnFailure.SKIP:
                    result.status = "skipped"
                artifact = self._store_result(result)
                slot = slot.model_copy(
                    update={"phase": result.status, "result": artifact}
                )
                self._write_slot(key, slot)
                if (
                    result.status != "failed"
                    or attempt >= maximum
                    or step.on_failure != OnFailure.RETRY
                ):
                    break
            results.append(result)
            if result.status in {"cancelled", "failed", "escalated"}:
                return self._result(
                    "waiting" if result.status == "escalated" else result.status,
                    results,
                )
            if step.step_type == StepType.TERMINAL and result.status == "completed":
                return self._result("stopped", results)
        return self._result("completed", results)

    def _result(self, status: Any, results: list[StepResult]) -> PipelineResult:
        return PipelineResult(
            pipeline_id=self._pipeline_id,
            status=status,
            step_results=results,
            error=results[-1].error if results else None,
            attention_item_id=results[-1].attention_item_id if results else None,
            work_outcome=self._checkpoint.work_outcome,
        )

    def _stable_key(self, context: Context, name: str, version: str) -> str:
        return (
            "cogit:step:v1:"
            + hashlib.sha256(
                _json_bytes(
                    [
                        context.tenant_id,
                        context.agent_id,
                        self._agent_version,
                        str(self._journal.original_work_id),
                        self._pipeline_id,
                        name,
                        version,
                    ]
                )
            ).hexdigest()
        )

    def _write_slot(self, key: str, slot: PipelineSlot) -> None:
        candidate = self._state.model_copy(
            update={
                "revision": self._state.revision + 1,
                "steps": {**self._state.steps, key: slot},
            }
        )
        self._journal.write_pipeline(
            self._slot,
            candidate.model_dump(mode="json"),
            expected_revision=self._state.revision,
        )
        self._state = candidate

    def _store_result(self, result: StepResult) -> Any:
        try:
            return self._perform_store_result(result)
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Pipeline result evidence publication was not confirmed"
            ) from None

    def _perform_store_result(self, result: StepResult) -> Any:
        from cogit_runtime.agentdb.continuation_schema import ContinuationArtifact

        payload = {
            "result": asdict(result),
            "work_outcome": self._checkpoint.work_outcome.model_dump(mode="json")
            if self._checkpoint.work_outcome
            else None,
        }
        body = _json_bytes(payload)
        digest = hashlib.sha256(body).hexdigest()
        slot = self._handle.declare_artifact(
            "pipeline-result", "application/json", f"pipeline-{digest}.json"
        )
        artifact = self._handle.finalize_artifact(slot, body, digest)
        if (
            artifact.size != len(body)
            or (artifact.metadata or {}).get("hash") != digest
        ):
            raise AgentDbReconciliationRequiredError(
                "Pipeline result artifact commitment mismatch"
            )
        return ContinuationArtifact.model_validate(
            {
                "id": artifact.id,
                "mime_type": artifact.mime_type,
                "size": artifact.size,
                "metadata": {"hash": digest},
            }
        )

    def _read_result(self, slot: PipelineSlot) -> tuple[StepResult, WorkOutcome | None]:
        try:
            return self._perform_read_result(slot)
        except CoordinationFailure:
            raise
        except Exception:
            raise AgentDbReconciliationRequiredError(
                "Pipeline result evidence could not be verified"
            ) from None

    def _perform_read_result(
        self, slot: PipelineSlot
    ) -> tuple[StepResult, WorkOutcome | None]:
        assert slot.result is not None
        reference = ArtifactRef.model_validate(slot.result.model_dump(mode="json"))
        body = self._handle.read_artifact(reference, max_bytes=_RESULT_LIMIT)
        if (
            len(body) != slot.result.size
            or hashlib.sha256(body).hexdigest() != slot.result.metadata.hash
        ):
            raise AgentDbAuthorityError("Pipeline result artifact commitment mismatch")
        try:
            payload = json.loads(body)
            if set(payload) != {"result", "work_outcome"}:
                raise ValueError
            result = StepResult(**payload["result"])
            if result.status != slot.phase:
                raise ValueError
            outcome = (
                WorkOutcome.model_validate(payload["work_outcome"])
                if payload["work_outcome"] is not None
                else None
            )
            return result, outcome
        except (ValueError, TypeError, KeyError):
            raise AgentDbAuthorityError("Invalid pipeline result artifact") from None


def _json_bytes(value: Any) -> bytes:
    try:
        body = json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
            ensure_ascii=False,
        ).encode("utf-8")
    except (TypeError, ValueError, RecursionError):
        raise AgentDbAuthorityError("Pipeline state is not bounded JSON") from None
    if len(body) > _RESULT_LIMIT:
        raise AgentDbAuthorityError("Pipeline result exceeds its byte bound")
    return body
