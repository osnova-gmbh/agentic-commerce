"""Shared helpers for OperationExecutor boundary logic."""

from __future__ import annotations

import inspect
from collections.abc import Callable
from typing import Any, Literal

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.types import CapabilityGrant, Context, ErrorInfo
from cogit_agent_sdk.types.requirements import IdempotencyLevel, OperationRequirements
from cogit_agent_sdk.types.requirements import (
    missing_capabilities as missing_sdk_capabilities,
)
from pydantic import BaseModel

from cogit_runtime.cancellation import RuntimeCancellation

INVALID_OUTPUT_MESSAGE = "Operation returned invalid output"


def require_idempotency_key(
    idempotency: IdempotencyLevel,
    exposure_name: str,
    idempotency_key: str | None,
) -> ErrorInfo | None:
    if idempotency != "keyed":
        return None
    if idempotency_key is not None and idempotency_key.strip():
        return None
    return ErrorInfo(
        code="MISSING_IDEMPOTENCY_KEY",
        message=(
            f"Operation '{exposure_name}' requires a non-empty Idempotency-Key "
            "before invocation."
        ),
        retryable=False,
    )


def resolve_idempotency_key(
    *,
    key_for: Callable[[Any, Context], str] | None,
    request: BaseModel,
    context: Context,
    supplied_key: str | None,
    key_source: Literal["caller", "generated"] = "caller",
    idempotency: IdempotencyLevel,
    exposure_name: str,
) -> tuple[str | None, ErrorInfo | None]:
    """Resolve a binding's logical key from validated input before any effect."""

    try:
        # Explicit caller keys (including HTTP Idempotency-Key) own their
        # identity. Generated pipeline slots may yield to a domain resolver.
        use_resolver = key_for is not None and (
            key_source == "generated" or supplied_key is None
        )
        key: object = (
            key_for(request, context)
            if use_resolver and key_for is not None
            else supplied_key
        )
    except CoordinationFailure:
        raise
    except Exception:
        return None, ErrorInfo(
            code="INVALID_IDEMPOTENCY_KEY",
            message=f"Operation '{exposure_name}' could not resolve its logical key.",
            retryable=False,
        )
    if key is None:
        return None, require_idempotency_key(idempotency, exposure_name, None)
    if (
        not isinstance(key, str)
        or not key.strip()
        or key != key.strip()
        or len(key) > 256
    ):
        return None, ErrorInfo(
            code="INVALID_IDEMPOTENCY_KEY",
            message=(
                f"Operation '{exposure_name}' requires a non-empty logical key "
                "without surrounding whitespace and of at most 256 characters."
            ),
            retryable=False,
        )
    return key, None


def missing_capabilities(
    requirements: OperationRequirements,
    exposure_name: str,
    context: Any,
) -> ErrorInfo | None:
    required = tuple(requirements.required_capabilities)
    if not required:
        return None
    permissions = context.permissions
    # Preserve the exact legacy-string boundary: string subclasses may carry
    # scope metadata and must not silently become core authority.
    grants = (
        tuple(
            value
            for value in permissions
            if type(value) is str or isinstance(value, CapabilityGrant)
        )
        if isinstance(permissions, (list, tuple))
        else ()
    )
    missing = missing_sdk_capabilities(required, grants)
    if not missing:
        return None
    joined = ", ".join(
        value.name
        if value.module_scope is None
        else f"{value.name}@{value.module_scope}"
        for value in missing
    )
    unset = " (permissions are unset)" if permissions is None else ""
    return ErrorInfo(
        code="CAPABILITY_DENIED",
        message=(
            f"Operation '{exposure_name}' requires capabilities not present "
            f"in context{unset}: {joined}"
        ),
        retryable=False,
    )


def coerce_output(output_model: type[BaseModel], raw_result: Any) -> BaseModel:
    if isinstance(raw_result, output_model):
        return raw_result
    if isinstance(raw_result, BaseModel):
        return output_model.model_validate(raw_result.model_dump(mode="json"))
    return output_model.model_validate(raw_result)


def serialize_output(output: BaseModel) -> Any:
    return output.model_dump(mode="json", by_alias=True)


def cancelled_error() -> ErrorInfo:
    return ErrorInfo(
        code="CANCELLED",
        message="Operation was cancelled",
        retryable=False,
    )


async def invoke_operation_callable(
    operation: Callable[..., Any],
    args: tuple[Any, ...],
    cancellation: RuntimeCancellation,
) -> Any:
    """Invoke sync operations on the worker thread and await async operations."""

    if inspect.iscoroutinefunction(operation):
        return await operation(*args)
    underlying_call = type(operation).__call__
    if underlying_call is not object.__call__ and inspect.iscoroutinefunction(
        underlying_call
    ):
        return await underlying_call(operation, *args)

    from cogit_runtime.cooperative_worker import call_maybe_async

    return await call_maybe_async(operation, *args, cancellation=cancellation)
