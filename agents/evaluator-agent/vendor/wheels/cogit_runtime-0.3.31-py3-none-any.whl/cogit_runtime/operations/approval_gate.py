"""Shared approval gate for all action invocation adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from cogit_agent_sdk.types import ActionDescriptor, AttentionItem, Context, ErrorInfo
from cogit_agent_sdk.types.tools import ToolDescriptor

from cogit_runtime.approvals import ApprovalStore
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.reporter import RunReporter

ExposureDescriptor = ActionDescriptor | ToolDescriptor

ApprovalSource = Literal["action", "pipeline", "continuation", "tool"]

_IDEMPOTENCY_KEY_METADATA = "idempotency_key"


@dataclass(frozen=True)
class ApprovalGateResult:
    """Outcome of the approval gate before operation invocation."""

    payload: dict[str, Any] | None = None
    blocked: OperationExecutionResult | None = None
    consume_approval_id: str | None = None
    idempotency_key: str | None = None


def apply_approval_gate(
    *,
    descriptor: ExposureDescriptor,
    action_name: str,
    payload: dict[str, Any],
    context: Context,
    execution_id: str | None,
    approval_id: str | None,
    idempotency_key: str | None,
    approvals: ApprovalStore | None,
    reporter: RunReporter | None,
    source: ApprovalSource,
) -> ApprovalGateResult:
    """Validate and pin payload before executor preflight; defer consumption."""

    if not descriptor.requires_approval and source != "continuation":
        return ApprovalGateResult(payload=payload, idempotency_key=idempotency_key)

    if approvals is None:
        return ApprovalGateResult(
            blocked=_blocked(
                code="APPROVAL_DENIED",
                message=(
                    f"Action '{action_name}' requires approval "
                    "but no store is configured."
                ),
            ),
        )

    if not approval_id:
        return _park_for_approval(
            descriptor=descriptor,
            action_name=action_name,
            payload=payload,
            context=context,
            execution_id=execution_id,
            idempotency_key=idempotency_key,
            approvals=approvals,
            reporter=reporter,
            source=source,
        )

    decision = approvals.decision_for(approval_id)
    approved_item = approvals.get(approval_id)
    approved_action = (
        approved_item.metadata.get("action")
        if approved_item is not None and approved_item.metadata
        else None
    )
    if (
        decision is None
        or decision.action not in {"approve", "continue"}
        or approved_action != action_name
    ):
        if source == "continuation":
            return ApprovalGateResult(
                blocked=_blocked(
                    code="APPROVAL_DENIED",
                    message=f"Action '{action_name}' is not approved for execution.",
                ),
            )
        return _park_for_approval(
            descriptor=descriptor,
            action_name=action_name,
            payload=payload,
            context=context,
            execution_id=execution_id,
            idempotency_key=idempotency_key,
            approvals=approvals,
            reporter=reporter,
            source=source,
        )

    approved_payload = approvals.payload_for(approval_id)
    if approved_payload is None:
        return ApprovalGateResult(
            blocked=_blocked(
                code="APPROVAL_PAYLOAD_UNAVAILABLE",
                message=(
                    "The approved payload for this approval could not be verified. "
                    "Request a fresh approval before retrying."
                ),
            ),
        )

    if source == "continuation":
        if (
            approved_item is not None
            and approved_item.metadata
            and approved_item.metadata.get("source") == "loop"
        ):
            arguments = approved_payload.get("arguments")
            approved_payload = arguments if isinstance(arguments, dict) else {}
    elif source in {"action", "pipeline", "tool"}:
        if approved_payload != payload:
            return ApprovalGateResult(
                blocked=_blocked(
                    code="APPROVAL_PAYLOAD_MISMATCH",
                    message=(
                        "The submitted payload does not match the payload that was "
                        "approved. Request a fresh approval for the new payload."
                    ),
                ),
            )

    approved_key = idempotency_key_from_item(approved_item)
    key_error = _validate_approved_idempotency_key(
        descriptor=descriptor,
        submitted_key=idempotency_key,
        approved_key=approved_key,
    )
    if key_error is not None:
        return ApprovalGateResult(blocked=key_error)

    effective_key = approved_key if approved_key is not None else idempotency_key
    return ApprovalGateResult(
        payload=approved_payload,
        consume_approval_id=approval_id,
        idempotency_key=effective_key,
    )


def idempotency_key_from_item(item: AttentionItem | None) -> str | None:
    if item is None or not item.metadata:
        return None
    value = item.metadata.get(_IDEMPOTENCY_KEY_METADATA)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _validate_approved_idempotency_key(
    *,
    descriptor: ExposureDescriptor,
    submitted_key: str | None,
    approved_key: str | None,
) -> OperationExecutionResult | None:
    if descriptor.idempotency != "keyed":
        return None
    if approved_key is None:
        return _blocked(
            code="APPROVAL_PAYLOAD_UNAVAILABLE",
            message=(
                "The approved idempotency key for this approval could not be "
                "verified. Request a fresh approval before retrying."
            ),
        )
    if submitted_key is not None and submitted_key.strip() != approved_key:
        return _blocked(
            code="IDEMPOTENCY_KEY_MISMATCH",
            message=(
                "The submitted Idempotency-Key does not match the key that was "
                "approved. Request a fresh approval for the new key."
            ),
        )
    return None


def _park_for_approval(
    *,
    descriptor: ExposureDescriptor,
    action_name: str,
    payload: dict[str, Any],
    context: Context,
    execution_id: str | None,
    idempotency_key: str | None,
    approvals: ApprovalStore,
    reporter: RunReporter | None,
    source: ApprovalSource,
) -> ApprovalGateResult:
    existing = approvals.find_pending_park(
        execution_id=execution_id,
        action_name=action_name,
        source=source,
        payload=payload,
    )
    if existing is not None:
        return ApprovalGateResult(
            blocked=OperationExecutionResult(
                status="failed",
                error=ErrorInfo(
                    code="APPROVAL_REQUIRED",
                    message=existing.message,
                    retryable=False,
                ),
                attention_item_id=existing.id,
            ),
        )

    metadata: dict[str, Any] = {
        "action": action_name,
        "risk": descriptor.risk,
        "source": source,
    }
    if idempotency_key is not None and idempotency_key.strip():
        metadata[_IDEMPOTENCY_KEY_METADATA] = idempotency_key.strip()

    item = approvals.park(
        kind="approval_required",
        message=f"Action '{action_name}' requires approval before it runs.",
        context=context,
        payload=payload,
        execution_id=execution_id,
        metadata=metadata,
    )
    if reporter is not None and execution_id is not None:
        reporter.emit(
            execution_id=execution_id,
            event_type="attention_required",
            payload={
                "attention_item_id": item.id,
                "action": action_name,
            },
        )
    return ApprovalGateResult(
        blocked=OperationExecutionResult(
            status="failed",
            error=ErrorInfo(
                code="APPROVAL_REQUIRED",
                message=item.message,
                retryable=False,
            ),
            attention_item_id=item.id,
        ),
    )


def _blocked(*, code: str, message: str) -> OperationExecutionResult:
    return OperationExecutionResult(
        status="failed",
        error=ErrorInfo(code=code, message=message, retryable=False),
        invocation_started=False,
    )
