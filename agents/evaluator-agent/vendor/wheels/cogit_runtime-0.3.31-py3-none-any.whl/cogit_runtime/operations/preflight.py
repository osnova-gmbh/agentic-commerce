"""Shared pre-invocation hooks for operation execution."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from cogit_agent_sdk.types import Context, ErrorInfo
from pydantic import BaseModel

from cogit_runtime.approvals import ApprovalStore
from cogit_runtime.operations.approval_gate import (
    ApprovalSource,
    ExposureDescriptor,
    apply_approval_gate,
)
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.reporter import RunReporter


@dataclass
class PreflightContext:
    """Mutable pre-invocation state updated by approval and related hooks."""

    idempotency_key: str | None = None


BeforeInvoke = Callable[[BaseModel, PreflightContext], OperationExecutionResult | None]


def build_approval_preflight(
    *,
    descriptor: ExposureDescriptor,
    exposure_name: str,
    context: Context,
    execution_id: str | None,
    approval_id: str | None,
    idempotency_key: str | None,
    approvals: ApprovalStore | None,
    reporter: RunReporter | None,
    source: ApprovalSource,
) -> BeforeInvoke:
    """Return a before-invoke hook that runs after input validation."""

    def _before_invoke(
        validated: BaseModel,
        preflight: PreflightContext,
    ) -> OperationExecutionResult | None:
        payload = validated.model_dump(mode="json", by_alias=True)
        gate = apply_approval_gate(
            descriptor=descriptor,
            action_name=exposure_name,
            payload=payload,
            context=context,
            execution_id=execution_id,
            approval_id=approval_id,
            idempotency_key=preflight.idempotency_key,
            approvals=approvals,
            reporter=reporter,
            source=source,
        )
        if gate.blocked is not None:
            return gate.blocked
        if gate.idempotency_key is not None:
            preflight.idempotency_key = gate.idempotency_key
        if gate.consume_approval_id is not None and approvals is not None:
            if not approvals.consume(gate.consume_approval_id):
                return OperationExecutionResult(
                    status="failed",
                    error=ErrorInfo(
                        code="APPROVAL_ALREADY_CONSUMED",
                        message=(
                            "This approval has already been used to execute an "
                            "operation. Request a fresh approval to retry."
                        ),
                        retryable=False,
                    ),
                    invocation_started=False,
                )
        return None

    return _before_invoke


def chain_before_invoke(
    *hooks: BeforeInvoke | None,
) -> BeforeInvoke | None:
    """Run multiple before-invoke hooks in order."""

    active = [hook for hook in hooks if hook is not None]
    if not active:
        return None

    def _chained(
        validated: BaseModel,
        preflight: PreflightContext,
    ) -> OperationExecutionResult | None:
        for hook in active:
            blocked = hook(validated, preflight)
            if blocked is not None:
                return blocked
        return None

    return _chained


__all__ = [
    "BeforeInvoke",
    "PreflightContext",
    "build_approval_preflight",
    "chain_before_invoke",
]
