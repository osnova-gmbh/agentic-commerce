"""Manifest and binding parity checks for Proposal 019."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import Any

from cogit_agent_sdk.operations.action_binding import ActionBinding
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.types import ActionDescriptor, ToolDescriptor
from cogit_agent_sdk.types._base import to_camel
from cogit_agent_sdk.types._immutable import thaw_value
from jsonschema import Draft202012Validator

_ACTION_PARITY_FIELDS = (
    "name",
    "description",
    "input_schema",
    "output_schema",
    "risk",
    "idempotency",
    "required_capabilities",
    "requires_approval",
    "metadata",
)
_TOOL_PARITY_FIELDS = (
    "name",
    "description",
    "input_schema",
    "output_schema",
    "risk",
    "idempotency",
    "required_capabilities",
    "requires_approval",
    "execution_mode",
    "timeout_seconds",
    "metadata",
)
_REMOVED_MANIFEST_FIELDS = frozenset(
    {
        "idempotent",
        "side_effects",
        "exposed_as_tool",
        "exposedAsTool",
    },
)
_ALLOWED_ACTION_KEYS = (
    frozenset(_ACTION_PARITY_FIELDS)
    | frozenset(to_camel(field) for field in _ACTION_PARITY_FIELDS)
    | _REMOVED_MANIFEST_FIELDS
)
_ALLOWED_TOOL_KEYS = (
    frozenset(_TOOL_PARITY_FIELDS)
    | frozenset(to_camel(field) for field in _TOOL_PARITY_FIELDS)
    | _REMOVED_MANIFEST_FIELDS
)


def validate_manifest_action_entries(
    raw_actions: Sequence[Mapping[str, Any]] | None,
) -> list[str]:
    """Reject duplicate names, unknown fields, and invalid schemas in raw YAML."""

    if not raw_actions:
        return []

    errors: list[str] = []
    seen: set[str] = set()
    for index, raw_action in enumerate(raw_actions):
        if not isinstance(raw_action, Mapping):
            errors.append(f"Manifest action at index {index} must be an object.")
            continue
        name = raw_action.get("name")
        if not isinstance(name, str) or not name:
            errors.append(f"Manifest action at index {index} is missing a valid name.")
            continue
        if name in seen:
            errors.append(f"Manifest declares duplicate action name '{name}'.")
        seen.add(name)

        unknown = sorted(set(raw_action) - _ALLOWED_ACTION_KEYS)
        if unknown:
            joined = ", ".join(unknown)
            errors.append(
                f"Action '{name}' declares unknown manifest field(s): {joined}.",
            )
        removed = sorted(set(raw_action) & _REMOVED_MANIFEST_FIELDS)
        if removed:
            joined = ", ".join(removed)
            errors.append(
                f"Action '{name}' declares removed manifest field(s): {joined}.",
            )

        for schema_field in ("input_schema", "inputSchema"):
            schema = raw_action.get(schema_field)
            if schema is None:
                continue
            errors.extend(_validate_schema_object(name, schema, kind="input"))

        for schema_field in ("output_schema", "outputSchema"):
            schema = raw_action.get(schema_field)
            if schema is None:
                continue
            errors.extend(_validate_schema_object(name, schema, kind="output"))

    return errors


def validate_manifest_tool_entries(
    raw_tools: Sequence[Mapping[str, Any]] | None,
) -> list[str]:
    """Reject duplicate names, unknown fields, and invalid schemas in raw YAML."""

    if not raw_tools:
        return []

    errors: list[str] = []
    seen: set[str] = set()
    for index, raw_tool in enumerate(raw_tools):
        if not isinstance(raw_tool, Mapping):
            errors.append(f"Manifest tool at index {index} must be an object.")
            continue
        name = raw_tool.get("name")
        if not isinstance(name, str) or not name:
            errors.append(f"Manifest tool at index {index} is missing a valid name.")
            continue
        if name in seen:
            errors.append(f"Manifest declares duplicate tool name '{name}'.")
        seen.add(name)

        unknown = sorted(set(raw_tool) - _ALLOWED_TOOL_KEYS)
        if unknown:
            joined = ", ".join(unknown)
            errors.append(
                f"Tool '{name}' declares unknown manifest field(s): {joined}.",
            )
        removed = sorted(set(raw_tool) & _REMOVED_MANIFEST_FIELDS)
        if removed:
            joined = ", ".join(removed)
            errors.append(
                f"Tool '{name}' declares removed manifest field(s): {joined}.",
            )

        for schema_field in ("input_schema", "inputSchema"):
            schema = raw_tool.get(schema_field)
            if schema is None:
                continue
            errors.extend(_validate_schema_object(name, schema, kind="input"))

        for schema_field in ("output_schema", "outputSchema"):
            schema = raw_tool.get(schema_field)
            if schema is None:
                continue
            errors.extend(_validate_schema_object(name, schema, kind="output"))

    return errors


def validate_action_binding_parity(
    manifest_actions: Sequence[ActionDescriptor],
    bindings: Sequence[ActionBinding[Any, Any]],
) -> list[str]:
    """Compare manifest action descriptors with canonical executable bindings."""

    return _validate_descriptor_parity(
        manifest_items=manifest_actions,
        bindings=bindings,
        exposure_kind="Action",
        parity_fields=_ACTION_PARITY_FIELDS,
        binding_name=lambda item: item.descriptor.name,
        binding_descriptor=lambda item: item.descriptor,
        manifest_name=lambda item: item.name,
    )


def validate_tool_binding_parity(
    manifest_tools: Sequence[ToolDescriptor],
    bindings: Sequence[ToolBinding[Any, Any]],
) -> list[str]:
    """Compare manifest tool descriptors with canonical executable bindings."""

    return _validate_descriptor_parity(
        manifest_items=manifest_tools,
        bindings=bindings,
        exposure_kind="Tool",
        parity_fields=_TOOL_PARITY_FIELDS,
        binding_name=lambda item: item.descriptor.name,
        binding_descriptor=lambda item: item.descriptor,
        manifest_name=lambda item: item.name,
    )


def _validate_descriptor_parity(
    *,
    manifest_items: Sequence[Any],
    bindings: Sequence[Any],
    exposure_kind: str,
    parity_fields: tuple[str, ...],
    binding_name: Any,
    binding_descriptor: Any,
    manifest_name: Any,
) -> list[str]:
    errors: list[str] = []

    manifest_names = [manifest_name(item) for item in manifest_items]
    if len(manifest_names) != len(set(manifest_names)):
        errors.append(f"Manifest declares duplicate {exposure_kind.lower()} names.")

    binding_names = [binding_name(item) for item in bindings]
    if len(binding_names) != len(set(binding_names)):
        errors.append(f"Agent declares duplicate {exposure_kind.lower()} bindings.")

    binding_by_name = {binding_name(item): item for item in bindings}
    manifest_by_name = {manifest_name(item): item for item in manifest_items}

    for name in sorted(set(binding_by_name) - set(manifest_by_name)):
        errors.append(
            f"{exposure_kind} '{name}' is declared in code but "
            "missing from the manifest.",
        )

    for name in sorted(set(manifest_by_name) - set(binding_by_name)):
        errors.append(
            f"{exposure_kind} '{name}' is declared in the manifest "
            "but missing from the agent code.",
        )

    for name in sorted(set(binding_by_name) & set(manifest_by_name)):
        code_descriptor = binding_descriptor(binding_by_name[name])
        manifest_descriptor = manifest_by_name[name]
        for field in parity_fields:
            code_value = getattr(code_descriptor, field)
            manifest_value = getattr(manifest_descriptor, field)
            if not _values_equal(field, code_value, manifest_value):
                errors.append(
                    f"{exposure_kind} '{name}' field '{field}' mismatch: "
                    f"code={_preview(code_value)!r}, "
                    f"manifest={_preview(manifest_value)!r}.",
                )

    return errors


def _validate_schema_object(
    item_name: str,
    schema: object,
    *,
    kind: str,
) -> list[str]:
    if not isinstance(schema, Mapping):
        return [f"Item '{item_name}' {kind} schema must be a JSON object."]
    try:
        Draft202012Validator.check_schema(dict(schema))
    except Exception as exc:
        return [
            f"Item '{item_name}' has an invalid {kind} schema: {exc}",
        ]
    return []


def _values_equal(field: str, left: Any, right: Any) -> bool:
    if field in {"input_schema", "output_schema", "metadata"}:
        return _canonical_json(left) == _canonical_json(right)
    if field == "required_capabilities":
        return sorted(_thaw_list(left)) == sorted(_thaw_list(right))
    return left == right


def _canonical_json(value: Any) -> str:
    normalized = thaw_value(value)
    return json.dumps(normalized, sort_keys=True, separators=(",", ":"))


def _thaw_list(value: Any) -> list[Any]:
    thawed = thaw_value(value)
    if thawed is None:
        return []
    if isinstance(thawed, list):
        return list(thawed)
    return [thawed]


def _preview(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    return thaw_value(value)
