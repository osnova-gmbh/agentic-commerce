"""Normalized operation execution outcomes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from cogit_agent_sdk.types import ErrorInfo, WorkOutcome

OperationStatus = Literal["succeeded", "failed", "cancelled"]


@dataclass(frozen=True)
class OperationExecutionResult:
    """Single internal outcome for one operation invocation."""

    status: OperationStatus
    output: Any = None
    error: ErrorInfo | None = None
    invocation_started: bool = False
    attention_item_id: str | None = None
    work_outcome: WorkOutcome | None = None
