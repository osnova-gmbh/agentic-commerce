"""Central operation executor for Proposal 019."""

from __future__ import annotations

import asyncio
import dataclasses
import logging
from collections.abc import Awaitable, Callable
from typing import Any, Literal

from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.operations.contract import (
    OperationContract,
    OperationError,
    OperationInvocation,
)
from cogit_agent_sdk.types import Context, ErrorInfo
from cogit_agent_sdk.types.cancellation import Cancellation
from cogit_agent_sdk.types.requirements import OperationRequirements
from pydantic import BaseModel, ValidationError

from cogit_runtime.cancellation import (
    RuntimeCancellation,
    RuntimeCancelledError,
    await_runtime_completion,
    operation_cancellation,
)
from cogit_runtime.cooperative_worker import (
    WorkerStillRunningError,
    retain_stop_failure,
)
from cogit_runtime.coordination import finish_cleanup
from cogit_runtime.operations.executor_support import (
    INVALID_OUTPUT_MESSAGE,
    cancelled_error,
    coerce_output,
    missing_capabilities,
    resolve_idempotency_key,
    serialize_output,
)
from cogit_runtime.operations.preflight import BeforeInvoke, PreflightContext
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.policy import RuntimePolicyGate
from cogit_runtime.policy_approval import central_approval_preflight

logger = logging.getLogger(__name__)

InvokeSyncAsync = Callable[
    [Callable[..., Any], tuple[Any, ...], RuntimeCancellation],
    Awaitable[Any],
]


class OperationExecutor:
    """Validate, invoke, and normalize one bound operation."""

    def __init__(
        self, *, invoke: InvokeSyncAsync, policy: RuntimePolicyGate | None = None
    ) -> None:
        self._invoke = invoke
        self._policy = policy

    async def execute(
        self,
        contract: OperationContract[Any, Any],
        requirements: OperationRequirements,
        exposure_name: str,
        raw_input: dict[str, Any],
        invocation: OperationInvocation,
        *,
        cancellation: Cancellation | RuntimeCancellation,
        timeout_seconds: float | None = None,
        before_invoke: BeforeInvoke | None = None,
        key_for: Callable[[Any, Context], str] | None = None,
        key_source: Literal["caller", "generated"] = "caller",
        policy_kind: Literal["action", "tool"] = "action",
    ) -> OperationExecutionResult:
        policy = self._policy
        operation = None
        payload = raw_input
        slot = str(
            (invocation.context.metadata or {}).get(
                "runtime_pipeline_slot", invocation.context.execution_id or "operation"
            )
        )
        if policy is not None:
            try:
                payload = contract.input_model.model_validate(raw_input).model_dump(
                    mode="json", by_alias=True
                )
            except ValidationError:
                return OperationExecutionResult(
                    status="failed",
                    error=ErrorInfo(
                        code="INVALID_INPUT",
                        message="Operation input failed validation",
                        retryable=False,
                    ),
                )
            operation = policy.operation(exposure_name, requirements, policy_kind)
            checkpoint = policy.checkpoint(
                phase="pre_tool",
                operation=operation,
                payload=payload,
                slot=slot,
            )
            if policy.require(invocation.handle, checkpoint):
                before_invoke = central_approval_preflight(
                    policy,
                    checkpoint,
                    invocation,
                    requirements,
                    before_invoke,
                )
        try:
            result = await self._execute_validated_boundary(
                contract,
                requirements,
                exposure_name,
                raw_input,
                invocation,
                cancellation=cancellation,
                timeout_seconds=timeout_seconds,
                before_invoke=before_invoke,
                key_for=key_for,
                key_source=key_source,
            )
        except (
            CoordinationFailure,
            WorkerStillRunningError,
            asyncio.CancelledError,
        ) as error:
            from cogit_runtime.agentdb.current_decisions import (
                DecisionParkRequiredError,
            )

            if (
                policy is not None
                and operation is not None
                and not isinstance(error, DecisionParkRequiredError)
            ):
                try:
                    policy.require(
                        invocation.handle,
                        policy.checkpoint(
                            phase="post_tool",
                            operation=operation,
                            payload=payload,
                            slot=slot,
                            result={"status": "interrupted"},
                            state="unknown",
                        ),
                    )
                except Exception:
                    # Preserve the original fence or owned deferred task. A failed
                    # observation cannot turn interruption into successful work.
                    logger.warning("Post-tool interruption observation unavailable")
            raise
        if policy is not None and operation is not None:
            # An error after handler entry may have committed an external effect.
            state = (
                "completed"
                if result.status == "succeeded"
                else ("unknown" if result.invocation_started else "failed")
            )
            policy.require(
                invocation.handle,
                policy.checkpoint(
                    phase="post_tool",
                    operation=operation,
                    payload=payload,
                    slot=slot,
                    result={
                        "status": result.status,
                        "output": result.output,
                        "error": result.error.model_dump(mode="json")
                        if result.error
                        else None,
                    },
                    state=state,
                ),
            )
        return result

    async def _execute_validated_boundary(
        self,
        contract: OperationContract[Any, Any],
        requirements: OperationRequirements,
        exposure_name: str,
        raw_input: dict[str, Any],
        invocation: OperationInvocation,
        *,
        cancellation: Cancellation | RuntimeCancellation,
        timeout_seconds: float | None,
        before_invoke: BeforeInvoke | None,
        key_for: Callable[[Any, Context], str] | None,
        key_source: Literal["caller", "generated"],
    ) -> OperationExecutionResult:
        capability_error = missing_capabilities(
            requirements,
            exposure_name,
            invocation.context,
        )
        if capability_error is not None:
            return OperationExecutionResult(status="failed", error=capability_error)

        try:
            request = contract.input_model.model_validate(raw_input)
        except ValidationError:
            return OperationExecutionResult(
                status="failed",
                error=ErrorInfo(
                    code="INVALID_INPUT",
                    message="Operation input failed validation",
                    retryable=False,
                ),
            )

        try:
            cancellation.throw_if_cancelled()
        except RuntimeCancelledError:
            return OperationExecutionResult(
                status="cancelled",
                error=cancelled_error(),
                invocation_started=False,
            )

        key, key_error = resolve_idempotency_key(
            key_for=key_for,
            request=request,
            context=invocation.context,
            supplied_key=invocation.idempotency_key,
            key_source=key_source,
            idempotency=requirements.idempotency,
            exposure_name=exposure_name,
        )
        if key_error is not None:
            return OperationExecutionResult(status="failed", error=key_error)

        effective_invocation = dataclasses.replace(invocation, idempotency_key=key)

        preflight = PreflightContext(idempotency_key=key)
        if before_invoke is not None:
            blocked = before_invoke(request, preflight)
            if blocked is not None:
                return blocked

        if preflight.idempotency_key != key:
            _approved_key, approved_key_error = resolve_idempotency_key(
                key_for=None,
                request=request,
                context=invocation.context,
                supplied_key=preflight.idempotency_key,
                idempotency=requirements.idempotency,
                exposure_name=exposure_name,
            )
            if approved_key_error is not None:
                return OperationExecutionResult(
                    status="failed", error=approved_key_error
                )
            effective_invocation = dataclasses.replace(
                effective_invocation,
                idempotency_key=preflight.idempotency_key,
            )

        bounded = operation_cancellation(
            cancellation,
            timeout_seconds=timeout_seconds,
        )
        invoke_invocation = dataclasses.replace(
            effective_invocation,
            cancellation=bounded,
        )
        deferred_cleanup = False
        try:
            raw_result = await self._invoke_with_boundary(
                contract,
                request,
                invoke_invocation,
                timeout_seconds=timeout_seconds,
            )
            bounded.throw_if_cancelled()
        except WorkerStillRunningError as pending:
            deferred_cleanup = True

            # Exception target names are cleared when the except block exits.
            worker = pending.task
            interruption = pending.interruption

            async def owned_completion() -> Any:
                try:
                    return await await_runtime_completion(worker)
                finally:
                    finish_cleanup(bounded.close)

            raise WorkerStillRunningError(
                asyncio.create_task(owned_completion()), interruption=interruption
            ) from None
        except CoordinationFailure:
            raise
        except RuntimeCancelledError:
            return OperationExecutionResult(
                status="cancelled",
                error=cancelled_error(),
                invocation_started=True,
            )
        except TimeoutError:
            return OperationExecutionResult(
                status="failed",
                error=ErrorInfo(
                    code="TIMEOUT",
                    message=f"Operation '{exposure_name}' timed out",
                    retryable=False,
                ),
                invocation_started=True,
            )
        except asyncio.CancelledError:
            raise
        except OperationError as exc:
            return OperationExecutionResult(
                status="failed",
                error=exc.error,
                invocation_started=True,
            )
        except Exception as exc:
            logger.debug(
                "Unexpected operation failure for %r (%s)",
                exposure_name,
                type(exc).__name__,
            )
            return OperationExecutionResult(
                status="failed",
                error=ErrorInfo(
                    code="OPERATION_ERROR",
                    message=f"Operation failed ({type(exc).__name__})",
                    retryable=False,
                ),
                invocation_started=True,
            )
        finally:
            if not deferred_cleanup:
                finish_cleanup(bounded.close)

        try:
            output = coerce_output(contract.output_model, raw_result)
        except ValidationError:
            return OperationExecutionResult(
                status="failed",
                error=ErrorInfo(
                    code="INVALID_OUTPUT",
                    message=INVALID_OUTPUT_MESSAGE,
                    retryable=False,
                ),
                invocation_started=True,
            )

        return OperationExecutionResult(
            status="succeeded",
            output=serialize_output(output),
            invocation_started=True,
        )

    async def _invoke_with_boundary(
        self,
        contract: OperationContract[Any, Any],
        request: BaseModel,
        invocation: OperationInvocation,
        *,
        timeout_seconds: float | None,
    ) -> Any:
        cancellation = invocation.cancellation
        if not isinstance(cancellation, RuntimeCancellation):
            msg = "OperationInvocation.cancellation must be a RuntimeCancellation"
            raise TypeError(msg)
        operation = contract.__call__
        if timeout_seconds is None:
            return await self._invoke(operation, (request, invocation), cancellation)

        async def _bounded_invoke() -> Any:
            return await self._invoke(
                operation,
                (request, invocation),
                cancellation,
            )

        task = asyncio.create_task(_bounded_invoke())
        try:
            return await asyncio.wait_for(asyncio.shield(task), timeout=timeout_seconds)
        except (TimeoutError, asyncio.CancelledError) as interrupted:
            stop_error: BaseException | None = None
            try:
                cancellation.cancel()
            except BaseException as exc:
                stop_error = exc
            done, _pending = await await_runtime_completion(
                asyncio.create_task(asyncio.wait({task}, timeout=1.0))
            )
            if task not in done:
                raise WorkerStillRunningError(
                    retain_stop_failure(task, stop_error), interruption=interrupted
                ) from None
            try:
                task.result()
            except CoordinationFailure:
                raise
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                logger.debug(
                    "Worker exited after timeout (%s)",
                    type(exc).__name__,
                )
            if stop_error is not None:
                raise stop_error from None
            raise interrupted from None
