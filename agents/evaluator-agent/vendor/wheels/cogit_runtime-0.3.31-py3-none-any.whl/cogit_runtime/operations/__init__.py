"""Proposal 019 runtime operation execution."""

from cogit_runtime.operations.errors import OperationExecutionError
from cogit_runtime.operations.executor import OperationExecutor
from cogit_runtime.operations.executor_support import invoke_operation_callable
from cogit_runtime.operations.parity import (
    validate_action_binding_parity,
    validate_manifest_action_entries,
    validate_manifest_tool_entries,
    validate_tool_binding_parity,
)
from cogit_runtime.operations.preflight import (
    BeforeInvoke,
    PreflightContext,
    build_approval_preflight,
    chain_before_invoke,
)
from cogit_runtime.operations.registry import (
    RuntimeActionRegistry,
    RuntimeToolRegistry,
    build_action_registry,
    build_tool_registry,
    freeze_agent_action_registration,
    freeze_agent_tool_registration,
)
from cogit_runtime.operations.result import OperationExecutionResult

__all__ = [
    "BeforeInvoke",
    "OperationExecutionError",
    "OperationExecutionResult",
    "OperationExecutor",
    "PreflightContext",
    "RuntimeActionRegistry",
    "RuntimeToolRegistry",
    "build_action_registry",
    "build_approval_preflight",
    "build_tool_registry",
    "chain_before_invoke",
    "freeze_agent_action_registration",
    "freeze_agent_tool_registration",
    "invoke_operation_callable",
    "validate_action_binding_parity",
    "validate_manifest_action_entries",
    "validate_manifest_tool_entries",
    "validate_tool_binding_parity",
]
