"""Runtime canonical action and tool binding registries."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import replace
from typing import Any

from cogit_agent_sdk.operations.action_binding import ActionBinding
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.resident import CogitAgent
from cogit_agent_sdk.types import ActionDescriptor, ToolDescriptor
from cogit_agent_sdk.types.actions import canonicalize_action_descriptor
from cogit_agent_sdk.types.tools import canonicalize_tool_descriptor

from cogit_runtime.errors import RuntimeConfigurationError


def _validate_action_binding_sequence(
    bindings: Sequence[object],
) -> list[ActionBinding[Any, Any]]:
    validated: list[ActionBinding[Any, Any]] = []
    seen: set[str] = set()
    for index, binding in enumerate(bindings):
        if not isinstance(binding, ActionBinding):
            raise RuntimeConfigurationError(
                "agent.action_bindings() must yield ActionBinding values; "
                f"item at index {index} is {type(binding)!r}.",
            )
        name = binding.descriptor.name
        if name in seen:
            raise RuntimeConfigurationError(
                f"Duplicate action binding for '{name}'",
            )
        seen.add(name)
        validated.append(binding)
    return validated


def _validate_tool_binding_sequence(
    bindings: Sequence[object],
) -> list[ToolBinding[Any, Any]]:
    validated: list[ToolBinding[Any, Any]] = []
    seen: set[str] = set()
    for index, binding in enumerate(bindings):
        if not isinstance(binding, ToolBinding):
            raise RuntimeConfigurationError(
                "agent.tool_bindings() must yield ToolBinding values; "
                f"item at index {index} is {type(binding)!r}.",
            )
        name = binding.descriptor.name
        if name in seen:
            raise RuntimeConfigurationError(
                f"Duplicate tool binding for '{name}'",
            )
        seen.add(name)
        validated.append(binding)
    return validated


def _resolve_inventory_method(agent: object, method_name: str) -> Callable[[], object]:
    class_attr = getattr(type(agent), method_name, None)
    if class_attr is None:
        raise RuntimeConfigurationError(
            f"Agent must implement {method_name}() returning explicit bindings.",
        )
    if isinstance(class_attr, property):
        raise RuntimeConfigurationError(
            f"Agent must implement {method_name}() as a method, not a property.",
        )
    instance_method = getattr(agent, method_name, None)
    if not callable(instance_method):
        raise RuntimeConfigurationError(
            f"Agent must implement {method_name}() returning explicit bindings.",
        )
    return instance_method


def _action_bindings_from_agent(agent: object) -> list[ActionBinding[Any, Any]]:
    raw = _resolve_inventory_method(agent, "action_bindings")()
    if isinstance(raw, ActionBinding):
        return _restore_declared_keys(
            agent, _validate_action_binding_sequence([raw]), ActionBinding
        )
    if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes, bytearray)):
        return _restore_declared_keys(
            agent, _validate_action_binding_sequence(list(raw)), ActionBinding
        )
    raise RuntimeConfigurationError(
        "agent.action_bindings() must return a sequence of ActionBinding values.",
    )


def _tool_bindings_from_agent(agent: object) -> list[ToolBinding[Any, Any]]:
    raw = _resolve_inventory_method(agent, "tool_bindings")()
    if isinstance(raw, ToolBinding):
        return _restore_declared_keys(
            agent, _validate_tool_binding_sequence([raw]), ToolBinding
        )
    if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes, bytearray)):
        return _restore_declared_keys(
            agent, _validate_tool_binding_sequence(list(raw)), ToolBinding
        )
    raise RuntimeConfigurationError(
        "agent.tool_bindings() must return a sequence of ToolBinding values.",
    )


def _restore_declared_keys(
    agent: object,
    bindings: list[ActionBinding[Any, Any]] | list[ToolBinding[Any, Any]],
    binding_type: type[ActionBinding[Any, Any]] | type[ToolBinding[Any, Any]],
) -> list[Any]:
    """Retain class-declared SDK resolvers lost during canonical registration.

    SDK 0.5.5 copies operation/descriptor but drops ``key_for`` in its
    registry. Match the original public class declaration by both name and
    operation identity only when the SDK's own inventory method supplied the
    binding. Custom inventories and dynamic bindings stay keyless.
    """

    method_name = (
        "action_bindings" if binding_type is ActionBinding else "tool_bindings"
    )
    inventory = getattr(agent, method_name, None)
    if not isinstance(agent, CogitAgent) or getattr(
        inventory, "__func__", None
    ) is not getattr(CogitAgent, method_name):
        return list(bindings)

    declared: dict[str, Any] = {}
    for owner in reversed(type(agent).__mro__):
        for value in vars(owner).values():
            if isinstance(value, binding_type):
                declared[value.descriptor.name] = value
    restored: list[Any] = []
    for binding in bindings:
        original = declared.get(binding.descriptor.name)
        expected_descriptor = (
            canonicalize_action_descriptor(original.descriptor)
            if isinstance(original, ActionBinding)
            else canonicalize_tool_descriptor(original.descriptor)
            if isinstance(original, ToolBinding)
            else None
        )
        if (
            binding.key_for is None
            and original is not None
            and original.operation is binding.operation
            and binding.descriptor == expected_descriptor
            and (
                not isinstance(binding, ToolBinding)
                or (
                    isinstance(original, ToolBinding)
                    and binding.prepare_arguments is original.prepare_arguments
                )
            )
            and original.key_for is not None
        ):
            restored.append(replace(binding, key_for=original.key_for))
        else:
            restored.append(binding)
    return restored


def build_action_registry(
    agent: object,
    manifest_actions: Sequence[ActionDescriptor],
) -> RuntimeActionRegistry:
    """Build the frozen action registry from explicit agent bindings only."""

    _ = manifest_actions
    freeze_agent_action_registration(agent)
    return RuntimeActionRegistry(_action_bindings_from_agent(agent))


def build_tool_registry(
    agent: object,
    manifest_tools: Sequence[ToolDescriptor],
) -> RuntimeToolRegistry:
    """Build the frozen tool registry from explicit agent bindings only."""

    _ = manifest_tools
    freeze_agent_tool_registration(agent)
    return RuntimeToolRegistry(_tool_bindings_from_agent(agent))


class RuntimeActionRegistry:
    """Exact-name lookup table built from ``agent.action_bindings()``."""

    def __init__(self, bindings: Sequence[ActionBinding[Any, Any]]) -> None:
        validated = _validate_action_binding_sequence(bindings)
        self._by_name = {binding.descriptor.name: binding for binding in validated}
        self._bindings: tuple[ActionBinding[Any, Any], ...] = tuple(
            sorted(validated, key=lambda item: item.descriptor.name)
        )

    @classmethod
    def from_agent(cls, agent: object) -> RuntimeActionRegistry:
        freeze_agent_action_registration(agent)
        return cls(_action_bindings_from_agent(agent))

    @property
    def bindings(self) -> tuple[ActionBinding[Any, Any], ...]:
        return self._bindings

    def get(self, action_name: str) -> ActionBinding[Any, Any] | None:
        return self._by_name.get(action_name)

    def require(self, action_name: str) -> ActionBinding[Any, Any]:
        binding = self.get(action_name)
        if binding is None:
            raise RuntimeConfigurationError(
                f"No binding for action '{action_name}' is registered on the agent.",
            )
        return binding

    def descriptors_by_name(self) -> dict[str, ActionDescriptor]:
        return {
            binding.descriptor.name: binding.descriptor for binding in self._bindings
        }

    def validate_parity(
        self,
        manifest_actions: Sequence[ActionDescriptor],
    ) -> list[str]:
        from cogit_runtime.operations.parity import validate_action_binding_parity

        return validate_action_binding_parity(manifest_actions, self._bindings)


class RuntimeToolRegistry:
    """Exact-name lookup table built from ``agent.tool_bindings()``."""

    def __init__(self, bindings: Sequence[ToolBinding[Any, Any]]) -> None:
        validated = _validate_tool_binding_sequence(bindings)
        self._by_name = {binding.descriptor.name: binding for binding in validated}
        self._bindings: tuple[ToolBinding[Any, Any], ...] = tuple(
            sorted(validated, key=lambda item: item.descriptor.name)
        )

    @classmethod
    def from_agent(cls, agent: object) -> RuntimeToolRegistry:
        freeze_agent_tool_registration(agent)
        return cls(_tool_bindings_from_agent(agent))

    @property
    def bindings(self) -> tuple[ToolBinding[Any, Any], ...]:
        return self._bindings

    def get(self, tool_name: str) -> ToolBinding[Any, Any] | None:
        return self._by_name.get(tool_name)

    def require(self, tool_name: str) -> ToolBinding[Any, Any]:
        binding = self.get(tool_name)
        if binding is None:
            raise RuntimeConfigurationError(
                f"No binding for tool '{tool_name}' is registered on the agent.",
            )
        return binding

    def descriptors_by_name(self) -> dict[str, ToolDescriptor]:
        return {
            binding.descriptor.name: binding.descriptor for binding in self._bindings
        }

    def validate_parity(
        self,
        manifest_tools: Sequence[ToolDescriptor],
    ) -> list[str]:
        from cogit_runtime.operations.parity import validate_tool_binding_parity

        return validate_tool_binding_parity(manifest_tools, self._bindings)


def freeze_agent_action_registration(agent: object) -> None:
    """Freeze SDK action registration after configure and before startup."""

    freeze_fn = getattr(agent, "freeze_action_registration", None)
    if callable(freeze_fn):
        freeze_fn()
        return
    if isinstance(agent, CogitAgent):
        agent.freeze_action_registration()


def freeze_agent_tool_registration(agent: object) -> None:
    """Freeze SDK tool registration after configure and before startup."""

    freeze_fn = getattr(agent, "freeze_tool_registration", None)
    if callable(freeze_fn):
        freeze_fn()
        return
    if isinstance(agent, CogitAgent):
        agent.freeze_tool_registration()
