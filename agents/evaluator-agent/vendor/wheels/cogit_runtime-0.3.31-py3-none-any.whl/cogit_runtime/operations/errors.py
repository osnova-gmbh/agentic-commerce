"""Operation execution errors surfaced to runtime adapters."""

from __future__ import annotations

from cogit_runtime.operations.result import OperationExecutionResult


class OperationExecutionError(Exception):
    """Expected adapter boundary for a failed or cancelled operation."""

    def __init__(self, result: OperationExecutionResult) -> None:
        self.result = result
        message = result.error.message if result.error is not None else result.status
        super().__init__(message)
