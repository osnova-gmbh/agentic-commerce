"""Runtime configuration and environment parsing."""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field

from cogit_runtime.agentdb.config import AgentDbConfig
from cogit_runtime.errors import RuntimeConfigurationError


class StrictRuntimeModel(BaseModel):
    """Base model for runtime-owned config.

    SDK wire models are intentionally tolerant. Runtime config is not: an
    unknown key usually means a typo that should fail during boot.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)


class RateLimitConfig(StrictRuntimeModel):
    """Per-client rate-limit settings, independent of supplied credentials."""

    requests_per_minute: int | None = Field(default=None, gt=0)
    burst: int | None = Field(default=None, ge=0)


class ServerConfig(StrictRuntimeModel):
    """HTTP server behavior controlled by the runtime."""

    host: str = "127.0.0.1"
    port: int = Field(default=8000, ge=1, le=65535)
    sync_run_timeout_seconds: int = Field(default=120, gt=0)
    body_limit_mb: int = Field(default=10, gt=0)
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)


class WorkerConfig(StrictRuntimeModel):
    """Queue worker defaults."""

    enabled: bool = True
    concurrency: int = Field(default=4, gt=0)
    poll_interval_seconds: int = Field(default=5, gt=0)
    lease_seconds: int = Field(default=900, gt=0)


class SessionConfig(StrictRuntimeModel):
    """Session retention and history-window settings."""

    max_history_messages: int = Field(default=40, ge=0)
    idle_archive_days: int = Field(default=30, gt=0)


class TraceConfig(StrictRuntimeModel):
    """Local trace persistence settings."""

    persist_messages: bool = False
    retention_days: int = Field(default=30, gt=0)


class DiagnosticHistoryLimits(StrictRuntimeModel):
    """Finite limits for the optional AgentDb worker-local diagnostic shadow."""

    completed_records: int = Field(default=128, gt=0)
    active_executions: int = Field(default=1, gt=0)
    events_per_run: int = Field(default=256, gt=0)
    event_bytes_per_run: int = Field(default=262_144, gt=0)
    events_total: int = Field(default=4_096, gt=0)
    event_bytes_total: int = Field(default=4_194_304, gt=0)
    steps_per_run: int = Field(default=128, gt=0)
    step_bytes_per_run: int = Field(default=262_144, gt=0)
    steps_total: int = Field(default=2_048, gt=0)
    step_bytes_total: int = Field(default=4_194_304, gt=0)


class BudgetDefaultsConfig(StrictRuntimeModel):
    """Default budget limits applied by the runtime."""

    max_cost: float | None = Field(default=None, gt=0)
    max_duration_seconds: int | None = Field(default=None, gt=0)


class LoopConfig(StrictRuntimeModel):
    """SDK loop host defaults."""

    max_turns_default: int = Field(default=25, gt=0)
    budget_defaults: BudgetDefaultsConfig = Field(default_factory=BudgetDefaultsConfig)
    budget_warning_turns_remaining: int = Field(default=2, ge=0)


class ReporterConfig(StrictRuntimeModel):
    """Execution reporter queue/outbox settings."""

    step_queue_max: int = Field(default=1000, gt=0)
    outbox_flush_interval_seconds: int = Field(default=30, gt=0)


ModelAdapter: TypeAlias = Literal[
    "anthropic",
    "openai",
    "openrouter",
    "google-adk",
    "litellm",
    "custom",
]


class ModelFallbackConfig(StrictRuntimeModel):
    """A fallback provider with an explicit provider-compatible model."""

    adapter: ModelAdapter
    model: str = Field(min_length=1)
    supports_tools: bool = False
    supports_streaming: bool = False
    context_window: int | None = Field(default=None, gt=0, le=1_000_000_000)
    max_output_tokens: int | None = Field(default=None, gt=0, le=1_000_000_000)


class AllowedModelConfig(StrictRuntimeModel):
    """One exact provider/model pair admitted for direct resident dispatch."""

    provider: Literal["anthropic", "openai", "openrouter"]
    model: str = Field(min_length=1)
    supports_tools: bool = False
    supports_streaming: bool = False
    context_window: int | None = Field(default=None, gt=0, le=1_000_000_000)
    max_output_tokens: int | None = Field(default=None, gt=0, le=1_000_000_000)


class ModelConfig(StrictRuntimeModel):
    """Model-client adapter selection."""

    profile: Literal["sdk", "external", "disabled"] | None = None
    adapter: ModelAdapter = "custom"
    fallbacks: list[str | ModelFallbackConfig] | None = None
    allowed_models: list[AllowedModelConfig] = Field(default_factory=list)


class ObservabilityConfig(StrictRuntimeModel):
    """Runtime logging and tracing configuration."""

    log_level: str = "info"
    otel_endpoint: str | None = None


class StoreConfig(StrictRuntimeModel):
    """Legacy manifest setting, retained for AgentDB manifest compatibility."""

    mode: Literal["memory", "sqlalchemy"] = "sqlalchemy"


class RuntimeConfig(StrictRuntimeModel):
    """Resolved runtime config from the manifest's ``runtime`` block."""

    server: ServerConfig = Field(default_factory=ServerConfig)
    worker: WorkerConfig = Field(default_factory=WorkerConfig)
    session: SessionConfig = Field(default_factory=SessionConfig)
    trace: TraceConfig = Field(default_factory=TraceConfig)
    diagnostic_history: DiagnosticHistoryLimits = Field(
        default_factory=DiagnosticHistoryLimits
    )
    loop: LoopConfig = Field(default_factory=LoopConfig)
    reporter: ReporterConfig = Field(default_factory=ReporterConfig)
    model: ModelConfig = Field(default_factory=ModelConfig)
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)
    store: StoreConfig = Field(default_factory=StoreConfig)
    policy_prompt: str | None = None


class RuntimeEnvironment(StrictRuntimeModel):
    """Runtime environment variables parsed once at boot."""

    api_url: str | None = None
    api_key: str | None = None
    agent_token: str | None = None
    agent_api_key: str | None = None
    agent_admin_key: str | None = None
    dev_mode: bool = False
    tenant_id: str | None = None
    database_url: str | None = None
    runtime_role: Literal["serve", "work", "all"] = "all"
    log_level: str | None = None
    otel_endpoint: str | None = None
    agentdb: AgentDbConfig | None = None

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> RuntimeEnvironment:
        """Parse supported environment variables into one immutable object."""

        source = os.environ if env is None else env
        return cls(
            api_url=_blank_to_none(source.get("COGIT_API_URL")),
            api_key=_blank_to_none(source.get("COGIT_API_KEY")),
            agent_token=_blank_to_none(source.get("COGIT_AGENT_TOKEN")),
            agent_api_key=_blank_to_none(source.get("COGIT_AGENT_API_KEY")),
            agent_admin_key=_blank_to_none(source.get("COGIT_AGENT_ADMIN_KEY")),
            dev_mode=_parse_bool(source.get("COGIT_DEV_MODE")),
            tenant_id=_blank_to_none(source.get("COGIT_TENANT_ID")),
            database_url=_blank_to_none(source.get("DATABASE_URL")),
            runtime_role=_parse_runtime_role(source.get("COGIT_RUNTIME_ROLE")),
            log_level=_blank_to_none(source.get("COGIT_LOG_LEVEL")),
            otel_endpoint=_blank_to_none(source.get("COGIT_OTEL_ENDPOINT")),
            agentdb=AgentDbConfig.from_env(source),
        )

    @property
    def outbound_credential(self) -> str | None:
        """Credential used by the future Cogit client."""

        return self.agent_token or self.api_key

    def require_agentdb_execution(self) -> AgentDbConfig:
        """Reject configuration that could select a standalone execution store."""
        if self.dev_mode:
            raise RuntimeConfigurationError(
                "COGIT_DEV_MODE is unavailable for deployed Runtime execution. "
                "Configure the AgentDB service."
            )
        if self.database_url is not None:
            raise RuntimeConfigurationError(
                "DATABASE_URL is unavailable for Runtime execution. "
                "AgentDB owns durable execution state."
            )
        if self.agentdb is None:
            raise RuntimeConfigurationError(
                "Runtime execution requires COGIT_AGENTDB_URL, "
                "COGIT_AGENTDB_API_VERSION, COGIT_AGENTDB_POOL_ID, and "
                "COGIT_AGENTDB_WORKER_TOKEN."
            )
        return self.agentdb

    def validate_boot(
        self, config: RuntimeConfig, *, worker_only: bool = False
    ) -> None:
        """Validate security-sensitive boot invariants."""

        self.validate_bind_host(config.server.host)
        if self.dev_mode:
            return

        if not self.agent_api_key and not (
            worker_only and self.runtime_role == "work" and self.agentdb is not None
        ):
            msg = "COGIT_AGENT_API_KEY must be configured when COGIT_DEV_MODE is off"
            raise RuntimeConfigurationError(msg)

    def validate_bind_host(self, host: str) -> None:
        """Check the actual listener address, including CLI overrides."""
        if self.dev_mode and not _is_loopback_host(host):
            msg = "COGIT_DEV_MODE=1 is only allowed on a loopback bind address"
            raise RuntimeConfigurationError(msg)


def _blank_to_none(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def _parse_bool(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_runtime_role(value: str | None) -> Literal["serve", "work", "all"]:
    normalized = (value or "all").strip().lower()
    if normalized == "serve":
        return "serve"
    if normalized == "work":
        return "work"
    if normalized == "all":
        return "all"
    msg = "COGIT_RUNTIME_ROLE must be one of: serve, work, all"
    raise RuntimeConfigurationError(msg)


def _is_loopback_host(host: str) -> bool:
    normalized = host.strip().lower()
    return normalized in {"127.0.0.1", "localhost", "::1"}
