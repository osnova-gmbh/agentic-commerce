"""Resolve the resident class from the single authored agent manifest."""

from __future__ import annotations

import re

from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.manifest import load_manifest

_IMPORT_PATH = re.compile(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*:[A-Za-z_]\w*", re.ASCII)


def resolve_agent_entrypoint(manifest: str, explicit: str | None = None) -> str:
    """Prefer YAML metadata; retain explicit imports for older manifests.

    Resolution never imports agent code. Canonical cohort verification must still
    run before import. An explicit option cannot override an authored identity.
    """
    descriptor = load_manifest(manifest).descriptor
    authored = (descriptor.metadata or {}).get("entrypoint")
    if authored is not None and (
        not isinstance(authored, str) or _IMPORT_PATH.fullmatch(authored) is None
    ):
        raise RuntimeConfigurationError(
            "Manifest metadata.entrypoint must be module:ClassName"
        )
    if authored is not None:
        normalized = explicit
        if explicit is not None and ":" not in explicit:
            module, separator, name = explicit.rpartition(".")
            normalized = f"{module}:{name}" if separator else explicit
        if explicit is not None and normalized != authored:
            raise RuntimeConfigurationError(
                "--agent differs from manifest metadata.entrypoint"
            )
        return authored
    if explicit is None:
        raise RuntimeConfigurationError(
            "Set metadata.entrypoint in cogit.yaml or pass --agent"
        )
    return explicit
