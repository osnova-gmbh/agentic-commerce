"""Translate immediate and deferred pipeline completion into the same run result."""

from __future__ import annotations

from typing import Literal

from cogit_agent_sdk.types import ErrorInfo, RunResult

from cogit_runtime.pipeline import PipelineResult
from cogit_runtime.reporter import RunReporter


def complete_pipeline(
    result: PipelineResult,
    reporter: RunReporter,
    execution_id: str,
    *,
    pipeline_name: str,
    waiting_for_approval: bool = False,
) -> RunResult:
    """Keep business disposition independent of the pipeline's execution status."""
    status: Literal["completed", "failed", "cancelled", "waiting"] = "completed"
    outcome_label = "pipeline_completed"
    error = None
    if result.status == "failed":
        status, outcome_label = "failed", "pipeline_failed"
        error = ErrorInfo(
            code="PIPELINE_FAILED",
            message=result.error or "Pipeline failed",
            retryable=False,
        )
    elif result.status == "cancelled":
        status, outcome_label = "cancelled", "pipeline_cancelled"
        error = ErrorInfo(code="CANCELLED", message="Run cancelled", retryable=False)
    elif result.status == "waiting":
        status, outcome_label = "waiting", "waiting_for_approval"
    if status != "cancelled" and waiting_for_approval:
        status, outcome_label = "waiting", "waiting_for_approval"
        error = None
    completed = reporter.complete(
        execution_id,
        status=status,
        output_summary=f"Pipeline {pipeline_name}: {result.status}",
        outcome_label=outcome_label,
        error=error,
    )
    return RunResult(
        execution_record=completed,
        output={
            "pipeline": pipeline_name,
            "status": result.status,
            "steps": [
                {
                    "id": step.step_name,
                    "status": step.status,
                    "output": step.output,
                    "error": step.error,
                }
                for step in result.step_results
            ],
        },
        status=status,
        outcome_label=outcome_label,
        error=error,
        work_outcome=result.work_outcome,
    )
