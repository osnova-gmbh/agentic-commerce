"""Structural manifest and agent validation without executing Runtime work."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from cogit_agent_sdk.types import AgentDescriptor

from cogit_runtime.config import RuntimeEnvironment
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.lifecycle import AgentLifecycleManager
from cogit_runtime.manifest import load_manifest
from cogit_runtime.operations.registry import (
    RuntimeActionRegistry,
    RuntimeToolRegistry,
    build_action_registry,
    build_tool_registry,
    freeze_agent_action_registration,
    freeze_agent_tool_registration,
)


def validate_manifest_agent(
    manifest_path: str | Path, *, agent_class: type[Any]
) -> None:
    """Validate a trusted resident class and manifest without starting a Runtime."""
    descriptor = load_manifest(manifest_path).descriptor
    lifecycle = AgentLifecycleManager(agent_class, descriptor, RuntimeEnvironment())
    agent = lifecycle.construct()
    lifecycle.configure(agent, lifecycle.inject_services(agent))
    build_validated_registries(agent, descriptor)


def build_validated_registries(
    agent: object, descriptor: AgentDescriptor
) -> tuple[RuntimeActionRegistry, RuntimeToolRegistry]:
    """Freeze configured bindings and check that they match declared operations."""
    freeze_agent_action_registration(agent)
    freeze_agent_tool_registration(agent)
    actions = list(descriptor.actions)
    tools = list(descriptor.tools)
    action_registry = build_action_registry(agent, actions)
    tool_registry = build_tool_registry(agent, tools)
    parity_errors = action_registry.validate_parity(actions)
    parity_errors.extend(tool_registry.validate_parity(tools))
    if parity_errors:
        joined = "; ".join(parity_errors)
        raise RuntimeConfigurationError(
            f"Action/manifest parity check failed: {joined}"
        )
    return action_registry, tool_registry
