"""SQL-backed implementation of the RuntimeStore protocol."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any, cast

from cogit_agent_sdk.types import (
    ArtifactRef,
    AssistantMessage,
    AttentionItem,
    Case,
    Context,
    Decision,
    EvalRecord,
    ExecutionRecord,
    ExecutionStepRecord,
    ExperimentRecord,
    Feedback,
    LearningRecord,
    Message,
    QueueItem,
    RunEvent,
    Session,
    ToolResultMessage,
)
from sqlalchemy import Engine, event, func, or_, select, update
from sqlalchemy.engine import CursorResult
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session as DbSession

from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.migrations import require_legacy_postgres
from cogit_runtime.persistence import (
    RuntimeArtifact,
    RuntimeAttention,
    RuntimeCase,
    RuntimeEval,
    RuntimeExecutionStep,
    RuntimeExperiment,
    RuntimeFeedback,
    RuntimeLearning,
    RuntimeOutbox,
    RuntimeQueueItem,
    RuntimeRun,
    RuntimeRunEvent,
    RuntimeSession,
)
from cogit_runtime.store import (
    OUTBOX_MAX_RETRIES,
    ApprovalRecord,
    OutboxRecord,
    _normalize_session_message,
    outbox_backoff_seconds,
)

_APPROVAL_CONTEXT_KEY = "_cogit_parked_context"
_APPROVAL_PAYLOAD_KEY = "_cogit_parked_payload"
_APPROVAL_DECISION_ID_KEY = "_cogit_decision_id"
_APPROVAL_DECISION_PATCH_KEY = "_cogit_decision_patch"
_APPROVAL_CONSUMED_KEY = "_cogit_approval_consumed"


class SqlRuntimeStore:
    """SQL-backed runtime store using SQLAlchemy.

    Every public method opens its own session so callers don't need to
    manage transactions.
    """

    def __init__(self, engine: Engine, *, tenant_id: str | None = None) -> None:
        require_legacy_postgres(engine.dialect.name)
        self._engine = engine
        self._tenant_id = tenant_id

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _session(self) -> DbSession:
        session = DbSession(self._engine)
        if self._tenant_id is not None:
            event.listen(session, "before_flush", self._enforce_tenant_writes)
        return session

    def _enforce_tenant_writes(
        self, session: DbSession, _flush_context: object, _instances: object
    ) -> None:
        for row in session.new.union(session.dirty):
            if not hasattr(row, "tenant_id"):
                continue
            tenant_id = row.tenant_id
            if tenant_id is None:
                # Optional tenant fields inherit the database's sole owner.
                row.tenant_id = self._tenant_id
            elif tenant_id != self._tenant_id:
                raise RuntimeConfigurationError(
                    "SQL write does not match the database tenant"
                )

    # ------------------------------------------------------------------
    # runs
    # ------------------------------------------------------------------

    def put_run(self, record: ExecutionRecord) -> ExecutionRecord:
        with self._session() as s:
            row = s.get(RuntimeRun, record.id)
            data = record.model_dump()
            if row is None:
                row = RuntimeRun(
                    id=data["id"],
                    tenant_id=data["tenant_id"],
                    organization_id=data.get("organization_id"),
                    agent_id=data["agent_id"],
                    case_id=data.get("case_id"),
                    session_id=data.get("session_id"),
                    trigger=data["trigger"],
                    status=data["status"],
                    outcome_label=data.get("outcome_label"),
                    input_summary=data.get("input_summary"),
                    output_summary=data.get("output_summary"),
                    started_at=data["started_at"],
                    completed_at=data.get("completed_at"),
                    usage=_dump_optional_model(record.usage),
                    error=_dump_optional_model(record.error),
                    run_metadata=data.get("metadata"),
                )
                s.add(row)
            else:
                row.tenant_id = data["tenant_id"]
                row.organization_id = data.get("organization_id")
                row.agent_id = data["agent_id"]
                row.case_id = data.get("case_id")
                row.session_id = data.get("session_id")
                row.trigger = data["trigger"]
                row.status = data["status"]
                row.outcome_label = data.get("outcome_label")
                row.input_summary = data.get("input_summary")
                row.output_summary = data.get("output_summary")
                row.started_at = data["started_at"]
                row.completed_at = data.get("completed_at")
                row.usage = _dump_optional_model(record.usage)
                row.error = _dump_optional_model(record.error)
                row.run_metadata = data.get("metadata")
            s.commit()
        return record

    def create_run_if_absent(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord | None = None,
    ) -> bool:
        try:
            with self._session() as s:
                data = record.model_dump()
                s.add(
                    RuntimeRun(
                        id=data["id"],
                        tenant_id=data["tenant_id"],
                        organization_id=data.get("organization_id"),
                        agent_id=data["agent_id"],
                        case_id=data.get("case_id"),
                        session_id=data.get("session_id"),
                        trigger=data["trigger"],
                        status=data["status"],
                        outcome_label=data.get("outcome_label"),
                        input_summary=data.get("input_summary"),
                        output_summary=data.get("output_summary"),
                        started_at=data["started_at"],
                        completed_at=data.get("completed_at"),
                        usage=_dump_optional_model(record.usage),
                        error=_dump_optional_model(record.error),
                        run_metadata=data.get("metadata"),
                    )
                )
                s.flush()
                if outbox is not None:
                    self._enqueue_outbox_in_session(s, outbox)
                s.commit()
                return True
        except IntegrityError:
            return False

    def get_run(self, execution_id: str) -> ExecutionRecord | None:
        with self._session() as s:
            row = s.get(RuntimeRun, execution_id)
            if row is None:
                return None
            return _run_row_to_record(row)

    def complete_run_if_running(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord | None = None,
    ) -> bool:
        with self._session() as s:
            result = cast(
                CursorResult[Any],
                s.execute(
                    update(RuntimeRun)
                    .where(
                        RuntimeRun.id == record.id,
                        RuntimeRun.status == "running",
                    )
                    .values(
                        status=record.status,
                        outcome_label=record.outcome_label,
                        output_summary=record.output_summary,
                        completed_at=record.completed_at,
                        usage=_dump_optional_model(record.usage),
                        error=_dump_optional_model(record.error),
                        run_metadata=record.metadata,
                    )
                ),
            )
            won = result.rowcount == 1
            if won and outbox is not None:
                self._enqueue_outbox_in_session(s, outbox)
            s.commit()
            return won

    def list_runs(self) -> list[ExecutionRecord]:
        with self._session() as s:
            rows = (
                s.execute(select(RuntimeRun).order_by(RuntimeRun.started_at.desc()))
                .scalars()
                .all()
            )
            return [_run_row_to_record(r) for r in rows]

    # ------------------------------------------------------------------
    # events
    # ------------------------------------------------------------------

    def append_event(self, event: RunEvent) -> RunEvent:
        current = event
        last_error: Exception | None = None
        for _ in range(8):
            try:
                with self._session() as s:
                    row = RuntimeRunEvent(
                        execution_id=current.execution_id,
                        case_id=current.case_id,
                        sequence=current.sequence,
                        ts=current.timestamp,
                        type=current.type,
                        payload=current.payload,
                    )
                    s.add(row)
                    s.commit()
                return current
            except IntegrityError as exc:
                last_error = exc
                current = current.model_copy(
                    update={
                        "sequence": self.next_event_sequence(current.execution_id),
                    }
                )
        assert last_error is not None
        raise last_error

    def list_events(self, execution_id: str, *, after_seq: int = 0) -> list[RunEvent]:
        with self._session() as s:
            rows = (
                s.execute(
                    select(RuntimeRunEvent)
                    .where(RuntimeRunEvent.execution_id == execution_id)
                    .where(RuntimeRunEvent.sequence > after_seq)
                    .order_by(RuntimeRunEvent.sequence)
                )
                .scalars()
                .all()
            )
            return [
                RunEvent(
                    execution_id=r.execution_id,
                    case_id=r.case_id,
                    sequence=r.sequence,
                    timestamp=r.ts,
                    type=r.type,  # type: ignore[arg-type]
                    payload=r.payload,
                )
                for r in rows
            ]

    def next_event_sequence(self, execution_id: str) -> int:
        with self._session() as s:
            max_seq = s.scalar(
                select(func.max(RuntimeRunEvent.sequence)).where(
                    RuntimeRunEvent.execution_id == execution_id
                )
            )
            return int(max_seq or 0) + 1

    # ------------------------------------------------------------------
    # sessions
    # ------------------------------------------------------------------

    def put_session(self, session: Session) -> Session:
        with self._session() as s:
            row = s.get(RuntimeSession, session.id)
            data = session.model_dump()
            msgs = [
                m.model_dump(mode="json") if hasattr(m, "model_dump") else m
                for m in session.messages
            ]
            if row is None:
                row = RuntimeSession(
                    id=data["id"],
                    tenant_id=data["tenant_id"],
                    agent_id=data["agent_id"],
                    created_at=data["created_at"],
                    updated_at=data["updated_at"],
                    messages=msgs,
                    state=data.get("state"),
                    session_metadata=data.get("metadata"),
                )
                s.add(row)
            else:
                row.tenant_id = data["tenant_id"]
                row.agent_id = data["agent_id"]
                row.created_at = data["created_at"]
                row.updated_at = data["updated_at"]
                row.messages = msgs  # type: ignore[assignment]
                row.state = data.get("state")
                row.session_metadata = data.get("metadata")
            s.commit()
        return session

    def get_session(self, session_id: str) -> Session | None:
        with self._session() as s:
            row = s.get(RuntimeSession, session_id)
            if row is None:
                return None
            return _session_row_to_record(row)

    def delete_session(self, session_id: str) -> Session | None:
        with self._session() as s:
            row = s.get(RuntimeSession, session_id)
            if row is None:
                return None
            result = _session_row_to_record(row)
            s.delete(row)
            s.commit()
            return result

    def get_or_create_session(
        self,
        *,
        session_id: str,
        tenant_id: str,
        agent_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> Session:
        with self._session() as s:
            row = s.get(RuntimeSession, session_id)
            if row is not None:
                return _session_row_to_record(row)
            now = datetime.now(UTC)
            new_row = RuntimeSession(
                id=session_id,
                tenant_id=tenant_id,
                agent_id=agent_id,
                created_at=now,
                updated_at=now,
                messages=[],
                state=None,
                session_metadata=metadata,
            )
            s.add(new_row)
            s.commit()
            return Session(
                id=session_id,
                tenant_id=tenant_id,
                agent_id=agent_id,
                created_at=now,
                updated_at=now,
                messages=[],
                metadata=metadata,
            )

    def append_session_messages(
        self,
        session_id: str,
        messages: list[Message | AssistantMessage | ToolResultMessage],
        *,
        max_history: int,
    ) -> Session | None:
        with self._session() as s:
            row = s.get(RuntimeSession, session_id)
            if row is None:
                return None
            transcript = list(row.messages or [])
            for entry in messages:
                normalized = _normalize_session_message(entry)
                if normalized is not None:
                    transcript.append(normalized.model_dump(mode="json"))
            if max_history > 0 and len(transcript) > max_history:
                transcript = transcript[-max_history:]
            now = datetime.now(UTC)
            row.messages = transcript
            row.updated_at = now
            row.session_metadata = row.session_metadata
            s.commit()
            return _session_row_to_record(row)

    # ------------------------------------------------------------------
    # evals
    # ------------------------------------------------------------------

    def list_evals(self) -> list[EvalRecord]:
        with self._session() as s:
            rows = (
                s.execute(select(RuntimeEval).order_by(RuntimeEval.started_at.desc()))
                .scalars()
                .all()
            )
            return [_eval_row_to_record(r) for r in rows]

    def put_eval(self, record: EvalRecord) -> EvalRecord:
        with self._session() as s:
            row = s.get(RuntimeEval, record.id)
            data = record.model_dump()
            serialized = record.model_dump(mode="json")
            if row is None:
                row = RuntimeEval(
                    id=data["id"],
                    tenant_id=data.get("tenant_id"),
                    agent_id=data["agent_id"],
                    agent_version=data["agent_version"],
                    suite_name=data["suite_name"],
                    status=data["status"],
                    started_at=data["started_at"],
                    completed_at=data.get("completed_at"),
                    eval_metadata=_eval_store_metadata(serialized),
                )
                s.add(row)
            else:
                row.tenant_id = data.get("tenant_id")
                row.agent_id = data["agent_id"]
                row.agent_version = data["agent_version"]
                row.suite_name = data["suite_name"]
                row.status = data["status"]
                row.started_at = data["started_at"]
                row.completed_at = data.get("completed_at")
                row.eval_metadata = _eval_store_metadata(serialized)
            s.commit()
        return record

    def get_eval(self, eval_id: str) -> EvalRecord | None:
        with self._session() as s:
            row = s.get(RuntimeEval, eval_id)
            if row is None:
                return None
            return _eval_row_to_record(row)

    # ------------------------------------------------------------------
    # platform outbox
    # ------------------------------------------------------------------

    def enqueue_outbox(self, record: OutboxRecord) -> OutboxRecord:
        with self._session() as s:
            stored = self._enqueue_outbox_in_session(s, record)
            s.commit()
            return stored

    def list_pending_outbox(self, *, limit: int = 100) -> list[OutboxRecord]:
        now = datetime.now(UTC)
        with self._session() as s:
            rows = (
                s.execute(
                    select(RuntimeOutbox)
                    .where(
                        RuntimeOutbox.delivered.is_(False),
                        or_(
                            RuntimeOutbox.dead_lettered.is_(False),
                            RuntimeOutbox.dead_lettered.is_(None),
                        ),
                        or_(
                            RuntimeOutbox.available_at.is_(None),
                            RuntimeOutbox.available_at <= now,
                        ),
                    )
                    .order_by(
                        RuntimeOutbox.enqueued_at.asc(),
                        RuntimeOutbox.id.asc(),
                    )
                    .limit(limit)
                )
                .scalars()
                .all()
            )
            return [_outbox_row_to_record(row) for row in rows]

    def mark_outbox_delivered(self, outbox_id: int) -> None:
        with self._session() as s:
            row = s.get(RuntimeOutbox, outbox_id)
            if row is None:
                return
            row.delivered = True
            row.dead_lettered = False
            row.last_error = None
            s.commit()

    def mark_outbox_failed(self, outbox_id: int, error: str) -> None:
        with self._session() as s:
            row = s.get(RuntimeOutbox, outbox_id)
            if row is None:
                return
            row.last_error = error
            row.retries += 1
            row.available_at = datetime.now(UTC) + timedelta(
                seconds=outbox_backoff_seconds(row.retries)
            )
            if row.retries >= OUTBOX_MAX_RETRIES:
                row.dead_lettered = True
            s.commit()

    def count_pending_outbox(self) -> int:
        with self._session() as s:
            return int(
                s.scalar(
                    select(func.count())
                    .select_from(RuntimeOutbox)
                    .where(
                        RuntimeOutbox.delivered.is_(False),
                        or_(
                            RuntimeOutbox.dead_lettered.is_(False),
                            RuntimeOutbox.dead_lettered.is_(None),
                        ),
                    )
                )
                or 0
            )

    def put_run_and_enqueue_outbox(
        self,
        record: ExecutionRecord,
        outbox: OutboxRecord,
    ) -> tuple[ExecutionRecord, OutboxRecord]:
        with self._session() as s:
            self._upsert_run_in_session(s, record)
            stored_outbox = self._enqueue_outbox_in_session(s, outbox)
            s.commit()
            return record, stored_outbox

    def put_eval_and_enqueue_outbox(
        self,
        record: EvalRecord,
        outbox: OutboxRecord,
    ) -> tuple[EvalRecord, OutboxRecord]:
        with self._session() as s:
            self._upsert_eval_in_session(s, record)
            stored_outbox = self._enqueue_outbox_in_session(s, outbox)
            s.commit()
            return record, stored_outbox

    def _enqueue_outbox_in_session(
        self,
        s: DbSession,
        record: OutboxRecord,
    ) -> OutboxRecord:
        if record.idempotency_key is not None:
            existing = s.execute(
                select(RuntimeOutbox).where(
                    RuntimeOutbox.idempotency_key == record.idempotency_key
                )
            ).scalar_one_or_none()
            if existing is not None:
                return _outbox_row_to_record(existing)

        now = datetime.now(UTC)
        row = RuntimeOutbox(
            operation=record.operation,
            payload=record.payload,
            context=record.context,
            idempotency_key=record.idempotency_key,
            enqueued_at=record.enqueued_at,
            available_at=record.available_at or now,
            delivered=False,
            dead_lettered=False,
            last_error=None,
            retries=0,
        )
        try:
            with s.begin_nested():
                s.add(row)
                s.flush()
        except IntegrityError:
            if record.idempotency_key is None:
                raise
            existing = s.execute(
                select(RuntimeOutbox).where(
                    RuntimeOutbox.idempotency_key == record.idempotency_key
                )
            ).scalar_one_or_none()
            if existing is None:
                raise
            return _outbox_row_to_record(existing)
        return _outbox_row_to_record(row)

    def _upsert_run_in_session(self, s: DbSession, record: ExecutionRecord) -> None:
        row = s.get(RuntimeRun, record.id)
        data = record.model_dump()
        if row is None:
            row = RuntimeRun(
                id=data["id"],
                tenant_id=data["tenant_id"],
                organization_id=data.get("organization_id"),
                agent_id=data["agent_id"],
                case_id=data.get("case_id"),
                session_id=data.get("session_id"),
                trigger=data["trigger"],
                status=data["status"],
                outcome_label=data.get("outcome_label"),
                input_summary=data.get("input_summary"),
                output_summary=data.get("output_summary"),
                started_at=data["started_at"],
                completed_at=data.get("completed_at"),
                usage=_dump_optional_model(record.usage),
                error=_dump_optional_model(record.error),
                run_metadata=data.get("metadata"),
            )
            s.add(row)
            return
        row.tenant_id = data["tenant_id"]
        row.organization_id = data.get("organization_id")
        row.agent_id = data["agent_id"]
        row.case_id = data.get("case_id")
        row.session_id = data.get("session_id")
        row.trigger = data["trigger"]
        row.status = data["status"]
        row.outcome_label = data.get("outcome_label")
        row.input_summary = data.get("input_summary")
        row.output_summary = data.get("output_summary")
        row.started_at = data["started_at"]
        row.completed_at = data.get("completed_at")
        row.usage = _dump_optional_model(record.usage)
        row.error = _dump_optional_model(record.error)
        row.run_metadata = data.get("metadata")

    def _upsert_eval_in_session(self, s: DbSession, record: EvalRecord) -> None:
        row = s.get(RuntimeEval, record.id)
        data = record.model_dump()
        serialized = record.model_dump(mode="json")
        if row is None:
            row = RuntimeEval(
                id=data["id"],
                tenant_id=data.get("tenant_id"),
                agent_id=data["agent_id"],
                agent_version=data["agent_version"],
                suite_name=data["suite_name"],
                status=data["status"],
                started_at=data["started_at"],
                completed_at=data.get("completed_at"),
                eval_metadata=_eval_store_metadata(serialized),
            )
            s.add(row)
            return
        row.tenant_id = data.get("tenant_id")
        row.agent_id = data["agent_id"]
        row.agent_version = data["agent_version"]
        row.suite_name = data["suite_name"]
        row.status = data["status"]
        row.started_at = data["started_at"]
        row.completed_at = data.get("completed_at")
        row.eval_metadata = _eval_store_metadata(serialized)

    # ------------------------------------------------------------------
    # approvals
    # ------------------------------------------------------------------

    def put_approval(self, record: ApprovalRecord) -> ApprovalRecord:
        with self._session() as s:
            item = record.item
            metadata = dict(item.metadata or {})
            metadata[_APPROVAL_CONTEXT_KEY] = record.context.model_dump(
                by_alias=True,
                mode="json",
                exclude_none=True,
            )
            metadata[_APPROVAL_PAYLOAD_KEY] = record.payload
            if record.consumed:
                metadata[_APPROVAL_CONSUMED_KEY] = True
            if record.decision is not None:
                metadata[_APPROVAL_DECISION_ID_KEY] = record.decision.id
                if record.decision.patch is not None:
                    metadata[_APPROVAL_DECISION_PATCH_KEY] = record.decision.patch

            row = s.get(RuntimeAttention, item.id)
            if row is None:
                row = RuntimeAttention(
                    id=item.id,
                    kind=item.kind,
                    execution_id=item.execution_id,
                    case_id=item.case_id,
                    message=item.message,
                    options=(
                        [
                            option.model_dump(
                                by_alias=True,
                                mode="json",
                                exclude_none=True,
                            )
                            for option in item.options
                        ]
                        if item.options
                        else None
                    ),
                    item_metadata=metadata,
                    created_at=record.created_at,
                )
                s.add(row)
            else:
                if record.decision is None or row.decision_action is not None:
                    return _attention_row_to_record(row)
                # Parked subject/payload and final decisions are immutable. A
                # delayed decision writer must never clear a consumed marker.
                metadata = dict(row.item_metadata or {})
                metadata[_APPROVAL_DECISION_ID_KEY] = record.decision.id
                if record.decision.patch is not None:
                    metadata[_APPROVAL_DECISION_PATCH_KEY] = record.decision.patch
                consumed = RuntimeAttention.item_metadata[
                    _APPROVAL_CONSUMED_KEY
                ].as_boolean()
                s.execute(
                    update(RuntimeAttention)
                    .where(RuntimeAttention.id == item.id)
                    .where(RuntimeAttention.decision_action.is_(None))
                    .where(or_(consumed.is_(None), consumed.is_(False)))
                    .values(
                        item_metadata=metadata,
                        decision_action=record.decision.action,
                        decision_rationale=record.decision.rationale,
                        decided_by=record.decision.decided_by,
                        decided_at=record.decision.decided_at,
                    )
                    .execution_options(synchronize_session=False)
                )
                s.commit()
                s.refresh(row)
                return _attention_row_to_record(row)

            decision = record.decision
            row.decision_action = decision.action if decision is not None else None
            row.decision_rationale = (
                decision.rationale if decision is not None else None
            )
            row.decided_by = decision.decided_by if decision is not None else None
            row.decided_at = decision.decided_at if decision is not None else None
            s.commit()
        return record

    def get_approval(self, item_id: str) -> ApprovalRecord | None:
        with self._session() as s:
            row = s.get(RuntimeAttention, item_id)
            if row is None:
                return None
            return _attention_row_to_record(row)

    def consume_approval(self, item_id: str) -> bool:
        with self._session() as s:
            row = s.get(RuntimeAttention, item_id)
            if row is None:
                return False
            metadata = dict(row.item_metadata or {})
            if metadata.get(_APPROVAL_CONSUMED_KEY):
                return False
            metadata[_APPROVAL_CONSUMED_KEY] = True
            consumed = RuntimeAttention.item_metadata[
                _APPROVAL_CONSUMED_KEY
            ].as_boolean()
            result = s.execute(
                update(RuntimeAttention)
                .where(RuntimeAttention.id == item_id)
                .where(or_(consumed.is_(None), consumed.is_(False)))
                .values(item_metadata=metadata)
                .execution_options(synchronize_session=False)
            )
            s.commit()
            return cast(CursorResult[Any], result).rowcount == 1

    def list_pending_approvals(self) -> list[ApprovalRecord]:
        with self._session() as s:
            rows = (
                s.execute(
                    select(RuntimeAttention)
                    .where(RuntimeAttention.decision_action.is_(None))
                    .order_by(RuntimeAttention.created_at.asc())
                )
                .scalars()
                .all()
            )
            return [_attention_row_to_record(row) for row in rows]

    # ------------------------------------------------------------------
    # learnings
    # ------------------------------------------------------------------

    def list_learnings(self) -> list[LearningRecord]:
        with self._session() as s:
            rows = (
                s.execute(
                    select(RuntimeLearning).order_by(RuntimeLearning.created_at.desc())
                )
                .scalars()
                .all()
            )
            return [_learning_row_to_record(r) for r in rows]

    def put_learning(self, record: LearningRecord) -> LearningRecord:
        with self._session() as s:
            row = s.get(RuntimeLearning, record.id)
            data = record.model_dump()
            if row is None:
                row = RuntimeLearning(
                    id=data["id"],
                    agent_id=data["agent_id"],
                    tenant_id=data.get("tenant_id"),
                    organization_id=data.get("organization_id"),
                    title=data["title"],
                    body=data["body"],
                    status=data["status"],
                    tags=data.get("tags", []),
                    source=data["source"],
                    created_at=data["created_at"],
                )
                s.add(row)
            else:
                row.agent_id = data["agent_id"]
                row.tenant_id = data.get("tenant_id")
                row.organization_id = data.get("organization_id")
                row.title = data["title"]
                row.body = data["body"]
                row.status = data["status"]
                row.tags = data.get("tags", [])
                row.source = data["source"]
                row.created_at = data["created_at"]
            s.commit()
        return record

    # ------------------------------------------------------------------
    # experiments
    # ------------------------------------------------------------------

    def list_experiments(self) -> list[ExperimentRecord]:
        with self._session() as s:
            rows = (
                s.execute(
                    select(RuntimeExperiment).order_by(
                        RuntimeExperiment.created_at.desc()
                    )
                )
                .scalars()
                .all()
            )
            return [_experiment_row_to_record(r) for r in rows]

    def put_experiment(self, record: ExperimentRecord) -> ExperimentRecord:
        with self._session() as s:
            row = s.get(RuntimeExperiment, record.id)
            data = record.model_dump()
            if row is None:
                row = RuntimeExperiment(
                    id=data["id"],
                    agent_id=data["agent_id"],
                    organization_id=data.get("organization_id"),
                    hypothesis=data["hypothesis"],
                    changed_surface=data["changed_surface"],
                    metrics=data["metrics"],
                    verdict=data["verdict"],
                    created_at=data["created_at"],
                )
                s.add(row)
            else:
                row.agent_id = data["agent_id"]
                row.organization_id = data.get("organization_id")
                row.hypothesis = data["hypothesis"]
                row.changed_surface = data["changed_surface"]
                row.metrics = data["metrics"]
                row.verdict = data["verdict"]
                row.created_at = data["created_at"]
            s.commit()
        return record

    def get_experiment(self, experiment_id: str) -> ExperimentRecord | None:
        with self._session() as s:
            row = s.get(RuntimeExperiment, experiment_id)
            if row is None:
                return None
            return _experiment_row_to_record(row)

    # ------------------------------------------------------------------
    # queue items
    # ------------------------------------------------------------------

    def put_queue_item(self, item: QueueItem) -> QueueItem:
        with self._session() as s:
            row = s.get(RuntimeQueueItem, item.id)
            data = item.model_dump()
            if row is None:
                row = RuntimeQueueItem(
                    id=data["id"],
                    tenant_id=data["tenant_id"],
                    organization_id=data.get("organization_id"),
                    queue_name=data["queue_name"],
                    item_type=data["item_type"],
                    payload=data["payload"],
                    addressed_to=data.get("addressed_to"),
                    status=data["status"],
                    case_id=data.get("case_id"),
                    source_id=data.get("source_id"),
                    idempotency_key=data.get("idempotency_key"),
                    dedupe_key=data.get("dedupe_key"),
                    retry_count=data.get("retry_count", 0),
                    max_retries=data.get("max_retries", 3),
                    lease_expires_at=data.get("lease_expires_at"),
                    heartbeat_at=data.get("heartbeat_at"),
                    error=data.get("error"),
                )
                s.add(row)
            else:
                row.tenant_id = data["tenant_id"]
                row.organization_id = data.get("organization_id")
                row.queue_name = data["queue_name"]
                row.item_type = data["item_type"]
                row.payload = data["payload"]
                row.addressed_to = data.get("addressed_to")
                row.status = data["status"]
                row.case_id = data.get("case_id")
                row.source_id = data.get("source_id")
                row.idempotency_key = data.get("idempotency_key")
                row.dedupe_key = data.get("dedupe_key")
                row.retry_count = data.get("retry_count", 0)
                row.max_retries = data.get("max_retries", 3)
                row.lease_expires_at = data.get("lease_expires_at")
                row.heartbeat_at = data.get("heartbeat_at")
                row.error = data.get("error")
            s.commit()
        return item

    def list_queue_items(self) -> list[QueueItem]:
        with self._session() as s:
            rows = s.execute(select(RuntimeQueueItem)).scalars().all()
            return [_queue_row_to_item(r) for r in rows]

    # ------------------------------------------------------------------
    # cases
    # ------------------------------------------------------------------

    def put_case(self, case: Case) -> Case:
        with self._session() as s:
            row = s.get(RuntimeCase, case.id)
            data = case.model_dump()
            error_data = _case_error_for_storage(case.error)
            agent_id = data.get("agent_id") or "unknown"
            if row is None:
                row = RuntimeCase(
                    id=data["id"],
                    tenant_id=data["tenant_id"],
                    organization_id=data.get("organization_id"),
                    agent_id=agent_id,
                    source_type=data["source_type"],
                    source_id=data["source_id"],
                    status=data["status"],
                    current_goal=data.get("current_goal"),
                    process_id=data.get("process_id"),
                    process_version=data.get("process_version"),
                    assigned_agent_ids=data.get("assigned_agent_ids"),
                    owner=data.get("owner"),
                    retry_count=data.get("retry_count", 0),
                    next_retry_at=data.get("next_retry_at"),
                    last_attempt_at=data.get("last_attempt_at"),
                    created_at=data.get("created_at"),
                    updated_at=data.get("updated_at"),
                    completed_at=data.get("completed_at"),
                    final_outcome=data.get("final_outcome"),
                    error=error_data,
                    case_metadata=data.get("metadata"),
                )
                s.add(row)
            else:
                row.tenant_id = data["tenant_id"]
                row.organization_id = data.get("organization_id")
                row.agent_id = agent_id
                row.source_type = data["source_type"]
                row.source_id = data["source_id"]
                row.status = data["status"]
                row.current_goal = data.get("current_goal")
                row.process_id = data.get("process_id")
                row.process_version = data.get("process_version")
                row.assigned_agent_ids = data.get("assigned_agent_ids")
                row.owner = data.get("owner")
                row.retry_count = data.get("retry_count", 0)
                row.next_retry_at = data.get("next_retry_at")
                row.last_attempt_at = data.get("last_attempt_at")
                row.created_at = data.get("created_at")
                row.updated_at = data.get("updated_at")
                row.completed_at = data.get("completed_at")
                row.final_outcome = data.get("final_outcome")
                row.error = error_data
                row.case_metadata = data.get("metadata")
            s.commit()
        return case

    def get_case(self, case_id: str) -> Case | None:
        with self._session() as s:
            row = s.get(RuntimeCase, case_id)
            if row is None:
                return None
            return _case_row_to_record(row)

    def list_cases(self, *, tenant_id: str | None = None) -> list[Case]:
        with self._session() as s:
            stmt = select(RuntimeCase)
            if tenant_id is not None:
                stmt = stmt.where(RuntimeCase.tenant_id == tenant_id)
            rows = s.execute(stmt).scalars().all()
            return [_case_row_to_record(r) for r in rows]

    def resolve_case(
        self,
        *,
        tenant_id: str,
        source_type: str,
        source_id: str,
    ) -> Case | None:
        with self._session() as s:
            row = (
                s.execute(
                    select(RuntimeCase)
                    .where(RuntimeCase.tenant_id == tenant_id)
                    .where(RuntimeCase.source_type == source_type)
                    .where(RuntimeCase.source_id == source_id)
                )
                .scalars()
                .first()
            )
            if row is None:
                return None
            return _case_row_to_record(row)

    # ------------------------------------------------------------------
    # execution steps
    # ------------------------------------------------------------------

    def put_execution_step(self, step: ExecutionStepRecord) -> ExecutionStepRecord:
        with self._session() as s:
            row = s.get(RuntimeExecutionStep, step.id)
            data = step.model_dump()
            if row is None:
                row = RuntimeExecutionStep(
                    id=data["id"],
                    execution_id=data["execution_id"],
                    case_id=data.get("case_id"),
                    order_num=data["order"],
                    kind=data["kind"],
                    name=data["name"],
                    status=data["status"],
                    started_at=data["started_at"],
                    completed_at=data.get("completed_at"),
                    summary=data.get("summary"),
                    data=data.get("data"),
                    error=_dump_optional_model(step.error),
                    usage=_dump_optional_model(step.usage),
                )
                s.add(row)
            else:
                row.execution_id = data["execution_id"]
                row.case_id = data.get("case_id")
                row.order_num = data["order"]
                row.kind = data["kind"]
                row.name = data["name"]
                row.status = data["status"]
                row.started_at = data["started_at"]
                row.completed_at = data.get("completed_at")
                row.summary = data.get("summary")
                row.data = data.get("data")
                row.error = _dump_optional_model(step.error)
                row.usage = _dump_optional_model(step.usage)
            s.commit()
        return step

    def list_execution_steps(self, execution_id: str) -> list[ExecutionStepRecord]:
        with self._session() as s:
            rows = (
                s.execute(
                    select(RuntimeExecutionStep)
                    .where(RuntimeExecutionStep.execution_id == execution_id)
                    .order_by(RuntimeExecutionStep.order_num.asc())
                )
                .scalars()
                .all()
            )
            return [_step_row_to_record(r) for r in rows]

    # ------------------------------------------------------------------
    # artifacts
    # ------------------------------------------------------------------

    def put_artifact(self, artifact: ArtifactRef) -> ArtifactRef:
        metadata = dict(artifact.metadata or {})
        case_id = metadata.get("caseId")
        execution_id = metadata.get("executionId")
        tenant_id = metadata.get("tenantId")
        with self._session() as s:
            row = s.get(RuntimeArtifact, artifact.id)
            if row is None:
                row = RuntimeArtifact(
                    id=artifact.id,
                    name=artifact.name,
                    mime_type=artifact.mime_type,
                    size=artifact.size,
                    uri=artifact.uri,
                    case_id=case_id if isinstance(case_id, str) else None,
                    execution_id=(
                        execution_id if isinstance(execution_id, str) else None
                    ),
                    tenant_id=tenant_id if isinstance(tenant_id, str) else None,
                    artifact_metadata=artifact.metadata,
                    created_at=datetime.now(UTC),
                )
                s.add(row)
            else:
                row.name = artifact.name
                row.mime_type = artifact.mime_type
                row.size = artifact.size
                row.uri = artifact.uri
                row.case_id = case_id if isinstance(case_id, str) else None
                row.execution_id = (
                    execution_id if isinstance(execution_id, str) else None
                )
                row.tenant_id = tenant_id if isinstance(tenant_id, str) else None
                row.artifact_metadata = artifact.metadata
            s.commit()
        return artifact

    def get_artifact(self, artifact_id: str) -> ArtifactRef | None:
        with self._session() as s:
            row = s.get(RuntimeArtifact, artifact_id)
            if row is None:
                return None
            return _artifact_row_to_record(row)

    def list_artifacts(
        self,
        *,
        case_id: str | None = None,
        execution_id: str | None = None,
    ) -> list[ArtifactRef]:
        with self._session() as s:
            stmt = select(RuntimeArtifact)
            if case_id is not None:
                stmt = stmt.where(RuntimeArtifact.case_id == case_id)
            if execution_id is not None:
                stmt = stmt.where(RuntimeArtifact.execution_id == execution_id)
            rows = s.execute(stmt.order_by(RuntimeArtifact.created_at.desc())).scalars()
            return [_artifact_row_to_record(row) for row in rows]

    # ------------------------------------------------------------------
    # feedback
    # ------------------------------------------------------------------

    def put_feedback(self, feedback: Feedback) -> Feedback:
        data = feedback.model_dump()
        with self._session() as s:
            row = s.get(RuntimeFeedback, feedback.id)
            if row is None:
                row = RuntimeFeedback(
                    id=data["id"],
                    tenant_id=data["tenant_id"],
                    case_id=data.get("case_id"),
                    execution_id=data.get("execution_id"),
                    rating=data.get("rating"),
                    score=data.get("score"),
                    comment=data.get("comment"),
                    source=data.get("source"),
                    created_at=data.get("created_at") or datetime.now(UTC),
                    feedback_metadata=data.get("metadata"),
                )
                s.add(row)
            else:
                row.tenant_id = data["tenant_id"]
                row.case_id = data.get("case_id")
                row.execution_id = data.get("execution_id")
                row.rating = data.get("rating")
                row.score = data.get("score")
                row.comment = data.get("comment")
                row.source = data.get("source")
                row.created_at = data.get("created_at") or row.created_at
                row.feedback_metadata = data.get("metadata")
            s.commit()
        return feedback

    def get_feedback(self, feedback_id: str) -> Feedback | None:
        with self._session() as s:
            row = s.get(RuntimeFeedback, feedback_id)
            if row is None:
                return None
            return _feedback_row_to_record(row)

    def list_feedback(
        self,
        *,
        case_id: str | None = None,
        execution_id: str | None = None,
    ) -> list[Feedback]:
        with self._session() as s:
            stmt = select(RuntimeFeedback)
            if case_id is not None:
                stmt = stmt.where(RuntimeFeedback.case_id == case_id)
            if execution_id is not None:
                stmt = stmt.where(RuntimeFeedback.execution_id == execution_id)
            rows = (
                s.execute(stmt.order_by(RuntimeFeedback.created_at.desc()))
                .scalars()
                .all()
            )
            return [_feedback_row_to_record(row) for row in rows]

    # ------------------------------------------------------------------
    # queue operations
    # ------------------------------------------------------------------

    def get_queue_item(self, item_id: str) -> QueueItem | None:
        with self._session() as s:
            row = s.get(RuntimeQueueItem, item_id)
            if row is None:
                return None
            return _queue_row_to_item(row)

    def claim_queue_item(
        self,
        queues: list[str],
        item_types: list[str],
        lease_seconds: int,
    ) -> QueueItem | None:
        with self._session() as s:
            stmt = select(RuntimeQueueItem).where(RuntimeQueueItem.status == "pending")
            if queues:
                stmt = stmt.where(RuntimeQueueItem.queue_name.in_(queues))
            if item_types:
                stmt = stmt.where(RuntimeQueueItem.item_type.in_(item_types))
            row = s.execute(stmt).scalars().first()
            if row is None:
                return None
            now = datetime.now(UTC)
            row.status = "processing"
            row.lease_expires_at = now + timedelta(seconds=lease_seconds)
            row.heartbeat_at = now
            s.commit()
            return _queue_row_to_item(row)

    def complete_queue_item(
        self, item_id: str, outcome: dict[str, object]
    ) -> QueueItem | None:
        _ = outcome
        with self._session() as s:
            row = s.get(RuntimeQueueItem, item_id)
            if row is None:
                return None
            row.status = "processed"
            row.lease_expires_at = None
            s.commit()
            return _queue_row_to_item(row)

    def fail_queue_item(
        self, item_id: str, error: str, retryable: bool
    ) -> QueueItem | None:
        with self._session() as s:
            row = s.get(RuntimeQueueItem, item_id)
            if row is None:
                return None
            if retryable and row.retry_count < row.max_retries:
                row.status = "pending"
                row.error = error
                row.retry_count = row.retry_count + 1
                row.lease_expires_at = None
                row.heartbeat_at = None
            else:
                row.status = "failed"
                row.error = error
            s.commit()
            return _queue_row_to_item(row)

    def heartbeat_queue_item(
        self, item_id: str, lease_seconds: int = 900
    ) -> QueueItem | None:
        with self._session() as s:
            row = s.get(RuntimeQueueItem, item_id)
            if row is None:
                return None
            now = datetime.now(UTC)
            row.lease_expires_at = now + timedelta(seconds=lease_seconds)
            row.heartbeat_at = now
            s.commit()
            return _queue_row_to_item(row)

    def park_queue_item(self, item_id: str) -> QueueItem | None:
        with self._session() as s:
            row = s.get(RuntimeQueueItem, item_id)
            if row is None:
                return None
            row.status = "parked"
            row.lease_expires_at = None
            row.heartbeat_at = None
            s.commit()
            return _queue_row_to_item(row)


# ------------------------------------------------------------------
# Row → SDK record converters
# ------------------------------------------------------------------


def _dump_optional_model(obj: Any) -> dict[str, Any] | None:
    """Convert a Pydantic model (Usage/ErrorInfo) to dict, or return None."""
    if obj is None:
        return None
    if hasattr(obj, "model_dump"):
        return obj.model_dump()  # type: ignore[no-any-return]
    return obj  # type: ignore[return-value]


def _run_row_to_record(row: RuntimeRun) -> ExecutionRecord:
    return ExecutionRecord.model_validate(
        {
            "id": row.id,
            "tenant_id": row.tenant_id,
            "organization_id": row.organization_id,
            "agent_id": row.agent_id,
            "case_id": row.case_id,
            "session_id": row.session_id,
            "trigger": row.trigger,
            "status": row.status,
            "outcome_label": row.outcome_label,
            "input_summary": row.input_summary,
            "output_summary": row.output_summary,
            "started_at": row.started_at,
            "completed_at": row.completed_at,
            "usage": row.usage,
            "error": row.error,
            "metadata": row.run_metadata,
        }
    )


def _session_row_to_record(row: RuntimeSession) -> Session:
    return Session.model_validate(
        {
            "id": row.id,
            "tenant_id": row.tenant_id,
            "agent_id": row.agent_id,
            "created_at": row.created_at,
            "updated_at": row.updated_at,
            "messages": row.messages or [],
            "state": row.state,
            "metadata": row.session_metadata,
        }
    )


def _outbox_row_to_record(row: RuntimeOutbox) -> OutboxRecord:
    return OutboxRecord(
        id=row.id,
        operation=row.operation,
        payload=row.payload,
        context=row.context,
        enqueued_at=row.enqueued_at,
        available_at=row.available_at,
        delivered=row.delivered,
        dead_lettered=bool(row.dead_lettered),
        last_error=row.last_error,
        retries=row.retries,
        idempotency_key=row.idempotency_key,
    )


def _attention_row_to_record(row: RuntimeAttention) -> ApprovalRecord:
    metadata = dict(row.item_metadata or {})
    context_data = metadata.pop(_APPROVAL_CONTEXT_KEY, None)
    payload = metadata.pop(_APPROVAL_PAYLOAD_KEY, {})
    decision_id = metadata.pop(_APPROVAL_DECISION_ID_KEY, None)
    decision_patch = metadata.pop(_APPROVAL_DECISION_PATCH_KEY, None)
    consumed = bool(metadata.pop(_APPROVAL_CONSUMED_KEY, False))

    context = Context.model_validate(
        context_data
        or {
            "tenant_id": "unknown",
            "correlation_id": row.id,
            "execution_id": row.execution_id,
            "case_id": row.case_id,
        }
    )
    item = AttentionItem.model_validate(
        {
            "id": row.id,
            "kind": row.kind,
            "execution_id": row.execution_id,
            "case_id": row.case_id,
            "message": row.message,
            "options": row.options,
            "metadata": metadata or None,
        }
    )
    decision = None
    if row.decision_action is not None:
        decision = Decision.model_validate(
            {
                "id": decision_id or f"decision-{row.id}",
                "attention_item_id": row.id,
                "action": row.decision_action,
                "rationale": row.decision_rationale,
                "patch": decision_patch,
                "decided_by": row.decided_by or "unknown",
                "decided_at": row.decided_at or row.created_at,
            }
        )
    return ApprovalRecord(
        item=item,
        context=context,
        payload=dict(payload) if isinstance(payload, dict) else {},
        created_at=row.created_at,
        decision=decision,
        consumed=consumed,
    )


def _eval_store_metadata(data: dict[str, Any]) -> dict[str, Any] | None:
    metadata = dict(data.get("metadata") or {})
    for key in ("items_total", "items_passed", "score", "results"):
        value = data.get(key)
        if value is not None:
            metadata[key] = value
    return metadata or None


def _eval_row_to_record(row: RuntimeEval) -> EvalRecord:
    metadata = dict(row.eval_metadata or {})
    return EvalRecord.model_validate(
        {
            "id": row.id,
            "tenant_id": row.tenant_id,
            "agent_id": row.agent_id,
            "agent_version": row.agent_version,
            "suite_name": row.suite_name,
            "status": row.status,
            "started_at": row.started_at,
            "completed_at": row.completed_at,
            "items_total": metadata.pop("items_total", None),
            "items_passed": metadata.pop("items_passed", None),
            "score": metadata.pop("score", None),
            "results": metadata.pop("results", None),
            "metadata": metadata or None,
        }
    )


def _learning_row_to_record(row: RuntimeLearning) -> LearningRecord:
    return LearningRecord.model_validate(
        {
            "id": row.id,
            "agent_id": row.agent_id,
            "tenant_id": row.tenant_id,
            "organization_id": row.organization_id,
            "title": row.title,
            "body": row.body,
            "status": row.status,
            "tags": row.tags,
            "source": row.source,
            "created_at": row.created_at,
        }
    )


def _experiment_row_to_record(row: RuntimeExperiment) -> ExperimentRecord:
    return ExperimentRecord.model_validate(
        {
            "id": row.id,
            "agent_id": row.agent_id,
            "organization_id": row.organization_id,
            "hypothesis": row.hypothesis,
            "changed_surface": row.changed_surface,
            "metrics": row.metrics,
            "verdict": row.verdict,
            "created_at": row.created_at,
        }
    )


def _queue_row_to_item(row: RuntimeQueueItem) -> QueueItem:
    return QueueItem.model_validate(
        {
            "id": row.id,
            "tenant_id": row.tenant_id,
            "organization_id": row.organization_id,
            "queue_name": row.queue_name,
            "item_type": row.item_type,
            "payload": row.payload,
            "addressed_to": row.addressed_to,
            "status": row.status,
            "case_id": row.case_id,
            "source_id": row.source_id,
            "idempotency_key": row.idempotency_key,
            "dedupe_key": row.dedupe_key,
            "retry_count": row.retry_count,
            "max_retries": row.max_retries,
            "lease_expires_at": row.lease_expires_at,
            "heartbeat_at": row.heartbeat_at,
            "error": row.error,
        }
    )


def _case_error_for_storage(error: Any) -> Any:
    """Persist Case.error (str) while tolerating legacy ErrorInfo-shaped values."""
    if error is None:
        return None
    if isinstance(error, str):
        return error
    if hasattr(error, "model_dump"):
        dumped = error.model_dump()
        if isinstance(dumped, dict) and "message" in dumped:
            return dumped["message"]
        return dumped
    if isinstance(error, dict):
        message = error.get("message")
        return message if isinstance(message, str) else error
    return str(error)


def _case_error_from_storage(error: Any) -> str | None:
    if error is None:
        return None
    if isinstance(error, str):
        return error
    if isinstance(error, dict):
        message = error.get("message")
        return message if isinstance(message, str) else str(error)
    return str(error)


def _case_row_to_record(row: RuntimeCase) -> Case:
    return Case.model_validate(
        {
            "id": row.id,
            "tenant_id": row.tenant_id,
            "organization_id": row.organization_id,
            "agent_id": row.agent_id,
            "source_type": row.source_type,
            "source_id": row.source_id,
            "status": row.status,
            "current_goal": getattr(row, "current_goal", None),
            "process_id": getattr(row, "process_id", None),
            "process_version": getattr(row, "process_version", None),
            "assigned_agent_ids": getattr(row, "assigned_agent_ids", None),
            "owner": getattr(row, "owner", None),
            "retry_count": row.retry_count,
            "next_retry_at": row.next_retry_at,
            "last_attempt_at": row.last_attempt_at,
            "created_at": getattr(row, "created_at", None),
            "updated_at": getattr(row, "updated_at", None),
            "completed_at": getattr(row, "completed_at", None),
            "final_outcome": getattr(row, "final_outcome", None),
            "error": _case_error_from_storage(row.error),
            "metadata": row.case_metadata,
        }
    )


def _step_row_to_record(row: RuntimeExecutionStep) -> ExecutionStepRecord:
    return ExecutionStepRecord.model_validate(
        {
            "id": row.id,
            "execution_id": row.execution_id,
            "case_id": row.case_id,
            "order": row.order_num,
            "kind": row.kind,
            "name": row.name,
            "status": row.status,
            "started_at": row.started_at,
            "completed_at": row.completed_at,
            "summary": row.summary,
            "data": row.data,
            "error": row.error,
            "usage": row.usage,
        }
    )


def _artifact_row_to_record(row: RuntimeArtifact) -> ArtifactRef:
    metadata = dict(row.artifact_metadata or {})
    if row.case_id is not None:
        metadata.setdefault("caseId", row.case_id)
    if row.execution_id is not None:
        metadata.setdefault("executionId", row.execution_id)
    if row.tenant_id is not None:
        metadata.setdefault("tenantId", row.tenant_id)
    return ArtifactRef(
        id=row.id,
        name=row.name,
        mime_type=row.mime_type,
        size=row.size,
        uri=row.uri,
        metadata=metadata or None,
    )


def _feedback_row_to_record(row: RuntimeFeedback) -> Feedback:
    return Feedback.model_validate(
        {
            "id": row.id,
            "tenant_id": row.tenant_id,
            "case_id": row.case_id,
            "execution_id": row.execution_id,
            "rating": row.rating,
            "score": row.score,
            "comment": row.comment,
            "source": row.source,
            "created_at": row.created_at,
            "metadata": row.feedback_metadata,
        }
    )


__all__ = ["SqlRuntimeStore"]
