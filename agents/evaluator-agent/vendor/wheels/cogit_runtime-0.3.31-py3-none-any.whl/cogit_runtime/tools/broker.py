"""Runtime tool broker — sole owner of model-facing tool execution."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Callable
from typing import Any

from cogit_agent_sdk._types import JsonObject
from cogit_agent_sdk.contracts import RunHandle
from cogit_agent_sdk.coordination import CoordinationFailure
from cogit_agent_sdk.operations.contract import OperationInvocation
from cogit_agent_sdk.operations.tool_binding import ToolBinding
from cogit_agent_sdk.types import Context, RunEvent, TextContent, ToolResult
from cogit_agent_sdk.types.cancellation import Cancellation

from cogit_runtime.approvals import ApprovalStore
from cogit_runtime.cancellation import (
    RuntimeCancellation,
    RuntimeWorkDeferred,
    await_runtime_completion,
)
from cogit_runtime.cooperative_worker import WorkerStillRunningError
from cogit_runtime.operations.executor import OperationExecutor
from cogit_runtime.operations.preflight import build_approval_preflight
from cogit_runtime.operations.registry import RuntimeToolRegistry
from cogit_runtime.operations.result import OperationExecutionResult
from cogit_runtime.reporter import RunReporter

logger = logging.getLogger(__name__)

ProgressCallback = Callable[[RunEvent], None]
_MAX_PROGRESS_EVENTS = 64


class _ProgressTracker:
    """Bounded, broker-owned progress forwarding for one tool call."""

    def __init__(
        self,
        *,
        execution_id: str,
        tool_call_id: str,
        on_progress: ProgressCallback | None,
    ) -> None:
        self._execution_id = execution_id
        self._tool_call_id = tool_call_id
        self._on_progress = on_progress
        self._sequence = 0

    def emit(self, event: RunEvent) -> None:
        if self._on_progress is None:
            return
        if self._sequence >= _MAX_PROGRESS_EVENTS:
            return
        self._sequence += 1
        payload = dict(event.payload or {})
        payload["executionId"] = self._execution_id
        payload["toolCallId"] = self._tool_call_id
        payload["progressSequence"] = self._sequence
        self._on_progress(
            event.model_copy(
                update={
                    "payload": payload,
                    "execution_id": self._execution_id,
                    "sequence": self._sequence,
                },
            ),
        )


class ToolBroker:
    """Resolve explicit tool bindings and delegate to the operation executor."""

    def __init__(
        self,
        *,
        registry: RuntimeToolRegistry,
        executor: OperationExecutor,
        approvals: ApprovalStore | None = None,
        reporter: RunReporter | None = None,
        track_deferred_task: Callable[[asyncio.Task[Any]], asyncio.Task[Any]]
        | None = None,
    ) -> None:
        self._registry = registry
        self._executor = executor
        self._approvals = approvals
        self._reporter = reporter
        self._track_deferred_task = track_deferred_task
        self._pending: dict[str, asyncio.Task[ToolResult]] = {}

    @property
    def registry(self) -> RuntimeToolRegistry:
        return self._registry

    async def execute(
        self,
        tool_name: str,
        raw_arguments: JsonObject,
        context: Context,
        *,
        tool_call_id: str,
        execution_id: str,
        allowed_tool_names: set[str] | None = None,
        cancellation: Cancellation | RuntimeCancellation,
        on_progress: ProgressCallback | None = None,
        approval_id: str | None = None,
        idempotency_key: str | None = None,
        handle: RunHandle | None = None,
        _prepared_arguments: JsonObject | None = None,
    ) -> ToolResult:
        pending = self._pending.get(execution_id)
        if pending is not None:
            await await_runtime_completion(pending)
            self._pending.pop(execution_id, None)
        if allowed_tool_names is not None and tool_name not in allowed_tool_names:
            return _blocked_tool_result(
                tool_call_id=tool_call_id,
                tool_name=tool_name,
                code="TOOL_NOT_ALLOWED",
                message="Tool is not available for this turn",
            )

        binding = self._registry.get(tool_name)
        if binding is None:
            return _blocked_tool_result(
                tool_call_id=tool_call_id,
                tool_name=tool_name,
                code="UNKNOWN_TOOL",
                message=f"Unknown tool: {tool_name}",
            )

        descriptor = binding.descriptor
        try:
            prepared = (
                _prepared_arguments
                if _prepared_arguments is not None
                else self._prepare_arguments(binding, raw_arguments, context)
            )
        except CoordinationFailure:
            raise
        except Exception:
            logger.debug(
                "prepare_arguments failed for %r",
                tool_name,
                exc_info=True,
            )
            return _blocked_tool_result(
                tool_call_id=tool_call_id,
                tool_name=tool_name,
                code="INVALID_INPUT",
                message="Tool arguments failed preparation",
            )
        execution_context = context.model_copy(update={"execution_id": execution_id})
        progress = _ProgressTracker(
            execution_id=execution_id,
            tool_call_id=tool_call_id,
            on_progress=on_progress,
        )
        invocation = OperationInvocation(
            context=execution_context,
            handle=handle
            or RunHandle(execution_id=execution_id, context=execution_context),
            cancellation=cancellation,
            idempotency_key=idempotency_key,
            emit_progress=progress.emit,
        )
        from cogit_runtime.agentdb.handle import AgentDbRunHandle
        from cogit_runtime.canonical_approval import build_canonical_approval_preflight

        before_invoke = (
            build_canonical_approval_preflight(
                descriptor=descriptor,
                exposure_name=tool_name,
                context=execution_context,
                handle=handle,
            )
            if isinstance(handle, AgentDbRunHandle)
            else build_approval_preflight(
                descriptor=descriptor,
                exposure_name=tool_name,
                context=context,
                execution_id=execution_id,
                approval_id=approval_id,
                idempotency_key=idempotency_key,
                approvals=self._approvals,
                reporter=self._reporter,
                source="tool",
            )
        )
        try:
            result = await self._executor.execute(
                binding.operation,
                descriptor.requirements,
                descriptor.name,
                prepared,
                invocation,
                cancellation=cancellation,
                timeout_seconds=descriptor.timeout_seconds,
                before_invoke=before_invoke,
                key_for=binding.key_for if _prepared_arguments is None else None,
                policy_kind="tool",
            )
        except WorkerStillRunningError as pending:
            worker = pending.task
            interruption = pending.interruption

            async def finish_worker() -> ToolResult:
                try:
                    await await_runtime_completion(worker)
                except CoordinationFailure:
                    raise
                except (Exception, asyncio.CancelledError) as exc:
                    logger.debug("Timed tool worker exited (%s)", type(exc).__name__)
                if isinstance(interruption, asyncio.CancelledError):
                    raise interruption
                return _blocked_tool_result(
                    tool_call_id=tool_call_id,
                    tool_name=tool_name,
                    code="TIMEOUT",
                    message="Tool execution timed out",
                )

            completion = asyncio.create_task(finish_worker())
            if self._track_deferred_task is not None:
                completion = self._track_deferred_task(completion)
            self._pending[execution_id] = completion
            raise RuntimeWorkDeferred(completion) from None

        if result.status == "succeeded":
            return _render_tool_result(
                result.output,
                tool_call_id=tool_call_id,
                tool_name=tool_name,
            )

        return _tool_result_from_execution(
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            result=result,
        )

    def _prepare_arguments(
        self,
        binding: ToolBinding[Any, Any],
        raw_arguments: JsonObject,
        context: Context,
    ) -> JsonObject:
        if binding.prepare_arguments is None:
            return raw_arguments
        return binding.prepare_arguments(raw_arguments, context)


def _render_tool_result(
    raw_output: Any,
    *,
    tool_call_id: str,
    tool_name: str,
) -> ToolResult:
    if isinstance(raw_output, str):
        text = raw_output
    elif isinstance(raw_output, dict) and set(raw_output) == {"text"}:
        text = str(raw_output["text"])
    else:
        text = json.dumps(raw_output, ensure_ascii=False)
    return ToolResult(
        tool_call_id=tool_call_id,
        tool_name=tool_name,
        content=[TextContent(text=text)],
        is_error=False,
    )


def _tool_result_from_execution(
    *,
    tool_call_id: str,
    tool_name: str,
    result: OperationExecutionResult,
) -> ToolResult:
    if result.status == "succeeded":
        return ToolResult(
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            content=[TextContent(text=json.dumps(result.output))],
            is_error=False,
        )

    error = result.error
    code = error.code if error is not None else result.status.upper()
    if code == "INVALID_OUTPUT":
        message = "Tool returned invalid output"
    elif code == "TIMEOUT":
        message = "Tool execution timed out"
    elif error is not None:
        message = error.message
    else:
        message = "Tool failed"
    details: dict[str, Any] = {"code": code}
    if result.attention_item_id is not None:
        details["attention_item_id"] = result.attention_item_id
    return ToolResult(
        tool_call_id=tool_call_id,
        tool_name=tool_name,
        content=[TextContent(text=message)],
        is_error=True,
        details=details,
    )


def _blocked_tool_result(
    *,
    tool_call_id: str,
    tool_name: str,
    code: str,
    message: str,
) -> ToolResult:
    return ToolResult(
        tool_call_id=tool_call_id,
        tool_name=tool_name,
        content=[TextContent(text=message)],
        is_error=True,
        details={"code": code},
    )


__all__ = ["ToolBroker"]
