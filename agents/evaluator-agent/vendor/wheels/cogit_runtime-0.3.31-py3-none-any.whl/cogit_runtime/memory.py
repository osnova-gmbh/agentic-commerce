"""Session and knowledge memory boundary for the runtime.

The memory module is deliberately a thin interface right now. Concrete
implementations will land in a later slice — one that materializes session
history from the persistent store, and one that resolves knowledge hits
through the platform ``knowledge`` client. Both hang off the same
``MemoryProvider`` contract so agent code has a stable surface.
"""

from __future__ import annotations

from typing import Protocol

from cogit_agent_sdk.types import (
    AssistantMessage,
    Context,
    KnowledgeHit,
    KnowledgeQuery,
    Message,
    ToolResultMessage,
)

SessionMessage = Message | AssistantMessage | ToolResultMessage


class MemoryProvider(Protocol):
    """Read/append boundary for session and knowledge memory.

    Runtime code should never touch a raw session table or knowledge client
    directly. Every read passes through this provider so the runtime can
    layer session compaction, knowledge fusion, and eviction later without
    touching the loop host.
    """

    def load_session_history(
        self,
        session_id: str,
        *,
        limit: int,
        context: Context,
    ) -> list[SessionMessage]:
        """Load the most recent ``limit`` messages for a session, oldest first."""
        ...

    def append_session_messages(
        self,
        session_id: str,
        messages: list[SessionMessage],
        *,
        context: Context,
    ) -> None:
        """Append messages to a session transcript."""
        ...

    def query_knowledge(
        self,
        query: KnowledgeQuery,
        context: Context,
    ) -> list[KnowledgeHit]:
        """Return knowledge hits relevant to ``query``."""
        ...


class NullMemoryProvider:
    """Default ``MemoryProvider`` that returns nothing and stores nothing."""

    def load_session_history(
        self,
        session_id: str,
        *,
        limit: int,
        context: Context,
    ) -> list[SessionMessage]:
        _ = (session_id, limit, context)
        return []

    def append_session_messages(
        self,
        session_id: str,
        messages: list[SessionMessage],
        *,
        context: Context,
    ) -> None:
        _ = (session_id, messages, context)

    def query_knowledge(
        self,
        query: KnowledgeQuery,
        context: Context,
    ) -> list[KnowledgeHit]:
        _ = (query, context)
        return []


__all__ = ["MemoryProvider", "NullMemoryProvider", "SessionMessage"]
