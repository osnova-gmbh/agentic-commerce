"""Run declared commands with frozen contracts and one owned event loop."""

from __future__ import annotations

import argparse
from collections.abc import Callable

from cogit_agent_sdk.resident import AgentServices
from cogit_agent_sdk.types import AgentDescriptor

from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.lifecycle import AgentLifecycleManager
from cogit_runtime.operations.registry import build_action_registry, build_tool_registry
from cogit_runtime.policy import RuntimePolicyGate


async def run_custom_command(
    *,
    agent: object,
    lifecycle: AgentLifecycleManager,
    descriptor: AgentDescriptor,
    handler: Callable[[AgentServices, argparse.Namespace], int | None],
    args: argparse.Namespace,
) -> int:
    """Validate before startup; keep startup, command and cleanup on one loop.

    Custom commands still receive no durable store or model client. An agent's
    startup must roll back partial acquisition; shutdown is also attempted after
    startup failure so its idempotent cleanup can release remaining resources.
    """
    if RuntimePolicyGate.from_descriptor(descriptor) is not None:
        raise RuntimeConfigurationError(
            "Policy-enabled agent work requires the standard admitted worker path"
        )
    services = lifecycle.inject_services(agent)
    lifecycle.configure(agent, services)
    actions = build_action_registry(agent, descriptor.actions)
    tools = build_tool_registry(agent, descriptor.tools)
    errors = actions.validate_parity(descriptor.actions)
    errors.extend(tools.validate_parity(descriptor.tools))
    if errors:
        raise RuntimeConfigurationError(
            "Manifest parity check failed: " + "; ".join(errors)
        )
    try:
        await lifecycle.startup(agent)
        result = handler(services, args)
        return int(result) if result is not None else 0
    finally:
        await lifecycle.shutdown(agent)
