"""Runtime-owned model dispatch guard carried on every resident RunHandle."""

from __future__ import annotations

from cogit_agent_sdk.types import Context, ModelClient, RunBudget

from cogit_runtime.bounded_handle import BoundedRunHandle
from cogit_runtime.errors import RuntimeConfigurationError
from cogit_runtime.readiness import ModelInvocationPolicy


class RuntimeRunHandle(BoundedRunHandle):
    """Expose the reviewed direct-provider boundary without changing SDK types."""

    _model_policy: ModelInvocationPolicy | None = None

    def bind_model_policy(self, policy: ModelInvocationPolicy) -> None:
        if self._model_policy is not None and self._model_policy is not policy:
            raise RuntimeConfigurationError("RunHandle model policy cannot be replaced")
        self._model_policy = policy

    def require_external_model_dispatch(
        self,
        *,
        client: ModelClient,
        provider: str,
        model: str,
        budget: RunBudget | None = None,
    ) -> None:
        """Require the exact injected client and boot-verified provider/model."""

        policy = self._model_policy
        if policy is None:
            raise RuntimeConfigurationError("RunHandle has no model dispatch policy")
        context: Context = self.context
        policy.require_external_model_dispatch(
            client=client,
            provider=provider,
            model=model,
            budget=budget,
            context=context,
        )
