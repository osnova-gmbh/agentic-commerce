"""Registered, bounded JEV evidence; classification never grants permission.

The trusted service supplies registration and immutable action bytes. Existing
JevDecisionClient instances can be injected unchanged; they kill their dedicated
credential-isolated worker on timeout/cancellation. No agent criteria are read.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from time import monotonic
from typing import Annotated, Protocol, Self
from uuid import UUID

from choices_core.backend import BackendReply
from choices_core.normalize import mapping, normalize, probability, rounding_decimals
from choices_core.schemas import DecisionRequest
from pydantic import BaseModel, ConfigDict, Field, model_validator

Identifier = Annotated[str, Field(strict=True, min_length=1, max_length=128)]
Sha256 = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]


class ClassificationUnavailable(RuntimeError):
    """No accepted evidence was produced; the protected action stays held."""


class RegisteredChoice(BaseModel):
    """Host registration, with immutable criteria and no business defaults."""

    model_config = ConfigDict(extra="forbid", frozen=True, allow_inf_nan=False)
    policy_version_id: UUID
    model_id: Identifier
    model_version: Identifier
    question: Annotated[str, Field(strict=True, min_length=1, max_length=4096)]
    criteria: tuple[tuple[Identifier, Identifier], ...] = Field(min_length=2, max_length=32)
    criteria_sha256: Sha256

    @model_validator(mode="after")
    def _committed_criteria(self) -> Self:
        if len(dict(self.criteria)) != len(self.criteria):
            raise ValueError("Registered criterion labels must be distinct")
        if self.criteria_sha256 != self.content_sha256(self.question, self.criteria):
            raise ValueError("Registered criteria commitment does not match")
        return self

    @staticmethod
    def content_sha256(question: str, criteria: tuple[tuple[str, str], ...]) -> str:
        body = json.dumps(
            {"question": question, "criteria": dict(criteria)},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(body.encode()).hexdigest()


class DecisionTransport(Protocol):
    async def predict(self, request: DecisionRequest) -> BackendReply: ...


@dataclass(frozen=True)
class RegisteredEvidence:
    action_id: UUID
    policy_version_id: UUID
    criteria_sha256: str
    model_id: str
    model_version: str
    input_sha256: str
    facts_revision: str
    labels: tuple[str, ...]
    probabilities: tuple[float, ...]
    normalized_probabilities: tuple[float, ...]
    confidence: float | None
    observed_at: datetime
    expires_at: datetime

    def request_body(self) -> dict[str, object]:
        """Only the authenticated producer sends this body to AgentDB."""
        return {
            "contractVersion": "universal-policy.v1",
            "actionId": str(self.action_id),
            "policyVersionId": str(self.policy_version_id),
            "criteriaSha256": self.criteria_sha256,
            "modelId": self.model_id,
            "modelVersion": self.model_version,
            "inputSha256": self.input_sha256,
            "factsRevision": self.facts_revision,
            "labels": list(self.labels),
            "probabilities": list(self.probabilities),
            "confidence": self.confidence,
            "observedAt": self.observed_at.isoformat(),
            "expiresAt": self.expires_at.isoformat(),
        }


class RegisteredJevEvaluator:
    def __init__(
        self,
        registration: RegisteredChoice,
        transport: DecisionTransport,
        *,
        max_calls: int,
        timeout_seconds: float,
        max_request_bytes: int,
        max_response_bytes: int,
    ) -> None:
        if (
            type(max_calls) is not int
            or type(max_request_bytes) is not int
            or type(max_response_bytes) is not int
            or type(timeout_seconds) not in (int, float)
        ) or not (
            1 <= max_calls <= 1000
            and 0 < timeout_seconds <= 120
            and 1 <= max_request_bytes <= 128_000
            and 1 <= max_response_bytes <= 256_000
        ):
            raise ValueError("Invalid classifier resource budget")
        self.registration, self.transport = registration, transport
        self.remaining, self.timeout = max_calls, timeout_seconds
        self.max_request_bytes, self.max_response_bytes = max_request_bytes, max_response_bytes

    async def evaluate(
        self,
        *,
        action_id: UUID,
        immutable_input: bytes,
        input_sha256: str,
        facts_revision: str,
        lifetime_seconds: int,
    ) -> RegisteredEvidence:
        deadline = monotonic() + self.timeout
        if type(lifetime_seconds) is not int or not (1 <= lifetime_seconds <= 31_536_000):
            raise ValueError("Evidence lifetime must be explicitly configured")
        if (
            len(immutable_input) > self.max_request_bytes
            or hashlib.sha256(immutable_input).hexdigest() != input_sha256
            or len(facts_revision) != 64
            or any(c not in "0123456789abcdef" for c in facts_revision)
        ):
            raise ClassificationUnavailable("Immutable classifier evidence does not match")
        if self.remaining <= 0:
            raise ClassificationUnavailable("Classifier call budget is exhausted")
        self.remaining -= 1
        try:
            request = self._request(immutable_input)
            self._require_deadline(deadline)
            async with asyncio.timeout(deadline - monotonic()):
                reply = await self.transport.predict(request)
            self._require_deadline(deadline)
            evidence = self._evidence(
                request, reply, action_id, input_sha256, facts_revision, lifetime_seconds
            )
            self._require_deadline(deadline)
            return evidence
        except asyncio.CancelledError:
            raise
        except Exception:
            raise ClassificationUnavailable(
                "Registered classifier produced no valid evidence"
            ) from None

    @staticmethod
    def _require_deadline(deadline: float) -> None:
        if monotonic() >= deadline:
            raise ClassificationUnavailable("Registered classifier exceeded its total deadline")

    def _request(self, immutable_input: bytes) -> DecisionRequest:
        registered = self.registration
        request = DecisionRequest.model_validate(
            {
                "state": json.loads(immutable_input),
                "questions": {
                    "policy": {
                        "type": "choice",
                        "instructions": registered.question,
                        "criteria": dict(registered.criteria),
                    }
                },
            }
        )
        if len(request.model_dump_json().encode()) > self.max_request_bytes:
            raise ClassificationUnavailable("Registered classifier request exceeds its limit")
        return request

    def _evidence(
        self,
        request: DecisionRequest,
        reply: BackendReply,
        action_id: UUID,
        input_sha256: str,
        facts_revision: str,
        lifetime_seconds: int,
    ) -> RegisteredEvidence:
        registration = self.registration
        if (
            reply.raw_response.get("model") != registration.model_id
            or reply.metadata.get("model_revision") != registration.model_version
        ):
            raise ValueError("Registered model identity does not match")
        if len(json.dumps(reply.raw_response, allow_nan=False).encode()) > self.max_response_bytes:
            raise ValueError("Classifier reply exceeds its limit")
        predictions = normalize(
            request,
            reply.raw_response,
            "jev_native",
            probability_decimals=rounding_decimals(reply.metadata),
        )
        native = mapping(mapping(mapping(reply.raw_response["answers"])["policy"])["probabilities"])
        predicted = mapping(predictions["policy"])
        normalized = mapping(predicted["probabilities"])
        labels = tuple(dict(registration.criteria))
        observed = datetime.now(UTC)
        confidence = predicted["native_confidence"]
        return RegisteredEvidence(
            action_id,
            registration.policy_version_id,
            registration.criteria_sha256,
            registration.model_id,
            registration.model_version,
            input_sha256,
            facts_revision,
            labels,
            tuple(probability(native[label]) for label in labels),
            tuple(probability(normalized[label]) for label in labels),
            float(confidence) if isinstance(confidence, int | float) else None,
            observed,
            observed + timedelta(seconds=lifetime_seconds),
        )
