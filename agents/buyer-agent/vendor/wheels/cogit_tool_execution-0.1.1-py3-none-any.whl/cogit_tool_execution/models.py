"""Strict public process session schemas."""

from __future__ import annotations

from typing import Literal

from cogit_tool_core import Model
from pydantic import Field, field_validator


class StartRequest(Model):
    argv: list[str] = Field(min_length=1, max_length=128)
    cwd: str = "."
    wait_ms: int = Field(default=1000, ge=0, le=10000)
    max_runtime_seconds: float = Field(default=600.0, ge=0.1, le=3600.0)

    @field_validator("argv")
    @classmethod
    def valid_argv(cls, value: list[str]) -> list[str]:
        if any("\x00" in item for item in value) or not value[0]:
            raise ValueError("argv requires an executable and no NUL characters")
        if sum(len(item) for item in value) > 65536:
            raise ValueError("argv exceeds 65536 characters")
        return value


class PollRequest(Model):
    process_id: str
    cursor: int = Field(default=0, ge=0)
    wait_ms: int = Field(default=0, ge=0, le=10000)
    max_chars: int = Field(default=16000, ge=1, le=65536)


class InputRequest(PollRequest):
    text: str = Field(default="", max_length=262144)
    eof: bool = False


class StopRequest(Model):
    process_id: str


class ListRequest(Model):
    pass


class ProcessOutput(Model):
    process_id: str
    pid: int
    status: Literal["running", "exited"]
    exit_code: int | None
    output: str
    cursor: int
    dropped_before: int
    truncated: bool
    log_path: str
    termination_reason: str | None = None


class ProcessInfo(Model):
    process_id: str
    pid: int
    argv: list[str]
    status: Literal["running", "exited"]
    exit_code: int | None
    log_path: str


class ProcessList(Model):
    processes: list[ProcessInfo]
