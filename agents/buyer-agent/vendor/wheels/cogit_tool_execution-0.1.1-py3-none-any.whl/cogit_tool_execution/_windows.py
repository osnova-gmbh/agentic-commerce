"""Checked Win32 handles and resumption of an owned suspended process."""

from __future__ import annotations

import ctypes
from ctypes import wintypes


class _ThreadEntry(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ThreadID", wintypes.DWORD),
        ("th32OwnerProcessID", wintypes.DWORD),
        ("tpBasePri", wintypes.LONG),
        ("tpDeltaPri", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
    ]


def close_handle(handle: int) -> None:
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    if not kernel.CloseHandle(ctypes.c_void_p(handle)):
        raise OSError(ctypes.get_last_error(), "CloseHandle failed")


def _resume_thread(thread_id: int) -> None:
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenThread.restype = wintypes.HANDLE
    kernel.ResumeThread.restype = wintypes.DWORD
    handle = kernel.OpenThread(0x0002, False, thread_id)  # THREAD_SUSPEND_RESUME
    if not handle:
        raise OSError(ctypes.get_last_error(), "OpenThread failed")
    try:
        if kernel.ResumeThread(ctypes.c_void_p(handle)) == 0xFFFFFFFF:
            raise OSError(ctypes.get_last_error(), "ResumeThread failed")
    finally:
        close_handle(int(handle))


def resume_process(pid: int) -> None:
    """Resume only the primary thread of our CREATE_SUSPENDED child after job assignment."""
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    snapshot = kernel.CreateToolhelp32Snapshot(0x00000004, 0)  # TH32CS_SNAPTHREAD
    if snapshot is None or snapshot == ctypes.c_void_p(-1).value:
        raise OSError(ctypes.get_last_error(), "Thread snapshot failed")
    entry = _ThreadEntry()
    entry.dwSize = ctypes.sizeof(entry)
    try:
        found = kernel.Thread32First(ctypes.c_void_p(snapshot), ctypes.byref(entry))
        while found:
            if entry.th32OwnerProcessID == pid:
                _resume_thread(entry.th32ThreadID)
                return
            found = kernel.Thread32Next(ctypes.c_void_p(snapshot), ctypes.byref(entry))
        raise OSError("Suspended process primary thread was not found")
    finally:
        close_handle(int(snapshot))
