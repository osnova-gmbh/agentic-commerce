"""Synchronous lifecycle ownership independent of SDK event-loop lifetimes."""

from __future__ import annotations

import os
import subprocess
import threading
import uuid
from collections.abc import Mapping
from pathlib import Path
from typing import BinaryIO

from cogit_tool_core import Tool, ToolError, ToolLike, Workspace

from ._session import Session
from ._tree import ProcessTree
from .models import (
    InputRequest,
    ListRequest,
    PollRequest,
    ProcessList,
    ProcessOutput,
    StartRequest,
    StopRequest,
)

_ENV_KEYS = {
    "PATH",
    "SYSTEMROOT",
    "SYSTEMDRIVE",
    "PROGRAMDATA",
    "ALLUSERSPROFILE",
    "LOCALAPPDATA",
    "APPDATA",
    "WINDIR",
    "COMSPEC",
    "PATHEXT",
    "TEMP",
    "TMP",
    "TMPDIR",
    "USERPROFILE",
    "HOME",
    "HOMEDRIVE",
    "HOMEPATH",
    "LANG",
    "LC_ALL",
    "TERM",
}


class ProcessService:
    def __init__(
        self,
        workspace: Path,
        *,
        environment: Mapping[str, str] | None = None,
        max_processes: int = 8,
        max_sessions: int = 64,
        buffer_chars: int = 65536,
        max_log_bytes: int = 67108864,
    ) -> None:
        if min(max_processes, max_sessions, buffer_chars, max_log_bytes) < 1:
            raise ValueError("Resource limits must be positive")
        self.workspace = Workspace(workspace)
        self.environment = {k: v for k, v in os.environ.items() if k.upper() in _ENV_KEYS}
        self.environment.update({"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"})
        self.environment.update(environment or {})
        self.max_processes, self.max_sessions = max_processes, max_sessions
        self.buffer_chars, self.max_log_bytes = buffer_chars, max_log_bytes
        self._sessions: dict[str, Session] = {}
        self._lock = threading.RLock()
        self._closed = False

    def start(self, request: StartRequest) -> ProcessOutput:
        with self._lock:
            self._ensure_open()
            self._reserve_capacity()
            cwd = self.workspace.resolve(request.cwd)
            if not cwd.is_dir():
                raise ToolError("invalid_cwd", "Working directory must exist inside workspace")
            process_id = uuid.uuid4().hex
            log_path = self.workspace.resolve(f".process-logs/{process_id}.log")
            log = self._open_log(log_path)
            try:
                process = subprocess.Popen(
                    request.argv,
                    cwd=cwd,
                    env=self.environment,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    creationflags=(subprocess.CREATE_NEW_PROCESS_GROUP | 0x00000004)
                    if os.name == "nt"
                    else 0,
                    start_new_session=os.name != "nt",
                )
            except (OSError, ValueError) as exc:
                log.close()
                raise ToolError("process_start_failed", f"Cannot start process: {exc}") from None
            tree: ProcessTree | None = None
            try:
                tree = ProcessTree(process)
                tree.resume()
                session = Session(
                    process_id,
                    process,
                    tree,
                    request.argv,
                    log,
                    log_path,
                    self.buffer_chars,
                    self.max_log_bytes,
                    request.max_runtime_seconds,
                )
            except (OSError, RuntimeError) as exc:
                failures = self._abort_start(process, tree, log)
                detail = f"; cleanup failed: {failures}" if failures else ""
                raise ToolError(
                    "process_setup_failed", f"Cannot own process: {exc}{detail}"
                ) from None
            self._sessions[process_id] = session
        return session.poll(PollRequest(process_id=process_id, wait_ms=request.wait_ms))

    @staticmethod
    def _open_log(path: Path) -> BinaryIO:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            return path.open("xb")
        except OSError as exc:
            raise ToolError("log_failed", f"Cannot create process log: {exc}") from None

    @staticmethod
    def _abort_start(
        process: subprocess.Popen[bytes], tree: ProcessTree | None, log: BinaryIO
    ) -> str:
        failures: list[str] = []
        if tree is not None:
            try:
                tree.close()
            except OSError as exc:
                failures.append(str(exc))
        try:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=5)
        except (OSError, subprocess.TimeoutExpired) as exc:
            failures.append(str(exc))
        for stream in (process.stdin, process.stdout, log):
            if stream is not None:
                try:
                    stream.close()
                except (OSError, ValueError) as exc:
                    failures.append(str(exc))
        return "; ".join(failures)

    def poll(self, request: PollRequest) -> ProcessOutput:
        return self._get(request.process_id).poll(request)

    def input(self, request: InputRequest) -> ProcessOutput:
        session = self._get(request.process_id)
        session.send(request.text, request.eof)
        return session.poll(request)

    def stop(self, request: StopRequest) -> ProcessOutput:
        session = self._get(request.process_id)
        session.stop()
        session.close()
        return session.poll(PollRequest(process_id=request.process_id))

    def list(self, request: ListRequest) -> ProcessList:
        del request
        with self._lock:
            self._ensure_open()
            return ProcessList(processes=[session.info() for session in self._sessions.values()])

    def _get(self, process_id: str) -> Session:
        with self._lock:
            self._ensure_open()
            if process_id not in self._sessions:
                raise ToolError("unknown_process", "No owned process has that identifier")
            return self._sessions[process_id]

    def _ensure_open(self) -> None:
        if self._closed:
            raise ToolError("service_closed", "Process service is closed")

    def _reserve_capacity(self) -> None:
        running = [
            session for session in self._sessions.values() if session.info().status == "running"
        ]
        if len(running) >= self.max_processes:
            raise ToolError("process_limit", "Stop an owned process before starting another")
        if len(self._sessions) >= self.max_sessions:
            completed = next(
                (key for key, value in self._sessions.items() if value.info().status == "exited"),
                None,
            )
            if completed is None:
                raise ToolError("session_limit", "No completed session available to evict")
            self._sessions.pop(completed).close()

    def tools(self) -> tuple[ToolLike, ...]:
        return (
            Tool(
                "process_start",
                "Start argv directly; returns output and a persistent process ID. "
                "Use -u for interactive Python. Execution uses OS permissions, not a sandbox.",
                StartRequest,
                ProcessOutput,
                self.start,
            ),
            Tool(
                "process_poll",
                "Read incremental output with cursor; optionally wait up to 10s.",
                PollRequest,
                ProcessOutput,
                self.poll,
            ),
            Tool(
                "process_input",
                "Write text or EOF to owned process stdin, then read output.",
                InputRequest,
                ProcessOutput,
                self.input,
            ),
            Tool(
                "process_stop",
                "Stop the owned process tree and release its pipes.",
                StopRequest,
                ProcessOutput,
                self.stop,
            ),
            Tool(
                "process_list",
                "List retained owned sessions and their exit status.",
                ListRequest,
                ProcessList,
                self.list,
            ),
        )

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            failures: list[str] = []
            for process_id, session in self._sessions.items():
                try:
                    session.close()
                except (OSError, ToolError, subprocess.TimeoutExpired) as exc:
                    failures.append(f"{process_id}: {exc}")
            if failures:
                raise ToolError("cleanup_failed", "; ".join(failures))
            self._closed = True
