"""One owned process service with trusted session/execution handle isolation."""

import asyncio
from collections.abc import Callable, Mapping
from threading import RLock

from cogit_agent_sdk.operations import OperationInvocation
from cogit_agent_sdk.types import Context
from cogit_tool_core import Model, ToolError
from cogit_tool_core.deferred import DeferredService
from cogit_tool_core.providers import HostContext, PreparedTools, ToolProvider, invocation_scope
from cogit_tool_core.sdk import ToolMetadata, bind_scoped_tool
from pydantic import Field

from .models import (
    InputRequest,
    ListRequest,
    PollRequest,
    ProcessList,
    ProcessOutput,
    StartRequest,
    StopRequest,
)
from .service import ProcessService


class ExecutionSettings(Model):
    max_processes: int = Field(default=8, ge=1, le=256)
    max_sessions: int = Field(default=64, ge=1, le=4096)
    buffer_chars: int = Field(default=65536, ge=1, le=1048576)
    max_log_bytes: int = Field(default=67108864, ge=1, le=268435456)


class ExecutionResources(DeferredService[ProcessService]):
    """Shell and process bindings share this owner and its scope index."""

    def __init__(self, settings: ExecutionSettings, host: HostContext) -> None:
        super().__init__(
            lambda: ProcessService(
                host.workspace,
                environment=host.environment,
                max_processes=settings.max_processes,
                max_sessions=settings.max_sessions,
                buffer_chars=settings.buffer_chars,
                max_log_bytes=settings.max_log_bytes,
            ),
            host,
        )
        self._owners: dict[str, str] = {}
        self._scope_lock = RLock()

    async def release_scope(self, context: Context) -> None:
        """Retire ended execution-owned work; explicit session owners survive."""
        if context.tenant_id != self.host.tenant_id or (
            context.agent_id is not None and context.agent_id != self.host.agent_id
        ):
            raise ToolError("scope_mismatch", "Invocation does not own this provider scope")
        if context.session_id or not context.execution_id:
            return
        await asyncio.to_thread(self._release_execution, "execution:" + context.execution_id)

    def _release_execution(self, key: str) -> None:
        with self._scope_lock:
            identities = [identity for identity, owner in self._owners.items() if owner == key]
            if not identities:
                return  # Never acquire a service just to release an unused scope.
            failures: list[Exception] = []
            service = self.ready()
            for identity in identities:
                try:
                    result = service.stop(StopRequest(process_id=identity))
                    if result.status != "exited":
                        raise ToolError("cleanup_failed", "Process retirement is unconfirmed")
                except Exception as exc:
                    failures.append(exc)  # Retain ownership for a later cleanup retry.
                else:
                    del self._owners[identity]
            if failures:
                raise ExceptionGroup("Execution process cleanup failed", failures)

    def _key(self, invocation: OperationInvocation) -> str:
        scope = invocation_scope(invocation, self.host)
        assert scope.session_key is not None
        self.ready()
        return scope.session_key

    def record_creation(
        self, invocation: OperationInvocation, create: Callable[[], ProcessOutput]
    ) -> ProcessOutput:
        with self._scope_lock:
            key = self._key(invocation)
            result = create()
            retained = {item.process_id for item in self.ready().list(ListRequest()).processes}
            self._owners = {
                identity: owner for identity, owner in self._owners.items() if identity in retained
            }
            self._owners[result.process_id] = key
            return result

    def start_process(
        self, request: StartRequest, invocation: OperationInvocation
    ) -> ProcessOutput:
        return self.record_creation(invocation, lambda: self.ready().start(request))

    def _owned(self, identity: str, invocation: OperationInvocation) -> ProcessService:
        key = self._key(invocation)
        if self._owners.get(identity) != key:
            raise ToolError(
                "unknown_process", "No process in this invocation scope has that identifier"
            )
        return self.ready()

    def poll(self, request: PollRequest, invocation: OperationInvocation) -> ProcessOutput:
        with self._scope_lock:
            return self._owned(request.process_id, invocation).poll(request)

    def input(self, request: InputRequest, invocation: OperationInvocation) -> ProcessOutput:
        with self._scope_lock:
            return self._owned(request.process_id, invocation).input(request)

    def stop(self, request: StopRequest, invocation: OperationInvocation) -> ProcessOutput:
        with self._scope_lock:
            return self._owned(request.process_id, invocation).stop(request)

    def list(self, request: ListRequest, invocation: OperationInvocation) -> ProcessList:
        with self._scope_lock:
            key = self._key(invocation)
            return ProcessList(
                processes=[
                    item
                    for item in self.ready().list(request).processes
                    if self._owners.get(item.process_id) == key
                ]
            )


def prepare(
    settings: ExecutionSettings, host: HostContext, dependencies: Mapping[str, PreparedTools]
) -> PreparedTools:
    del dependencies
    owner = ExecutionResources(settings, host)
    read = ToolMetadata(risk="read", idempotency="inherent")
    write = ToolMetadata(risk="destructive", idempotency="none")
    bindings = (
        bind_scoped_tool(
            "process_start",
            "Start argv under OS authority, not a sandbox; returns a persistent scoped process ID.",
            StartRequest,
            ProcessOutput,
            owner.start_process,
            metadata=write,
            record=host.record,
        ),
        bind_scoped_tool(
            "process_poll",
            "Read incremental output from an owned process with a cursor and bounded wait.",
            PollRequest,
            ProcessOutput,
            owner.poll,
            metadata=read,
            record=host.record,
        ),
        bind_scoped_tool(
            "process_input",
            "Write stdin or EOF to an owned process and read output.",
            InputRequest,
            ProcessOutput,
            owner.input,
            metadata=write,
            record=host.record,
        ),
        bind_scoped_tool(
            "process_stop",
            "Stop the owned process tree and release pipes.",
            StopRequest,
            ProcessOutput,
            owner.stop,
            metadata=write,
            record=host.record,
        ),
        bind_scoped_tool(
            "process_list",
            "List only processes owned by this trusted session/execution.",
            ListRequest,
            ProcessList,
            owner.list,
            metadata=read,
            record=host.record,
        ),
    )
    return PreparedTools(
        bindings=bindings,
        prompt_fragments=(
            "Check exit codes, poll running processes and stop owned work when finished. "
            "Interactive state lasts for this owned process only. Authorized coding tasks "
            "may install dependencies, clone, edit and test through available execution tools.",
        ),
        start=owner.start,
        close=owner.close,
        resource=owner,
        release_scope=owner.release_scope,
    )


provider = ToolProvider(ExecutionSettings, prepare)
