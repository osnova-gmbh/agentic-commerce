"""OS process-tree ownership. Windows jobs also retain exited parents' children."""

from __future__ import annotations

import ctypes
import os
import signal
import threading
from contextlib import suppress
from ctypes import wintypes
from subprocess import Popen

from ._windows import close_handle, resume_process


class _BasicLimits(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_longlong),
        ("PerJobUserTimeLimit", ctypes.c_longlong),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class _IoCounters(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_ulonglong)
        for name in (
            "ReadOperationCount",
            "WriteOperationCount",
            "OtherOperationCount",
            "ReadTransferCount",
            "WriteTransferCount",
            "OtherTransferCount",
        )
    ]


class _ExtendedLimits(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", _BasicLimits),
        ("IoInfo", _IoCounters),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


class ProcessTree:
    def __init__(self, process: Popen[bytes]) -> None:
        self.process = process
        self._job: int | None = None
        self._lock = threading.Lock()
        if os.name == "nt":
            self._assign_windows_job()

    def _assign_windows_job(self) -> None:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateJobObjectW.restype = wintypes.HANDLE
        kernel.OpenProcess.restype = wintypes.HANDLE
        job = kernel.CreateJobObjectW(None, None)
        if not job:
            raise OSError(ctypes.get_last_error(), "CreateJobObjectW failed")
        limits = _ExtendedLimits()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE
        process_handle = kernel.OpenProcess(0x0100 | 0x0001, False, self.process.pid)
        try:
            configured = kernel.SetInformationJobObject(
                ctypes.c_void_p(job), 9, ctypes.byref(limits), ctypes.sizeof(limits)
            )
            assigned = (
                configured
                and process_handle
                and kernel.AssignProcessToJobObject(
                    ctypes.c_void_p(job), ctypes.c_void_p(process_handle)
                )
            )
            if not assigned:
                raise OSError(ctypes.get_last_error(), "Cannot own process tree")
            self._job = int(job)
        finally:
            try:
                if process_handle:
                    close_handle(int(process_handle))
            except OSError:
                close_handle(int(job))
                self._job = None
                raise
            if self._job is None:
                close_handle(int(job))

    def resume(self) -> None:
        if os.name == "nt":
            resume_process(self.process.pid)

    def close(self) -> None:
        with self._lock:
            self._close()

    def _close(self) -> None:
        if os.name == "nt":
            if self._job is not None:
                close_handle(self._job)
                self._job = None
        else:
            with suppress(ProcessLookupError):
                os.killpg(self.process.pid, signal.SIGKILL)
