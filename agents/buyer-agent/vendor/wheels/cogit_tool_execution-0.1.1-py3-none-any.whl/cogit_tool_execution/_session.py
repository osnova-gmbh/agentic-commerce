"""One owned process, a bounded output tail, and a complete bounded-size log."""

from __future__ import annotations

import codecs
import os
import subprocess
import threading
import time
from pathlib import Path
from typing import BinaryIO

from cogit_tool_core import ToolError

from ._tree import ProcessTree
from .models import PollRequest, ProcessInfo, ProcessOutput


class Session:
    def __init__(
        self,
        process_id: str,
        process: subprocess.Popen[bytes],
        tree: ProcessTree,
        argv: list[str],
        log: BinaryIO,
        log_path: Path,
        buffer_chars: int,
        log_limit: int,
        runtime_seconds: float,
    ) -> None:
        self.process_id, self.process, self.tree = process_id, process, tree
        self.argv, self.log, self.log_path = argv, log, log_path
        self.buffer_chars, self.log_limit = buffer_chars, log_limit
        self.condition = threading.Condition()
        self.input_lock = threading.Lock()
        self._tail, self._offset, self._log_bytes = "", 0, 0
        self._reason: str | None = None
        self._finished = False
        self._tree_error: str | None = None
        self._timer = threading.Timer(runtime_seconds, self.stop, args=("timeout",))
        self._timer.daemon = True
        self._reader = threading.Thread(
            target=self._read, name=f"cogit-output-{process_id}", daemon=True
        )
        self._watcher = threading.Thread(
            target=self._watch_exit, name=f"cogit-exit-{process_id}", daemon=True
        )
        try:
            self._reader.start()
            self._watcher.start()
            self._timer.start()
        except RuntimeError:
            self.close()
            raise

    def _watch_exit(self) -> None:
        try:
            self.process.wait()
        finally:
            self._close_tree()

    def _close_tree(self) -> None:
        with self.condition:
            try:
                self.tree.close()
                self._tree_error = None
            except OSError as exc:
                self._tree_error = str(exc)

    def _read(self) -> None:
        decoder = codecs.getincrementaldecoder("utf-8")("replace")
        try:
            pipe = self.process.stdout
            assert pipe is not None
            while chunk := os.read(pipe.fileno(), 4096):
                available = self.log_limit - self._log_bytes
                saved = chunk[:available]
                self.log.write(saved)
                self.log.flush()
                self._log_bytes += len(saved)
                self._append(decoder.decode(saved))
                if len(saved) < len(chunk):
                    self.stop("output_limit")
                    break
            self._append(decoder.decode(b"", final=True))
            self.process.wait()
        except (OSError, ValueError):
            self.stop("io_error")
        finally:
            self._timer.cancel()
            self._close_tree()
            self.log.close()
            if self.process.stdout is not None:
                self.process.stdout.close()
            with self.condition:
                self._finished = True
                self.condition.notify_all()

    def _append(self, text: str) -> None:
        with self.condition:
            self._tail += text
            removed = max(0, len(self._tail) - self.buffer_chars)
            self._tail = self._tail[removed:]
            self._offset += removed
            self.condition.notify_all()

    def poll(self, request: PollRequest) -> ProcessOutput:
        deadline = time.monotonic() + request.wait_ms / 1000
        with self.condition:
            while not self._finished and request.cursor >= self._offset + len(self._tail):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                self.condition.wait(remaining)
            start = max(request.cursor, self._offset)
            end = self._offset + len(self._tail)
            if request.cursor > end:
                raise ToolError("invalid_cursor", f"Cursor exceeds available output end {end}")
            output = self._tail[start - self._offset : start - self._offset + request.max_chars]
            return ProcessOutput(
                process_id=self.process_id,
                pid=self.process.pid,
                status="exited" if self._finished else "running",
                exit_code=self.process.poll() if self._finished else None,
                output=output,
                cursor=start + len(output),
                dropped_before=self._offset,
                truncated=request.cursor < self._offset or start + len(output) < end,
                log_path=str(self.log_path),
                termination_reason=self._reason,
            )

    def send(self, text: str, eof: bool) -> None:
        if not self.input_lock.acquire(blocking=False):
            raise ToolError("stdin_busy", "An earlier stdin write is still pending")
        completed = threading.Event()
        failure: list[str] = []

        def write() -> None:
            try:
                pipe = self.process.stdin
                if self.process.poll() is not None or pipe is None:
                    failure.append("Process no longer accepts input")
                    return
                pipe.write(text.encode("utf-8"))
                pipe.flush()
                if eof:
                    pipe.close()
            except (OSError, ValueError):
                failure.append("Process stdin is closed")
            finally:
                self.input_lock.release()
                completed.set()

        threading.Thread(target=write, daemon=True).start()
        if not completed.wait(5):
            raise ToolError("stdin_timeout", "Process did not consume stdin; poll or stop it")
        if failure:
            raise ToolError("stdin_closed", failure[0])

    def stop(self, reason: str = "stopped") -> None:
        with self.condition:
            if self._finished:
                return
            self._reason = self._reason or reason
            self._close_tree()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=5)
        if self.process.stdin is not None:
            with self.input_lock:
                self.process.stdin.close()

    def close(self) -> None:
        self.stop("service_closed")
        self._timer.cancel()
        self._close_tree()
        for thread in (self._reader, self._watcher):
            if thread.ident is not None:
                thread.join(timeout=5)
            if thread.is_alive():
                raise ToolError("cleanup_failed", "Process reader/watcher did not terminate")
        if self.process.stdout is not None:
            self.process.stdout.close()
        self.log.close()
        if self.process.stdin is not None and not self.process.stdin.closed:
            self.process.stdin.close()
        if self._tree_error is not None:
            raise ToolError("cleanup_failed", self._tree_error)

    def info(self) -> ProcessInfo:
        return ProcessInfo(
            process_id=self.process_id,
            pid=self.process.pid,
            argv=self.argv,
            status="exited" if self._finished else "running",
            exit_code=self.process.poll(),
            log_path=str(self.log_path),
        )
