"""Windows job ownership survives worker crashes without enumerating other browsers."""

from __future__ import annotations

import ctypes
from ctypes import wintypes


class _BasicLimits(ctypes.Structure):
    _fields_ = [
        ("process_time", ctypes.c_int64),
        ("job_time", ctypes.c_int64),
        ("flags", wintypes.DWORD),
        ("minimum", ctypes.c_size_t),
        ("maximum", ctypes.c_size_t),
        ("active_limit", wintypes.DWORD),
        ("affinity", ctypes.c_size_t),
        ("priority", wintypes.DWORD),
        ("scheduling", wintypes.DWORD),
    ]


class _IoCounters(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_uint64)
        for name in (
            "read_ops",
            "write_ops",
            "other_ops",
            "read_bytes",
            "write_bytes",
            "other_bytes",
        )
    ]


class _ExtendedLimits(ctypes.Structure):
    _fields_ = [
        ("basic", _BasicLimits),
        ("io", _IoCounters),
        ("process_memory", ctypes.c_size_t),
        ("job_memory", ctypes.c_size_t),
        ("peak_process_memory", ctypes.c_size_t),
        ("peak_job_memory", ctypes.c_size_t),
    ]


class _Accounting(ctypes.Structure):
    _fields_ = [
        ("user_time", ctypes.c_int64),
        ("kernel_time", ctypes.c_int64),
        ("period_user", ctypes.c_int64),
        ("period_kernel", ctypes.c_int64),
        ("faults", wintypes.DWORD),
        ("total", wintypes.DWORD),
        ("active", wintypes.DWORD),
        ("terminated", wintypes.DWORD),
    ]


class _ProcessIds(ctypes.Structure):
    # Bound only enumeration memory. Exceeding this fails retirement closed.
    _fields_ = [
        ("assigned", wintypes.DWORD),
        ("count", wintypes.DWORD),
        ("ids", ctypes.c_size_t * 4096),
    ]


class WindowsJob:
    def __init__(self) -> None:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        self._kernel = kernel
        self._process_handles: dict[int, int] = {}
        kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        kernel.CreateJobObjectW.restype = wintypes.HANDLE
        kernel.SetInformationJobObject.argtypes = [
            wintypes.HANDLE,
            ctypes.c_int,
            ctypes.c_void_p,
            wintypes.DWORD,
        ]
        kernel.SetInformationJobObject.restype = wintypes.BOOL
        kernel.QueryInformationJobObject.argtypes = [
            wintypes.HANDLE,
            ctypes.c_int,
            ctypes.c_void_p,
            wintypes.DWORD,
            ctypes.c_void_p,
        ]
        kernel.QueryInformationJobObject.restype = wintypes.BOOL
        kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        kernel.AssignProcessToJobObject.restype = wintypes.BOOL
        kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        kernel.TerminateJobObject.restype = wintypes.BOOL
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        self._handle = kernel.CreateJobObjectW(None, None)
        if not self._handle:
            raise ctypes.WinError(ctypes.get_last_error())
        limits = _ExtendedLimits()
        limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not kernel.SetInformationJobObject(
            self._handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)
        ):
            self.close()
            raise ctypes.WinError(ctypes.get_last_error())

    def attach(self, pid: int) -> None:
        process = self._kernel.OpenProcess(0x0100 | 0x0001 | 0x100000, False, pid)
        if not process:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            if not self._kernel.AssignProcessToJobObject(self._handle, process):
                raise ctypes.WinError(ctypes.get_last_error())
        except BaseException:
            self._kernel.CloseHandle(process)
            raise
        self._process_handles[pid] = process

    def _retain_members(self) -> None:
        members = _ProcessIds()
        if not self._kernel.QueryInformationJobObject(
            self._handle, 3, ctypes.byref(members), ctypes.sizeof(members), None
        ):
            raise ctypes.WinError(ctypes.get_last_error())
        for index in range(members.count):
            pid = members.ids[index]
            if pid in self._process_handles:
                continue
            handle = self._kernel.OpenProcess(0x100000, False, pid)
            if not handle:
                error = ctypes.get_last_error()
                if error == 87:  # Process already ceased to exist, including its kernel object.
                    continue
                raise ctypes.WinError(error)
            self._process_handles[pid] = handle

    def terminate(self) -> None:
        # Job accounting can report zero before process handles are signaled.
        # Retain the actual owned objects before killing; never inspect unrelated PIDs.
        failure: OSError | None = None
        try:
            self._retain_members()
        except OSError as exc:
            failure = exc
        if not self._kernel.TerminateJobObject(self._handle, 1):
            raise ctypes.WinError(ctypes.get_last_error())
        if failure is not None:
            raise failure

    def retain_members(self) -> None:
        """Keep exact owned objects before their supervisor closes the driver pipe."""
        self._retain_members()

    def empty(self) -> bool:
        counts = _Accounting()
        if not self._kernel.QueryInformationJobObject(
            self._handle, 1, ctypes.byref(counts), ctypes.sizeof(counts), None
        ):
            raise ctypes.WinError(ctypes.get_last_error())
        if counts.active:
            return False
        for handle in self._process_handles.values():
            state = self._kernel.WaitForSingleObject(handle, 0)
            if state == 0xFFFFFFFF:
                raise ctypes.WinError(ctypes.get_last_error())
            if state != 0:
                return False
        return True

    def close(self) -> None:
        if self._handle:
            self._kernel.CloseHandle(self._handle)
            self._handle = None
        for handle in self._process_handles.values():
            self._kernel.CloseHandle(handle)
        self._process_handles.clear()
