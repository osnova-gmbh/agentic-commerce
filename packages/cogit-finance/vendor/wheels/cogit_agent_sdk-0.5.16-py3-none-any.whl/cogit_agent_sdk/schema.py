"""JSON Schema export for all cogit-agent-sdk types.

Note: Protocol types and TypeAlias literals are intentionally excluded since
they cannot produce JSON schemas. Only concrete Pydantic BaseModel subclasses
are included.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from cogit_agent_sdk.functions import (
    DescribeFunctionInput,
    DescribeFunctionOutput,
    FunctionDispatchError,
    RunFunctionInput,
    RunFunctionOutput,
)
from cogit_agent_sdk.types import (
    ActionDescriptor,
    ActionIntent,
    ActionKey,
    ActionRef,
    AgentDescriptor,
    AgentLoopConfig,
    AgentLoopResult,
    AgentLoopState,
    AgentRecord,
    ArtifactRef,
    AssistantMessage,
    AttentionItem,
    CapabilityGrant,
    CapabilityRequirement,
    Case,
    CheckResult,
    Context,
    DatabaseExportRequirement,
    DatabasePackageRequirement,
    Decision,
    DecisionOption,
    Diagnostic,
    ErrorInfo,
    EstimatedCost,
    EvalItemResult,
    EvalRecord,
    ExecutionRecord,
    ExecutionStepRecord,
    ExperimentRecord,
    FileRefContent,
    FrozenPromptStrings,
    Handoff,
    ImageContent,
    KnowledgeHit,
    KnowledgeQuery,
    KnowledgeResult,
    LearningRecord,
    LearningSource,
    Message,
    ModelCost,
    ModelDefaults,
    ModelDescriptor,
    ModelProviderInfo,
    ModelRequest,
    ModelResponse,
    ModelResponseFormat,
    ModelStreamEvent,
    PipelineDescriptor,
    PipelineStep,
    Principal,
    QueryRequest,
    QueryResult,
    QueueItem,
    RunBudget,
    RunEvent,
    RunRequest,
    RunResult,
    ScheduleDescriptor,
    Session,
    StructuredContent,
    TextContent,
    ThinkingContent,
    ToolCall,
    ToolDescriptor,
    ToolResult,
    ToolResultMessage,
    ToolsetDescriptor,
    UniversalPolicyDecision,
    UniversalPolicyRequest,
    Usage,
    WorkOutcome,
)

ALL_TYPES: list[type[BaseModel]] = [
    UniversalPolicyDecision,
    UniversalPolicyRequest,
    ActionIntent,
    ActionKey,
    ActionRef,
    WorkOutcome,
    Principal,
    CapabilityGrant,
    CapabilityRequirement,
    Context,
    DatabaseExportRequirement,
    DatabasePackageRequirement,
    TextContent,
    ImageContent,
    ThinkingContent,
    FileRefContent,
    StructuredContent,
    ToolCall,
    Diagnostic,
    Message,
    AssistantMessage,
    ToolResultMessage,
    EstimatedCost,
    Usage,
    RunBudget,
    ErrorInfo,
    ToolDescriptor,
    ToolResult,
    ToolsetDescriptor,
    ArtifactRef,
    ModelCost,
    ModelDefaults,
    ModelDescriptor,
    ModelProviderInfo,
    ModelRequest,
    ModelResponse,
    ModelResponseFormat,
    ModelStreamEvent,
    ExecutionRecord,
    ExecutionStepRecord,
    CheckResult,
    EvalItemResult,
    EvalRecord,
    LearningSource,
    LearningRecord,
    ExperimentRecord,
    FunctionDispatchError,
    DescribeFunctionInput,
    DescribeFunctionOutput,
    RunFunctionInput,
    RunFunctionOutput,
    ActionDescriptor,
    ScheduleDescriptor,
    PipelineStep,
    PipelineDescriptor,
    FrozenPromptStrings,
    AgentLoopState,
    AgentLoopConfig,
    AgentLoopResult,
    AgentDescriptor,
    AgentRecord,
    Session,
    Case,
    QueueItem,
    KnowledgeHit,
    KnowledgeResult,
    KnowledgeQuery,
    DecisionOption,
    AttentionItem,
    Decision,
    Handoff,
    RunRequest,
    RunResult,
    RunEvent,
    QueryRequest,
    QueryResult,
]


def export_all_schemas() -> dict[str, Any]:
    """Export JSON Schema for every SDK model type.

    Returns a dict keyed by class name, with each value being
    the JSON Schema dict produced by Pydantic's model_json_schema().
    Schemas use camelCase field names (by_alias=True) matching
    the wire format.
    """
    schemas: dict[str, Any] = {}
    for model_cls in ALL_TYPES:
        schemas[model_cls.__name__] = model_cls.model_json_schema(by_alias=True)
    return schemas


def export_schemas_json(indent: int = 2) -> str:
    """Export all schemas as a formatted JSON string."""
    return json.dumps(export_all_schemas(), indent=indent, ensure_ascii=False)


def write_schema_artifact(path: str | Path | None = None) -> Path:
    """Write the schema export artifact used for release diffing.

    The committed artifact lives at `schemas/cogit-agent-sdk.schemas.json`;
    a test asserts it matches the current export so drift fails CI and
    breaking changes are visible in review (spec §0.4.4, §12).
    """
    target = Path(path) if path is not None else default_schema_artifact_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(export_schemas_json() + "\n", encoding="utf-8")
    return target


def default_schema_artifact_path() -> Path:
    """Location of the committed schema artifact, relative to the repo root cwd."""
    return Path("schemas") / "cogit-agent-sdk.schemas.json"


if __name__ == "__main__":
    print(write_schema_artifact())
