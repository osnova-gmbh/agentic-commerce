"""Internal presentation policy shared by typed input-validation paths."""

from __future__ import annotations

import re

MAX_VALIDATION_ERRORS = 8
_MAX_VALIDATION_TEXT = 2048


def validation_field(location: tuple[str | int, ...], fields: set[str]) -> str:
    # Locations may contain user-controlled mapping keys. Display a bounded
    # schema-level field and numeric indices; redact subsequent string keys.
    parts: list[str] = []
    for index, part in enumerate(location[:5]):
        if isinstance(part, int):
            parts.append(str(part) if 0 <= part <= 1_000_000 else "index")
        elif index == 0 and part in fields and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", part):
            parts.append(part)
        else:
            parts.append("<field>")
    return ".".join(parts) or "arguments"


def validation_tool_name(tool_name: str) -> str:
    return tool_name if re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", tool_name) else "requested tool"


def format_validation_details(tool_name: str, details: list[str], *, omitted: bool) -> str:
    if omitted:
        details.append("additional validation errors omitted")
    text = f"Invalid arguments for tool {validation_tool_name(tool_name)}: {'; '.join(details)}"
    return text[:_MAX_VALIDATION_TEXT]
