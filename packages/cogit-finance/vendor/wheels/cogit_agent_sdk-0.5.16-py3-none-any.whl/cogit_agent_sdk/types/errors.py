"""ErrorInfo type (definitions.md §26).

Error messages are truncated to 500 characters client-side.
"""

from __future__ import annotations

from typing import Any

from pydantic import field_validator

from cogit_agent_sdk.types._base import SdkModel
from cogit_agent_sdk.types.usage import Usage

_MAX_ERROR_MESSAGE_LEN = 500
_PROVIDER_CODES = frozenset(
    {
        "connection_error",
        "context_length_exceeded",
        "incomplete_response",
        "insufficient_quota",
        "invalid_api_key",
        "invalid_response",
        "invalid_value",
        "model_mismatch",
        "model_not_found",
        "rate_limit_exceeded",
        "reasoning_effort_mismatch",
        "refused",
        "request_failed",
        "timeout",
        "unsupported_parameter",
        "unsupported_value",
    }
)
_PROVIDER_PARAMETERS = frozenset(
    {
        "input",
        "max_output_tokens",
        "model",
        "reasoning",
        "reasoning.effort",
        "reasoning_effort",
        "temperature",
        "text",
        "text.format",
        "text.format.schema",
        "tools",
    }
)


class ErrorInfo(SdkModel):
    """Typed error container — embeds in results, records, events, handoffs."""

    code: str
    message: str
    retryable: bool | None = None
    details: dict[str, Any] | None = None

    @field_validator("message")
    @classmethod
    def _truncate_message(cls, v: str) -> str:
        if len(v) > _MAX_ERROR_MESSAGE_LEN:
            return v[: _MAX_ERROR_MESSAGE_LEN - 3] + "..."
        return v


class ModelProviderError(RuntimeError):
    """Provider failure with allowlisted diagnostics and no upstream message."""

    def __init__(
        self,
        code: str,
        *,
        parameter: str | None = None,
        status_code: int | None = None,
    ) -> None:
        self.code = code if code in _PROVIDER_CODES else "request_failed"
        self.parameter = parameter if parameter in _PROVIDER_PARAMETERS else None
        self.status_code = (
            status_code if status_code is not None and 400 <= status_code <= 599 else None
        )
        super().__init__(f"OpenAI Responses request failed ({self.code})")
        self.usage: Usage | None = None

    @classmethod
    def from_exception(cls, exc: Exception) -> ModelProviderError:
        code = getattr(exc, "code", None)
        parameter = getattr(exc, "param", None)
        status = getattr(exc, "status_code", None)
        if isinstance(exc, TimeoutError) or type(exc).__name__ == "APITimeoutError":
            code = "timeout"
        elif isinstance(exc, ConnectionError) or type(exc).__name__ == "APIConnectionError":
            code = "connection_error"
        return cls(
            code if isinstance(code, str) else "request_failed",
            parameter=parameter if isinstance(parameter, str) else None,
            status_code=status if isinstance(status, int) else None,
        )

    @property
    def error_details(self) -> dict[str, str | int]:
        details: dict[str, str | int] = {
            "provider": "openai",
            "provider_api": "responses",
            "provider_error_code": self.code,
        }
        if self.parameter is not None:
            details["provider_parameter"] = self.parameter
        if self.status_code is not None:
            details["provider_status_code"] = self.status_code
        return details
