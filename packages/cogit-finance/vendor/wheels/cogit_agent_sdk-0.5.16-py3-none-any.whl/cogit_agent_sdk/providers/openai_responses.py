"""Text ModelClient backed by the OpenAI Responses API."""

from __future__ import annotations

import json
import re
from collections.abc import Iterable
from importlib import import_module
from typing import Any, NoReturn, cast, get_args

from cogit_agent_sdk.coordination import raise_coordination_failure
from cogit_agent_sdk.types import (
    AssistantMessage,
    Cancellation,
    ModelClient,
    ModelProviderInfo,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
    TextContent,
    Usage,
)
from cogit_agent_sdk.types.errors import ModelProviderError
from cogit_agent_sdk.types.model import ReasoningEffort

_EFFORTS = frozenset(get_args(ReasoningEffort))


class OpenAIResponsesModelClient(ModelClient):
    """Send stateless text requests with optional structured output."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        client: Any | None = None,
        default_model: str | None = None,
    ) -> None:
        if client is None:
            try:
                openai = import_module("openai")
                client = openai.OpenAI(api_key=api_key, base_url=base_url, max_retries=0)
            except ImportError as exc:  # pragma: no cover - optional extra.
                raise RuntimeError(
                    "Install cogit-agent-sdk[openai] to use OpenAIResponsesModelClient"
                ) from exc
        if not callable(getattr(getattr(client, "responses", None), "create", None)):
            raise RuntimeError("The installed OpenAI client does not support Responses")
        self._client = client
        self._default_model = default_model

    def generate(self, request: ModelRequest, cancellation: Cancellation) -> ModelResponse:
        cancellation.throw_if_cancelled()
        wire = self._request_kwargs(request)
        client: Any = self._client
        remaining = getattr(cancellation, "remaining_seconds", None)
        with_options = getattr(client, "with_options", None)
        if isinstance(remaining, int | float) and callable(with_options):
            client = with_options(timeout=max(0.001, float(remaining)))
        cancellation.throw_if_cancelled()
        try:
            response = client.responses.create(**wire)
        except Exception as exc:
            raise_coordination_failure(exc)
            cancellation.throw_if_cancelled()
            raise ModelProviderError.from_exception(exc) from None
        cancellation.throw_if_cancelled()
        effort = wire.get("reasoning", {}).get("effort")
        usage = _usage(getattr(response, "usage", None))
        try:
            return _response(
                response,
                wire["model"],
                effort,
                usage,
                structured=request.response_format is not None,
            )
        except ModelProviderError as exc:
            exc.usage = usage
            raise

    def stream(
        self, request: ModelRequest, cancellation: Cancellation
    ) -> Iterable[ModelStreamEvent]:
        cancellation.throw_if_cancelled()
        raise ValueError("The OpenAI Responses adapter does not support streaming")

    def _request_kwargs(self, request: ModelRequest) -> dict[str, Any]:
        descriptor = request.model
        if descriptor is not None and (
            descriptor.provider != "openai" or descriptor.openai_api == "chat_completions"
        ):
            raise ValueError("The OpenAI Responses adapter requires an OpenAI Responses model")
        if request.tools or request.tool_choice == "required":
            raise ValueError("The OpenAI Responses adapter does not support tool calls")
        if request.reasoning_max_tokens is not None:
            raise ValueError("Responses uses reasoning effort and a total output token limit")
        model = descriptor.model if descriptor is not None else self._default_model
        if not model:
            raise ValueError("A model is required for the OpenAI Responses adapter")
        kwargs: dict[str, Any] = {
            "model": model,
            "input": _messages(request),
            "store": False,
        }
        kwargs.update(_reasoning_options(request))
        max_tokens = request.max_output_tokens
        if max_tokens is None and descriptor is not None:
            max_tokens = descriptor.max_output_tokens
        if max_tokens is not None:
            kwargs["max_output_tokens"] = max_tokens
        response_format = request.response_format
        if response_format is not None:
            wire_format: dict[str, Any] = {"type": response_format.type}
            if response_format.type == "json_schema":
                wire_format.update(
                    name=response_format.name,
                    schema=response_format.json_schema,
                    strict=True,
                )
            kwargs["text"] = {"format": wire_format}
        return kwargs


def _reasoning_options(request: ModelRequest) -> dict[str, Any]:
    defaults = request.model.defaults if request.model is not None else None
    effort = defaults.thinking_level if defaults is not None else None
    options: dict[str, Any] = {}
    if effort is not None:
        if effort not in _EFFORTS:
            raise ValueError("Unsupported OpenAI reasoning effort")
        options["reasoning"] = {"effort": effort}
    temperature = request.temperature
    if temperature is None and defaults is not None:
        temperature = defaults.temperature
    if temperature is not None:
        if effort not in (None, "none"):
            raise ValueError("Temperature cannot be combined with Responses reasoning effort")
        options["temperature"] = temperature
    return options


def _messages(request: ModelRequest) -> list[dict[str, str]]:
    system = request.system or ""
    if request.response_format is not None and request.response_format.type == "json_object":
        system = (system + "\n\nReturn exactly one JSON object.").lstrip("\n")
    messages: list[dict[str, str]] = []
    if system:
        messages.append({"role": "developer", "content": system})
    for message in request.messages:
        if message.role == "tool_result" or (
            isinstance(message, AssistantMessage) and message.tool_calls
        ):
            raise ValueError("The OpenAI Responses adapter does not support tool messages")
        if not all(isinstance(block, TextContent) for block in message.content):
            raise ValueError("The OpenAI Responses adapter only supports text messages")
        text = "\n".join(block.text for block in message.content if isinstance(block, TextContent))
        role = "developer" if message.role == "system" else message.role
        messages.append({"role": role, "content": text})
    if not messages:
        raise ValueError("At least one message is required for OpenAI Responses")
    return messages


def _response(
    response: Any,
    requested_model: str,
    requested_effort: ReasoningEffort | None,
    usage: Usage | None,
    *,
    structured: bool,
) -> ModelResponse:
    if response.status != "completed":
        raise ModelProviderError("incomplete_response")
    for item in response.output:
        if item.type == "message":
            if any(block.type == "refusal" for block in item.content):
                raise ModelProviderError("refused")
        elif item.type != "reasoning":
            raise ModelProviderError("invalid_response")
    output_text = response.output_text
    if not isinstance(output_text, str) or not output_text.strip():
        raise ModelProviderError("invalid_response")
    if structured:
        _require_json_object(output_text)
    effort = getattr(getattr(response, "reasoning", None), "effort", None)
    if requested_effort is not None and effort is not None and requested_effort != effort:
        raise ModelProviderError("reasoning_effort_mismatch", parameter="reasoning.effort")
    provider_info = ModelProviderInfo(
        requested_effort=requested_effort,
        effective_effort=(
            cast(ReasoningEffort, effort)
            if isinstance(effort, str) and effort in _EFFORTS
            else None
        ),
    )
    model = _verified_model(response.model, requested_model)
    return ModelResponse(
        message=AssistantMessage(
            content=[TextContent(text=output_text)],
            model=model,
            provider="openai",
            stop_reason="stop",
        ),
        usage=usage.model_copy(update={"model": model}) if usage is not None else None,
        stop_reason="stop",
        provider_response_id=response.id,
        provider_info=provider_info,
    )


def _require_json_object(output_text: str) -> None:
    try:
        value = json.loads(output_text, parse_constant=_reject_constant)
    except (ValueError, RecursionError):
        raise ModelProviderError("invalid_response") from None
    if not isinstance(value, dict):
        raise ModelProviderError("invalid_response")


def _verified_model(model: object, requested_model: str) -> str:
    if isinstance(model, str) and (
        model == requested_model
        or re.fullmatch(rf"{re.escape(requested_model)}-[0-9]{{4}}-[0-9]{{2}}-[0-9]{{2}}", model)
    ):
        return model
    raise ModelProviderError("model_mismatch", parameter="model")


def _reject_constant(value: str) -> NoReturn:
    raise ValueError("Expected finite JSON")


def _usage(usage: Any) -> Usage | None:
    if usage is None:
        return None
    input_details = getattr(usage, "input_tokens_details", None)
    counts = (
        getattr(usage, "input_tokens", None),
        getattr(usage, "output_tokens", None),
        getattr(input_details, "cached_tokens", 0) or 0,
        getattr(input_details, "cache_write_tokens", 0) or 0,
    )
    if any(type(count) is not int or count < 0 for count in counts):
        return None
    input_tokens, output_tokens, cached, written = cast(tuple[int, int, int, int], counts)
    if cached + written > input_tokens:
        return None
    return Usage(
        input_tokens=input_tokens - cached - written,
        output_tokens=output_tokens,
        cache_read_tokens=cached,
        cache_write_tokens=written,
        provider="openai",
    )
