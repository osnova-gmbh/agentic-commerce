"""Optional first-party model provider adapters."""

from cogit_agent_sdk.providers.anthropic import AnthropicModelClient
from cogit_agent_sdk.providers.dispatch import (
    DispatchingModelClient,
    IdentifiedModelClient,
    ModelDispatchFailure,
    SelectedModelCall,
)
from cogit_agent_sdk.providers.openai import OpenAIModelClient
from cogit_agent_sdk.providers.openai_responses import OpenAIResponsesModelClient
from cogit_agent_sdk.types.errors import ModelProviderError

__all__ = [
    "AnthropicModelClient",
    "DispatchingModelClient",
    "IdentifiedModelClient",
    "ModelDispatchFailure",
    "ModelProviderError",
    "OpenAIModelClient",
    "OpenAIResponsesModelClient",
    "SelectedModelCall",
]
