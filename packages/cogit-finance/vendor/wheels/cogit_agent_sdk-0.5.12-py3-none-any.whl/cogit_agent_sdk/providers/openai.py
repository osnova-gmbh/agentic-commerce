"""OpenAI-compatible provider adapter for the SDK model-client contract.

One adapter class serves both OpenAI and any OpenAI-compatible endpoint
(notably OpenRouter) via ``base_url`` + ``api_key``; the request/response
shape is OpenAI's Chat Completions API, which OpenRouter mirrors by design.
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from importlib import import_module
from typing import Any

from cogit_agent_sdk.coordination import raise_coordination_failure
from cogit_agent_sdk.types import (
    AssistantMessage,
    Cancellation,
    ContentBlock,
    Diagnostic,
    FileRefContent,
    ModelClient,
    ModelRequest,
    ModelResponse,
    ModelStreamEvent,
    StructuredContent,
    TextContent,
    ThinkingContent,
    ToolCall,
    ToolResultMessage,
    Usage,
)


class OpenAIModelClient(ModelClient):
    """ModelClient implementation backed by OpenAI's Chat Completions API."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        client: Any | None = None,
        default_model: str | None = None,
        provider: str | None = None,
    ) -> None:
        resolved_client = client
        if resolved_client is None:
            try:
                openai_module = import_module("openai")
            except ImportError as exc:  # pragma: no cover - exercised by optional extra users.
                raise RuntimeError(
                    "Install cogit-agent-sdk[openai] to use OpenAIModelClient"
                ) from exc
            # A durable model slot reserves spend for one provider dispatch.
            # The OpenAI transport otherwise retries some failures twice behind
            # the host's reservation and reconciliation boundary.
            resolved_client = openai_module.OpenAI(
                api_key=api_key, base_url=base_url, max_retries=0
            )

        self._client = resolved_client
        self._default_model = default_model
        self._provider = provider or (
            "openrouter"
            if base_url is not None and "openrouter.ai" in base_url.casefold()
            else "openai"
        )

    def generate(self, request: ModelRequest, cancellation: Cancellation) -> ModelResponse:
        cancellation.throw_if_cancelled()
        kwargs = self._request_kwargs(request)
        response = self._completions_api(cancellation).create(**kwargs)
        cancellation.throw_if_cancelled()
        return self._response(response, self._provider_name(request))

    def stream(
        self,
        request: ModelRequest,
        cancellation: Cancellation,
    ) -> Iterable[ModelStreamEvent]:
        """Stream normalized deltas from OpenAI's raw SSE chunks.

        Ordinary provider failures and cancellations terminate with a single ``error`` event
        carrying the partial message assembled so far. Gateways that ignore
        ``stream=True`` and return a complete message fall back to one
        ``message_completed``.
        Host CoordinationFailure exceptions propagate for reconciliation.
        """

        provider = self._provider_name(request)
        accumulator = _StreamAccumulator(provider)
        sequence = 0

        def next_sequence() -> int:
            nonlocal sequence
            sequence += 1
            return sequence

        try:
            cancellation.throw_if_cancelled()
            # The shared builder omits optional fields instead of sending JSON
            # nulls, which are fragile across OpenAI-compatible endpoints.
            kwargs = self._request_kwargs(request)
            kwargs["stream"] = True
            kwargs["stream_options"] = {"include_usage": True}
            raw = self._completions_api(cancellation).create(**kwargs)
            if cancellation.cancelled:
                yield accumulator.error_event(
                    next_sequence(),
                    "aborted",
                    "Run was cancelled",
                )
                return

            if _is_complete_response(raw):
                response = self._response(raw, provider)
                if cancellation.cancelled:
                    yield accumulator.error_event(
                        next_sequence(),
                        "aborted",
                        "Run was cancelled",
                    )
                    return
                yield ModelStreamEvent(
                    type="message_completed",
                    sequence=next_sequence(),
                    message=response.message,
                    usage=response.usage,
                    stop_reason=response.stop_reason,
                    diagnostics=response.diagnostics,
                )
                return

            for chunk in raw:
                if cancellation.cancelled:
                    yield accumulator.error_event(next_sequence(), "aborted", "Run was cancelled")
                    return
                for normalized in accumulator.consume(chunk):
                    normalized.sequence = next_sequence()
                    yield normalized
            if cancellation.cancelled:
                yield accumulator.error_event(
                    next_sequence(),
                    "aborted",
                    "Run was cancelled",
                )
                return
        except Exception as exc:
            raise_coordination_failure(exc)
            reason = "aborted" if cancellation.cancelled else "error"
            yield accumulator.error_event(
                next_sequence(),
                reason,
                f"Provider stream failed ({type(exc).__name__})",
            )
            return

        yield accumulator.completed_event(next_sequence())

    def _request_kwargs(self, request: ModelRequest) -> dict[str, Any]:
        """Build conditional wire fields shared by generate and stream."""

        kwargs: dict[str, Any] = {
            "model": self._model_name(request),
            "messages": self._messages(request),
        }
        max_tokens = self._max_tokens(request)
        if max_tokens is not None:
            key = "max_completion_tokens" if self._provider == "openai" else "max_tokens"
            kwargs[key] = max_tokens
        defaults = request.model.defaults if request.model is not None else None
        if (
            self._provider == "openai"
            and defaults is not None
            and defaults.thinking_level is not None
        ):
            kwargs["reasoning_effort"] = defaults.thinking_level
        reasoning = self._reasoning_extra_body(request, max_tokens)
        if reasoning is not None:
            kwargs["extra_body"] = reasoning
        if request.temperature is not None:
            kwargs["temperature"] = request.temperature
        tools = self._tools(request)
        if tools:
            kwargs["tools"] = tools
            tool_choice = self._tool_choice(request)
            if tool_choice is not None:
                kwargs["tool_choice"] = tool_choice
        return kwargs

    def _completions_api(self, cancellation: Cancellation) -> Any:
        """Bind the provider transport timeout to the remaining run deadline."""

        client: Any = self._client
        remaining = getattr(cancellation, "remaining_seconds", None)
        with_options = getattr(client, "with_options", None)
        if isinstance(remaining, int | float) and callable(with_options):
            cancellation.throw_if_cancelled()
            client = with_options(timeout=max(0.001, float(remaining)))
        return client.chat.completions

    def _model_name(self, request: ModelRequest) -> str:
        if request.model is not None:
            return request.model.model
        if self._default_model is not None:
            return self._default_model
        raise ValueError("OpenAI model must be supplied in request.model or default_model")

    def dispatch_identity(self, request: ModelRequest) -> tuple[str, str]:
        """Report the actual endpoint provider and model before transport dispatch."""

        return self._provider, self._model_name(request)

    def _provider_name(self, request: ModelRequest) -> str:
        if request.model is not None and request.model.provider in {"openai", "openrouter"}:
            return request.model.provider
        return self._provider

    @staticmethod
    def _max_tokens(request: ModelRequest) -> int | None:
        if request.max_output_tokens is not None:
            return request.max_output_tokens
        if request.model is not None and request.model.max_output_tokens is not None:
            return request.model.max_output_tokens
        return None

    def _reasoning_extra_body(
        self, request: ModelRequest, max_tokens: int | None
    ) -> dict[str, Any] | None:
        cap = request.reasoning_max_tokens
        if cap is None:
            return None
        if (
            self._provider != "openrouter"
            or type(cap) is not int
            or max_tokens is None
            or type(max_tokens) is not int
            or not 0 < cap < max_tokens
        ):
            raise ValueError("Bounded reasoning requires an OpenRouter total output limit")
        return {"reasoning": {"max_tokens": cap, "exclude": True}}

    @staticmethod
    def _tools(request: ModelRequest) -> list[dict[str, Any]] | None:
        if not request.tools:
            return None
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.input_schema,
                },
            }
            for tool in request.tools
        ]

    @staticmethod
    def _tool_choice(request: ModelRequest) -> str | None:
        # OpenAI accepts the literal strings "auto"/"none"/"required" for
        # tool_choice. Omit it entirely when there are no tools.
        if not request.tools:
            return None
        if request.tool_choice == "none":
            return "none"
        if request.tool_choice == "required":
            return "required"
        return "auto"

    def _messages(self, request: ModelRequest) -> list[dict[str, Any]]:
        converted: list[dict[str, Any]] = []
        # Unlike Anthropic, OpenAI carries the system prompt as a leading
        # system-role message rather than a dedicated request parameter.
        if request.system:
            converted.append({"role": "system", "content": request.system})
        for message in request.messages:
            if isinstance(message, ToolResultMessage):
                converted.append(
                    {
                        "role": "tool",
                        "tool_call_id": message.tool_call_id,
                        "content": self._content_to_text(message.content),
                    }
                )
                continue
            if message.role == "system":
                converted.append(
                    {"role": "system", "content": self._content_to_text(message.content)}
                )
                continue
            if isinstance(message, AssistantMessage):
                entry: dict[str, Any] = {
                    "role": "assistant",
                    "content": self._content_to_text(message.content) or None,
                }
                if message.tool_calls:
                    entry["tool_calls"] = [
                        {
                            "id": tool_call.id,
                            "type": "function",
                            "function": {
                                "name": tool_call.tool_name,
                                "arguments": json.dumps(tool_call.arguments, ensure_ascii=False),
                            },
                        }
                        for tool_call in message.tool_calls
                    ]
                converted.append(entry)
                continue
            converted.append({"role": "user", "content": self._content_to_text(message.content)})
        return converted

    @staticmethod
    def _content_to_text(content: list[ContentBlock]) -> str:
        values: list[str] = []
        for block in content:
            if isinstance(block, TextContent | ThinkingContent):
                values.append(block.text)
            elif isinstance(block, StructuredContent):
                values.append(json.dumps(block.data, ensure_ascii=False))
            elif isinstance(block, FileRefContent):
                values.append(block.uri)
            else:
                values.append(block.source)
        return "\n".join(values)

    @classmethod
    def _response(cls, response: Any, provider: str) -> ModelResponse:
        content: list[ContentBlock] = []
        tool_calls: list[ToolCall] = []
        diagnostics: list[Diagnostic] = []

        choices = getattr(response, "choices", None) or []
        message = _get(_get_at(choices, 0), "message")
        text = _get(message, "content")
        if text:
            content.append(TextContent(text=str(text)))

        for raw_tool in _get(message, "tool_calls") or []:
            function = _get(raw_tool, "function")
            tool_name = str(_get(function, "name"))
            arguments = cls._parse_arguments(
                tool_name,
                _get(function, "arguments"),
                diagnostics,
                provider,
            )
            tool_calls.append(
                ToolCall(
                    id=str(_get(raw_tool, "id")),
                    tool_name=tool_name,
                    arguments=arguments,
                )
            )

        usage = cls._usage(_get(response, "usage"), provider)
        finish_reason = _get(_get_at(choices, 0), "finish_reason")
        model = _get(response, "model")
        assistant = AssistantMessage(
            content=content,
            model=str(model) if model else None,
            provider=provider,
            usage=usage,
            stop_reason=str(finish_reason) if finish_reason else None,
            tool_calls=tool_calls or None,
            diagnostics=diagnostics or None,
        )
        return ModelResponse(
            message=assistant,
            usage=usage,
            stop_reason=assistant.stop_reason,
            provider_response_id=str(_get(response, "id") or "") or None,
            diagnostics=diagnostics or None,
        )

    @staticmethod
    def _parse_arguments(
        tool_name: str,
        raw_arguments: Any,
        diagnostics: list[Diagnostic],
        provider: str,
    ) -> dict[str, Any]:
        # OpenAI delivers tool-call arguments as a JSON string, not a dict.
        if not raw_arguments:
            return {}
        try:
            parsed = json.loads(raw_arguments)
        except (TypeError, ValueError):
            diagnostics.append(
                Diagnostic(
                    level="warning",
                    message=f"Tool call {tool_name} arguments were not valid JSON",
                    source=provider,
                )
            )
            return {}
        return dict(parsed) if isinstance(parsed, dict) else {}

    @staticmethod
    def _usage(raw_usage: Any, provider: str) -> Usage | None:
        return _normalized_usage(raw_usage, provider)


def _normalized_usage(raw_usage: Any, provider: str) -> Usage | None:
    if raw_usage is None:
        return None
    input_tokens = _token_count(raw_usage, "prompt_tokens")
    output_tokens = _token_count(raw_usage, "completion_tokens")
    if input_tokens is None or output_tokens is None:
        return None
    return Usage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        provider=provider,
    )


def _get(value: Any, key: str) -> Any:
    if isinstance(value, dict):
        return value.get(key)
    return getattr(value, key, None)


def _token_count(value: Any, key: str) -> int | None:
    count = _get(value, key)
    return count if type(count) is int and count >= 0 else None


def _get_at(values: Any, index: int) -> Any:
    if not values:
        return None
    try:
        return values[index]
    except (IndexError, KeyError, TypeError):
        return None


def _is_complete_response(raw: Any) -> bool:
    """True when a gateway ignored ``stream=True`` and returned a full object."""

    choices = getattr(raw, "choices", None)
    if not choices:
        return False
    return hasattr(_get_at(choices, 0), "message")


class _StreamToolCall:
    """Mutable per-index tool-call accumulation state during streaming."""

    def __init__(self, index: int) -> None:
        self.index = index
        self.id = ""
        self.name = ""
        self.partial_json = ""
        self.started = False
        self.completed = False


class _StreamAccumulator:
    """Normalizes raw OpenAI stream chunks into SDK ModelStreamEvents.

    OpenAI streams content as ``choices[0].delta.content`` and tool calls as
    indexed ``choices[0].delta.tool_calls`` (with the id+name on the first
    chunk for an index, argument JSON arriving as partial strings afterward).
    Usage, when present, lands on the final chunk. This mirrors the Anthropic
    adapter's accumulation shape without sharing its private helpers.
    """

    def __init__(self, provider: str) -> None:
        self._provider = provider
        self._text = ""
        self._tool_calls: dict[int, _StreamToolCall] = {}
        self._usage: Usage | None = None
        self._stop_reason: str | None = None
        self._model: str | None = None
        self._response_id: str | None = None
        self._started = False
        self._diagnostics: list[Diagnostic] = []

    def consume(self, chunk: Any) -> list[ModelStreamEvent]:
        events: list[ModelStreamEvent] = []
        if not self._started:
            self._started = True
            self._response_id = _get(chunk, "id")
            model = _get(chunk, "model")
            self._model = str(model) if model else None
            events.append(
                ModelStreamEvent(
                    type="message_started",
                    metadata={"responseId": self._response_id, "model": self._model},
                )
            )

        choices = _get(chunk, "choices") or []
        if choices:
            # Any later provider output invalidates an earlier usage snapshot.
            self._usage = None
            choice = _get_at(choices, 0)
            delta = _get(choice, "delta")
            text = _get(delta, "content")
            if text:
                chunk_text = str(text)
                self._text += chunk_text
                events.append(ModelStreamEvent(type="message_delta", delta=chunk_text))
            for tool_delta in _get(delta, "tool_calls") or []:
                events.extend(self._on_tool_call(tool_delta))
            finish_reason = _get(choice, "finish_reason")
            if finish_reason is not None:
                self._stop_reason = str(finish_reason)
                events.extend(self._complete_open_tool_calls())

        usage = _get(chunk, "usage")
        if usage is not None:
            self._usage = self._usage_from(usage)
            events.append(
                ModelStreamEvent(
                    type="usage_delta",
                    usage=self._usage,
                    stop_reason=self._stop_reason,
                )
            )
        return events

    def _on_tool_call(self, tool_delta: Any) -> list[ModelStreamEvent]:
        events: list[ModelStreamEvent] = []
        index = int(_get(tool_delta, "index") or 0)
        block = self._tool_calls.get(index)
        if block is None:
            block = _StreamToolCall(index)
            self._tool_calls[index] = block

        function = _get(tool_delta, "function")
        tool_id = _get(tool_delta, "id")
        name = _get(function, "name")
        arguments = _get(function, "arguments")
        if tool_id:
            block.id = str(tool_id)
        if name:
            block.name = str(name)
        if arguments:
            block.partial_json += str(arguments)

        if block.id and not block.started:
            block.started = True
            events.append(
                ModelStreamEvent(
                    type="tool_call_started",
                    tool_call_id=block.id,
                    tool_name=block.name,
                )
            )
            if arguments:
                events.append(
                    ModelStreamEvent(
                        type="tool_call_delta",
                        tool_call_id=block.id,
                        tool_name=block.name,
                        tool_arguments_delta={"partialJson": str(arguments)},
                    )
                )
        elif arguments and block.started:
            events.append(
                ModelStreamEvent(
                    type="tool_call_delta",
                    tool_call_id=block.id,
                    tool_name=block.name,
                    tool_arguments_delta={"partialJson": str(arguments)},
                )
            )
        return events

    def _complete_open_tool_calls(self) -> list[ModelStreamEvent]:
        events: list[ModelStreamEvent] = []
        for index in sorted(self._tool_calls):
            block = self._tool_calls[index]
            if not block.completed:
                block.completed = True
                events.append(
                    ModelStreamEvent(
                        type="tool_call_completed",
                        tool_call_id=block.id,
                        tool_name=block.name,
                    )
                )
        return events

    def _usage_from(self, raw_usage: Any) -> Usage | None:
        return _normalized_usage(raw_usage, self._provider)

    def completed_event(self, sequence: int) -> ModelStreamEvent:
        message = self._assemble_message(self._stop_reason)
        return ModelStreamEvent(
            type="message_completed",
            sequence=sequence,
            message=message,
            usage=self._usage,
            stop_reason=self._stop_reason,
            diagnostics=self._diagnostics or None,
        )

    def error_event(self, sequence: int, reason: str, message: str) -> ModelStreamEvent:
        self._diagnostics.append(Diagnostic(level="error", message=message, source=self._provider))
        partial = self._assemble_message(reason)
        return ModelStreamEvent(
            type="error",
            sequence=sequence,
            message=partial,
            usage=self._usage,
            stop_reason=reason,
            diagnostics=list(self._diagnostics),
        )

    def _assemble_message(self, stop_reason: str | None) -> AssistantMessage:
        content: list[ContentBlock] = []
        if self._text:
            content.append(TextContent(text=self._text))
        tool_calls: list[ToolCall] = []
        for index in sorted(self._tool_calls):
            block = self._tool_calls[index]
            tool_calls.append(
                ToolCall(
                    id=block.id,
                    tool_name=block.name,
                    arguments=self._parse_arguments(block),
                )
            )
        return AssistantMessage(
            content=content,
            model=self._model,
            provider=self._provider,
            usage=self._usage,
            stop_reason=stop_reason,
            tool_calls=tool_calls or None,
            diagnostics=self._diagnostics or None,
        )

    def _parse_arguments(self, block: _StreamToolCall) -> dict[str, Any]:
        if not block.partial_json:
            return {}
        try:
            parsed = json.loads(block.partial_json)
        except ValueError:
            self._diagnostics.append(
                Diagnostic(
                    level="warning",
                    message=f"Tool call {block.name} arguments were incomplete JSON",
                    source=self._provider,
                )
            )
            return {}
        return dict(parsed) if isinstance(parsed, dict) else {}
