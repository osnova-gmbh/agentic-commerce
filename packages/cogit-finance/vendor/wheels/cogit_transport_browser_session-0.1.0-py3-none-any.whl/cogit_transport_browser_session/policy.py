"""Fixed-origin, fixed-route policies for browser-backed GET requests."""

from __future__ import annotations

import re
from collections.abc import Mapping
from enum import StrEnum
from typing import TYPE_CHECKING, TypeAlias
from urllib.parse import unquote, urlencode, urlsplit
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

if TYPE_CHECKING:
    from cogit_transport_browser_session.models import BrowserRequest

QueryScalar: TypeAlias = str | int
QueryValue: TypeAlias = QueryScalar | tuple[QueryScalar, ...]

_NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,63}$")
_PARAMETER_PATTERN = re.compile(r"^\{([A-Za-z][A-Za-z0-9_]{0,63})\}$")
_ENCODED_DANGEROUS_PATTERN = re.compile(r"%(?:2f|5c|2e|3f|23|25)", re.IGNORECASE)
_MALFORMED_ESCAPE_PATTERN = re.compile(r"%(?![0-9A-Fa-f]{2})")
_SENSITIVE_QUERY_NAME_PATTERN = re.compile(
    r"(?:authorization|cookie|credential|password|secret|session|token)",
    re.IGNORECASE,
)


class QueryValueKind(StrEnum):
    """Supported structured query scalar kinds."""

    STRING = "string"
    INTEGER = "integer"


class QueryParameterPolicy(BaseModel):
    """Bounds for one policy-owned query parameter."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    name: str
    kind: QueryValueKind = QueryValueKind.STRING
    required: bool = False
    min_values: int = Field(default=1, ge=1, le=100)
    max_values: int = Field(default=1, ge=1, le=100)
    min_length: int = Field(default=1, ge=0, le=2048)
    max_length: int = Field(default=256, ge=1, le=2048)
    min_integer: int | None = None
    max_integer: int | None = None
    allowed_values: tuple[QueryScalar, ...] = ()
    pattern: str | None = None

    @model_validator(mode="after")
    def _validate_policy(self) -> QueryParameterPolicy:
        if not _NAME_PATTERN.fullmatch(self.name):
            raise ValueError("query parameter name must be a bounded identifier")
        if _SENSITIVE_QUERY_NAME_PATTERN.search(self.name):
            raise ValueError("credential-like query parameter names are forbidden")
        if self.min_values > self.max_values:
            raise ValueError("min_values cannot exceed max_values")
        if self.min_length > self.max_length:
            raise ValueError("min_length cannot exceed max_length")
        if (
            self.min_integer is not None
            and self.max_integer is not None
            and self.min_integer > self.max_integer
        ):
            raise ValueError("min_integer cannot exceed max_integer")
        if self.pattern is not None:
            re.compile(self.pattern)
        for value in self.allowed_values:
            self._validate_scalar(value)
        return self

    def render_values(self, value: QueryValue) -> tuple[str, ...]:
        """Validate and render one structured query value."""
        values = value if isinstance(value, tuple) else (value,)
        if not self.min_values <= len(values) <= self.max_values:
            raise ValueError(f"query parameter {self.name!r} has invalid cardinality")
        for item in values:
            self._validate_scalar(item)
        return tuple(str(item) for item in values)

    def _validate_scalar(self, value: QueryScalar) -> None:
        if self.kind is QueryValueKind.STRING:
            self._validate_string(value)
        else:
            self._validate_integer(value)
        if self.allowed_values and value not in self.allowed_values:
            raise ValueError(f"query parameter {self.name!r} has a disallowed value")

    def _validate_string(self, value: QueryScalar) -> None:
        if not isinstance(value, str):
            raise ValueError(f"query parameter {self.name!r} requires string values")
        if not self.min_length <= len(value) <= self.max_length:
            raise ValueError(f"query parameter {self.name!r} is outside its length bounds")
        if self.pattern is not None and re.fullmatch(self.pattern, value) is None:
            raise ValueError(f"query parameter {self.name!r} does not match its pattern")

    def _validate_integer(self, value: QueryScalar) -> None:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"query parameter {self.name!r} requires integer values")
        if self.min_integer is not None and value < self.min_integer:
            raise ValueError(f"query parameter {self.name!r} is below its minimum")
        if self.max_integer is not None and value > self.max_integer:
            raise ValueError(f"query parameter {self.name!r} is above its maximum")


class PolicyRoute(BaseModel):
    """One immutable route selected from a provider-owned policy."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    name: str
    origin: str
    path_template: str
    uuid_path_parameters: frozenset[str] = frozenset()
    query_parameters: tuple[QueryParameterPolicy, ...] = ()

    @model_validator(mode="after")
    def _validate_route(self) -> PolicyRoute:
        if not _NAME_PATTERN.fullmatch(self.name):
            raise ValueError("route name must be a bounded identifier")
        _validate_origin(self.origin)
        parameters = _path_parameter_names(self.path_template)
        if parameters != self.uuid_path_parameters:
            raise ValueError("every dynamic path segment must be declared as a UUID parameter")
        names = [parameter.name for parameter in self.query_parameters]
        if len(names) != len(set(names)):
            raise ValueError("query parameter policies must have unique names")
        return self

    def render_path(self, path_values: Mapping[str, str]) -> str:
        """Render a route after exact-key and canonical UUID validation."""
        expected = self.uuid_path_parameters
        if set(path_values) != set(expected):
            raise ValueError("path values must exactly match the route parameters")
        rendered = self.path_template
        for name in sorted(expected):
            value = path_values[name]
            _validate_uuid(value)
            rendered = rendered.replace(f"{{{name}}}", value)
        return rendered

    def query_items(self, query: Mapping[str, QueryValue]) -> tuple[tuple[str, str], ...]:
        """Validate exact query names and return deterministic encoded items."""
        policies = {parameter.name: parameter for parameter in self.query_parameters}
        unknown = set(query).difference(policies)
        missing = {name for name, policy in policies.items() if policy.required}.difference(query)
        if unknown:
            raise ValueError(f"unknown query parameters: {', '.join(sorted(unknown))}")
        if missing:
            raise ValueError(f"missing query parameters: {', '.join(sorted(missing))}")
        items: list[tuple[str, str]] = []
        for parameter in self.query_parameters:
            if parameter.name not in query:
                continue
            items.extend(
                (parameter.name, value) for value in parameter.render_values(query[parameter.name])
            )
        return tuple(items)


class RoutePolicy(BaseModel):
    """An immutable allowlist of exact origins and named routes."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    allowed_origins: frozenset[str]
    routes: tuple[PolicyRoute, ...]

    @model_validator(mode="after")
    def _validate_policy(self) -> RoutePolicy:
        if not self.allowed_origins:
            raise ValueError("at least one exact origin is required")
        if not self.routes:
            raise ValueError("at least one route is required")
        for origin in self.allowed_origins:
            _validate_origin(origin)
        names = [route.name for route in self.routes]
        if len(names) != len(set(names)):
            raise ValueError("route names must be unique")
        if any(route.origin not in self.allowed_origins for route in self.routes):
            raise ValueError("every route origin must be explicitly allowed")
        return self

    def select(self, name: str) -> PolicyRoute:
        """Select a route by an exact policy-owned name."""
        for route in self.routes:
            if route.name == name:
                return route
        raise ValueError(f"route {name!r} is not allowed")

    def validate_route(self, route: PolicyRoute) -> PolicyRoute:
        """Reject any route object not selected from this policy instance."""
        if not any(candidate is route for candidate in self.routes):
            raise ValueError(f"route {route.name!r} is not allowed")
        return route

    def resolve_url(self, request: BrowserRequest) -> str:
        """Resolve a request only after exact policy-membership validation."""
        route = self.validate_route(request.route)
        path = route.render_path(request.path_values)
        encoded_query = urlencode(route.query_items(request.query))
        return f"{route.origin}{path}" + (f"?{encoded_query}" if encoded_query else "")


def _validate_origin(origin: str) -> None:
    if "\\" in origin or any(character.isspace() for character in origin):
        raise ValueError("origin contains forbidden characters")
    try:
        parsed = urlsplit(origin)
        _ = parsed.port
    except ValueError as exc:
        raise ValueError("origin is malformed") from exc
    if parsed.scheme != "https" or not parsed.netloc or parsed.hostname is None:
        raise ValueError("origin must be an absolute HTTPS origin")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("origin cannot contain user information")
    if parsed.path or parsed.query or parsed.fragment or origin != f"https://{parsed.netloc}":
        raise ValueError("origin must not contain a path, query, or fragment")


def _path_parameter_names(path_template: str) -> frozenset[str]:
    _validate_path_template(path_template)
    names: set[str] = set()
    for segment in path_template.split("/")[1:]:
        match = _PARAMETER_PATTERN.fullmatch(segment)
        if match is not None:
            name = match.group(1)
            if name in names:
                raise ValueError("path parameter names must be unique")
            names.add(name)
        elif "{" in segment or "}" in segment:
            raise ValueError("dynamic values must occupy a complete path segment")
    return frozenset(names)


def _validate_path_template(path_template: str) -> None:
    if not path_template.startswith("/") or path_template.startswith("//"):
        raise ValueError("path template must be an absolute-origin relative path")
    if "?" in path_template or "#" in path_template:
        raise ValueError("path template cannot contain a query or fragment")
    if "\\" in path_template or _ENCODED_DANGEROUS_PATTERN.search(path_template):
        raise ValueError("path template contains an encoded dangerous character")
    if _MALFORMED_ESCAPE_PATTERN.search(path_template):
        raise ValueError("path template contains a malformed percent escape")
    decoded = unquote(path_template)
    if "\\" in decoded:
        raise ValueError("path template contains an encoded backslash")
    segments = decoded.split("/")[1:]
    if any(segment in {"", ".", ".."} for segment in segments):
        raise ValueError("path template contains an empty or traversal segment")
    if urlsplit(path_template).scheme or urlsplit(path_template).netloc:
        raise ValueError("absolute and network-path URLs are forbidden")


def _validate_uuid(value: object) -> None:
    if not isinstance(value, str):
        raise ValueError("UUID path values must be strings")
    try:
        parsed = UUID(value)
    except ValueError as exc:
        raise ValueError("path value must be a canonical UUID") from exc
    if str(parsed) != value:
        raise ValueError("path value must be a canonical lowercase UUID")


NAME_PATTERN = _NAME_PATTERN
SENSITIVE_QUERY_NAME_PATTERN = _SENSITIVE_QUERY_NAME_PATTERN
validate_origin = _validate_origin
validate_path_template = _validate_path_template
validate_uuid = _validate_uuid
path_parameter_names = _path_parameter_names
