"""Deterministic worker-loop shutdown helpers for SessionRunner."""

from __future__ import annotations

import asyncio

from cogit_transport_browser_session.errors import (
    BrowserSessionError,
    CancellationError,
    TransportError,
)


async def cancel_runner_owned_tasks(inflight: set[asyncio.Task[object]]) -> None:
    """Cancel only runner-submitted request/check work, not library internals."""
    owned = list(inflight)
    for task in owned:
        task.cancel()
    if owned:
        await asyncio.gather(*owned, return_exceptions=True)


async def cancel_residual_loop_tasks() -> None:
    """Cancel remaining loop tasks after session resources are closed."""
    current = asyncio.current_task()
    pending = [task for task in asyncio.all_tasks() if task is not current and not task.done()]
    for task in pending:
        task.cancel()
    if pending:
        await asyncio.gather(*pending, return_exceptions=True)


def as_shutdown_cleanup_error(exc: BaseException) -> BaseException:
    """Map session teardown failures without reusing startup diagnostics."""
    if isinstance(exc, BrowserSessionError):
        return exc
    if isinstance(exc, asyncio.CancelledError):
        return CancellationError("Browser-session shutdown was cancelled.")
    return TransportError(f"Browser-session shutdown failed: {exc}")
