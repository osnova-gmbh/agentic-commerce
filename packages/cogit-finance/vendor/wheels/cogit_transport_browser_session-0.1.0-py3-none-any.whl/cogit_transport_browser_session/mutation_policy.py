"""Fixed-origin mutation routes with bounded method, body, and header policies."""

from __future__ import annotations

import re
from collections.abc import Mapping
from enum import StrEnum
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict, Field, model_validator

from cogit_transport_browser_session.mutation_body import (
    BodyFieldKind as BodyFieldKind,
)
from cogit_transport_browser_session.mutation_body import (
    BodyFieldPolicy as BodyFieldPolicy,
)
from cogit_transport_browser_session.mutation_body import (
    BodyScalar as BodyScalar,
)
from cogit_transport_browser_session.mutation_body import (
    BodyValue as BodyValue,
)
from cogit_transport_browser_session.mutation_body import (
    serialize_json_body,
    validate_body_fields,
)
from cogit_transport_browser_session.policy import (
    NAME_PATTERN,
    SENSITIVE_QUERY_NAME_PATTERN,
    QueryParameterPolicy,
    QueryValue,
    path_parameter_names,
    validate_origin,
    validate_path_template,
    validate_uuid,
)

if TYPE_CHECKING:
    from cogit_transport_browser_session.models import BrowserMutationRequest

_ALLOWED_CONTENT_TYPES = frozenset(
    {
        "application/json",
        "application/x-www-form-urlencoded",
    }
)
_HEADER_NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")
_CSRF_NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,63}$")
_RESERVED_HEADER_NAMES = frozenset(
    {
        "authorization",
        "connection",
        "content-length",
        "content-type",
        "cookie",
        "host",
        "origin",
        "proxy-authorization",
        "referer",
        "transfer-encoding",
    }
)


class MutationMethod(StrEnum):
    """HTTP methods permitted on a static mutation route."""

    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class StaticHeaderPolicy(BaseModel):
    """One route-owned static request header with a fixed value."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    name: str
    value: str = Field(min_length=1, max_length=4096)

    @model_validator(mode="after")
    def _validate_header(self) -> StaticHeaderPolicy:
        if not _HEADER_NAME_PATTERN.fullmatch(self.name):
            raise ValueError("static header name must be a bounded identifier")
        if self.name.lower() in _RESERVED_HEADER_NAMES:
            raise ValueError("reserved static header names are forbidden")
        if SENSITIVE_QUERY_NAME_PATTERN.search(self.name):
            raise ValueError("credential-like static header names are forbidden")
        if "\r" in self.value or "\n" in self.value:
            raise ValueError("static header value must not contain CRLF")
        return self


class CsrfTokenSourceKind(StrEnum):
    """Package-owned page sources for CSRF tokens."""

    META_NAME = "meta_name"


class CsrfTokenSource(BaseModel):
    """How the bridge reads a CSRF token from the authenticated page."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    kind: CsrfTokenSourceKind = CsrfTokenSourceKind.META_NAME
    name: str

    @model_validator(mode="after")
    def _validate_source(self) -> CsrfTokenSource:
        if self.kind is not CsrfTokenSourceKind.META_NAME:
            raise ValueError("unsupported CSRF token source kind")
        if not _CSRF_NAME_PATTERN.fullmatch(self.name):
            raise ValueError("CSRF source name must be a bounded identifier")
        return self


class MutationPolicyRoute(BaseModel):
    """One immutable mutation route selected from a provider-owned policy."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    name: str
    origin: str
    path_template: str
    method: MutationMethod
    content_type: str | None
    uuid_path_parameters: frozenset[str] = frozenset()
    query_parameters: tuple[QueryParameterPolicy, ...] = ()
    static_headers: tuple[StaticHeaderPolicy, ...] = ()
    csrf_header_name: str | None = None
    csrf_source: CsrfTokenSource | None = None
    body_fields: tuple[BodyFieldPolicy, ...] = ()
    max_body_bytes: int = Field(default=65_536, ge=1, le=1_048_576)

    @model_validator(mode="after")
    def _validate_route(self) -> MutationPolicyRoute:
        if not NAME_PATTERN.fullmatch(self.name):
            raise ValueError("route name must be a bounded identifier")
        validate_origin(self.origin)
        validate_path_template(self.path_template)
        parameters = path_parameter_names(self.path_template)
        if parameters != self.uuid_path_parameters:
            raise ValueError("every dynamic path segment must be declared as a UUID parameter")
        if self.content_type is None and self.body_fields:
            raise ValueError("bodyless mutation routes cannot declare body fields")
        if self.content_type is not None and self.content_type not in _ALLOWED_CONTENT_TYPES:
            raise ValueError("content type is not allowed for mutation routes")
        if self.content_type != "application/json" and any(
            field.kind is BodyFieldKind.OBJECT_ARRAY for field in self.body_fields
        ):
            raise ValueError("form-urlencoded routes cannot declare structured body fields")
        header_names = [header.name.lower() for header in self.static_headers]
        if len(header_names) != len(set(header_names)):
            raise ValueError("static header names must be unique")
        if (self.csrf_header_name is None) != (self.csrf_source is None):
            raise ValueError("csrf_header_name and csrf_source must be declared together")
        if self.csrf_header_name is not None:
            if not _HEADER_NAME_PATTERN.fullmatch(self.csrf_header_name):
                raise ValueError("csrf header name must be a bounded identifier")
            if self.csrf_header_name.lower() in _RESERVED_HEADER_NAMES:
                raise ValueError("reserved CSRF header names are forbidden")
            if self.csrf_header_name.lower() in header_names:
                raise ValueError("csrf header must not duplicate a static header")
        query_names = [parameter.name for parameter in self.query_parameters]
        if len(query_names) != len(set(query_names)):
            raise ValueError("query parameter policies must have unique names")
        body_names = [field.name for field in self.body_fields]
        if len(body_names) != len(set(body_names)):
            raise ValueError("body field policies must have unique names")
        return self

    def render_path(self, path_values: Mapping[str, str]) -> str:
        """Render a route after exact-key and canonical UUID validation."""
        expected = self.uuid_path_parameters
        if set(path_values) != set(expected):
            raise ValueError("path values must exactly match the route parameters")
        rendered = self.path_template
        for name in sorted(expected):
            value = path_values[name]
            validate_uuid(value)
            rendered = rendered.replace(f"{{{name}}}", value)
        return rendered

    def query_items(self, query: Mapping[str, QueryValue]) -> tuple[tuple[str, str], ...]:
        """Validate exact query names and return deterministic encoded items."""
        policies = {parameter.name: parameter for parameter in self.query_parameters}
        unknown = set(query).difference(policies)
        missing = {name for name, policy in policies.items() if policy.required}.difference(query)
        if unknown:
            raise ValueError(f"unknown query parameters: {', '.join(sorted(unknown))}")
        if missing:
            raise ValueError(f"missing query parameters: {', '.join(sorted(missing))}")
        items: list[tuple[str, str]] = []
        for parameter in self.query_parameters:
            if parameter.name not in query:
                continue
            items.extend(
                (parameter.name, value) for value in parameter.render_values(query[parameter.name])
            )
        return tuple(items)

    def validate_body(self, body: Mapping[str, BodyValue]) -> dict[str, BodyValue]:
        """Validate exact body fields and policy-bound scalar or object-array values."""
        return validate_body_fields(self.body_fields, body)

    def serialize_body(self, body: Mapping[str, BodyValue]) -> bytes:
        """Serialize a validated body within the route byte limit."""
        validated = self.validate_body(body)
        if self.content_type is None:
            return b""
        if self.content_type == "application/json":
            encoded = serialize_json_body(validated)
        else:
            from urllib.parse import urlencode

            if any(isinstance(value, tuple) for value in validated.values()):
                raise ValueError("form-urlencoded bodies cannot contain structured values")
            encoded = urlencode(validated).encode("utf-8")
        if len(encoded) > self.max_body_bytes:
            raise ValueError("serialized body exceeds the route byte limit")
        return encoded

    def bridge_headers(self) -> dict[str, str]:
        """Return static headers the bridge may attach to the request."""
        headers = {header.name: header.value for header in self.static_headers}
        if self.content_type is not None:
            headers.setdefault("content-type", self.content_type)
        return headers


class MutationRoutePolicy(BaseModel):
    """An immutable allowlist of exact origins and named mutation routes."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    allowed_origins: frozenset[str]
    routes: tuple[MutationPolicyRoute, ...]

    @model_validator(mode="after")
    def _validate_policy(self) -> MutationRoutePolicy:
        if not self.allowed_origins:
            raise ValueError("at least one exact origin is required")
        if not self.routes:
            raise ValueError("at least one mutation route is required")
        for origin in self.allowed_origins:
            validate_origin(origin)
        names = [route.name for route in self.routes]
        if len(names) != len(set(names)):
            raise ValueError("route names must be unique")
        if any(route.origin not in self.allowed_origins for route in self.routes):
            raise ValueError("every route origin must be explicitly allowed")
        return self

    def select(self, name: str) -> MutationPolicyRoute:
        """Select a route by an exact policy-owned name."""
        for route in self.routes:
            if route.name == name:
                return route
        raise ValueError(f"route {name!r} is not allowed")

    def validate_route(self, route: MutationPolicyRoute) -> MutationPolicyRoute:
        """Reject any route object not selected from this policy instance."""
        if not any(candidate is route for candidate in self.routes):
            raise ValueError(f"route {route.name!r} is not allowed")
        return route

    def resolve_url(self, request: BrowserMutationRequest) -> str:
        """Resolve a mutation request only after exact policy-membership validation."""
        from urllib.parse import urlencode

        route = self.validate_route(request.route)
        path = route.render_path(request.path_values)
        encoded_query = urlencode(route.query_items(request.query))
        return f"{route.origin}{path}" + (f"?{encoded_query}" if encoded_query else "")
