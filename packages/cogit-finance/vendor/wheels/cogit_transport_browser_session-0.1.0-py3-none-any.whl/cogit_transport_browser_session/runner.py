"""Loop-neutral session runner: one worker thread owns one asyncio loop."""

from __future__ import annotations

import asyncio
import inspect
import threading
from collections.abc import Awaitable, Callable
from concurrent.futures import CancelledError as FutureCancelledError
from concurrent.futures import Future
from pathlib import Path
from typing import Protocol, TypeVar, cast

from cogit_transport_browser_session.errors import (
    BrowserSessionError,
    CancellationError,
    ConfigurationError,
    TransportError,
    UnknownOutcomeError,
)
from cogit_transport_browser_session.lifecycle import SessionLifecycle
from cogit_transport_browser_session.locking import ProfileLock, canonicalize_profile_path
from cogit_transport_browser_session.models import (
    BrowserMutationRequest,
    BrowserRequest,
    BrowserResponse,
    SessionState,
)
from cogit_transport_browser_session.runner_shutdown import (
    as_shutdown_cleanup_error,
    cancel_residual_loop_tasks,
    cancel_runner_owned_tasks,
)

T = TypeVar("T")
TSession = TypeVar("TSession", bound="LoopAffineSession")


class LoopAffineSession(Protocol):
    """Session object that must live on the worker event loop."""

    async def request(self, request: BrowserRequest) -> BrowserResponse: ...

    async def mutate(self, request: BrowserMutationRequest) -> BrowserResponse: ...

    async def check_session(self) -> SessionState: ...

    async def aclose(self) -> None: ...


SessionFactory = Callable[[], Awaitable[LoopAffineSession]] | Callable[[], LoopAffineSession]


class SessionRunner:
    """Host-owned runner that bridges short-lived caller loops to one worker."""

    def __init__(
        self,
        *,
        profile_path: str | Path,
        session_factory: Callable[[], Awaitable[TSession]] | Callable[[], TSession],
        join_timeout_seconds: float = 5.0,
    ) -> None:
        if join_timeout_seconds <= 0:
            raise ConfigurationError("join_timeout_seconds must be positive.")
        self.profile_lock = ProfileLock(canonicalize_profile_path(profile_path))
        self._lifecycle = SessionLifecycle(
            self.profile_lock,
            join_timeout_seconds=join_timeout_seconds,
        )
        self._factory = cast(SessionFactory, session_factory)
        self._join_timeout_seconds = join_timeout_seconds
        self._loop: asyncio.AbstractEventLoop | None = None
        self._session: LoopAffineSession | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._startup_error: BaseException | None = None
        self._failed = False
        self._shutdown_scheduled = False
        self._inflight: set[asyncio.Task[object]] = set()
        self._shutdown_cleanup_error: BaseException | None = None
        self.profile_lock.acquire()
        try:
            self._start_worker()
        except BaseException:
            self._lifecycle.release_lock()
            raise

    @property
    def worker_thread(self) -> threading.Thread | None:
        return self._thread

    async def request(self, request: BrowserRequest) -> BrowserResponse:
        return await self._call(lambda session: session.request(request))

    async def mutate(self, request: BrowserMutationRequest) -> BrowserResponse:
        return await self._call(
            lambda session: session.mutate(request),
            unknown_on_cancel=True,
        )

    async def check_session(self) -> SessionState:
        return await self._call(lambda session: session.check_session())

    async def aclose(self) -> None:
        await asyncio.to_thread(self.close)

    def close(self) -> None:
        already_closed = self._lifecycle.closed
        self._lifecycle.shutdown(self._signal_stop)
        cleanup_error = self._shutdown_cleanup_error
        if cleanup_error is not None and not already_closed:
            raise cleanup_error

    def _start_worker(self) -> None:
        thread = threading.Thread(
            target=self._run_worker,
            name="cogit-browser-session-worker",
            daemon=False,
        )
        self._thread = thread
        self._lifecycle.attach_thread(thread)
        thread.start()
        self._wait_until_ready()
        if self._startup_error is not None:
            thread.join(timeout=self._join_timeout_seconds)
            raise self._startup_error

    def _wait_until_ready(self) -> None:
        while not self._ready.wait(timeout=0.05):
            thread = self._thread
            if thread is None or not thread.is_alive():
                self._failed = True
                raise TransportError("Browser-session worker exited during startup.")

    def _run_worker(self) -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        self._loop = loop
        try:
            self._bootstrap_session(loop)
            if self._startup_error is not None:
                return
            loop.run_forever()
        except BaseException as exc:
            if self._startup_error is None:
                self._startup_error = _as_typed_error(exc)
            self._failed = True
        finally:
            self._finish_worker(loop)

    def _bootstrap_session(self, loop: asyncio.AbstractEventLoop) -> None:
        try:
            self._session = loop.run_until_complete(_instantiate_session(self._factory))
        except BaseException as exc:
            self._startup_error = _as_typed_error(exc)
        finally:
            self._ready.set()

    def _finish_worker(self, loop: asyncio.AbstractEventLoop) -> None:
        _close_loop(loop)
        self._loop = None
        self._session = None
        if not self._lifecycle.stopping:
            self._failed = True
            self._lifecycle.release_lock()

    def _signal_stop(self) -> None:
        loop = self._loop
        if loop is None or not loop.is_running():
            return
        try:
            loop.call_soon_threadsafe(self._schedule_shutdown)
        except RuntimeError:
            return

    def _schedule_shutdown(self) -> None:
        if self._shutdown_scheduled:
            return
        self._shutdown_scheduled = True
        asyncio.get_running_loop().create_task(self._shutdown_on_loop())

    async def _shutdown_on_loop(self) -> None:
        loop = asyncio.get_running_loop()
        try:
            await cancel_runner_owned_tasks(self._inflight)
            session = self._session
            self._session = None
            if session is not None:
                try:
                    await session.aclose()
                except BaseException as exc:
                    self._shutdown_cleanup_error = as_shutdown_cleanup_error(exc)
            await cancel_residual_loop_tasks()
        finally:
            loop.stop()

    async def _call(
        self,
        operation: Callable[[LoopAffineSession], Awaitable[T]],
        *,
        unknown_on_cancel: bool = False,
    ) -> T:
        _, loop = self._require_running()
        future = asyncio.run_coroutine_threadsafe(self._invoke(operation), loop)
        return await _await_worker_future(future, unknown_on_cancel=unknown_on_cancel)

    async def _invoke(self, operation: Callable[[LoopAffineSession], Awaitable[T]]) -> T:
        task = asyncio.current_task()
        if task is not None:
            self._inflight.add(task)
        try:
            session, _loop = self._require_running()
            return await operation(session)
        finally:
            if task is not None:
                self._inflight.discard(task)

    def _require_running(self) -> tuple[LoopAffineSession, asyncio.AbstractEventLoop]:
        if self._lifecycle.closed or self._lifecycle.stopping or self._failed:
            raise TransportError("The browser-session worker is not running.")
        session = self._session
        loop = self._loop
        if session is None or loop is None or not loop.is_running():
            raise TransportError("The browser-session worker is not running.")
        return session, loop


async def _instantiate_session(factory: SessionFactory) -> LoopAffineSession:
    created: LoopAffineSession | Awaitable[LoopAffineSession] = factory()
    if inspect.isawaitable(created):
        session = await created
    else:
        session = created
    return _require_session(session)


def _require_session(session: object) -> LoopAffineSession:
    request = getattr(session, "request", None)
    mutate = getattr(session, "mutate", None)
    check_session = getattr(session, "check_session", None)
    aclose = getattr(session, "aclose", None)
    if (
        not callable(request)
        or not callable(mutate)
        or not callable(check_session)
        or not callable(aclose)
    ):
        raise ConfigurationError("session_factory must return a closeable browser session.")
    return cast(LoopAffineSession, session)


async def _await_worker_future(
    future: Future[T],
    *,
    unknown_on_cancel: bool = False,
) -> T:
    """Wait for worker work without cancelling it when the caller is cancelled."""
    done = asyncio.Event()
    caller_loop = asyncio.get_running_loop()

    def _mark_done(_: Future[T]) -> None:
        try:
            caller_loop.call_soon_threadsafe(done.set)
        except RuntimeError:
            return

    future.add_done_callback(_mark_done)
    try:
        await done.wait()
    except asyncio.CancelledError as exc:
        if unknown_on_cancel:
            raise UnknownOutcomeError(
                "mutation caller cancelled while the worker outcome remained unknown"
            ) from exc
        raise CancellationError() from exc
    return _result_from_worker(future, unknown_on_cancel=unknown_on_cancel)


def _result_from_worker(
    future: Future[T],
    *,
    unknown_on_cancel: bool = False,
) -> T:
    try:
        return future.result()
    except BrowserSessionError:
        raise
    except (asyncio.CancelledError, FutureCancelledError) as exc:
        if unknown_on_cancel:
            raise UnknownOutcomeError(
                "mutation worker cancelled while the provider outcome remained unknown"
            ) from exc
        raise CancellationError() from exc
    except Exception as exc:
        raise TransportError(f"Browser-session worker failed: {exc}") from exc


def _as_typed_error(exc: BaseException) -> BaseException:
    if isinstance(exc, BrowserSessionError):
        return exc
    if isinstance(exc, asyncio.CancelledError):
        return CancellationError("Browser-session startup was cancelled.")
    return TransportError(f"Browser-session startup failed: {exc}")


def _close_loop(loop: asyncio.AbstractEventLoop) -> None:
    if loop.is_closed():
        return
    try:
        _cancel_pending(loop)
    finally:
        loop.close()


def _cancel_pending(loop: asyncio.AbstractEventLoop) -> None:
    pending = asyncio.all_tasks(loop)
    if not pending:
        return
    for task in pending:
        task.cancel()
    try:
        loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
    except RuntimeError:
        return
