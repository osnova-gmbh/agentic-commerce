"""Strict public request, response, and session-state models."""

from __future__ import annotations

from collections.abc import Mapping
from enum import StrEnum
from types import MappingProxyType
from typing import Literal, cast

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_serializer,
    field_validator,
    model_validator,
)

from cogit_transport_browser_session.mutation_policy import BodyValue, MutationPolicyRoute
from cogit_transport_browser_session.policy import PolicyRoute, QueryValue

MAX_RESPONSE_BODY_BYTES = 5 * 1024 * 1024
SAFE_RESPONSE_HEADERS = frozenset(
    {
        "content-type",
        "content-length",
        "date",
        "x-grld-request-id",
    }
)


class BrowserRequest(BaseModel):
    """A policy-selected GET request with no caller-controlled transport fields."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        validate_default=True,
    )

    route: PolicyRoute
    path_values: Mapping[str, str] = Field(default_factory=dict, repr=False)
    query: Mapping[str, QueryValue] = Field(default_factory=dict, repr=False)
    timeout_seconds: float = Field(default=30.0, gt=0.0, le=300.0)

    @field_validator("path_values")
    @classmethod
    def _freeze_path_values(cls, value: Mapping[str, str]) -> Mapping[str, str]:
        return MappingProxyType(dict(value))

    @field_validator("query")
    @classmethod
    def _freeze_query(cls, value: Mapping[str, QueryValue]) -> Mapping[str, QueryValue]:
        return MappingProxyType(dict(value))

    @field_serializer("path_values", "query")
    def _serialize_mappings(self, value: Mapping[str, object]) -> dict[str, object]:
        return dict(value)

    @model_validator(mode="after")
    def _validate_against_route(self) -> BrowserRequest:
        self.route.render_path(self.path_values)
        self.route.query_items(self.query)
        return self

    @property
    def method(self) -> Literal["GET"]:
        """The only transport method supported by the contract."""
        return "GET"


class BrowserMutationRequest(BaseModel):
    """A policy-selected mutation request with no caller-controlled transport fields."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        validate_default=True,
    )

    route: MutationPolicyRoute
    path_values: Mapping[str, str] = Field(default_factory=dict, repr=False)
    query: Mapping[str, QueryValue] = Field(default_factory=dict, repr=False)
    body: Mapping[str, BodyValue] = Field(default_factory=dict, repr=False)
    timeout_seconds: float = Field(default=30.0, gt=0.0, le=300.0)

    @field_validator("path_values")
    @classmethod
    def _freeze_path_values(cls, value: Mapping[str, str]) -> Mapping[str, str]:
        return MappingProxyType(dict(value))

    @field_validator("query")
    @classmethod
    def _freeze_query(cls, value: Mapping[str, QueryValue]) -> Mapping[str, QueryValue]:
        return MappingProxyType(dict(value))

    @field_validator("body")
    @classmethod
    def _freeze_body(cls, value: Mapping[str, BodyValue]) -> Mapping[str, BodyValue]:
        return MappingProxyType(
            {
                name: tuple(MappingProxyType(dict(item)) for item in field)
                if isinstance(field, tuple)
                else field
                for name, field in value.items()
            }
        )

    @field_serializer("path_values", "query")
    def _serialize_mappings(self, value: Mapping[str, object]) -> dict[str, object]:
        return dict(value)

    @field_serializer("body")
    def _serialize_body(self, value: Mapping[str, BodyValue]) -> dict[str, object]:
        return {
            name: tuple(dict(item) for item in field) if isinstance(field, tuple) else field
            for name, field in value.items()
        }

    @model_validator(mode="after")
    def _validate_against_route(self) -> BrowserMutationRequest:
        self.route.render_path(self.path_values)
        self.route.query_items(self.query)
        self.route.validate_body(self.body)
        return self

    @property
    def method(self) -> str:
        """The transport method fixed by the selected mutation route."""
        return self.route.method.value


class BrowserResponse(BaseModel):
    """A bounded response exposing only explicitly safe metadata."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        validate_default=True,
    )

    status_code: int = Field(ge=100, le=599)
    headers: Mapping[str, str] = Field(default_factory=dict, repr=False)
    body: bytes | str = Field(repr=False)

    @model_validator(mode="before")
    @classmethod
    def _reject_oversized_body(cls, value: object) -> object:
        if not isinstance(value, Mapping):
            return value
        values = cast(Mapping[object, object], value)
        body = values.get("body")
        if isinstance(body, (bytes, str)):
            size = len(body) if isinstance(body, bytes) else len(body.encode("utf-8"))
            if size > MAX_RESPONSE_BODY_BYTES:
                from cogit_transport_browser_session.errors import ResponseLimitExceeded

                raise ResponseLimitExceeded(
                    limit_bytes=MAX_RESPONSE_BODY_BYTES,
                    observed_bytes=size,
                )
        return values

    @field_validator("headers", mode="before")
    @classmethod
    def _validate_safe_headers(cls, value: object) -> object:
        if not isinstance(value, Mapping):
            return value
        safe: dict[str, str] = {}
        headers = cast(Mapping[object, object], value)
        for raw_name, raw_value in headers.items():
            if not isinstance(raw_name, str) or not isinstance(raw_value, str):
                raise ValueError("response headers must contain string names and values")
            name = raw_name.lower()
            if name not in SAFE_RESPONSE_HEADERS:
                raise ValueError(f"response header {name!r} is not safe to expose")
            if name in safe:
                raise ValueError(f"response header {name!r} is duplicated")
            if "\r" in raw_value or "\n" in raw_value or len(raw_value) > 4096:
                raise ValueError(f"response header {name!r} has an unsafe value")
            safe[name] = raw_value
        return safe

    @field_validator("headers")
    @classmethod
    def _freeze_headers(cls, value: Mapping[str, str]) -> Mapping[str, str]:
        return MappingProxyType(dict(value))

    @field_serializer("headers")
    def _serialize_headers(self, value: Mapping[str, str]) -> dict[str, str]:
        return dict(value)


class SessionState(StrEnum):
    """Safe high-level state returned by provider-owned session probes."""

    READY = "READY"
    AUTH_REQUIRED = "AUTH_REQUIRED"
    FORBIDDEN = "FORBIDDEN"
    UNKNOWN = "UNKNOWN"
