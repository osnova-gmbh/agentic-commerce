"""Package-private redaction for error and representation safety."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Mapping
from typing import NamedTuple, TypeAlias, cast

REDACTED = "***REDACTED***"

Redactable: TypeAlias = object

_MAX_DETECTION_LENGTH = 65_536
_MAX_DECODE_ITERATIONS = 16
_UNSAFE_CATEGORIES = frozenset({"Cc", "Cf", "Cs", "Zl", "Zp"})
_SENSITIVE_KEY_TERMS = r"authorization|cookie|credential|password|secret|session|token"
_SENSITIVE_KEY_TOKEN = rf"[A-Za-z0-9_.-]*(?:{_SENSITIVE_KEY_TERMS})[A-Za-z0-9_.-]*"
_SENSITIVE_KEY_PATTERN = re.compile(_SENSITIVE_KEY_TOKEN, re.IGNORECASE)
_SENSITIVE_HEADER_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9_.-]){_SENSITIVE_KEY_TOKEN}\s*:\s*(?P<value>[^\r\n]+)",
    re.IGNORECASE,
)
_SENSITIVE_ASSIGNMENT_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9_.-]){_SENSITIVE_KEY_TOKEN}\s*=\s*"
    r"(?P<value>\"[^\"]*\"|'[^']*'|[^&#\r\n,;]+)",
    re.IGNORECASE,
)
_BEARER_PATTERN = re.compile(r"\bBearer\s+(?P<value>[^\s,;]+)", re.IGNORECASE)
_BASIC_PATTERN = re.compile(r"\bBasic\s+(?P<value>[A-Za-z0-9+/=]+)", re.IGNORECASE)
_JWT_PATTERN = re.compile(
    r"\b(?P<value>eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)\b",
    re.IGNORECASE,
)
_SENSITIVE_VALUE_PATTERNS = (
    _SENSITIVE_HEADER_PATTERN,
    _SENSITIVE_ASSIGNMENT_PATTERN,
    _BEARER_PATTERN,
    _BASIC_PATTERN,
    _JWT_PATTERN,
)


class _ShadowUnit(NamedTuple):
    character: str
    source_start: int
    source_end: int


def redact_sensitive_text(value: str) -> str:
    """Redact via a decoded shadow while emitting only sanitized source text."""
    shadow = _detection_shadow(value)
    if shadow is None:
        return REDACTED
    shadow_text, units = shadow
    spans = _sensitive_source_spans(shadow_text, units)
    return _escape_controls(_replace_source_spans(value, spans))


def redact_mapping(values: Mapping[str, Redactable]) -> dict[str, Redactable]:
    """Return a recursively sanitized copy suitable for diagnostics."""
    redacted: dict[str, Redactable] = {}
    for key, value in values.items():
        safe_key = _escape_controls(key)
        if _is_sensitive_key(key):
            redacted[safe_key] = REDACTED
        elif isinstance(value, str):
            redacted[safe_key] = redact_sensitive_text(value)
        elif isinstance(value, Mapping):
            mapping = cast(Mapping[object, object], value)
            redacted[safe_key] = redact_mapping(_string_key_mapping(mapping))
        elif isinstance(value, tuple):
            items = cast(tuple[object, ...], value)
            redacted[safe_key] = tuple(_redact_item(item) for item in items)
        elif isinstance(value, list):
            items = cast(list[object], value)
            redacted[safe_key] = [_redact_item(item) for item in items]
        else:
            redacted[safe_key] = value
    return redacted


def _redact_item(value: Redactable) -> Redactable:
    if isinstance(value, str):
        return redact_sensitive_text(value)
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        return redact_mapping(_string_key_mapping(mapping))
    if isinstance(value, tuple):
        items = cast(tuple[object, ...], value)
        return tuple(_redact_item(item) for item in items)
    if isinstance(value, list):
        items = cast(list[object], value)
        return [_redact_item(item) for item in items]
    return value


def _string_key_mapping(value: Mapping[object, object]) -> dict[str, object]:
    return {str(key): item for key, item in value.items()}


def _is_sensitive_key(value: str) -> bool:
    shadow = _detection_shadow(value)
    if shadow is None:
        return True
    return _SENSITIVE_KEY_PATTERN.search(shadow[0]) is not None


def _detection_shadow(value: str) -> tuple[str, tuple[_ShadowUnit, ...]] | None:
    if len(value) > _MAX_DETECTION_LENGTH:
        return None
    units = [_ShadowUnit(character, index, index + 1) for index, character in enumerate(value)]
    for _ in range(_MAX_DECODE_ITERATIONS):
        decoded = _decode_shadow_once(units)
        if decoded is None:
            return None
        if decoded == units:
            return _shadow_result(units)
        if len(decoded) > _MAX_DETECTION_LENGTH:
            return None
        units = decoded
    final_decode = _decode_shadow_once(units)
    if final_decode is None or final_decode != units:
        return None
    return _shadow_result(units)


def _decode_shadow_once(units: list[_ShadowUnit]) -> list[_ShadowUnit] | None:
    decoded: list[_ShadowUnit] = []
    index = 0
    while index < len(units):
        if _is_percent_triplet(units, index):
            encoded_bytes, index = _percent_byte_run(units, index)
            decoded_run = _decode_utf8_run(encoded_bytes)
            if decoded_run is None:
                return None
            decoded.extend(decoded_run)
        else:
            decoded.append(units[index])
            index += 1
    return decoded


def _is_percent_triplet(units: list[_ShadowUnit], index: int) -> bool:
    if index + 2 >= len(units) or units[index].character != "%":
        return False
    hexadecimal = units[index + 1].character + units[index + 2].character
    return re.fullmatch(r"[0-9A-Fa-f]{2}", hexadecimal) is not None


def _percent_byte_run(
    units: list[_ShadowUnit],
    index: int,
) -> tuple[list[tuple[int, int, int]], int]:
    encoded: list[tuple[int, int, int]] = []
    while _is_percent_triplet(units, index):
        first, second, third = units[index : index + 3]
        byte = int(second.character + third.character, 16)
        encoded.append((byte, first.source_start, third.source_end))
        index += 3
    return encoded, index


def _decode_utf8_run(encoded: list[tuple[int, int, int]]) -> list[_ShadowUnit] | None:
    decoded: list[_ShadowUnit] = []
    index = 0
    while index < len(encoded):
        width = _utf8_width(encoded[index][0])
        if width is None or index + width > len(encoded):
            return None
        chunk = bytes(item[0] for item in encoded[index : index + width])
        try:
            character = chunk.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            return None
        if len(character) != 1:
            return None
        decoded.append(_ShadowUnit(character, encoded[index][1], encoded[index + width - 1][2]))
        index += width
    return decoded


def _utf8_width(first_byte: int) -> int | None:
    if first_byte <= 0x7F:
        return 1
    if 0xC2 <= first_byte <= 0xDF:
        return 2
    if 0xE0 <= first_byte <= 0xEF:
        return 3
    if 0xF0 <= first_byte <= 0xF4:
        return 4
    return None


def _shadow_result(units: list[_ShadowUnit]) -> tuple[str, tuple[_ShadowUnit, ...]]:
    safe_units = tuple(unit for unit in units if not _is_unsafe_character(unit.character))
    return "".join(unit.character for unit in safe_units), safe_units


def _sensitive_source_spans(
    shadow: str,
    units: tuple[_ShadowUnit, ...],
) -> tuple[tuple[int, int], ...]:
    spans: list[tuple[int, int]] = []
    for pattern in _SENSITIVE_VALUE_PATTERNS:
        for match in pattern.finditer(shadow):
            start, end = match.span("value")
            if start < end:
                spans.append((units[start].source_start, units[end - 1].source_end))
    return _merge_spans(spans)


def _merge_spans(spans: list[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    merged: list[tuple[int, int]] = []
    for start, end in sorted(spans):
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return tuple(merged)


def _replace_source_spans(value: str, spans: tuple[tuple[int, int], ...]) -> str:
    parts: list[str] = []
    cursor = 0
    for start, end in spans:
        parts.extend((value[cursor:start], REDACTED))
        cursor = end
    parts.append(value[cursor:])
    return "".join(parts)


def _escape_controls(value: str) -> str:
    return "".join(_escape_character(character) for character in value)


def _escape_character(character: str) -> str:
    if not _is_unsafe_character(character):
        return character
    codepoint = ord(character)
    if codepoint <= 0xFF:
        return f"\\x{codepoint:02x}"
    if codepoint <= 0xFFFF:
        return f"\\u{codepoint:04x}"
    return f"\\U{codepoint:08x}"


def _is_unsafe_character(character: str) -> bool:
    return unicodedata.category(character) in _UNSAFE_CATEGORIES
