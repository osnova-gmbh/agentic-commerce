"""Package-owned streaming GET bridge. Callers never supply JavaScript."""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from typing import cast
from urllib.parse import urlsplit

from cogit_transport_browser_session.errors import (
    MalformedResponseError,
    ResponseLimitExceeded,
    raise_for_authentication,
)
from cogit_transport_browser_session.models import (
    MAX_RESPONSE_BODY_BYTES,
    SAFE_RESPONSE_HEADERS,
    BrowserRequest,
    BrowserResponse,
)
from cogit_transport_browser_session.policy import RoutePolicy

FETCH_BRIDGE_SOURCE = """
async ({ url, maxBytes }) => {
  const controller = new AbortController();
  const response = await fetch(url, {
    method: "GET",
    cache: "no-store",
    credentials: "include",
    redirect: "manual",
    signal: controller.signal,
  });
  const headers = {};
  for (const name of ["content-type", "content-length", "date", "x-grld-request-id"]) {
    const value = response.headers.get(name);
    if (value) {
      headers[name] = value;
    }
  }
  const reader = response.body ? response.body.getReader() : null;
  const chunks = [];
  let received = 0;
  let overflow = false;
  if (reader) {
    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        break;
      }
      received += value.byteLength;
      if (received > maxBytes) {
        overflow = true;
        controller.abort();
        await reader.cancel();
        break;
      }
      chunks.push(value);
    }
  }
  const body = [];
  if (!overflow) {
    for (const chunk of chunks) {
      body.push(...chunk);
    }
  }
  return {
    status: response.status,
    headers,
    location: response.headers.get("location"),
    body,
    overflow,
    received,
  };
}
"""

_LOGIN_PATH_MARKERS = ("/sign-in", "/login", "/authenticate")
_LOGIN_HTML_MARKERS = ("sign-in", "login", "authenticate")


def resolve_request_url(policy: RoutePolicy, request: BrowserRequest) -> str:
    """Resolve a policy-owned GET URL. Callers cannot supply a raw URL."""
    url = policy.resolve_url(request)
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != urlsplit(request.route.origin).netloc:
        raise MalformedResponseError("resolved request is not same-origin")
    if parsed.query and any(char in parsed.path for char in "?#"):
        raise MalformedResponseError("resolved path contains a query delimiter")
    return url


def assemble_limited_body(
    chunks: Iterable[bytes],
    *,
    limit_bytes: int = MAX_RESPONSE_BODY_BYTES,
    declared_length: int | None = None,
) -> bytes:
    """Count streamed bytes and fail before decoding when the limit is exceeded."""
    del declared_length
    collected = bytearray()
    for chunk in chunks:
        collected.extend(chunk)
        if len(collected) > limit_bytes:
            raise ResponseLimitExceeded(limit_bytes=limit_bytes, observed_bytes=len(collected))
    return bytes(collected)


def safe_headers(headers: Mapping[str, str]) -> dict[str, str]:
    """Keep only the public response-header allowlist."""
    safe: dict[str, str] = {}
    for raw_name, raw_value in headers.items():
        name = raw_name.lower()
        if name in SAFE_RESPONSE_HEADERS:
            safe[name] = raw_value
    return safe


def parse_content_length(headers: Mapping[str, str]) -> int | None:
    raw = headers.get("content-length")
    if raw is None:
        return None
    try:
        parsed = int(raw)
    except ValueError:
        return None
    return parsed if parsed >= 0 else None


def is_login_redirect(status_code: int, location: str | None, origin: str) -> bool:
    if status_code not in {301, 302, 303, 307, 308} or not location:
        return False
    lowered = location.lower()
    return any(marker in lowered for marker in _LOGIN_PATH_MARKERS) and (
        lowered.startswith("/") or lowered.startswith(origin.lower())
    )


def is_login_html(status_code: int, headers: Mapping[str, str], body: bytes) -> bool:
    if status_code != 200:
        return False
    content_type = headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if content_type != "text/html":
        return False
    sample = body[:2048].decode("utf-8", errors="ignore").lower()
    return any(marker in sample for marker in _LOGIN_HTML_MARKERS)


def decode_body(body: bytes, headers: Mapping[str, str]) -> bytes | str:
    """Decode text only after the byte limit has already been enforced."""
    content_type = headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if content_type.startswith("text/") or content_type.endswith("json"):
        return body.decode("utf-8")
    return body


def build_browser_response(
    *,
    status_code: int,
    headers: Mapping[str, str],
    body: bytes,
    location: str | None,
    origin: str,
    overflow: bool,
    observed_bytes: int | None = None,
) -> BrowserResponse:
    """Map a raw fetch result onto the public safe response surface."""
    if overflow:
        raise ResponseLimitExceeded(
            limit_bytes=MAX_RESPONSE_BODY_BYTES,
            observed_bytes=observed_bytes,
        )
    if len(body) > MAX_RESPONSE_BODY_BYTES:
        raise ResponseLimitExceeded(
            limit_bytes=MAX_RESPONSE_BODY_BYTES,
            observed_bytes=len(body),
        )
    safe = safe_headers(headers)
    login_redirect = is_login_redirect(status_code, location, origin)
    login_html = is_login_html(status_code, safe, body)
    raise_for_authentication(
        status_code,
        verified_login_redirect=login_redirect,
        verified_login_html=login_html,
        request_id=safe.get("x-grld-request-id"),
    )
    return BrowserResponse(
        status_code=status_code,
        headers=safe,
        body=decode_body(body, safe),
    )


def _bytes_from_parts(parts: list[object]) -> Iterator[bytes]:
    for part in parts:
        if not isinstance(part, int) or isinstance(part, bool) or part < 0 or part > 255:
            raise MalformedResponseError("fetch bridge returned a malformed body")
        yield bytes((part,))


def parse_bridge_payload(payload: Mapping[str, object], *, origin: str) -> BrowserResponse:
    """Interpret the fixed bridge return value without exposing raw cookies."""
    overflow = bool(payload.get("overflow"))
    raw_body = payload.get("body", [])
    if overflow:
        observed = payload.get("received")
        observed_bytes = observed if isinstance(observed, int) else None
        raise ResponseLimitExceeded(
            limit_bytes=MAX_RESPONSE_BODY_BYTES,
            observed_bytes=observed_bytes,
        )
    if not isinstance(raw_body, list):
        raise MalformedResponseError("fetch bridge returned a malformed body")
    parts = cast(list[object], raw_body)
    body = assemble_limited_body(_bytes_from_parts(parts))
    headers_obj = payload.get("headers", {})
    if not isinstance(headers_obj, Mapping):
        raise MalformedResponseError("fetch bridge returned malformed headers")
    headers = {
        str(name): str(value) for name, value in cast(Mapping[object, object], headers_obj).items()
    }
    status = payload.get("status")
    if not isinstance(status, int):
        raise MalformedResponseError("fetch bridge returned a malformed status")
    location = payload.get("location")
    return build_browser_response(
        status_code=status,
        headers=headers,
        body=body,
        location=location if isinstance(location, str) else None,
        origin=origin,
        overflow=False,
        observed_bytes=len(body),
    )
