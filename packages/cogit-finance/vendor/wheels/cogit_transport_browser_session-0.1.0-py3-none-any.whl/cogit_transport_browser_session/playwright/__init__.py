"""Optional Playwright persistent-session backend."""

from cogit_transport_browser_session.playwright.chrome import (
    BrowserMode,
    ChromeHandle,
    ChromeLauncher,
)
from cogit_transport_browser_session.playwright.context import AttachedPage, PlaywrightConnector
from cogit_transport_browser_session.playwright.dependencies import require_playwright_extra
from cogit_transport_browser_session.playwright.session import (
    PlaywrightPersistentSession,
    open_persistent_session,
)

__all__ = [
    "AttachedPage",
    "BrowserMode",
    "ChromeHandle",
    "ChromeLauncher",
    "PlaywrightConnector",
    "PlaywrightPersistentSession",
    "open_persistent_session",
    "require_playwright_extra",
]
