"""Absolute profile-path validation against host-supplied forbidden roots."""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from cogit_transport_browser_session.errors import ConfigurationError
from cogit_transport_browser_session.locking import canonicalize_profile_path


def validate_profile_path(
    profile_path: str | Path,
    forbidden_roots: Sequence[str | Path],
) -> Path:
    """Resolve an absolute profile path and reject forbidden descendants."""
    if not forbidden_roots:
        raise ConfigurationError("At least one forbidden profile root is required.")
    canonical = canonicalize_profile_path(profile_path)
    for raw_root in forbidden_roots:
        root = Path(raw_root).expanduser().resolve()
        if canonical == root or root in canonical.parents:
            raise ConfigurationError(
                "Browser profile path must not be inside a host-forbidden root."
            )
    return canonical


def validate_chrome_executable(chrome_executable: str | Path) -> Path:
    """Require an absolute host-supplied Chrome executable path."""
    expanded = Path(chrome_executable).expanduser()
    if not expanded.is_absolute():
        raise ConfigurationError("Chrome executable path must be an absolute path.")
    return expanded.resolve()
