"""Bounded host Chrome stderr collection with fail-closed profile redaction."""

from __future__ import annotations

import asyncio
import os
import re
from contextlib import suppress
from pathlib import Path

from cogit_transport_browser_session._redaction import redact_sensitive_text

_USER_DATA_DIR_PATTERN = re.compile(
    r'--user-data-dir=(?:"[^"\r\n]*"|\'[^\']*\'|[^\r\n]*)',
)
_DIAGNOSTIC_LIMIT = 512


class ChromeStderrCollector:
    """Retain a bounded tail of host Chrome stderr for safe failure diagnostics."""

    def __init__(
        self,
        process: asyncio.subprocess.Process,
        *,
        profile_path: Path | None = None,
        limit: int = 4096,
        case_insensitive_path_redaction: bool | None = None,
    ) -> None:
        self._process = process
        self._profile_variants = (
            profile_path_variants(profile_path) if profile_path is not None else ()
        )
        self._case_insensitive_path_redaction = case_insensitive_path_redaction
        self._limit = limit
        self._buffer = bytearray()
        self._task: asyncio.Task[None] | None = None

    @property
    def active(self) -> bool:
        return self._task is not None and not self._task.done()

    def start(self) -> None:
        if self._process.stderr is None or self._task is not None:
            return
        self._task = asyncio.create_task(self._collect())

    async def stop(self) -> None:
        if self._task is None:
            return
        if not self._task.done():
            try:
                await asyncio.wait_for(asyncio.shield(self._task), timeout=2.0)
            except TimeoutError:
                self._task.cancel()
                with suppress(asyncio.CancelledError):
                    await self._task
        self._task = None

    async def _collect(self) -> None:
        assert self._process.stderr is not None
        while True:
            chunk = await self._process.stderr.read(512)
            if not chunk:
                return
            self._buffer.extend(chunk)
            overflow = len(self._buffer) - self._limit
            if overflow > 0:
                del self._buffer[:overflow]

    def snapshot(self) -> str | None:
        if not self._buffer:
            return None
        text = bytes(self._buffer).decode("utf-8", errors="replace")
        sanitized = sanitize_diagnostic(
            text,
            profile_variants=self._profile_variants,
            case_insensitive_paths=self._case_insensitive_path_redaction,
        )
        if not sanitized:
            return None
        return sanitized[:_DIAGNOSTIC_LIMIT]


def profile_path_variants(profile_path: Path) -> tuple[str, ...]:
    candidates: set[str] = set()
    for path in (profile_path, profile_path.resolve()):
        text = str(path)
        candidates.add(text)
        candidates.add(text.replace("\\", "/"))
        candidates.add(text.replace("/", "\\"))
    return tuple(sorted((variant for variant in candidates if variant), key=len, reverse=True))


def replace_profile_variants(
    text: str,
    variants: tuple[str, ...],
    *,
    case_insensitive: bool | None = None,
) -> str:
    if case_insensitive is None:
        case_insensitive = os.name == "nt"
    result = text
    for variant in variants:
        if not variant:
            continue
        if case_insensitive:
            result = re.sub(re.escape(variant), "[REDACTED]", result, flags=re.IGNORECASE)
        else:
            result = result.replace(variant, "[REDACTED]")
    return result


def sanitize_diagnostic(
    text: str,
    *,
    profile_variants: tuple[str, ...],
    case_insensitive_paths: bool | None = None,
) -> str:
    cleaned = _USER_DATA_DIR_PATTERN.sub("--user-data-dir=[REDACTED]", text)
    cleaned = replace_profile_variants(
        cleaned,
        profile_variants,
        case_insensitive=case_insensitive_paths,
    )
    sanitized = redact_sensitive_text(cleaned).strip()
    return replace_profile_variants(
        sanitized,
        profile_variants,
        case_insensitive=case_insensitive_paths,
    )
