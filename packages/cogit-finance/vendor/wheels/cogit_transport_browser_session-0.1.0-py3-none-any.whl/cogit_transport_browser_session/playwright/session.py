"""Loop-affine Playwright session and host-facing factory."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from pathlib import Path
from typing import Literal

from cogit_transport_browser_session.errors import (
    ConfigurationError,
    MutationTimeoutError,
    TransportError,
)
from cogit_transport_browser_session.models import (
    MAX_RESPONSE_BODY_BYTES,
    BrowserMutationRequest,
    BrowserRequest,
    BrowserResponse,
    SessionState,
)
from cogit_transport_browser_session.mutation_policy import MutationRoutePolicy
from cogit_transport_browser_session.playwright.chrome import (
    BrowserMode,
    ChromeHandle,
    ChromeLauncher,
    HostChromeLauncher,
)
from cogit_transport_browser_session.playwright.context import (
    AttachedPage,
    CdpPlaywrightConnector,
    PlaywrightConnector,
)
from cogit_transport_browser_session.playwright.dependencies import require_playwright_extra
from cogit_transport_browser_session.playwright.fetch_bridge import resolve_request_url
from cogit_transport_browser_session.playwright.profile import (
    validate_chrome_executable,
    validate_profile_path,
)
from cogit_transport_browser_session.policy import RoutePolicy
from cogit_transport_browser_session.protocols import (
    SessionProbe,
    SessionSuccessPredicate,
    check_session_state,
)
from cogit_transport_browser_session.runner import SessionRunner


class PlaywrightPersistentSession:
    """Worker-loop session that owns Chrome, CDP, and one origin page."""

    def __init__(
        self,
        *,
        chrome: ChromeLauncher,
        connector: PlaywrightConnector,
        executable: Path,
        profile_path: Path,
        policy: RoutePolicy,
        origin: str,
        mode: BrowserMode,
        mutation_policy: MutationRoutePolicy | None = None,
        probe: SessionProbe | None = None,
        success_predicate: SessionSuccessPredicate | None = None,
    ) -> None:
        self._chrome = chrome
        self._connector = connector
        self._executable = executable
        self._profile_path = profile_path
        self._policy = policy
        self._mutation_policy = mutation_policy
        self._origin = origin
        self._mode: BrowserMode = mode
        self._probe = probe
        self._success_predicate = success_predicate
        self._handle: ChromeHandle | None = None
        self._page: AttachedPage | None = None

    async def start(self) -> PlaywrightPersistentSession:
        handle = await self._chrome.start(
            executable=self._executable,
            profile_path=self._profile_path,
            mode=self._mode,
        )
        self._handle = handle
        try:
            self._page = await self._connector.attach(
                handle.cdp_endpoint,
                origin=self._origin,
                mode=self._mode,
                mutation_policy=self._mutation_policy,
            )
        except BaseException:
            await handle.aclose()
            self._handle = None
            raise
        return self

    async def request(self, request: BrowserRequest) -> BrowserResponse:
        page = self._require_page()
        url = resolve_request_url(self._policy, request)
        try:
            async with asyncio.timeout(request.timeout_seconds):
                return await page.fetch(url, max_bytes=MAX_RESPONSE_BODY_BYTES)
        except TimeoutError as exc:
            raise TransportError(
                "The browser read request timed out.",
                retryable=True,
            ) from exc

    async def mutate(self, request: BrowserMutationRequest) -> BrowserResponse:
        if self._mutation_policy is None:
            raise ConfigurationError("Playwright session has no mutation policy configured.")
        page = self._require_page()
        try:
            async with asyncio.timeout(request.timeout_seconds):
                return await page.mutate(
                    self._mutation_policy,
                    request,
                    max_bytes=MAX_RESPONSE_BODY_BYTES,
                )
        except TimeoutError as exc:
            raise MutationTimeoutError() from exc

    async def check_session(self) -> SessionState:
        if self._probe is None or self._success_predicate is None:
            return SessionState.UNKNOWN
        return await check_session_state(
            self._probe,
            success_predicate=self._success_predicate,
        )

    async def aclose(self) -> None:
        page = self._page
        handle = self._handle
        self._page = None
        self._handle = None
        try:
            if page is not None:
                await page.aclose()
        finally:
            if handle is not None:
                await handle.aclose()

    def _require_page(self) -> AttachedPage:
        if self._page is None:
            raise ConfigurationError("Playwright session is not started.")
        return self._page


def open_persistent_session(
    *,
    profile_path: str | Path,
    chrome_executable: str | Path,
    policy: RoutePolicy,
    mode: Literal["headed", "headless"],
    forbidden_roots: Sequence[str | Path],
    mutation_policy: MutationRoutePolicy | None = None,
    chrome_launcher: ChromeLauncher | None = None,
    playwright_connector: PlaywrightConnector | None = None,
    probe: SessionProbe | None = None,
    success_predicate: SessionSuccessPredicate | None = None,
    join_timeout_seconds: float = 5.0,
    require_optional_deps: bool = True,
) -> SessionRunner:
    """Open a host-owned persistent session on the C-001 worker loop."""
    if require_optional_deps:
        require_playwright_extra()
    if mode not in {"headed", "headless"}:
        raise ConfigurationError("mode must be 'headed' or 'headless'.")
    if len(policy.allowed_origins) != 1:
        raise ConfigurationError("Playwright sessions require exactly one allowed origin.")
    if mutation_policy is not None:
        if mutation_policy.allowed_origins != policy.allowed_origins:
            raise ConfigurationError("mutation and read policies must share the same origin.")
        if len(mutation_policy.allowed_origins) != 1:
            raise ConfigurationError("Playwright sessions require exactly one allowed origin.")
    origin = next(iter(policy.allowed_origins))
    canonical_profile = validate_profile_path(profile_path, forbidden_roots)
    executable = validate_chrome_executable(chrome_executable)
    launcher = chrome_launcher or HostChromeLauncher()
    connector = playwright_connector or CdpPlaywrightConnector()

    async def factory() -> PlaywrightPersistentSession:
        session = PlaywrightPersistentSession(
            chrome=launcher,
            connector=connector,
            executable=executable,
            profile_path=canonical_profile,
            policy=policy,
            origin=origin,
            mode=mode,
            mutation_policy=mutation_policy,
            probe=probe,
            success_predicate=success_predicate,
        )
        return await session.start()

    return SessionRunner(
        profile_path=canonical_profile,
        session_factory=factory,
        join_timeout_seconds=join_timeout_seconds,
    )
