"""Lazy optional-dependency loading for the Playwright backend."""

from __future__ import annotations

import importlib
from types import ModuleType

from cogit_transport_browser_session.errors import ConfigurationError

_PLAYWRIGHT_REQUIRED = (
    "Playwright support requires the cogit-transport-browser-session[playwright] extra."
)


def load_optional_module(name: str) -> ModuleType:
    """Import an optional extra module or raise a typed configuration error."""
    try:
        return importlib.import_module(name)
    except ModuleNotFoundError as exc:
        raise ConfigurationError(_PLAYWRIGHT_REQUIRED) from exc


def require_playwright_extra() -> None:
    """Fail closed when Playwright or filelock is not installed."""
    load_optional_module("playwright")
    load_optional_module("filelock")
