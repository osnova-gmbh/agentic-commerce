"""Package-owned streaming mutation bridge. Callers never supply JavaScript."""

from __future__ import annotations

from collections.abc import Mapping
from urllib.parse import urlsplit

from cogit_transport_browser_session.errors import (
    MalformedResponseError,
    MutationTimeoutError,
    raise_for_mutation_status,
)
from cogit_transport_browser_session.models import BrowserMutationRequest, BrowserResponse
from cogit_transport_browser_session.mutation_policy import MutationRoutePolicy
from cogit_transport_browser_session.playwright.fetch_bridge import parse_bridge_payload

MUTATION_BRIDGE_SOURCE = """
async ({ url, method, headers, body, maxBytes, timeoutMs, csrfHeaderName, csrfSourceName }) => {
  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), timeoutMs);
  const requestHeaders = { ...headers };
  if (csrfHeaderName && csrfSourceName) {
    const meta = document.querySelector(`meta[name="${csrfSourceName}"]`);
    const token = meta ? meta.getAttribute("content") : null;
    if (!token) {
      clearTimeout(timeoutHandle);
      return {
        status: 0,
        headers: {},
        location: null,
        body: [],
        overflow: false,
        received: 0,
        csrfMissing: true,
      };
    }
    requestHeaders[csrfHeaderName] = token;
  }
  let response;
  try {
    response = await fetch(url, {
      method,
      credentials: "include",
      redirect: "manual",
      signal: controller.signal,
      headers: requestHeaders,
      body: body.length ? new Uint8Array(body) : undefined,
    });
  } catch (error) {
    if (controller.signal.aborted) {
      return {
        status: 0,
        headers: {},
        location: null,
        body: [],
        overflow: false,
        received: 0,
        csrfMissing: false,
        timedOut: true,
      };
    }
    throw error;
  } finally {
    clearTimeout(timeoutHandle);
  }
  const safeHeaders = {};
  for (const name of ["content-type", "content-length", "date", "x-grld-request-id"]) {
    const value = response.headers.get(name);
    if (value) {
      safeHeaders[name] = value;
    }
  }
  const reader = response.body ? response.body.getReader() : null;
  const chunks = [];
  let received = 0;
  let overflow = false;
  if (reader) {
    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        break;
      }
      received += value.byteLength;
      if (received > maxBytes) {
        overflow = true;
        controller.abort();
        await reader.cancel();
        break;
      }
      chunks.push(value);
    }
  }
  const bodyBytes = [];
  if (!overflow) {
    for (const chunk of chunks) {
      bodyBytes.push(...chunk);
    }
  }
  return {
    status: response.status,
    headers: safeHeaders,
    location: response.headers.get("location"),
    body: bodyBytes,
    overflow,
    received,
    csrfMissing: false,
    timedOut: false,
  };
}
"""


def resolve_mutation_url(policy: MutationRoutePolicy, request: BrowserMutationRequest) -> str:
    """Resolve a policy-owned mutation URL. Callers cannot supply a raw URL."""
    url = policy.resolve_url(request)
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != urlsplit(request.route.origin).netloc:
        raise MalformedResponseError("resolved mutation is not same-origin")
    if parsed.query and any(char in parsed.path for char in "?#"):
        raise MalformedResponseError("resolved path contains a query delimiter")
    return url


def build_mutation_bridge_args(
    policy: MutationRoutePolicy,
    request: BrowserMutationRequest,
    *,
    max_bytes: int,
) -> dict[str, object]:
    """Build fixed bridge arguments from a validated mutation request."""
    route = policy.validate_route(request.route)
    url = resolve_mutation_url(policy, request)
    body_bytes = list(route.serialize_body(request.body))
    headers = route.bridge_headers()
    csrf_source = route.csrf_source
    return {
        "url": url,
        "method": route.method.value,
        "headers": headers,
        "body": body_bytes,
        "maxBytes": max_bytes,
        "timeoutMs": int(request.timeout_seconds * 1000),
        "csrfHeaderName": route.csrf_header_name,
        "csrfSourceName": None if csrf_source is None else csrf_source.name,
    }


def parse_mutation_bridge_payload(
    payload: Mapping[str, object],
    *,
    origin: str,
) -> BrowserResponse:
    """Interpret the fixed mutation bridge return value."""
    if bool(payload.get("csrfMissing")):
        raise MalformedResponseError("required CSRF token was unavailable in the page context")
    if bool(payload.get("timedOut")):
        raise MutationTimeoutError()
    response = parse_bridge_payload(payload, origin=origin)
    safe_request_id = dict(response.headers).get("x-grld-request-id")
    raise_for_mutation_status(response.status_code, request_id=safe_request_id)
    return response
