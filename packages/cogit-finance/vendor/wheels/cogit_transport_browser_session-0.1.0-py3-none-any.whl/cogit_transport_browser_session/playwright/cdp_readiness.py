"""Loopback CDP HTTP readiness probing for host Chrome startup."""

from __future__ import annotations

import asyncio
import json
from contextlib import suppress
from typing import Any, cast
from urllib.parse import urlsplit

from cogit_transport_browser_session.errors import TransportError
from cogit_transport_browser_session.playwright.chrome_stderr import ChromeStderrCollector

_CDP_LOOPBACK_HOST = "127.0.0.1"
_CDP_VERSION_PATH = "/json/version"
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "[::1]", "::1"})
_MAX_HEADER_BYTES = 16_384
_MAX_CDP_JSON_BODY_BYTES = 64 * 1024

__all__ = ["ChromeStderrCollector", "probe_cdp_version", "wait_for_cdp_endpoint"]


async def wait_for_cdp_endpoint(
    port: int,
    process: asyncio.subprocess.Process,
    *,
    stderr_collector: ChromeStderrCollector | None = None,
    timeout_seconds: float = 15.0,
) -> None:
    """Wait until loopback CDP serves a usable /json/version response."""
    deadline = asyncio.get_running_loop().time() + timeout_seconds
    while asyncio.get_running_loop().time() < deadline:
        if process.returncode is not None:
            raise _chrome_exit_error(process, stderr_collector)
        if await probe_cdp_version(port):
            return
        await asyncio.sleep(0.05)
    raise _readiness_timeout_error(process, stderr_collector, timeout_seconds)


async def probe_cdp_version(port: int) -> bool:
    """Return True when loopback CDP exposes a usable webSocketDebuggerUrl."""
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(_CDP_LOOPBACK_HOST, port),
            timeout=1.0,
        )
    except (TimeoutError, OSError):
        return False
    try:
        request = (
            f"GET {_CDP_VERSION_PATH} HTTP/1.1\r\n"
            f"Host: {_CDP_LOOPBACK_HOST}:{port}\r\n"
            "Connection: close\r\n\r\n"
        )
        writer.write(request.encode("ascii"))
        await writer.drain()
        body = await _read_http_body(reader, timeout_seconds=2.0)
    except (TimeoutError, OSError):
        return False
    finally:
        writer.close()
        with suppress(OSError):
            await writer.wait_closed()
    if body is None:
        return False
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        return False
    return _is_usable_cdp_version(payload, expected_port=port)


async def _read_http_body(
    reader: asyncio.StreamReader,
    *,
    timeout_seconds: float,
) -> bytes | None:
    header_buffer = bytearray()
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_seconds
    while b"\r\n\r\n" not in header_buffer:
        remaining = deadline - loop.time()
        if remaining <= 0:
            return None
        chunk = await asyncio.wait_for(reader.read(4096), timeout=remaining)
        if not chunk:
            return None
        header_buffer.extend(chunk)
        if len(header_buffer) > _MAX_HEADER_BYTES:
            return None

    separator = header_buffer.index(b"\r\n\r\n")
    header_block = header_buffer[:separator].decode("ascii", errors="ignore")
    status_line = header_block.split("\r\n", 1)[0]
    if " 200 " not in status_line:
        return None

    content_length = _parse_content_length(header_block)
    body = bytes(header_buffer[separator + 4 :])
    if content_length is None:
        if len(body) > _MAX_CDP_JSON_BODY_BYTES:
            return None
        return body

    if content_length > _MAX_CDP_JSON_BODY_BYTES:
        return None

    if len(body) > content_length:
        return None

    while len(body) < content_length:
        remaining = deadline - loop.time()
        if remaining <= 0:
            return None
        chunk = await asyncio.wait_for(
            reader.read(min(content_length - len(body), 4096)),
            timeout=remaining,
        )
        if not chunk:
            return None
        body += chunk
        if len(body) > _MAX_CDP_JSON_BODY_BYTES:
            return None
    return body[:content_length]


def _parse_content_length(header_block: str) -> int | None:
    for line in header_block.split("\r\n")[1:]:
        name, _, value = line.partition(":")
        if name.strip().lower() == "content-length":
            try:
                length = int(value.strip())
            except ValueError:
                return None
            if length < 0:
                return None
            return length
    return None


def _is_usable_cdp_version(payload: Any, *, expected_port: int) -> bool:
    if not isinstance(payload, dict):
        return False
    data = cast(dict[str, object], payload)
    ws_url = data.get("webSocketDebuggerUrl")
    if not isinstance(ws_url, str) or not ws_url:
        return False
    try:
        parsed = urlsplit(ws_url)
    except ValueError:
        return False
    if parsed.scheme != "ws":
        return False
    host = parsed.hostname
    if host not in _LOOPBACK_HOSTS:
        return False
    try:
        ws_port = parsed.port
    except ValueError:
        return False
    if ws_port is None or ws_port != expected_port:
        return False
    return bool(parsed.path)


def _format_diagnostic(
    process: asyncio.subprocess.Process,
    stderr_collector: ChromeStderrCollector | None,
) -> str:
    parts: list[str] = []
    if process.returncode is not None:
        parts.append(f"exit_code={process.returncode}")
    stderr = None if stderr_collector is None else stderr_collector.snapshot()
    if stderr:
        parts.append(f"stderr={stderr}")
    return "; ".join(parts)


def _chrome_exit_error(
    process: asyncio.subprocess.Process,
    stderr_collector: ChromeStderrCollector | None,
) -> TransportError:
    detail = _format_diagnostic(process, stderr_collector)
    message = "Host Chrome exited before CDP became ready."
    if detail:
        message = f"{message} ({detail})"
    return TransportError(message)


def _readiness_timeout_error(
    process: asyncio.subprocess.Process,
    stderr_collector: ChromeStderrCollector | None,
    timeout_seconds: float,
) -> TransportError:
    detail = _format_diagnostic(process, stderr_collector)
    message = f"Host Chrome did not become CDP-ready within {timeout_seconds:.1f}s."
    if detail:
        message = f"{message} ({detail})"
    return TransportError(message)
