"""Playwright CDP attach and same-origin page ownership."""

from __future__ import annotations

from contextlib import suppress
from typing import Any, Protocol, cast

from cogit_transport_browser_session.errors import (
    AuthenticationRequired,
    BrowserSessionError,
    ConfigurationError,
    TransportError,
    UnknownOutcomeError,
)
from cogit_transport_browser_session.models import BrowserMutationRequest, BrowserResponse
from cogit_transport_browser_session.mutation_policy import MutationRoutePolicy
from cogit_transport_browser_session.playwright.dependencies import load_optional_module
from cogit_transport_browser_session.playwright.fetch_bridge import (
    FETCH_BRIDGE_SOURCE,
    parse_bridge_payload,
)
from cogit_transport_browser_session.playwright.mutation_bridge import (
    MUTATION_BRIDGE_SOURCE,
    build_mutation_bridge_args,
    parse_mutation_bridge_payload,
)

_HEADLESS_LOGIN_SETTLE_TIMEOUT_MS = 10_000.0
_DEFAULT_LOGIN_CLICK_TIMEOUT_MS = 5_000.0
_MAX_LOGIN_CLICK_TIMEOUT_MS = 30_000.0
_MAX_LOGIN_CLICK_SELECTOR_LENGTH = 256
_MAX_LOGIN_CLICK_ATTEMPTS = 3


class AttachedPage(Protocol):
    async def fetch(self, url: str, *, max_bytes: int) -> BrowserResponse: ...

    async def mutate(
        self,
        policy: MutationRoutePolicy,
        request: BrowserMutationRequest,
        *,
        max_bytes: int,
    ) -> BrowserResponse: ...

    async def aclose(self) -> None: ...


class PlaywrightConnector(Protocol):
    async def attach(
        self,
        cdp_endpoint: str,
        *,
        origin: str,
        mode: str,
        mutation_policy: MutationRoutePolicy | None = None,
    ) -> AttachedPage: ...


class CdpAttachedPage:
    """A Playwright page that can only execute the fixed fetch and mutation bridges."""

    def __init__(
        self,
        page: Any,
        browser: Any,
        playwright: Any,
        origin: str,
        *,
        auth_required_at_attach: bool = False,
        mutation_policy: MutationRoutePolicy | None = None,
    ) -> None:
        self._page = page
        self._browser = browser
        self._playwright = playwright
        self._origin = origin
        self._auth_required_at_attach = auth_required_at_attach
        self._mutation_policy = mutation_policy
        self._closed = False

    async def fetch(self, url: str, *, max_bytes: int) -> BrowserResponse:
        if self._auth_required_at_attach:
            raise AuthenticationRequired("Headless reuse reached a login page.")
        if not url.startswith(self._origin):
            raise TransportError("fetch URL is not same-origin")
        try:
            payload = await self._page.evaluate(
                FETCH_BRIDGE_SOURCE,
                {"url": url, "maxBytes": max_bytes},
            )
        except Exception as exc:
            raise TransportError("page-context fetch failed") from exc
        if not isinstance(payload, dict):
            raise TransportError("page-context fetch returned a malformed payload")
        typed_payload = cast(dict[str, object], payload)
        return parse_bridge_payload(typed_payload, origin=self._origin)

    async def mutate(
        self,
        policy: MutationRoutePolicy,
        request: BrowserMutationRequest,
        *,
        max_bytes: int,
    ) -> BrowserResponse:
        if self._mutation_policy is None or policy is not self._mutation_policy:
            raise TransportError("mutation policy is not configured for this session")
        if self._auth_required_at_attach:
            raise AuthenticationRequired("Headless reuse reached a login page.")
        bridge_args = build_mutation_bridge_args(policy, request, max_bytes=max_bytes)
        url = str(bridge_args["url"])
        if not url.startswith(self._origin):
            raise TransportError("mutation URL is not same-origin")
        try:
            payload = await self._page.evaluate(MUTATION_BRIDGE_SOURCE, bridge_args)
        except Exception as exc:
            raise UnknownOutcomeError("page-context mutation failed after dispatch") from exc
        if not isinstance(payload, dict):
            raise UnknownOutcomeError("page-context mutation returned a malformed payload")
        typed_payload = cast(dict[str, object], payload)
        return parse_mutation_bridge_payload(typed_payload, origin=self._origin)

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            await self._page.close()
        finally:
            try:
                await self._browser.close()
            finally:
                await self._playwright.stop()


class CdpPlaywrightConnector:
    """Attach Playwright over CDP. Never launches Playwright Chromium."""

    def __init__(
        self,
        *,
        login_click_selector: str | None = None,
        login_click_timeout_ms: float = _DEFAULT_LOGIN_CLICK_TIMEOUT_MS,
        login_click_attempts: int = 1,
    ) -> None:
        self._login_click_selector = _validated_login_click_selector(login_click_selector)
        if login_click_timeout_ms <= 0 or login_click_timeout_ms > _MAX_LOGIN_CLICK_TIMEOUT_MS:
            raise ConfigurationError(
                "Login click timeout must be greater than zero and at most 30000 milliseconds."
            )
        self._login_click_timeout_ms = login_click_timeout_ms
        if login_click_attempts < 1 or login_click_attempts > _MAX_LOGIN_CLICK_ATTEMPTS:
            raise ConfigurationError("Login click attempts must be between 1 and 3.")
        self._login_click_attempts = login_click_attempts

    async def attach(
        self,
        cdp_endpoint: str,
        *,
        origin: str,
        mode: str,
        mutation_policy: MutationRoutePolicy | None = None,
    ) -> AttachedPage:
        playwright_module = load_optional_module("playwright.async_api")
        manager = playwright_module.async_playwright()
        playwright = await manager.start()
        try:
            browser = await playwright.chromium.connect_over_cdp(cdp_endpoint)
            context = _first_context(browser)
            page, auth_required_at_attach = await _origin_page(
                context,
                origin,
                mode,
                timeout_error=playwright_module.TimeoutError,
                login_click_selector=self._login_click_selector,
                login_click_timeout_ms=self._login_click_timeout_ms,
                login_click_attempts=self._login_click_attempts,
            )
        except BaseException as exc:
            await playwright.stop()
            if isinstance(exc, BrowserSessionError):
                raise
            if isinstance(exc, Exception):
                raise TransportError("Failed to attach Playwright over CDP.") from exc
            raise
        return CdpAttachedPage(
            page,
            browser,
            playwright,
            origin,
            auth_required_at_attach=auth_required_at_attach,
            mutation_policy=mutation_policy,
        )


def _first_context(browser: Any) -> Any:
    contexts = getattr(browser, "contexts", None)
    if contexts:
        return contexts[0]
    raise TransportError("CDP browser has no context.")


async def _origin_page(
    context: Any,
    origin: str,
    mode: str,
    *,
    timeout_error: type[Exception],
    login_click_selector: str | None,
    login_click_timeout_ms: float,
    login_click_attempts: int,
) -> tuple[Any, bool]:
    page = context.pages[0] if context.pages else await context.new_page()
    try:
        response = await page.goto(origin, wait_until="domcontentloaded")
    except Exception as exc:
        raise TransportError("Failed to open the policy origin page.") from exc
    del response
    login_recovery_result = await _click_login_if_configured(
        page,
        origin,
        selector=login_click_selector,
        timeout_ms=login_click_timeout_ms,
        attempts=login_click_attempts,
        timeout_error=timeout_error,
    )
    auth_required_at_attach = False
    if mode == "headless":
        auth_required_at_attach = (
            login_recovery_result
            if login_recovery_result is not None
            else await _login_remains_after_settle(
                page,
                origin,
                timeout_error=timeout_error,
            )
        )
    return page, auth_required_at_attach


async def _click_login_if_configured(
    page: Any,
    origin: str,
    *,
    selector: str | None,
    timeout_ms: float,
    attempts: int,
    timeout_error: type[Exception],
) -> bool | None:
    if selector is None or not _looks_like_login(str(getattr(page, "url", origin)), origin):
        return None
    for attempt in range(attempts):
        try:
            await page.wait_for_timeout(timeout_ms)
            await page.locator(selector).click(timeout=timeout_ms)
        except timeout_error:
            pass
        remains = await _login_remains_after_settle(
            page,
            origin,
            timeout_error=timeout_error,
        )
        if not remains:
            return False
        if attempt + 1 < attempts:
            try:
                await page.goto(origin, wait_until="domcontentloaded")
            except Exception as exc:
                raise TransportError("Failed to reload the policy login page.") from exc
    return True


async def _login_remains_after_settle(
    page: Any,
    origin: str,
    *,
    timeout_error: type[Exception],
) -> bool:
    if not _looks_like_login(str(getattr(page, "url", origin)), origin):
        return False

    def left_login(url: Any) -> bool:
        return not _looks_like_login(str(url), origin)

    with suppress(timeout_error):
        await page.wait_for_url(
            left_login,
            timeout=_HEADLESS_LOGIN_SETTLE_TIMEOUT_MS,
        )
    return _looks_like_login(str(getattr(page, "url", origin)), origin)


def _looks_like_login(url: str, origin: str) -> bool:
    lowered = url.lower()
    return lowered.startswith(origin.lower()) and any(
        marker in lowered for marker in ("/sign-in", "/login", "/authenticate")
    )


def _validated_login_click_selector(selector: str | None) -> str | None:
    if selector is None:
        return None
    normalized = selector.strip()
    if not normalized:
        raise ConfigurationError("Login click selector must be omitted or non-empty.")
    if len(normalized) > _MAX_LOGIN_CLICK_SELECTOR_LENGTH:
        raise ConfigurationError("Login click selector must be at most 256 characters.")
    return normalized
