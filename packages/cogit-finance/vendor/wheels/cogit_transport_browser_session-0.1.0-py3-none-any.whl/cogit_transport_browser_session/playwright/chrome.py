"""Owned ordinary Chrome process started for CDP attach."""

from __future__ import annotations

import asyncio
import socket
from collections.abc import Sequence
from pathlib import Path
from typing import Literal, Protocol

from cogit_transport_browser_session.errors import ConfigurationError, TransportError
from cogit_transport_browser_session.playwright.cdp_readiness import (
    ChromeStderrCollector,
    wait_for_cdp_endpoint,
)

BrowserMode = Literal["headed", "headless"]


class ChromeHandle(Protocol):
    """A started Chrome process that exposes a CDP HTTP endpoint."""

    cdp_endpoint: str

    async def aclose(self) -> None: ...


class ChromeLauncher(Protocol):
    async def start(
        self,
        *,
        executable: Path,
        profile_path: Path,
        mode: BrowserMode,
    ) -> ChromeHandle: ...


class OwnedChromeProcess:
    """Subprocess handle that is terminated during reverse shutdown."""

    def __init__(
        self,
        process: asyncio.subprocess.Process,
        cdp_endpoint: str,
        *,
        stderr_collector: ChromeStderrCollector | None = None,
    ) -> None:
        self._process = process
        self.cdp_endpoint = cdp_endpoint
        self._stderr_collector = stderr_collector
        self._closed = False

    @property
    def stderr_collector(self) -> ChromeStderrCollector | None:
        return self._stderr_collector

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            if self._process.returncode is None:
                self._process.terminate()
                try:
                    await asyncio.wait_for(self._process.wait(), timeout=5.0)
                except TimeoutError:
                    self._process.kill()
                    await self._process.wait()
            else:
                await self._process.wait()
        finally:
            if self._stderr_collector is not None:
                await self._stderr_collector.stop()
                self._stderr_collector = None


class HostChromeLauncher:
    """Start operator-supplied Chrome. Never launches Playwright's Chromium."""

    async def start(
        self,
        *,
        executable: Path,
        profile_path: Path,
        mode: BrowserMode,
    ) -> ChromeHandle:
        if not executable.is_file():
            raise ConfigurationError("Chrome executable does not exist.")
        canonical_profile = profile_path.resolve()
        port = _free_tcp_port()
        command = _chrome_command(executable, canonical_profile, mode, port)
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
        except OSError as exc:
            raise TransportError(f"Failed to start host Chrome: {exc}") from exc
        stderr_collector = ChromeStderrCollector(process, profile_path=canonical_profile)
        stderr_collector.start()
        handle = OwnedChromeProcess(
            process,
            f"http://127.0.0.1:{port}",
            stderr_collector=stderr_collector,
        )
        try:
            await wait_for_cdp_endpoint(
                port,
                process,
                stderr_collector=stderr_collector,
            )
        except BaseException:
            await handle.aclose()
            raise
        return handle


def _chrome_command(
    executable: Path,
    profile_path: Path,
    mode: BrowserMode,
    port: int,
) -> list[str]:
    command = [
        str(executable),
        f"--user-data-dir={profile_path}",
        f"--remote-debugging-port={port}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-sync",
        "--disable-breakpad",
        "--disable-crash-reporter",
        "--disable-dev-shm-usage",
        "--disable-features=Translate,MediaRouter,CalculateNativeWinOcclusion",
    ]
    if mode == "headless":
        command.insert(1, "--headless=new")
    return command


def _free_tcp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def default_chrome_command(
    executable: Path,
    profile_path: Path,
    mode: BrowserMode,
) -> Sequence[str]:
    """Expose the argv used by the default launcher for contract tests."""
    return _chrome_command(executable, profile_path, mode, 0)
