"""Bounded scalar and single-level object-array mutation body policies."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from decimal import Decimal
from enum import StrEnum
from types import MappingProxyType
from typing import TypeAlias, cast

from pydantic import BaseModel, ConfigDict, Field, model_validator

from cogit_transport_browser_session.policy import (
    NAME_PATTERN,
    SENSITIVE_QUERY_NAME_PATTERN,
    validate_uuid,
)

BodyScalar: TypeAlias = str | int | Decimal
BodyValue: TypeAlias = BodyScalar | tuple[Mapping[str, BodyScalar], ...]


class BodyFieldKind(StrEnum):
    """Supported scalar kinds and one bounded level of object arrays."""

    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    UUID = "uuid"
    OBJECT_ARRAY = "object_array"


class BodyFieldPolicy(BaseModel):
    """Bounds for one policy-owned JSON body field."""

    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
    )

    name: str
    kind: BodyFieldKind = BodyFieldKind.STRING
    required: bool = True
    min_length: int = Field(default=1, ge=0, le=2048)
    max_length: int = Field(default=256, ge=1, le=2048)
    min_integer: int | None = None
    max_integer: int | None = None
    allowed_values: tuple[BodyScalar, ...] = ()
    pattern: str | None = None
    object_fields: tuple[BodyFieldPolicy, ...] = ()
    min_items: int = Field(default=1, ge=0, le=100)
    max_items: int = Field(default=1, ge=1, le=100)

    @model_validator(mode="after")
    def _validate_policy(self) -> BodyFieldPolicy:
        if not NAME_PATTERN.fullmatch(self.name):
            raise ValueError("body field name must be a bounded identifier")
        if SENSITIVE_QUERY_NAME_PATTERN.search(self.name):
            raise ValueError("credential-like body field names are forbidden")
        if self.min_length > self.max_length:
            raise ValueError("min_length cannot exceed max_length")
        if (
            self.min_integer is not None
            and self.max_integer is not None
            and self.min_integer > self.max_integer
        ):
            raise ValueError("min_integer cannot exceed max_integer")
        if self.pattern is not None:
            re.compile(self.pattern)
        self._validate_object_policy()
        for value in self.allowed_values:
            self._validate_scalar(value)
        return self

    def _validate_object_policy(self) -> None:
        if self.kind is not BodyFieldKind.OBJECT_ARRAY:
            if self.object_fields or self.min_items != 1 or self.max_items != 1:
                raise ValueError("scalar fields cannot declare object-array constraints")
            return
        if not 1 <= len(self.object_fields) <= 32:
            raise ValueError("object arrays require between 1 and 32 scalar field policies")
        if self.min_items > self.max_items:
            raise ValueError("min_items cannot exceed max_items")
        names = [field.name for field in self.object_fields]
        if len(names) != len(set(names)):
            raise ValueError("object field policies must have unique names")
        if any(field.kind is BodyFieldKind.OBJECT_ARRAY for field in self.object_fields):
            raise ValueError("nested object arrays are forbidden")
        if (
            self.allowed_values
            or self.pattern is not None
            or self.min_integer is not None
            or self.max_integer is not None
        ):
            raise ValueError("object arrays cannot declare scalar constraints")

    def validate_value(self, value: BodyValue) -> BodyValue:
        """Validate one scalar or a bounded tuple of scalar-only mappings."""
        if self.kind is BodyFieldKind.OBJECT_ARRAY:
            return self._validate_object_array(value)
        return self.validate_scalar(value)

    def validate_scalar(self, value: BodyValue) -> BodyScalar:
        """Enforce scalar type, bounds, and allowed values without coercion."""
        if self.kind is BodyFieldKind.OBJECT_ARRAY:
            raise ValueError("nested object arrays are forbidden")
        if not isinstance(value, (str, int, Decimal)):
            raise ValueError(f"body field {self.name!r} requires scalar values")
        self._validate_scalar(value)
        if self.allowed_values and value not in self.allowed_values:
            raise ValueError(f"body field {self.name!r} has a disallowed value")
        return value

    def _validate_object_array(self, value: object) -> tuple[Mapping[str, BodyScalar], ...]:
        if not isinstance(value, tuple):
            raise ValueError(f"body field {self.name!r} requires an object tuple")
        raw_items = cast(tuple[object, ...], value)
        if not self.min_items <= len(raw_items) <= self.max_items:
            raise ValueError(f"body field {self.name!r} is outside its item bounds")
        items: list[Mapping[str, BodyScalar]] = []
        for raw_item in raw_items:
            if not isinstance(raw_item, Mapping):
                raise ValueError(f"body field {self.name!r} requires object items")
            item = cast(Mapping[str, BodyScalar], raw_item)
            _validate_field_names(self.object_fields, item)
            validated = {
                field.name: field.validate_scalar(item[field.name])
                for field in self.object_fields
                if field.name in item
            }
            items.append(MappingProxyType(validated))
        return tuple(items)

    def _validate_scalar(self, value: BodyScalar) -> None:
        if self.kind is BodyFieldKind.STRING:
            self._validate_string(value)
        elif self.kind is BodyFieldKind.INTEGER:
            self._validate_integer(value)
        elif self.kind is BodyFieldKind.NUMBER:
            self._validate_number(value)
        else:
            self._validate_uuid_value(value)

    def _validate_string(self, value: BodyScalar) -> None:
        if not isinstance(value, str):
            raise ValueError(f"body field {self.name!r} requires string values")
        if not self.min_length <= len(value) <= self.max_length:
            raise ValueError(f"body field {self.name!r} is outside its length bounds")
        if self.pattern is not None and re.fullmatch(self.pattern, value) is None:
            raise ValueError(f"body field {self.name!r} does not match its pattern")

    def _validate_integer(self, value: BodyScalar) -> None:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"body field {self.name!r} requires integer values")
        if self.min_integer is not None and value < self.min_integer:
            raise ValueError(f"body field {self.name!r} is below its minimum")
        if self.max_integer is not None and value > self.max_integer:
            raise ValueError(f"body field {self.name!r} is above its maximum")

    def _validate_uuid_value(self, value: BodyScalar) -> None:
        if not isinstance(value, str):
            raise ValueError(f"body field {self.name!r} requires UUID string values")
        validate_uuid(value)

    def _validate_number(self, value: BodyScalar) -> None:
        if not isinstance(value, Decimal) or not value.is_finite():
            raise ValueError(f"body field {self.name!r} requires a finite Decimal")
        # Check representation bounds before formatting, including hostile exponents.
        exponent = value.as_tuple().exponent
        if (
            not isinstance(exponent, int)
            or abs(value.adjusted()) > self.max_length
            or abs(exponent) > self.max_length
        ):
            raise ValueError(f"body field {self.name!r} exceeds numeric bounds")
        self._validate_string(format(value, "f"))


def _validate_field_names(
    fields: tuple[BodyFieldPolicy, ...], body: Mapping[str, BodyValue]
) -> None:
    if any(not isinstance(name, str) for name in cast(Mapping[object, object], body)):
        raise ValueError("body field names must be strings")
    policies = {field.name: field for field in fields}
    unknown = set(body).difference(policies)
    missing = {name for name, policy in policies.items() if policy.required}.difference(body)
    if unknown:
        raise ValueError(f"unknown body fields: {', '.join(sorted(unknown))}")
    if missing:
        raise ValueError(f"missing body fields: {', '.join(sorted(missing))}")


def validate_body_fields(
    fields: tuple[BodyFieldPolicy, ...], body: Mapping[str, BodyValue]
) -> dict[str, BodyValue]:
    """Apply an exact policy allowlist to a body; never accept arbitrary JSON."""
    _validate_field_names(fields, body)
    return {
        field.name: field.validate_value(body[field.name]) for field in fields if field.name in body
    }


def _serialize_scalar(value: BodyScalar) -> str:
    return format(value, "f") if isinstance(value, Decimal) else json.dumps(value)


def _serialize_value(value: BodyValue) -> str:
    if isinstance(value, tuple):
        return (
            "["
            + ",".join(
                "{"
                + ",".join(
                    json.dumps(name) + ":" + _serialize_scalar(scalar)
                    for name, scalar in sorted(item.items())
                )
                + "}"
                for item in value
            )
            + "]"
        )
    return _serialize_scalar(value)


def serialize_json_body(body: Mapping[str, BodyValue]) -> bytes:
    """Encode previously validated values, preserving Decimal number tokens exactly."""
    members = (
        json.dumps(name) + ":" + _serialize_value(value) for name, value in sorted(body.items())
    )
    return ("{" + ",".join(members) + "}").encode("utf-8")
