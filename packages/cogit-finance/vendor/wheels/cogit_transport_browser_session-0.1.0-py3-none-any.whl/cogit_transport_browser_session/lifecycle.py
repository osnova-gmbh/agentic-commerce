"""Bounded, idempotent worker shutdown without atexit hooks."""

from __future__ import annotations

import threading
from collections.abc import Callable

from cogit_transport_browser_session.errors import ShutdownTimeoutError
from cogit_transport_browser_session.locking import ProfileLock


class SessionLifecycle:
    """Join the worker, then release the profile lock only after it stops."""

    def __init__(
        self,
        profile_lock: ProfileLock,
        *,
        join_timeout_seconds: float,
    ) -> None:
        self._profile_lock = profile_lock
        self._join_timeout_seconds = join_timeout_seconds
        self._thread: threading.Thread | None = None
        self._guard = threading.Lock()
        self._closed = False
        self._stopping = False

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def stopping(self) -> bool:
        return self._stopping

    def attach_thread(self, thread: threading.Thread) -> None:
        self._thread = thread

    def begin_stop(self) -> None:
        """Mark an intentional shutdown so worker exit is not treated as a crash."""
        self._stopping = True

    def release_lock(self) -> None:
        """Idempotent profile-lock release for crash, startup failure, or close."""
        self._profile_lock.release()

    def shutdown(self, request_stop: Callable[[], None]) -> None:
        """Stop the worker once. Concurrent callers serialize on a thread lock."""
        with self._guard:
            self._shutdown_locked(request_stop)

    def _shutdown_locked(self, request_stop: Callable[[], None]) -> None:
        if self._closed:
            return
        self.begin_stop()
        request_stop()
        self._join_or_timeout()
        self.release_lock()
        self._closed = True

    def _join_or_timeout(self) -> None:
        thread = self._thread
        if thread is None:
            return
        thread.join(timeout=self._join_timeout_seconds)
        if thread.is_alive():
            raise ShutdownTimeoutError(
                "Browser-session worker did not stop within the join timeout."
            )
