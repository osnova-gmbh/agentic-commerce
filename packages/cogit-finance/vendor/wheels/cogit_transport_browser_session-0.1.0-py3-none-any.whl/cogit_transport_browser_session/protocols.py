"""Loop-neutral async protocols for browser-session consumers and owners."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol, runtime_checkable

from cogit_transport_browser_session.errors import (
    BrowserSessionError,
    map_authentication_error,
    session_state_from_error,
)
from cogit_transport_browser_session.models import (
    BrowserMutationRequest,
    BrowserRequest,
    BrowserResponse,
    SessionState,
)

SessionProbe = Callable[[], Awaitable[BrowserResponse]]
SessionSuccessPredicate = Callable[[BrowserResponse], bool]
LoginHtmlPredicate = Callable[[BrowserResponse], bool]


@runtime_checkable
class BrowserMutationSession(Protocol):
    """Async mutation session with no event-loop ownership requirement."""

    async def mutate(self, request: BrowserMutationRequest) -> BrowserResponse: ...


@runtime_checkable
class BrowserSession(Protocol):
    """Async read session with no event-loop ownership requirement."""

    async def request(self, request: BrowserRequest) -> BrowserResponse: ...

    async def check_session(self) -> SessionState: ...


@runtime_checkable
class CloseableSessionRunner(Protocol):
    """Minimal lifecycle-owning runner contract used by SDK composition."""

    async def request(self, request: BrowserRequest) -> BrowserResponse: ...

    async def mutate(self, request: BrowserMutationRequest) -> BrowserResponse: ...

    async def aclose(self) -> None: ...


@runtime_checkable
class CloseableBrowserSession(
    BrowserSession, BrowserMutationSession, CloseableSessionRunner, Protocol
):
    """A full browser session whose lifecycle is explicitly host-owned."""


async def check_session_state(
    probe: SessionProbe,
    *,
    success_predicate: SessionSuccessPredicate,
    login_html_predicate: LoginHtmlPredicate | None = None,
) -> SessionState:
    """Evaluate a provider-owned probe using deterministic safe outcomes."""
    try:
        response = await probe()
        error = map_authentication_error(response.status_code)
        if error is not None:
            raise error
        if login_html_predicate is not None and login_html_predicate(response):
            login_error = map_authentication_error(
                response.status_code,
                verified_login_html=True,
            )
            if login_error is not None:
                raise login_error
        success = success_predicate(response)
    except BrowserSessionError as error:
        return session_state_from_error(error)
    return SessionState.READY if success is True else SessionState.UNKNOWN
