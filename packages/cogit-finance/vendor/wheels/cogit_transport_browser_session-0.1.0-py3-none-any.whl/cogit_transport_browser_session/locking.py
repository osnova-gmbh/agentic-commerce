"""Cross-process profile locking loaded lazily via importlib."""

from __future__ import annotations

import importlib
import os
import threading
from pathlib import Path
from types import ModuleType
from typing import Any, Protocol, cast

from cogit_transport_browser_session.errors import ConfigurationError, ProfileInUseError

_FILELOCK_REQUIRED = (
    "filelock is required to lock browser profiles; install the [playwright] extra."
)


class _LockHandle(Protocol):
    def acquire(self, timeout: float | None = None) -> bool: ...

    def release(self, force: bool = False) -> None: ...


def canonicalize_profile_path(path: str | Path) -> Path:
    """Expand and resolve an absolute profile path; reject relative paths."""
    expanded = Path(path).expanduser()
    if not expanded.is_absolute():
        raise ConfigurationError("Browser profile path must be an absolute path.")
    return expanded.resolve()


def load_filelock_module() -> ModuleType:
    """Load filelock without a static import so core AST scans stay clean."""
    try:
        return importlib.import_module("filelock")
    except ModuleNotFoundError as exc:
        raise ConfigurationError(_FILELOCK_REQUIRED) from exc


def _timeout_type(module: ModuleType) -> type[BaseException]:
    timeout_cls = getattr(module, "Timeout", None)
    if not isinstance(timeout_cls, type) or not issubclass(timeout_cls, BaseException):
        raise ConfigurationError(_FILELOCK_REQUIRED)
    return timeout_cls


class ProfileLock:
    """Fail-closed exclusive lock stored as a sibling `{canonical}.lock` file."""

    def __init__(self, profile_path: str | Path) -> None:
        self._canonical = canonicalize_profile_path(profile_path)
        self._lock_path = Path(f"{self._canonical}.lock")
        self._handle: _LockHandle | None = None
        self._held = False
        self._state = threading.Lock()

    @property
    def path(self) -> Path:
        return self._canonical

    @property
    def lock_path(self) -> Path:
        return self._lock_path

    @property
    def held(self) -> bool:
        return self._held

    def acquire(self) -> None:
        """Acquire immediately or raise ProfileInUseError. Requires filelock."""
        with self._state:
            if self._held:
                return
            handle = self._new_handle()
            timeout_cls = _timeout_type(load_filelock_module())
            try:
                handle.acquire(timeout=0)
            except timeout_cls as exc:
                raise ProfileInUseError() from exc
            self._handle = handle
            self._held = True

    def release(self) -> None:
        """Release the OS lock. Safe to call more than once."""
        with self._state:
            handle = self._handle
            self._handle = None
            self._held = False
        if handle is not None:
            handle.release()

    def _new_handle(self) -> _LockHandle:
        module: Any = load_filelock_module()
        handle = module.FileLock(str(self._lock_path), timeout=0, thread_local=False)
        return cast(_LockHandle, handle)


class _MultiprocessEvent(Protocol):
    def set(self) -> None: ...

    def wait(self, timeout: float | None = None) -> bool: ...


def hold_profile_lock(
    profile_path: str,
    ready: _MultiprocessEvent,
    hold: _MultiprocessEvent,
) -> None:
    """Acquire a profile lock, signal readiness, then wait until released.

    Module-level so spawn-context process tests can pickle the target.
    """
    lock = ProfileLock(profile_path)
    lock.acquire()
    ready.set()
    hold.wait(timeout=30.0)
    lock.release()


def acquire_profile_lock_and_crash(profile_path: str, ready: _MultiprocessEvent) -> None:
    """Acquire a profile lock, signal readiness, then hard-exit the process."""
    lock = ProfileLock(profile_path)
    lock.acquire()
    ready.set()
    os._exit(1)
