"""Typed browser-session errors with deterministic auth mapping."""

from __future__ import annotations

from enum import StrEnum

from cogit_transport_browser_session._redaction import redact_sensitive_text
from cogit_transport_browser_session.models import SessionState


class BrowserSessionErrorCode(StrEnum):
    """Stable machine-readable error outcomes."""

    AUTHENTICATION_REQUIRED = "authentication_required"
    AUTHORIZATION_DENIED = "authorization_denied"
    CONFLICT = "conflict"
    VALIDATION_REJECTED = "validation_rejected"
    RATE_LIMITED = "rate_limited"
    PROVIDER_SERVER_ERROR = "provider_server_error"
    UNKNOWN_OUTCOME = "unknown_outcome"
    MUTATION_TIMEOUT = "mutation_timeout"
    PROFILE_IN_USE = "profile_in_use"
    RESPONSE_LIMIT_EXCEEDED = "response_limit_exceeded"
    CONFIGURATION = "configuration"
    TRANSPORT = "transport"
    CANCELLED = "cancelled"
    MALFORMED_RESPONSE = "malformed_response"
    SHUTDOWN_TIMEOUT = "shutdown_timeout"


class BrowserSessionError(Exception):
    """Base error that stores only bounded, redacted diagnostic fields."""

    code: BrowserSessionErrorCode
    message: str
    retryable: bool
    status_code: int | None
    request_id: str | None

    def __init__(
        self,
        message: str,
        *,
        code: BrowserSessionErrorCode,
        retryable: bool = False,
        status_code: int | None = None,
        request_id: str | None = None,
    ) -> None:
        safe_message = redact_sensitive_text(message)[:1000]
        safe_request_id = None if request_id is None else redact_sensitive_text(request_id)[:256]
        super().__init__(safe_message)
        self.code = code
        self.message = safe_message
        self.retryable = retryable
        self.status_code = status_code
        self.request_id = safe_request_id

    def __str__(self) -> str:
        parts = [f"{self.code.value}: {self.message}"]
        if self.status_code is not None:
            parts.append(f"status={self.status_code}")
        if self.request_id is not None:
            parts.append(f"request_id={self.request_id}")
        return "; ".join(parts)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(code={self.code!r}, message={self.message!r}, "
            f"retryable={self.retryable!r}, status_code={self.status_code!r}, "
            f"request_id={self.request_id!r})"
        )

    def to_dict(self) -> dict[str, object]:
        """Return only the safe typed error envelope."""
        return {
            "code": self.code.value,
            "message": self.message,
            "retryable": self.retryable,
            "status_code": self.status_code,
            "request_id": self.request_id,
        }


class AuthenticationRequired(BrowserSessionError):
    def __init__(
        self,
        message: str = "The browser session requires authentication.",
        *,
        status_code: int | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.AUTHENTICATION_REQUIRED,
            status_code=status_code,
            request_id=request_id,
        )


class AuthorizationDenied(BrowserSessionError):
    def __init__(
        self,
        message: str = "The browser session is not authorized for this resource.",
        *,
        status_code: int | None = 403,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.AUTHORIZATION_DENIED,
            status_code=status_code,
            request_id=request_id,
        )


class ConflictError(BrowserSessionError):
    def __init__(
        self,
        message: str = "The mutation conflicted with current provider state.",
        *,
        status_code: int | None = 409,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.CONFLICT,
            status_code=status_code,
            request_id=request_id,
        )


class ValidationRejected(BrowserSessionError):
    def __init__(
        self,
        message: str = "The provider rejected the mutation payload.",
        *,
        status_code: int | None = 422,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.VALIDATION_REJECTED,
            status_code=status_code,
            request_id=request_id,
        )


class RateLimitedError(BrowserSessionError):
    def __init__(
        self,
        message: str = "The provider rate-limited the mutation.",
        *,
        status_code: int | None = 429,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.RATE_LIMITED,
            retryable=True,
            status_code=status_code,
            request_id=request_id,
        )


class ProviderServerError(BrowserSessionError):
    def __init__(
        self,
        message: str = "The provider returned a server error for the mutation.",
        *,
        status_code: int | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.PROVIDER_SERVER_ERROR,
            retryable=True,
            status_code=status_code,
            request_id=request_id,
        )


class UnknownOutcomeError(BrowserSessionError):
    def __init__(
        self,
        message: str = "The mutation outcome is unknown after transmission.",
        *,
        status_code: int | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.UNKNOWN_OUTCOME,
            retryable=False,
            status_code=status_code,
            request_id=request_id,
        )


class MutationTimeoutError(BrowserSessionError):
    def __init__(
        self,
        message: str = "The mutation timed out before a definitive response.",
        *,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.UNKNOWN_OUTCOME,
            retryable=False,
            request_id=request_id,
        )


class ProfileInUseError(BrowserSessionError):
    def __init__(self, message: str = "The browser profile is already in use.") -> None:
        super().__init__(message, code=BrowserSessionErrorCode.PROFILE_IN_USE)


class ResponseLimitExceeded(BrowserSessionError):
    limit_bytes: int
    observed_bytes: int | None

    def __init__(
        self,
        *,
        limit_bytes: int,
        observed_bytes: int | None = None,
    ) -> None:
        super().__init__(
            "The browser response exceeded the configured byte limit.",
            code=BrowserSessionErrorCode.RESPONSE_LIMIT_EXCEEDED,
        )
        self.limit_bytes = limit_bytes
        self.observed_bytes = observed_bytes

    def to_dict(self) -> dict[str, object]:
        result = super().to_dict()
        result["limit_bytes"] = self.limit_bytes
        result["observed_bytes"] = self.observed_bytes
        return result


class ConfigurationError(BrowserSessionError):
    def __init__(self, message: str) -> None:
        super().__init__(message, code=BrowserSessionErrorCode.CONFIGURATION)


class TransportError(BrowserSessionError):
    def __init__(
        self,
        message: str,
        *,
        retryable: bool = True,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.TRANSPORT,
            retryable=retryable,
            request_id=request_id,
        )


class CancellationError(BrowserSessionError):
    def __init__(self, message: str = "The browser operation was cancelled.") -> None:
        super().__init__(message, code=BrowserSessionErrorCode.CANCELLED)


class MalformedResponseError(BrowserSessionError):
    def __init__(
        self,
        message: str = "The browser response was malformed.",
        *,
        status_code: int | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.MALFORMED_RESPONSE,
            status_code=status_code,
            request_id=request_id,
        )


class ShutdownTimeoutError(BrowserSessionError):
    def __init__(self, message: str = "Browser-session shutdown timed out.") -> None:
        super().__init__(
            message,
            code=BrowserSessionErrorCode.SHUTDOWN_TIMEOUT,
            retryable=True,
        )


def map_authentication_error(
    status_code: int,
    *,
    verified_login_redirect: bool = False,
    verified_login_html: bool = False,
    request_id: str | None = None,
) -> AuthenticationRequired | AuthorizationDenied | None:
    """Map safe response facts without accepting or retaining a response body."""
    if status_code == 403:
        return AuthorizationDenied(status_code=status_code, request_id=request_id)
    if status_code == 401:
        return AuthenticationRequired(status_code=status_code, request_id=request_id)
    if verified_login_redirect or verified_login_html:
        return AuthenticationRequired(status_code=status_code, request_id=request_id)
    return None


def raise_for_authentication(
    status_code: int,
    *,
    verified_login_redirect: bool = False,
    verified_login_html: bool = False,
    request_id: str | None = None,
) -> None:
    """Raise deterministic typed auth errors from already-verified facts."""
    error = map_authentication_error(
        status_code,
        verified_login_redirect=verified_login_redirect,
        verified_login_html=verified_login_html,
        request_id=request_id,
    )
    if error is not None:
        raise error


def map_mutation_status_error(
    status_code: int,
    *,
    request_id: str | None = None,
) -> BrowserSessionError | None:
    """Map safe mutation response facts without retaining response bodies."""
    auth_error = map_authentication_error(status_code, request_id=request_id)
    if auth_error is not None:
        return auth_error
    if status_code == 409:
        return ConflictError(status_code=status_code, request_id=request_id)
    if status_code == 422:
        return ValidationRejected(status_code=status_code, request_id=request_id)
    if status_code == 429:
        return RateLimitedError(status_code=status_code, request_id=request_id)
    if status_code == 408 or status_code >= 500:
        return UnknownOutcomeError(status_code=status_code, request_id=request_id)
    return None


def raise_for_mutation_status(
    status_code: int,
    *,
    request_id: str | None = None,
) -> None:
    """Raise typed mutation errors from already-verified response facts."""
    error = map_mutation_status_error(status_code, request_id=request_id)
    if error is not None:
        raise error


def session_state_from_error(error: BrowserSessionError) -> SessionState:
    """Convert typed request errors into the public session-state model."""
    if isinstance(error, AuthenticationRequired):
        return SessionState.AUTH_REQUIRED
    if isinstance(error, AuthorizationDenied):
        return SessionState.FORBIDDEN
    return SessionState.UNKNOWN


BrowserSessionConfigurationError = ConfigurationError
BrowserSessionTransportError = TransportError
BrowserSessionCancelledError = CancellationError
